import { ElementRef, EventEmitter, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { ActionService } from '../../services/action/action.service';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import * as i0 from "@angular/core";
export declare class AdminLoginComponent implements OnInit {
    private libService;
    private actionService;
    /**
     * Provides event notifications that fire when login button has been clicked.
     * The event will contain the password value.
     */
    onLoginButtonClicked: EventEmitter<string>;
    /**
     * @internal
     */
    checkingLogged: boolean;
    /**
     * @internal
     */
    secret: string;
    /**
     * @internal
     */
    showSpinner: boolean;
    /**
     * @internal
     */
    loginFormControl: FormControl;
    /**
     * @internal
     */
    matcher: FormErrorStateMatcher;
    /**
     * @internal
     */
    submitBtn: ElementRef;
    /**
     * @internal
     */
    loginForm: ElementRef;
    private errorSub;
    /**
     * @internal
     */
    constructor(libService: OpenViduAngularConfigService, actionService: ActionService);
    /**
     * @internal
     */
    ngOnInit(): void;
    /**
     * @internal
     */
    ngOnDestroy(): void;
    /**
     * @internal
     */
    login(): void;
    /**
     * @internal
     */
    submitForm(): void;
    private subscribeToAdminLoginDirectives;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminLoginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AdminLoginComponent, "ov-admin-login", never, {}, { "onLoginButtonClicked": "onLoginButtonClicked"; }, never, never>;
}
/**
 * @internal
 */
export declare class FormErrorStateMatcher implements ErrorStateMatcher {
    isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean;
}
