import { OnInit, EventEmitter, OnDestroy } from '@angular/core';
import { RecordingInfo } from '../../models/recording.model';
import { ActionService } from '../../services/action/action.service';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import { RecordingService } from '../../services/recording/recording.service';
import * as i0 from "@angular/core";
export declare class AdminDashboardComponent implements OnInit, OnDestroy {
    private actionService;
    private recordingService;
    private libService;
    /**
     * Provides event notifications that fire when delete recording button has been clicked.
     * The recording should be deleted using the REST API.
     * @param recordingId
     */
    onDeleteRecordingClicked: EventEmitter<string>;
    /**
     * Provides event notifications that fire when refresh recordings button has been clicked.
     */
    onRefreshRecordingsClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when logout button has been clicked.
     */
    onLogoutClicked: EventEmitter<void>;
    /**
     * @internal
     */
    recordings: RecordingInfo[];
    /**
     * @internal
     */
    sortDescendent: boolean;
    /**
     * @internal
     */
    sortByLegend: string;
    /**
     * @internal
     */
    searchValue: string;
    private adminSubscription;
    /**
     * @internal
     */
    constructor(actionService: ActionService, recordingService: RecordingService, libService: OpenViduAngularConfigService);
    /**
     * @internal
     */
    ngOnInit(): void;
    /**
     * @internal
     */
    ngOnDestroy(): void;
    /**
     * @internal
     */
    logout(): void;
    /**
     * @internal
     */
    sortRecordingsByDate(): void;
    /**
     * @internal
     */
    sortRecordingsByDuration(): void;
    /**
     * @internal
     */
    sortRecordingsBySize(): void;
    /**
     * @internal
     */
    deleteRecording(recordingId: string): void;
    /**
     * @internal
     */
    download(recording: RecordingInfo): void;
    /**
     * @internal
     */
    refreshRecordings(): void;
    /**
     * @internal
     */
    play(recording: RecordingInfo): Promise<void>;
    private subscribeToAdminDirectives;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminDashboardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AdminDashboardComponent, "ov-admin-dashboard", never, {}, { "onDeleteRecordingClicked": "onDeleteRecordingClicked"; "onRefreshRecordingsClicked": "onRefreshRecordingsClicked"; "onLogoutClicked": "onLogoutClicked"; }, never, never>;
}
