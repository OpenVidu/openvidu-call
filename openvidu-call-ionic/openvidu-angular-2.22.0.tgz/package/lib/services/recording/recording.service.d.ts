import { DomSanitizer } from '@angular/platform-browser';
import { RecordingEvent } from 'openvidu-browser';
import { Observable } from 'rxjs';
import { RecordingInfo, RecordingStatus } from '../../models/recording.model';
import { ActionService } from '../action/action.service';
import * as i0 from "@angular/core";
export declare class RecordingService {
    private actionService;
    private sanitizer;
    /**
     * Recording status Observable which pushes the recording state in every update.
     */
    recordingStatusObs: Observable<{
        info: RecordingInfo;
        time?: Date;
    }>;
    private recordingTime;
    private recordingTimeInterval;
    private currentRecording;
    private recordingStatus;
    private baseUrl;
    /**
     * @internal
     * @param actionService
     * @param sanitizer
     */
    constructor(actionService: ActionService, sanitizer: DomSanitizer);
    /**
     * @internal
     * @param status
     */
    updateStatus(status: RecordingStatus): void;
    /**
     * @internal
     * @param event
     */
    startRecording(event: RecordingEvent): void;
    /**
     * @internal
     * @param event
     */
    stopRecording(event: RecordingEvent): void;
    /**
     * @internal
     * Play the recording blob received as parameter. This parameter must be obtained from backend using the OpenVidu REST API
     */
    playRecording(recording: RecordingInfo): void;
    /**
     * @internal
     * Download the the recording file received .
     * @param recording
     */
    downloadRecording(recording: RecordingInfo): void;
    private startRecordingTime;
    private stopRecordingTime;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RecordingService>;
}
