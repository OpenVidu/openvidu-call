import { ILogService } from '../../models/logger.model';
import { OpenViduAngularConfigService } from '../config/openvidu-angular.config.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class LoggerService implements ILogService {
    private openviduAngularConfigSrv;
    log: any;
    LOG_FNS: any[];
    MSG_PREFIXES: string[][];
    constructor(openviduAngularConfigSrv: OpenViduAngularConfigService);
    private getLoggerFns;
    get(prefix: string): {
        d: (...args: any[]) => void;
        w: (...args: any[]) => void;
        e: (...args: any[]) => void;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerService>;
}
