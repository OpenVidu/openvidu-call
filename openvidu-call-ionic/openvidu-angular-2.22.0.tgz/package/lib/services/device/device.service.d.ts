import { CustomDevice } from '../../models/device.model';
import { OpenViduAngularConfigService } from '../config/openvidu-angular.config.service';
import { LoggerService } from '../logger/logger.service';
import { PlatformService } from '../platform/platform.service';
import { StorageService } from '../storage/storage.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class DeviceService {
    private loggerSrv;
    private platformSrv;
    private storageSrv;
    private libSrv;
    private OV;
    private devices;
    private cameras;
    private microphones;
    private cameraSelected;
    private microphoneSelected;
    private log;
    private videoDevicesDisabled;
    private audioDevicesDisabled;
    private _isVideoMuted;
    private _isAudioMuted;
    private deviceAccessDeniedError;
    constructor(loggerSrv: LoggerService, platformSrv: PlatformService, storageSrv: StorageService, libSrv: OpenViduAngularConfigService);
    /**
     * Initialize media devices and devices selected checking in local storage (if exists) or
     * first devices found by default
     */
    forceInitDevices(): Promise<void>;
    /**
     * Initialize only the media devices available
     */
    initializeDevices(): Promise<void>;
    private initializeCustomDevices;
    private updateAudioDeviceSelected;
    private updateVideoDeviceSelected;
    isVideoMuted(): boolean;
    isAudioMuted(): boolean;
    getCameraSelected(): CustomDevice | null;
    getMicrophoneSelected(): CustomDevice | null;
    setCameraSelected(deviceField: any): void;
    setMicSelected(deviceField: any): void;
    needUpdateVideoTrack(newVideoSource: string): boolean;
    needUpdateAudioTrack(newAudioSource: string): boolean;
    getCameras(): CustomDevice[];
    getMicrophones(): CustomDevice[];
    hasVideoDeviceAvailable(): boolean;
    hasAudioDeviceAvailable(): boolean;
    cameraNeedsMirror(deviceField: string): boolean;
    areEmptyLabels(): boolean;
    disableVideoDevices(): void;
    disableAudioDevices(): void;
    clear(): void;
    private getCameraByDeviceField;
    private getMicrophoneByDeviceField;
    private getMicrophoneFromStogare;
    private getCameraFromStorage;
    private saveCameraToStorage;
    private saveMicrophoneToStorage;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeviceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DeviceService>;
}
