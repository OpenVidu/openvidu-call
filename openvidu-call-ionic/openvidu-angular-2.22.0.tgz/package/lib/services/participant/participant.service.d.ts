import { Publisher, Subscriber } from 'openvidu-browser';
import { BehaviorSubject, Observable } from 'rxjs';
import { ILogger } from '../../models/logger.model';
import { StreamModel, ParticipantAbstractModel, ParticipantProperties } from '../../models/participant.model';
import { VideoType } from '../../models/video-type.model';
import { OpenViduAngularConfigService } from '../config/openvidu-angular.config.service';
import { LoggerService } from '../logger/logger.service';
import * as i0 from "@angular/core";
export declare class ParticipantService {
    protected openviduAngularConfigSrv: OpenViduAngularConfigService;
    protected loggerSrv: LoggerService;
    /**
     * Local participant Observable which pushes the local participant object in every update.
     */
    localParticipantObs: Observable<ParticipantAbstractModel>;
    protected _localParticipant: BehaviorSubject<ParticipantAbstractModel | null>;
    /**
     * Remote participants Observable which pushes the remote participants array in every update.
     */
    remoteParticipantsObs: Observable<ParticipantAbstractModel[]>;
    protected _remoteParticipants: BehaviorSubject<ParticipantAbstractModel[]>;
    protected localParticipant: ParticipantAbstractModel;
    protected remoteParticipants: ParticipantAbstractModel[];
    protected log: ILogger;
    /**
     * @internal
     */
    constructor(openviduAngularConfigSrv: OpenViduAngularConfigService, loggerSrv: LoggerService);
    /**
     * @internal
     */
    initLocalParticipant(props: ParticipantProperties): void;
    getLocalParticipant(): ParticipantAbstractModel;
    /**
     * @internal
     */
    getMyCameraPublisher(): Publisher;
    /**
     * @internal
     */
    setMyCameraPublisher(publisher: Publisher): void;
    /**
     * @internal
     */
    setMyCameraConnectionId(connectionId: string): void;
    /**
     * @internal
     */
    getMyScreenPublisher(): Publisher;
    /**
     * @internal
     */
    setMyScreenPublisher(publisher: Publisher): void;
    /**
     * @internal
     */
    setMyScreenConnectionId(connectionId: string): void;
    /**
     * @internal
     */
    enableWebcamStream(): void;
    /**
     * @internal
     */
    disableWebcamStream(): void;
    /**
     * @internal
     */
    activeMyScreenShare(screenPublisher: Publisher): void;
    /**
     * @internal
     */
    disableScreenStream(): void;
    /**
     * @internal
     */
    setMyNickname(nickname: string): void;
    /**
     * @internal
     */
    getMyNickname(): string;
    getMyRole(): string;
    /**
     * @internal
     */
    toggleMyVideoEnlarged(connectionId: string): void;
    /**
     * @internal
     */
    resetMyStreamsToNormalSize(): void;
    /**
     * @internal
     */
    clear(): void;
    /**
     * @internal
     */
    isMyCameraActive(): boolean;
    isMyVideoActive(): boolean;
    isMyAudioActive(): boolean;
    /**
     * @internal
     */
    isMyScreenActive(): boolean;
    /**
     * @internal
     */
    isOnlyMyCameraActive(): boolean;
    /**
     * @internal
     */
    isOnlyMyScreenActive(): boolean;
    /**
     * @internal
     */
    haveICameraAndScreenActive(): boolean;
    /**
     * @internal
     */
    hasScreenAudioActive(): boolean;
    /**
     * Force to update the local participant object and fire a new {@link localParticipantObs} Observable event.
     */
    updateLocalParticipant(): void;
    /**
     * REMOTE USERS
     */
    /**
     * @internal
     */
    addRemoteConnection(connectionId: string, data: string, subscriber: Subscriber): void;
    getRemoteParticipants(): ParticipantAbstractModel[];
    /**
     * @internal
     */
    resetRemoteStreamsToNormalSize(): void;
    /**
     * @internal
     */
    removeConnectionByConnectionId(connectionId: string): void;
    /**
     * @internal
     */
    getRemoteParticipantByConnectionId(connectionId: string): ParticipantAbstractModel | undefined;
    protected getRemoteParticipantById(id: string): ParticipantAbstractModel | undefined;
    /**
     * @internal
     */
    someoneIsSharingScreen(): boolean;
    /**
     * @internal
     */
    toggleRemoteVideoEnlarged(connectionId: string): void;
    /**
     * @internal
     */
    getNicknameFromConnectionData(data: string): string;
    /**
     * @internal
     */
    setRemoteNickname(connectionId: string, nickname: string): void;
    /**
     * @internal
     */
    setRemoteMutedForcibly(id: string, value: boolean): void;
    /**
     * Force to update the remote participants object and fire a new {@link remoteParticipantsObs} Observable event.
     */
    updateRemoteParticipants(): void;
    protected getTypeConnectionData(data: string): VideoType;
    protected getParticipantIdFromData(data: string): string;
    protected newParticipant(props: ParticipantProperties, streamModel?: StreamModel): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ParticipantService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ParticipantService>;
}
