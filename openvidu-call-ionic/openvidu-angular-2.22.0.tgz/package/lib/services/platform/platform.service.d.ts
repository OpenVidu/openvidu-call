import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class PlatformService {
    constructor();
    isMobile(): boolean;
    isFirefox(): boolean;
    isAndroid(): boolean;
    isIos(): boolean;
    private isIPhoneOrIPad;
    private isSafariIos;
    private isIOSWithSafari;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlatformService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlatformService>;
}
