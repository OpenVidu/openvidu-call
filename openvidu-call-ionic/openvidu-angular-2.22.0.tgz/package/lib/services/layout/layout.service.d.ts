import { Observable } from 'rxjs';
import { OpenViduLayout } from '../../models/layout.model';
import { DocumentService } from '../document/document.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class LayoutService {
    private documentService;
    layoutContainer: HTMLElement | null;
    layoutWidthObs: Observable<number>;
    subtitlesTogglingObs: Observable<boolean>;
    private layoutWidth;
    private openviduLayout;
    private openviduLayoutOptions;
    private subtitlesToggling;
    constructor(documentService: DocumentService);
    initialize(container: HTMLElement): void;
    private getOptions;
    toggleSubtitles(): void;
    update(timeout?: number): void;
    getLayout(): OpenViduLayout;
    clear(): void;
    private sendLayoutWidthEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LayoutService>;
}
