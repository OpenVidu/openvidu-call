import { Connection, OpenVidu, Publisher, PublisherProperties, Session } from 'openvidu-browser';
import { LoggerService } from '../logger/logger.service';
import { ILogger } from '../../models/logger.model';
import { Signal } from '../../models/signal.model';
import { OpenViduAngularConfigService } from '../config/openvidu-angular.config.service';
import { PlatformService } from '../platform/platform.service';
import { DeviceService } from '../device/device.service';
import { VideoType } from '../../models/video-type.model';
import { ParticipantService } from '../participant/participant.service';
import { TokenService } from '../token/token.service';
import { OpenViduEdition } from '../../models/openvidu.model';
import * as i0 from "@angular/core";
export declare class OpenViduService {
    protected openviduAngularConfigSrv: OpenViduAngularConfigService;
    protected platformService: PlatformService;
    protected loggerSrv: LoggerService;
    private participantService;
    protected deviceService: DeviceService;
    protected tokenService: TokenService;
    private ovEdition;
    protected OV: OpenVidu;
    protected OVScreen: OpenVidu;
    protected webcamSession: Session;
    protected screenSession: Session;
    protected videoSource: any;
    protected audioSource: any;
    protected log: ILogger;
    /**
     * @internal
     */
    constructor(openviduAngularConfigSrv: OpenViduAngularConfigService, platformService: PlatformService, loggerSrv: LoggerService, participantService: ParticipantService, deviceService: DeviceService, tokenService: TokenService);
    /**
     * @internal
     */
    initialize(): void;
    /**
     * @internal
     */
    isOpenViduCE(): boolean;
    /**
     * @internal
     */
    setOpenViduEdition(edition: OpenViduEdition): void;
    isSessionConnected(): boolean;
    /**
     * @internal
     */
    clear(): Promise<void>;
    /**
     *
     * Returns the local Session. See {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Session.html  Session} object.
     */
    getSession(): Session;
    /**
     * @internal
     */
    getWebcamSession(): Session;
    /**
     * @internal
     */
    isWebcamSessionConnected(): boolean;
    /**
     * @internal
     */
    getScreenSession(): Session;
    /**
     * @internal
     */
    isScreenSessionConnected(): boolean;
    /**
     * @internal
     */
    connectSession(session: Session, token: string): Promise<void>;
    /**
     * Leaves the session, destroying all local streams and clean all participant data.
     */
    disconnect(): void;
    /**
     * @internal
     * Initialize a publisher checking devices saved on storage or if participant have devices available.
     */
    initDefaultPublisher(): Promise<Publisher>;
    /**
     * @internal
     */
    initPublisher(targetElement: string | HTMLElement, properties: PublisherProperties): Promise<Publisher>;
    /**
     * @internal
     */
    publish(publisher: Publisher): Promise<void>;
    /**
     * @internal
     */
    private unpublish;
    /**
     * Publish or unpublish the video stream (if available).
     * It hides the camera muted stream if screen is sharing.
     * See openvidu-browser {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Publisher.html#publishVideo publishVideo}
     */
    publishVideo(publish: boolean): Promise<void>;
    /**
     * @internal
     */
    private publishVideoAux;
    /**
     * Publish or unpublish the audio stream (if available).
     * See openvidu-browser {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Publisher.html#publishAudio publishAudio}.
     */
    publishAudio(publish: boolean): Promise<void>;
    /**
     * Share or unshare the screen.
     * Hide the camera muted stream when screen is sharing.
     */
    toggleScreenshare(): Promise<void>;
    /**
     * @internal
     */
    private publishAudioAux;
    /**
     * @internal
     */
    sendSignal(type: Signal, connections?: Connection[], data?: any): void;
    /**
     * @internal
     */
    replaceTrack(videoType: VideoType, props: PublisherProperties): Promise<void>;
    private destroyPublisher;
    private createMediaStream;
    /**
     * @internal
     */
    needSendNicknameSignal(): boolean;
    /**
     * @internal
     */
    isMyOwnConnection(connectionId: string): boolean;
    /**
     *
     * Returns the remote connections of the Session.
     * See {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Connection.html  Connection} object.
     */
    getRemoteConnections(): Connection[];
    private disconnectSession;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenViduService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpenViduService>;
}
