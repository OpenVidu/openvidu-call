import { StorageService } from '../storage/storage.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class TranslateService {
    private storageService;
    private availableLanguages;
    private langTitles;
    private currentLang;
    langSelected: {
        name: string;
        ISO: string;
    };
    constructor(storageService: StorageService);
    setLanguage(lang: string): void;
    getLangSelected(): {
        name: string;
        ISO: string;
    };
    getLanguagesInfo(): {
        name: string;
        ISO: string;
    }[];
    translate(key: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateService>;
}
