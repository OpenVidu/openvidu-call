import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { INotificationOptions } from '../../models/notification-options.model';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class ActionService {
    private snackBar;
    dialog: MatDialog;
    private dialogRef;
    private dialogSubscription;
    constructor(snackBar: MatSnackBar, dialog: MatDialog);
    launchNotification(options: INotificationOptions, callback: any): void;
    openDialog(titleMessage: string, descriptionMessage: string, allowClose?: boolean): void;
    openDeleteRecordingDialog(succsessCallback: any): void;
    openRecordingPlayerDialog(src: string, allowClose?: boolean): void;
    closeDialog(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ActionService>;
}
