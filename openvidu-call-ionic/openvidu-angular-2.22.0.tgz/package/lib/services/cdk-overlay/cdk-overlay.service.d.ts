import { CdkOverlayContainer } from '../../config/custom-cdk-overlay';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class CdkOverlayService {
    private cdkOverlayModel;
    constructor(cdkOverlayModel: CdkOverlayContainer);
    setSelector(selector: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdkOverlayService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdkOverlayService>;
}
