import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { ILogger } from '../../models/logger.model';
import { ChatMessage } from '../../models/chat.model';
import { INotificationOptions } from '../../models/notification-options.model';
import { ActionService } from '../action/action.service';
import { OpenViduService } from '../openvidu/openvidu.service';
import { LoggerService } from '../logger/logger.service';
import { PanelService } from '../panel/panel.service';
import { ParticipantService } from '../participant/participant.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class ChatService {
    protected loggerSrv: LoggerService;
    protected openviduService: OpenViduService;
    protected participantService: ParticipantService;
    protected panelService: PanelService;
    protected actionService: ActionService;
    messagesObs: Observable<ChatMessage[]>;
    private messageSound;
    protected _messageList: BehaviorSubject<ChatMessage[]>;
    protected messageList: ChatMessage[];
    protected log: ILogger;
    constructor(loggerSrv: LoggerService, openviduService: OpenViduService, participantService: ParticipantService, panelService: PanelService, actionService: ActionService);
    subscribeToChat(): void;
    sendMessage(message: string): void;
    protected launchNotification(options: INotificationOptions): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ChatService>;
}
