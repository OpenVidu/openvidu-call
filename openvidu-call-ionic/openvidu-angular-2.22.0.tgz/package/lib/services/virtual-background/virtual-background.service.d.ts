import { BehaviorSubject, Observable } from 'rxjs';
import { BackgroundEffect } from '../../models/background-effect.model';
import { ParticipantService } from '../participant/participant.service';
import { TokenService } from '../token/token.service';
import { TranslateService } from '../translate/translate.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class VirtualBackgroundService {
    private participantService;
    private translateService;
    private tokenService;
    backgroundSelected: BehaviorSubject<string>;
    backgroundSelectedObs: Observable<string>;
    backgrounds: BackgroundEffect[];
    constructor(participantService: ParticipantService, translateService: TranslateService, tokenService: TokenService);
    getBackgrounds(): any[];
    isBackgroundApplied(): boolean;
    applyBackground(effect: BackgroundEffect): Promise<void>;
    removeBackground(): Promise<void>;
    private replaceBackground;
    private hasSameTypeAsAbove;
    static ɵfac: i0.ɵɵFactoryDeclaration<VirtualBackgroundService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VirtualBackgroundService>;
}
