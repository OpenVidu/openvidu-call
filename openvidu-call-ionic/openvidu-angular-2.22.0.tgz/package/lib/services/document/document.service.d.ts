import { MediaChange, MediaObserver } from '@angular/flex-layout';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class DocumentService {
    private media;
    screenSizeObs: Observable<MediaChange[]>;
    constructor(media: MediaObserver);
    getHTMLElementByClassName(element: HTMLElement, className: string): HTMLElement;
    toggleFullscreen(elementId: string): void;
    isSmallElement(element: HTMLElement | Element): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentService>;
}
