import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class TokenService {
    private webcamToken;
    private screenToken;
    constructor();
    setWebcamToken(token: string): void;
    setScreenToken(token: string): void;
    getWebcamToken(): string;
    getScreenToken(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TokenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TokenService>;
}
