import { BehaviorSubject, Observable } from 'rxjs';
import { ILogger } from '../../models/logger.model';
import { PanelSettingsOptions, PanelType } from '../../models/panel.model';
import { LoggerService } from '../logger/logger.service';
import * as i0 from "@angular/core";
export interface PanelEvent {
    opened: boolean;
    type?: PanelType | string;
    expand?: string;
    oldType?: PanelType | string;
}
export declare class PanelService {
    protected loggerSrv: LoggerService;
    /**
     * Panel Observable which pushes the panel status in every update.
     */
    panelOpenedObs: Observable<PanelEvent>;
    protected log: ILogger;
    private isExternalOpened;
    private externalType;
    protected _panelOpened: BehaviorSubject<PanelEvent>;
    private panelMap;
    /**
     * @internal
     */
    constructor(loggerSrv: LoggerService);
    /**
     * Open or close the panel type received. Calling this method with the panel opened and the same type panel, will close the panel.
     * If the type is differente, it will switch to the properly panel.
     */
    togglePanel(type: PanelType | string, expand?: PanelSettingsOptions | string): void;
    /**
     * @internal
     */
    isPanelOpened(): boolean;
    /**
     * Closes the panel (if opened)
     */
    closePanel(): void;
    /**
     * Whether the chat panel is opened or not.
     */
    isChatPanelOpened(): boolean;
    /**
     * Whether the participants panel is opened or not.
     */
    isParticipantsPanelOpened(): boolean;
    /**
     * Whether the activities panel is opened or not.
     */
    isActivitiesPanelOpened(): boolean;
    /**
     * Whether the settings panel is opened or not.
     */
    isSettingsPanelOpened(): boolean;
    /**
     * Whether the background effects panel is opened or not.
     */
    isBackgroundEffectsPanelOpened(): boolean;
    isExternalPanelOpened(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PanelService>;
}
