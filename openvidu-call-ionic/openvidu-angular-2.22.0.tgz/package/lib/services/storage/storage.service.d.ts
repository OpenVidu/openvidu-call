import { ILogger } from '../../models/logger.model';
import { LoggerService } from '../logger/logger.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class StorageService {
    private loggerSrv;
    storage: globalThis.Storage;
    log: ILogger;
    constructor(loggerSrv: LoggerService);
    getNickname(): string;
    setNickname(name: string): void;
    getVideoDevice(): any;
    setVideoDevice(device: any): void;
    getAudioDevice(): any;
    setAudioDevice(device: any): void;
    isVideoMuted(): boolean;
    setVideoMuted(muted: boolean): void;
    isAudioMuted(): boolean;
    setAudioMuted(muted: boolean): void;
    setLang(lang: string): void;
    getLang(): string;
    private set;
    private get;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StorageService>;
}
