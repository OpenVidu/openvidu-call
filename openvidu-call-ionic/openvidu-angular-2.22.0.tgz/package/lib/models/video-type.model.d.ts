export declare enum VideoType {
    CAMERA = "CAMERA",
    SCREEN = "SCREEN",
    CUSTOM = "CUSTOM"
}
/**
 * @internal
 */
export declare enum ScreenType {
    WINDOW = "window",
    SCREEN = "screen"
}
