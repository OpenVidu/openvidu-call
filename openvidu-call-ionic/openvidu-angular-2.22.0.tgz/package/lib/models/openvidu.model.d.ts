/**
 * @internal
 */
export declare enum OpenViduEdition {
    CE = "CE",
    PRO = "PRO",
    ENTERPRISE = "ENTERPRISE"
}
