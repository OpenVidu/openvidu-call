/**
 * @internal
 */
export interface CustomDevice {
    label: string;
    device: string;
    type?: CameraType;
}
/**
 * @internal
 */
export declare enum CameraType {
    FRONT = "FRONT",
    BACK = "BACK"
}
/**
 * @internal
 */
export declare enum DeviceType {
    AUDIO_INPUT = "audioinput",
    VIDEO_INPUT = "videoinput"
}
