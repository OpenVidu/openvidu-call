/**
 * @internal
 */
export declare enum Storage {
    USER_NICKNAME = "openviduCallNickname",
    VIDEO_DEVICE = "openviduCallVideoDevice",
    AUDIO_DEVICE = "openviduCallAudioDevice",
    AUDIO_MUTED = "openviduCallAudioMuted",
    VIDEO_MUTED = "openviduCallVideoMuted",
    LANG = "openviduCallLang"
}
