/**
 * @internal
 */
export declare enum VideoSizeIcon {
    BIG = "zoom_in",
    NORMAL = "zoom_out"
}
