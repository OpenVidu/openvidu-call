/**
 * @internal
 */
export declare enum LayoutClass {
    ROOT_ELEMENT = "OT_root",
    BIG_ELEMENT = "OV_big",
    SMALL_ELEMENT = "OV_small",
    IGNORED_ELEMENT = "OV_ignored",
    SIDENAV_CONTAINER = "sidenav-container",
    NO_SIZE_ELEMENT = "no-size",
    CLASS_NAME = "layout"
}
/**
 * @internal
 */
export declare enum SidenavMode {
    OVER = "over",
    SIDE = "side"
}
export declare enum LayoutAlignment {
    START = "start",
    CENTER = "center",
    END = "end"
}
/**
 * @internal
 */
export interface OpenViduLayoutOptions {
    /**
     * The narrowest ratio that will be used (*2x3* by default)
     */
    maxRatio: number;
    /**
     * The widest ratio that will be used (*16x9* by default)
     */
    minRatio: number;
    /**
     * If this is true then the aspect ratio of the video is maintained and minRatio and maxRatio are ignored (*false* by default)
     */
    fixedRatio: boolean;
    /**
     * Whether you want to animate the transitions
     */
    animate: any;
    /**
     * The class to add to elements that should be sized bigger
     */
    bigClass: string;
    /**
     * The class to add to elements that should be sized smaller
     */
    smallClass: string;
    /**
     * The class to add to elements that should be ignored
     */
    ignoredClass: string;
    /**
     * The maximum percentage of space the big ones should take up
     */
    bigPercentage: any;
    /**
     * If this is set then it will scale down the big space if there is left over whitespace down to this minimum size
     */
    minBigPercentage: number;
    /**
     * FixedRatio for the big ones
     */
    bigFixedRatio: any;
    /**
     * The narrowest ratio to use for the big elements (*2x3* by default)
     */
    bigMaxRatio: any;
    /**
     * The widest ratio to use for the big elements (*16x9* by default)
     */
    bigMinRatio: any;
    /**
     * Whether to place the big one in the top left `true` or bottom right
     */
    bigFirst: boolean | 'column' | 'row';
    /**
     *
     */
    alignItems: LayoutAlignment;
    /**
     *
     */
    bigAlignItems: LayoutAlignment;
    /**
     *
     */
    smallAlignItems: LayoutAlignment;
    /**
     *  The maximum width of the elements
     */
    maxWidth: number;
    /**
     * The maximum height of the elements
     */
    maxHeight: number;
    smallMaxWidth: number;
    smallMaxHeight: number;
    bigMaxWidth: number;
    bigMaxHeight: number;
    /**
     *  If there are less elements on the last row then we can scale them up to take up more space
     */
    scaleLastRow?: boolean;
    /**
     * Scale last row for the big elements
     */
    bigScaleLastRow?: boolean;
}
/**
 * @internal
 */
export declare class OpenViduLayout {
    /**
     * @hidden
     */
    private layoutContainer;
    /**
     * @hidden
     */
    private opts;
    /**
     * Update the layout container
     * module export layout
     */
    updateLayout(container: HTMLElement, opts: any): void;
    /**
     * Initialize the layout inside of the container with the options required
     * @param container
     * @param opts
     */
    initLayoutContainer(container: HTMLElement, opts: OpenViduLayoutOptions): void;
    getLayoutContainer(): HTMLElement;
    /**
     * Set the layout configuration
     * @param options
     */
    private css;
    private height;
    private width;
    private defaults;
    /**
     * @hidden
     */
    private fixAspectRatio;
    /**
     * @hidden
     */
    private positionElement;
    /**
     * @hidden
     */
    private getChildDims;
    /**
     * @hidden
     */
    private getCSSNumber;
    /**
     * @hidden
     */
    private cheapUUID;
    /**
     * @hidden
     */
    private getHeight;
    /**
     * @hidden
     */
    private getWidth;
    /**
     * @hidden
     */
    /**
     * @hidden
     */
    /**
     * @hidden
     */
    /**
     * @hidden
     */
    /**
     * @hidden
     */
    /**
     * @hidden
     */
    /**
     * @hidden
     */
    private filterDisplayNone;
    /**
     *
     * --------------------------------------------------------------------------------
     *
     * GET LAYOUT
     *
     *
     */
    /**
     * @hidden
     */
    private getBestDimensions;
    private getVideoRatio;
    private getLayout;
    private getLayoutAux;
}
