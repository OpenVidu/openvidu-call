import { Publisher, StreamManager } from 'openvidu-browser';
import { VideoType } from './video-type.model';
/**
 * @internal
 */
export declare enum OpenViduRole {
    MODERATOR = "MODERATOR",
    PUBLISHER = "PUBLISHER"
}
export interface StreamModel {
    /**
     * Whether the stream is available or not
     */
    connected: boolean;
    /**
     * The stream type.{@link VideoType}
     */
    type: VideoType;
    /**
     * The streamManager object from openvidu-browser library.{@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/StreamManager.html}
     */
    streamManager: StreamManager;
    /**
     * Whether the stream is enlarged or not
     */
    videoEnlarged: boolean;
    /**
     * Unique identifier of the stream
     */
    connectionId: string;
    /**
     * The participant object
     */
    participant?: ParticipantAbstractModel;
}
export interface ParticipantProperties {
    /**
     * Whether the participant is local or not
     */
    local: boolean;
    /**
     * The participant nickname
     */
    nickname: string;
    /**
     * Unique identifier of the participant
     */
    id?: string;
    /**
     * The participant color profile
     */
    colorProfile?: string;
    /**
     * Whether the participant is muted forcibly or not
     */
    isMutedForcibly?: boolean;
}
export declare abstract class ParticipantAbstractModel {
    streams: Map<VideoType, StreamModel>;
    id: string;
    local: boolean;
    nickname: string;
    colorProfile: string;
    isMutedForcibly: boolean;
    constructor(props: ParticipantProperties, model?: StreamModel);
    /**
     * @internal
     */
    addConnection(streamModel: StreamModel): void;
    /**
     * @internal
     */
    hasAudioActive(): boolean;
    /**
     * @internal
     */
    private isCameraAudioActive;
    /**
     * @internal
     */
    isCameraVideoActive(): boolean;
    /**
     * @internal
     */
    isScreenAudioActive(): boolean;
    /**
     * @internal
     */
    hasConnectionType(type: VideoType): boolean;
    /**
     * @internal
     */
    getCameraConnection(): StreamModel;
    /**
     * @internal
     */
    getScreenConnection(): StreamModel;
    /**
     * @internal
     */
    getConnectionTypesActive(): VideoType[];
    /**
     * @internal
     */
    setCameraConnectionId(connectionId: string): void;
    /**
     * @internal
     */
    setScreenConnectionId(connectionId: string): void;
    /**
     * @internal
     */
    removeConnection(connectionId: string): StreamModel;
    /**
     * @internal
     */
    hasConnectionId(connectionId: string): boolean;
    /**
     * @internal
     */
    getConnectionById(connectionId: string): StreamModel;
    /**
     * @internal
     */
    getAvailableConnections(): StreamModel[];
    /**
     * @internal
     */
    isLocal(): boolean;
    /**
     * @internal
     */
    setNickname(nickname: string): void;
    /**
     * @internal
     */
    getNickname(): string;
    /**
     * @internal
     */
    setCameraPublisher(publisher: Publisher): void;
    /**
     * @internal
     */
    setScreenPublisher(publisher: Publisher): void;
    /**
     * @internal
     */
    setPublisher(connType: VideoType, publisher: StreamManager): void;
    /**
     * @internal
     */
    isCameraActive(): boolean;
    /**
     * @internal
     */
    enableCamera(): void;
    /**
     * @internal
     */
    disableCamera(): void;
    /**
     * @internal
     */
    isScreenActive(): boolean;
    /**
     * @internal
     */
    enableScreen(): void;
    /**
     * @internal
     */
    disableScreen(): void;
    /**
     * @internal
     */
    setAllVideoEnlarged(enlarged: boolean): void;
    /**
     * @internal
     */
    setCameraEnlarged(enlarged: boolean): void;
    /**
     * @internal
     */
    setScreenEnlarged(enlarged: boolean): void;
    /**
     * @internal
     */
    toggleVideoEnlarged(connectionId: string): void;
    /**
     * @internal
     */
    someHasVideoEnlarged(): boolean;
    /**
     * @internal
     */
    setMutedForcibly(muted: boolean): void;
    /**
     * @internal
     */
    getRole(): OpenViduRole;
}
/**
 * @internal
 */
export declare class ParticipantModel extends ParticipantAbstractModel {
}
