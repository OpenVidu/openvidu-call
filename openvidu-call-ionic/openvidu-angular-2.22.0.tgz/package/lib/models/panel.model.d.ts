export declare enum PanelType {
    CHAT = "chat",
    PARTICIPANTS = "participants",
    BACKGROUND_EFFECTS = "background-effects",
    ACTIVITIES = "activities",
    SETTINGS = "settings"
}
export declare enum PanelSettingsOptions {
    GENERAL = "general",
    AUDIO = "audio",
    VIDEO = "video",
    SUBTITLES = "subtitles"
}
