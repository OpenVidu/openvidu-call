/**
 * @internal
 */
export declare class Linkifier {
    private autolinker;
    constructor();
    link(textOrHtml: string): string;
}
