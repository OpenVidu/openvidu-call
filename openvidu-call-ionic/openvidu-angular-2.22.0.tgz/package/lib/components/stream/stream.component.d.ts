import { ElementRef, OnInit } from '@angular/core';
import { MatMenuPanel, MatMenuTrigger } from '@angular/material/menu';
import { VideoSizeIcon } from '../../models/icon.model';
import { VideoType } from '../../models/video-type.model';
import { CdkOverlayService } from '../../services/cdk-overlay/cdk-overlay.service';
import { OpenViduService } from '../../services/openvidu/openvidu.service';
import { LayoutService } from '../../services/layout/layout.service';
import { StorageService } from '../../services/storage/storage.service';
import { StreamModel } from '../../models/participant.model';
import { ParticipantService } from '../../services/participant/participant.service';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import * as i0 from "@angular/core";
/**
 * The **StreamComponent** is hosted inside of the {@link LayoutComponent}.
 * It is in charge of displaying the participant video stream in the videoconference layout.
 *
 * <div class="custom-table-container">
 * <div>
 *  <h3>API Directives</h3>
 *
 * This component allows us to show or hide certain HTML elements with the following {@link https://angular.io/guide/attribute-directives Angular attribute directives}
 * with the aim of fully customizing the StreamComponent.
 *
 * | **Parameter**                  | **Type**  | **Reference**                                   |
 * | :----------------------------: | :-------: | :---------------------------------------------: |
 * | **displayParticipantName**   | `boolean` | {@link StreamDisplayParticipantNameDirective}   |
 * | **displayAudioDetection**    | `boolean` | {@link StreamDisplayAudioDetectionDirective}    |
 * | **settingsButton**          | `boolean` | {@link StreamSettingsButtonDirective}           |
 *
 * <p class="component-link-text">
 * <span class="italic">See all {@link ApiDirectiveModule API Directives}</span>
 * </p>
 * </div>
 *
 * <div>
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The StreamComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovStream**           |            {@link StreamDirective}           |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 *
 * </div>
 */
export declare class StreamComponent implements OnInit {
    protected openviduService: OpenViduService;
    protected layoutService: LayoutService;
    protected participantService: ParticipantService;
    protected storageService: StorageService;
    protected cdkSrv: CdkOverlayService;
    private libService;
    /**
     * @ignore
     */
    menuTrigger: MatMenuTrigger;
    /**
     * @ignore
     */
    menu: MatMenuPanel;
    /**
     * @ignore
     */
    videoSizeIconEnum: typeof VideoSizeIcon;
    /**
     * @ignore
     */
    videoTypeEnum: typeof VideoType;
    /**
     * @ignore
     */
    videoSizeIcon: VideoSizeIcon;
    /**
     * @ignore
     */
    toggleNickname: boolean;
    /**
     * @ignore
     */
    _stream: StreamModel;
    /**
     * @ignore
     */
    nickname: string;
    /**
     * @ignore
     */
    isMinimal: boolean;
    /**
     * @ignore
     */
    showNickname: boolean;
    /**
     * @ignore
     */
    showAudioDetection: boolean;
    /**
     * @ignore
     */
    showSettingsButton: boolean;
    showVideo: boolean;
    /**
     * @ignore
     */
    set streamContainer(streamContainer: ElementRef);
    set stream(stream: StreamModel);
    /**
     * @ignore
     */
    set nicknameInputElement(element: ElementRef);
    private _streamContainer;
    private minimalSub;
    private displayParticipantNameSub;
    private displayAudioDetectionSub;
    private settingsButtonSub;
    /**
     * @ignore
     */
    constructor(openviduService: OpenViduService, layoutService: LayoutService, participantService: ParticipantService, storageService: StorageService, cdkSrv: CdkOverlayService, libService: OpenViduAngularConfigService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    toggleVideoEnlarged(): void;
    /**
     * @ignore
     */
    toggleVideoMenu(event: any): void;
    /**
     * @ignore
     */
    toggleMuteForcibly(): void;
    /**
     * @ignore
     */
    toggleNicknameForm(): void;
    /**
     * @ignore
     */
    updateNickname(event: any): void;
    /**
     * @ignore
     */
    replaceScreenTrack(): Promise<void>;
    private checkVideoEnlarged;
    private subscribeToStreamDirectives;
    static ɵfac: i0.ɵɵFactoryDeclaration<StreamComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StreamComponent, "ov-stream", never, { "stream": "stream"; }, {}, never, never>;
}
