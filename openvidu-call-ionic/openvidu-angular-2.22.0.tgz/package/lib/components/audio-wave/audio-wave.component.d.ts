import { OnDestroy, OnInit } from '@angular/core';
import { StreamManager } from 'openvidu-browser';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class AudioWaveComponent implements OnInit, OnDestroy {
    isSpeaking: boolean;
    streamManager: StreamManager;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    private subscribeSpeakingEvents;
    private unsubscribeSpeakingEvents;
    static ɵfac: i0.ɵɵFactoryDeclaration<AudioWaveComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AudioWaveComponent, "ov-audio-wave", never, { "streamManager": "streamManager"; }, {}, never, never>;
}
