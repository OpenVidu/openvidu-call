import { AfterViewInit, EventEmitter, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { Session } from 'openvidu-browser';
import { ChatPanelDirective, LayoutDirective, AdditionalPanelsDirective, PanelDirective, ParticipantPanelItemDirective, ParticipantPanelItemElementsDirective, ParticipantsPanelDirective, StreamDirective, ToolbarAdditionalButtonsDirective, ToolbarAdditionalPanelButtonsDirective, ToolbarDirective, ActivitiesPanelDirective } from '../../directives/template/openvidu-angular.directive';
import { ParticipantAbstractModel } from '../../models/participant.model';
import { TokenModel } from '../../models/token.model';
import { ActionService } from '../../services/action/action.service';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import { DeviceService } from '../../services/device/device.service';
import { LoggerService } from '../../services/logger/logger.service';
import { OpenViduService } from '../../services/openvidu/openvidu.service';
import { ParticipantService } from '../../services/participant/participant.service';
import { StorageService } from '../../services/storage/storage.service';
import { TokenService } from '../../services/token/token.service';
import { TranslateService } from '../../services/translate/translate.service';
import * as i0 from "@angular/core";
/**
 * The **VideoconferenceComponent** is the parent of all OpenVidu components.
 * It allow us to create a modern, useful and powerful videoconference apps with ease.
 *
 * <div class="custom-table-container">
 * <div>
 *  <h3>API Directives</h3>
 *
 * This component allows us to show or hide certain HTML elements with the following {@link https://angular.io/guide/attribute-directives Angular attribute directives}
 * with the aim of fully customizing the videoconference application.
 *
 * | **Parameter**                  | **Type**  | **Reference**                                   |
 * | :----------------------------: | :-------: | :---------------------------------------------: |
 * | **minimal**                        | `boolean` | {@link MinimalDirective}                        |
 * | **lang**                           | `string`  | {@link LangDirective}                           |
 * | **prejoin**                        | `boolean` | {@link PrejoinDirective}                        |
 * | **participantName**                | `string`  | {@link ParticipantNameDirective}                |
 * | **videoMuted**                     | `boolean` | {@link VideoMutedDirective}                     |
 * | **audioMuted**                     | `boolean` | {@link AudioMutedDirective}                     |
 * | **toolbarScreenshareButton**       | `boolean` | {@link ToolbarScreenshareButtonDirective}       |
 * | **toolbarFullscreenButton**        | `boolean` | {@link ToolbarFullscreenButtonDirective}        |
 * | **toolbarBackgroundEffectsButton** | `boolean` | {@link ToolbarBackgroundEffectsButtonDirective} |
 * | **toolbarLeaveButton**             | `boolean` | {@link ToolbarLeaveButtonDirective}             |
 * | **toolbarChatPanelButton**         | `boolean` | {@link ToolbarChatPanelButtonDirective}         |
 * | **toolbarParticipantsPanelButton** | `boolean` | {@link ToolbarParticipantsPanelButtonDirective} |
 * | **toolbarDisplayLogo**             | `boolean` | {@link ToolbarDisplayLogoDirective}             |
 * | **toolbarDisplaySessionName**      | `boolean` | {@link ToolbarDisplaySessionNameDirective}      |
 * | **streamDisplayParticipantName**   | `boolean` | {@link StreamDisplayParticipantNameDirective}   |
 * | **streamDisplayAudioDetection**    | `boolean` | {@link StreamDisplayAudioDetectionDirective}    |
 * | **streamSettingsButton**           | `boolean` | {@link StreamSettingsButtonDirective}           |
 * | **participantPanelItemMuteButton** | `boolean` | {@link ParticipantPanelItemMuteButtonDirective} |
 * | **recordingActivityRecordingList** | `{@link RecordingInfo}[]` | {@link RecordingActivityRecordingListDirective} |
 *
 * <p class="component-link-text">
 * <span class="italic">See all {@link ApiDirectiveModule API Directives}</span>
 * </p>
 * </div>
 *
 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 *
 * The VideoconferenceComponent is also providing us a way to **replace the default templates** with a custom one.
 * It will recognise the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * in the elements added as children.
 *
 * |             **Directive**           |                 **Reference**                 |
 * |:-----------------------------------:|:---------------------------------------------:|
 * |            ***ovToolbar**           |            {@link ToolbarDirective}           |
 * |   ***ovToolbarAdditionalButtons**   |   {@link ToolbarAdditionalButtonsDirective}   |
 * |***ovToolbarAdditionalPanelButtons**   |   {@link ToolbarAdditionalPanelButtonsDirective}   |
 * |             ***ovPanel**            |             {@link PanelDirective}            |
 * |        ***ovAdditionalPanels**      |       {@link AdditionalPanelsDirective}       |
 * |           ***ovChatPanel**          |           {@link ChatPanelDirective}          |
 * |       ***ovParticipantsPanel**      |       {@link ParticipantsPanelDirective}      |
 * |     ***ovParticipantPanelItem**     |     {@link ParticipantPanelItemDirective}     |
 * | ***ovParticipantPanelItemElements** | {@link ParticipantPanelItemElementsDirective} |
 * |            ***ovLayout**            |            {@link LayoutDirective}            |
 * |            ***ovStream**            |            {@link StreamDirective}            |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
export declare class VideoconferenceComponent implements OnInit, OnDestroy, AfterViewInit {
    private loggerSrv;
    private storageSrv;
    private participantService;
    private deviceSrv;
    private openviduService;
    private actionService;
    private libService;
    private tokenService;
    private translateService;
    /**
     * @internal
     */
    externalToolbar: ToolbarDirective;
    /**
     * @internal
     */
    externalToolbarAdditionalButtons: ToolbarAdditionalButtonsDirective;
    /**
     * @internal
     */
    externalToolbarAdditionalPanelButtons: ToolbarAdditionalPanelButtonsDirective;
    /**
     * @internal
     */
    externalAdditionalPanels: AdditionalPanelsDirective;
    /**
     * @internal
     */
    externalPanel: PanelDirective;
    /**
     * @internal
     */
    externalChatPanel: ChatPanelDirective;
    /**
     * @internal
     */
    externalActivitiesPanel: ActivitiesPanelDirective;
    /**
     * @internal
     */
    externalParticipantsPanel: ParticipantsPanelDirective;
    /**
     * @internal
     */
    externalParticipantPanelItem: ParticipantPanelItemDirective;
    /**
     * @internal
     */
    externalParticipantPanelItemElements: ParticipantPanelItemElementsDirective;
    /**
     * @internal
     */
    externalLayout: LayoutDirective;
    /**
     * @internal
     */
    externalStream: StreamDirective;
    /**
     * @internal
     */
    defaultToolbarTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    defaultPanelTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    defaultChatPanelTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    defaultParticipantsPanelTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    defaultActivitiesPanelTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    defaultParticipantPanelItemTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    defaultLayoutTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    defaultStreamTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularToolbarTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularToolbarAdditionalButtonsTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularActivitiesPanelTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularToolbarAdditionalPanelButtonsTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularPanelTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularChatPanelTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularParticipantsPanelTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularAdditionalPanelsTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularParticipantPanelItemTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularParticipantPanelItemElementsTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularLayoutTemplate: TemplateRef<any>;
    /**
     * @internal
     */
    openviduAngularStreamTemplate: TemplateRef<any>;
    /**
     * @param {TokenModel} tokens  The tokens parameter must be an object with `webcam` and `screen` fields.
     *  Both of them are `string` type. See {@link TokenModel}
     */
    set tokens(tokens: TokenModel);
    /**
     * Provides event notifications that fire when join button (in prejoin page) has been clicked.
     */
    onJoinButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when leave button has been clicked.
     */
    onToolbarLeaveButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when camera toolbar button has been clicked.
     */
    onToolbarCameraButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when microphone toolbar button has been clicked.
     */
    onToolbarMicrophoneButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when screenshare toolbar button has been clicked.
     */
    onToolbarScreenshareButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when fullscreen toolbar button has been clicked.
     */
    onToolbarFullscreenButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when participants panel button has been clicked.
     */
    onToolbarParticipantsPanelButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when chat panel button has been clicked.
     */
    onToolbarChatPanelButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when activities panel button has been clicked.
     */
    onToolbarActivitiesPanelButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when start recording button is clicked {@link ToolbarComponent}.
     *  The recording should be stopped using the REST API.
     */
    onToolbarStartRecordingClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when stop recording button is clicked from {@link ToolbarComponent}.
     *  The recording should be stopped using the REST API.
     */
    onToolbarStopRecordingClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when start recording button is clicked {@link ActivitiesPanelComponent}.
     *  The recording should be stopped using the REST API.
     */
    onActivitiesPanelStartRecordingClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when stop recording button is clicked from {@link ActivitiesPanelComponent}.
     *  The recording should be stopped using the REST API.
     */
    onActivitiesPanelStopRecordingClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when delete recording button is clicked from {@link ActivitiesPanelComponent}.
     *  The recording should be deleted using the REST API.
     */
    onActivitiesPanelDeleteRecordingClicked: EventEmitter<string>;
    /**
     * Provides event notifications that fire when play recording button is clicked from {@link ActivitiesPanelComponent}.
     */
    onActivitiesPanelPlayRecordingClicked: EventEmitter<string>;
    /**
     * Provides event notifications that fire when OpenVidu Session is created.
     * See {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Session.html openvidu-browser Session}.
     */
    onSessionCreated: EventEmitter<Session>;
    /**
     * Provides event notifications that fire when local participant is created.
     */
    onParticipantCreated: EventEmitter<ParticipantAbstractModel>;
    /**
     * @internal
     */
    showVideoconference: boolean;
    /**
     * @internal
     */
    participantReady: boolean;
    /**
     * @internal
     */
    error: boolean;
    /**
     * @internal
     */
    errorMessage: string;
    /**
     * @internal
     */
    showPrejoin: boolean;
    /**
     * @internal
     */
    isSessionInitialized: boolean;
    /**
     * @internal
     */
    loading: boolean;
    private externalParticipantName;
    private prejoinSub;
    private participantNameSub;
    private log;
    /**
     * @internal
     */
    constructor(loggerSrv: LoggerService, storageSrv: StorageService, participantService: ParticipantService, deviceSrv: DeviceService, openviduService: OpenViduService, actionService: ActionService, libService: OpenViduAngularConfigService, tokenService: TokenService, translateService: TranslateService);
    ngOnInit(): Promise<void>;
    private start;
    private initwebcamPublisher;
    ngOnDestroy(): Promise<void>;
    /**
     * @internal
     */
    ngAfterViewInit(): void;
    /**
     * @internal
     */
    _onJoinButtonClicked(): void;
    /**
     * @internal
     */
    onLeaveButtonClicked(): void;
    /**
     * @internal
     */
    onCameraButtonClicked(): void;
    /**
     * @internal
     */
    onMicrophoneButtonClicked(): void;
    /**
     * @internal
     */
    onScreenshareButtonClicked(): void;
    /**
     * @internal
     */
    onFullscreenButtonClicked(): void;
    /**
     * @internal
     */
    onParticipantsPanelButtonClicked(): void;
    /**
     * @internal
     */
    onChatPanelButtonClicked(): void;
    /**
     * @internal
     */
    onActivitiesPanelButtonClicked(): void;
    /**
     * @internal
     */
    onStartRecordingClicked(from: string): void;
    /**
     * @internal
     */
    onStopRecordingClicked(from: string): void;
    /**
     * @internal
     */
    onDeleteRecordingClicked(recordingId: string): void;
    /**
     * @internal
     */
    _onSessionCreated(session: Session): void;
    private handlePublisherError;
    private handlePublisherSuccess;
    private subscribeToVideconferenceDirectives;
    static ɵfac: i0.ɵɵFactoryDeclaration<VideoconferenceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VideoconferenceComponent, "ov-videoconference", never, { "tokens": "tokens"; }, { "onJoinButtonClicked": "onJoinButtonClicked"; "onToolbarLeaveButtonClicked": "onToolbarLeaveButtonClicked"; "onToolbarCameraButtonClicked": "onToolbarCameraButtonClicked"; "onToolbarMicrophoneButtonClicked": "onToolbarMicrophoneButtonClicked"; "onToolbarScreenshareButtonClicked": "onToolbarScreenshareButtonClicked"; "onToolbarFullscreenButtonClicked": "onToolbarFullscreenButtonClicked"; "onToolbarParticipantsPanelButtonClicked": "onToolbarParticipantsPanelButtonClicked"; "onToolbarChatPanelButtonClicked": "onToolbarChatPanelButtonClicked"; "onToolbarActivitiesPanelButtonClicked": "onToolbarActivitiesPanelButtonClicked"; "onToolbarStartRecordingClicked": "onToolbarStartRecordingClicked"; "onToolbarStopRecordingClicked": "onToolbarStopRecordingClicked"; "onActivitiesPanelStartRecordingClicked": "onActivitiesPanelStartRecordingClicked"; "onActivitiesPanelStopRecordingClicked": "onActivitiesPanelStopRecordingClicked"; "onActivitiesPanelDeleteRecordingClicked": "onActivitiesPanelDeleteRecordingClicked"; "onActivitiesPanelPlayRecordingClicked": "onActivitiesPanelPlayRecordingClicked"; "onSessionCreated": "onSessionCreated"; "onParticipantCreated": "onParticipantCreated"; }, ["externalToolbar", "externalToolbarAdditionalButtons", "externalToolbarAdditionalPanelButtons", "externalAdditionalPanels", "externalPanel", "externalChatPanel", "externalActivitiesPanel", "externalParticipantsPanel", "externalParticipantPanelItem", "externalParticipantPanelItemElements", "externalLayout", "externalStream"], never>;
}
