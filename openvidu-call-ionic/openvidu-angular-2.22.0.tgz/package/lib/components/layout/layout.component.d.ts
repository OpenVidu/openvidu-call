import { AfterViewInit, ChangeDetectorRef, OnDestroy, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';
import { ParticipantService } from '../../services/participant/participant.service';
import { ParticipantAbstractModel } from '../../models/participant.model';
import { LayoutService } from '../../services/layout/layout.service';
import { StreamDirective } from '../../directives/template/openvidu-angular.directive';
import * as i0 from "@angular/core";
/**
 *
 * The **LayoutComponent** is hosted inside of the {@link VideoconferenceComponent}.
 * It is in charge of displaying the participants streams layout.
 *
 * <div class="custom-table-container">
 *
 * <div>
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The LayoutComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |            ***ovLayout**            |            {@link LayoutDirective}            |
 *
 * </br>
 *
 * It is also providing us a way to **replace the {@link StreamComponent Stream Component}** (<span class="italic">which is hosted inside of it</span>) with a custom one.
 * It will recognise the following directive in a child element.
 *
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |            ***ovStream**            |            {@link StreamDirective}            |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
export declare class LayoutComponent implements OnInit, OnDestroy, AfterViewInit {
    protected layoutService: LayoutService;
    protected participantService: ParticipantService;
    private cd;
    /**
     * @ignore
     */
    streamTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    layoutContainer: ViewContainerRef;
    /**
     * @ignore
     */
    set externalStream(externalStream: StreamDirective);
    localParticipant: ParticipantAbstractModel;
    remoteParticipants: ParticipantAbstractModel[];
    /**
     * @ignore
     */
    subtitlesEnabled: boolean;
    private localParticipantSubs;
    private remoteParticipantsSubs;
    private subtitlesSubs;
    /**
     * @ignore
     */
    constructor(layoutService: LayoutService, participantService: ParticipantService, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private subscribeToSubtitles;
    private subscribeToParticipants;
    static ɵfac: i0.ɵɵFactoryDeclaration<LayoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LayoutComponent, "ov-layout", never, {}, {}, ["streamTemplate", "externalStream"], never>;
}
