import { AfterViewInit, ElementRef } from '@angular/core';
import { StreamManager } from 'openvidu-browser';
import { VideoType } from '../../models/video-type.model';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class VideoComponent implements AfterViewInit {
    mutedSound: boolean;
    _streamManager: StreamManager;
    _videoElement: ElementRef;
    type: VideoType;
    ngAfterViewInit(): void;
    set videoElement(element: ElementRef);
    set streamManager(streamManager: StreamManager);
    private updateVideoStyles;
    static ɵfac: i0.ɵɵFactoryDeclaration<VideoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VideoComponent, "ov-video", never, { "mutedSound": "mutedSound"; "streamManager": "streamManager"; }, {}, never, never>;
}
