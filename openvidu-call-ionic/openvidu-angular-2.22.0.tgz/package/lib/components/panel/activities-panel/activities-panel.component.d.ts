import { OnInit, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { OpenViduAngularConfigService } from '../../../services/config/openvidu-angular.config.service';
import { PanelService } from '../../../services/panel/panel.service';
import * as i0 from "@angular/core";
export declare class ActivitiesPanelComponent implements OnInit {
    private panelService;
    private libService;
    private cd;
    /**
     * Provides event notifications that fire when start recording button has been clicked.
     * The recording should be stated using the OpenVidu REST API.
     */
    onStartRecordingClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when stop recording button has been clicked.
     * The recording should be stopped using the OpenVidu REST API.
     */
    onStopRecordingClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when delete recording button has been clicked.
     * The recording should be deleted using the OpenVidu REST API.
     */
    onDeleteRecordingClicked: EventEmitter<string>;
    /**
     * @internal
     */
    expandedPanel: string;
    /**
     * @internal
     */
    showRecordingActivity: boolean;
    private panelSubscription;
    private recordingActivitySub;
    /**
     * @internal
     */
    constructor(panelService: PanelService, libService: OpenViduAngularConfigService, cd: ChangeDetectorRef);
    /**
     * @internal
     */
    ngOnInit(): void;
    /**
     * @internal
     */
    ngOnDestroy(): void;
    /**
     * @internal
     */
    close(): void;
    /**
     * @internal
     */
    _onStartRecordingClicked(): void;
    /**
     * @internal
     */
    _onStopRecordingClicked(): void;
    /**
     * @internal
     */
    _onDeleteRecordingClicked(recordingId: string): void;
    private subscribeToPanelToggling;
    private subscribeToActivitiesPanelDirective;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActivitiesPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActivitiesPanelComponent, "ov-activities-panel", never, {}, { "onStartRecordingClicked": "onStartRecordingClicked"; "onStopRecordingClicked": "onStopRecordingClicked"; "onDeleteRecordingClicked": "onDeleteRecordingClicked"; }, never, never>;
}
