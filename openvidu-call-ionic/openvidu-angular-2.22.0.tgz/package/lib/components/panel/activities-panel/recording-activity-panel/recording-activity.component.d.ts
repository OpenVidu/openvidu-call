import { OnInit, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { RecordingInfo, RecordingStatus } from '../../../../models/recording.model';
import { ActionService } from '../../../../services/action/action.service';
import { OpenViduAngularConfigService } from '../../../../services/config/openvidu-angular.config.service';
import { ParticipantService } from '../../../../services/participant/participant.service';
import { RecordingService } from '../../../../services/recording/recording.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class RecordingActivityComponent implements OnInit {
    private recordingService;
    private participantService;
    private libService;
    private actionService;
    private cd;
    /**
     * @internal
     */
    expanded: boolean;
    /**
     * Provides event notifications that fire when start recording button has been clicked.
     * The recording should be stopped using the REST API.
     */
    onStartRecordingClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when stop recording button has been clicked.
     * The recording should be stopped using the REST API.
     */
    onStopRecordingClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when delete recording button has been clicked.
     * The recording should be deleted using the REST API.
     */
    onDeleteRecordingClicked: EventEmitter<string>;
    /**
     * @internal
     */
    recordingStatus: RecordingStatus;
    oldRecordingStatus: RecordingStatus;
    /**
     * @internal
     */
    opened: boolean;
    /**
     * @internal
     */
    recStatusEnum: typeof RecordingStatus;
    /**
     * @internal
     */
    isSessionCreator: boolean;
    /**
     * @internal
     */
    recordingAlive: boolean;
    /**
     * @internal
     */
    recordingsList: RecordingInfo[];
    /**
     * @internal
     */
    recordingError: any;
    private recordingStatusSubscription;
    private recordingListSubscription;
    private recordingErrorSub;
    /**
     * @internal
     */
    constructor(recordingService: RecordingService, participantService: ParticipantService, libService: OpenViduAngularConfigService, actionService: ActionService, cd: ChangeDetectorRef);
    /**
     * @internal
     */
    ngOnInit(): void;
    /**
     * @internal
     */
    ngOnDestroy(): void;
    /**
     * @internal
     */
    panelOpened(): void;
    /**
     * @internal
     */
    panelClosed(): void;
    /**
     * @internal
     */
    resetStatus(): void;
    /**
     * @internal
     */
    startRecording(): void;
    /**
     * @internal
     */
    stopRecording(): void;
    /**
     * @internal
     */
    deleteRecording(id: string): void;
    /**
     * @internal
     */
    download(recording: RecordingInfo): void;
    /**
     * @internal
     */
    play(recording: RecordingInfo): void;
    private subscribeToRecordingStatus;
    private subscribeToRecordingActivityDirective;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordingActivityComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RecordingActivityComponent, "ov-recording-activity", never, { "expanded": "expanded"; }, { "onStartRecordingClicked": "onStartRecordingClicked"; "onStopRecordingClicked": "onStopRecordingClicked"; "onDeleteRecordingClicked": "onDeleteRecordingClicked"; }, never, never>;
}
