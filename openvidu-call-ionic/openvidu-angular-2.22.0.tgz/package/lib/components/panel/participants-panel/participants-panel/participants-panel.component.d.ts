import { AfterViewInit, ChangeDetectorRef, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { ParticipantAbstractModel } from '../../../../models/participant.model';
import { ParticipantService } from '../../../../services/participant/participant.service';
import { PanelService } from '../../../..//services/panel/panel.service';
import { ParticipantPanelItemDirective } from '../../../../directives/template/openvidu-angular.directive';
import * as i0 from "@angular/core";
/**
 *
 * The **ParticipantsPanelComponent** is hosted inside of the {@link PanelComponent}.
 * It is in charge of displaying the participants connected to the session.
 * This component is composed by the {@link ParticipantPanelItemComponent}.
 *
 * <div class="custom-table-container">
 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The ParticipantsPanelComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |       ***ovParticipantsPanel**      |       {@link ParticipantsPanelDirective}      |
 *
 * </br>
 *
 * As the ParticipantsPanelComponent is composed by ParticipantPanelItemComponent, it is also providing us a way to **replace the participant item** with a custom one.
 * It will recognise the following directive in a child element.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |     ***ovParticipantPanelItem**     |     {@link ParticipantPanelItemDirective}     |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
export declare class ParticipantsPanelComponent implements OnInit, OnDestroy, AfterViewInit {
    protected participantService: ParticipantService;
    protected panelService: PanelService;
    private cd;
    localParticipant: any;
    remoteParticipants: ParticipantAbstractModel[];
    /**
     * @ignore
     */
    defaultParticipantPanelItemTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    participantPanelItemTemplate: TemplateRef<any>;
    set externalParticipantPanelItem(externalParticipantPanelItem: ParticipantPanelItemDirective);
    private localParticipantSubs;
    private remoteParticipantsSubs;
    /**
     * @ignore
     */
    constructor(participantService: ParticipantService, panelService: PanelService, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ParticipantsPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ParticipantsPanelComponent, "ov-participants-panel", never, {}, {}, ["participantPanelItemTemplate", "externalParticipantPanelItem"], never>;
}
