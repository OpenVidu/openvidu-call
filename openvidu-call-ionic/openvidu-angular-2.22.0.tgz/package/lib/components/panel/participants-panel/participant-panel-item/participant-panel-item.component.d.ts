import { ChangeDetectorRef, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { ParticipantPanelItemElementsDirective } from '../../../../directives/template/openvidu-angular.directive';
import { ParticipantAbstractModel } from '../../../../models/participant.model';
import { OpenViduAngularConfigService } from '../../../../services/config/openvidu-angular.config.service';
import { ParticipantService } from '../../../../services/participant/participant.service';
import * as i0 from "@angular/core";
/**
 *
 * The **ParticipantPanelItemComponent** is hosted inside of the {@link ParticipantsPanelComponent}.
 * It is in charge of displaying the participants information inside of the ParticipansPanelComponent.
 *
 * <div class="custom-table-container">
 * <div>
 *  <h3>API Directives</h3>
 *
 * This component allows us to show or hide certain HTML elements with the following {@link https://angular.io/guide/attribute-directives Angular attribute directives}
 * with the aim of fully customizing the ToolbarComponent.
 *
 * | **Name**                  | **Type**  | **Reference**                                   |
 * | :----------------------------: | :-------: | :---------------------------------------------: |
 * | **muteButton** | `boolean` | {@link ParticipantPanelItemMuteButtonDirective} |
 *
 * <p class="component-link-text">
 * <span class="italic">See all {@link ApiDirectiveModule API Directives}</span>
 * </p>
 *
 * </div>
 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The ParticipantPanelItemComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |     ***ovParticipantPanelItem**     |     {@link ParticipantPanelItemDirective}     |
 *
 * </br>
 *
 * It is also providing us a way to **add additional buttons** to the default participant panel item.
 * It will recognise the following directive in a child element.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * | ***ovParticipantPanelItemElements** | {@link ParticipantPanelItemElementsDirective} |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
export declare class ParticipantPanelItemComponent implements OnInit, OnDestroy {
    private libService;
    protected participantService: ParticipantService;
    private cd;
    /**
     * @ignore
     */
    participantPanelItemElementsTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    showMuteButton: boolean;
    private muteButtonSub;
    /**
     * @ignore
     */
    set externalItemElements(externalItemElements: ParticipantPanelItemElementsDirective);
    set participant(participant: ParticipantAbstractModel);
    /**
     * @ignore
     */
    _participant: ParticipantAbstractModel;
    /**
     * @ignore
     */
    constructor(libService: OpenViduAngularConfigService, participantService: ParticipantService, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    toggleMuteForcibly(): void;
    private subscribeToParticipantPanelItemDirectives;
    static ɵfac: i0.ɵɵFactoryDeclaration<ParticipantPanelItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ParticipantPanelItemComponent, "ov-participant-panel-item", never, { "participant": "participant"; }, {}, ["participantPanelItemElementsTemplate", "externalItemElements"], never>;
}
