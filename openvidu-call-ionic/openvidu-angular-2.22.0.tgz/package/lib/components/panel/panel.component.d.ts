import { ChangeDetectorRef, OnInit, TemplateRef } from '@angular/core';
import { ChatPanelDirective, AdditionalPanelsDirective, ParticipantsPanelDirective, ActivitiesPanelDirective } from '../../directives/template/openvidu-angular.directive';
import { PanelService } from '../../services/panel/panel.service';
import * as i0 from "@angular/core";
/**
 *
 * The **PanelComponent** is hosted inside of the {@link VideoconferenceComponent}.
 * It is in charge of displaying the videoconference panels providing functionalities to the videoconference app
 * such as the chat ({@link ChatPanelComponent}) and list of participants ({@link ParticipantsPanelComponent}) .
 *
 * <div class="custom-table-container">

 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The PanelComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovPanel**           |            {@link PanelDirective}           |
 *
 * </br>
 *
 * It is also providing us a way to **replace the children panels** to the default panel.
 * It will recognise the following directive in a child element.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovChatPanel**          |           {@link ChatPanelDirective}          |
 * |       ***ovParticipantsPanel**      |       {@link ParticipantsPanelDirective}      |
 * |        ***ovAdditionalPanels**      |       {@link AdditionalPanelsDirective}       |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
export declare class PanelComponent implements OnInit {
    protected panelService: PanelService;
    private cd;
    /**
     * @ignore
     */
    participantsPanelTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    backgroundEffectsPanelTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    settingsPanelTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    activitiesPanelTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    chatPanelTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    additionalPanelsTemplate: TemplateRef<any>;
    set externalParticipantPanel(externalParticipantsPanel: ParticipantsPanelDirective);
    set externalActivitiesPanel(externalActivitiesPanel: ActivitiesPanelDirective);
    set externalChatPanel(externalChatPanel: ChatPanelDirective);
    set externalAdditionalPanels(externalAdditionalPanels: AdditionalPanelsDirective);
    isParticipantsPanelOpened: boolean;
    isChatPanelOpened: boolean;
    isBackgroundEffectsPanelOpened: boolean;
    isSettingsPanelOpened: boolean;
    isActivitiesPanelOpened: boolean;
    /**
     * @internal
     */
    isExternalPanelOpened: boolean;
    private panelSubscription;
    /**
     * @ignore
     */
    constructor(panelService: PanelService, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private subscribeToPanelToggling;
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PanelComponent, "ov-panel", never, {}, {}, ["participantsPanelTemplate", "backgroundEffectsPanelTemplate", "settingsPanelTemplate", "activitiesPanelTemplate", "chatPanelTemplate", "additionalPanelsTemplate", "externalParticipantPanel", "externalActivitiesPanel", "externalChatPanel", "externalAdditionalPanels"], never>;
}
