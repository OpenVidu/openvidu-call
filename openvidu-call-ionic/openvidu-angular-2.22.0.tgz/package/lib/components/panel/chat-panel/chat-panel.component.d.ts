import { AfterViewInit, ChangeDetectorRef, ElementRef, OnInit } from '@angular/core';
import { ChatMessage } from '../../../models/chat.model';
import { ChatService } from '../../../services/chat/chat.service';
import { PanelService } from '../../../services/panel/panel.service';
import * as i0 from "@angular/core";
/**
 *
 * The **ChatPanelComponent** is hosted inside of the {@link PanelComponent}.
 * It is in charge of displaying the session chat.
 *
 * <div class="custom-table-container">

 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The ChatPanelComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovChatPanel**          |           {@link ChatPanelDirective}          |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
export declare class ChatPanelComponent implements OnInit, AfterViewInit {
    private chatService;
    private panelService;
    private cd;
    /**
     * @ignore
     */
    chatScroll: ElementRef;
    /**
     * @ignore
     */
    chatInput: ElementRef;
    /**
     * @ignore
     */
    message: string;
    messageList: ChatMessage[];
    private chatMessageSubscription;
    /**
     * @ignore
     */
    constructor(chatService: ChatService, panelService: PanelService, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    eventKeyPress(event: any): void;
    sendMessage(): void;
    scrollToBottom(): void;
    close(): void;
    private subscribeToMessages;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatPanelComponent, "ov-chat-panel", never, {}, {}, never, never>;
}
