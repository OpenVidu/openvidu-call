import { ChangeDetectorRef, OnInit } from '@angular/core';
import { BackgroundEffect, EffectType } from '../../../models/background-effect.model';
import { PanelService } from '../../../services/panel/panel.service';
import { VirtualBackgroundService } from '../../../services/virtual-background/virtual-background.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class BackgroundEffectsPanelComponent implements OnInit {
    private panelService;
    private backgroundService;
    private cd;
    backgroundSelectedId: string;
    effectType: typeof EffectType;
    backgroundImages: BackgroundEffect[];
    noEffectAndBlurredBackground: BackgroundEffect[];
    private backgrounds;
    private backgroundSubs;
    /**
     * @internal
     * @param panelService
     * @param backgroundService
     * @param cd
     */
    constructor(panelService: PanelService, backgroundService: VirtualBackgroundService, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    subscribeToBackgroundSelected(): void;
    close(): void;
    applyBackground(effect: BackgroundEffect): Promise<void>;
    removeBackground(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BackgroundEffectsPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BackgroundEffectsPanelComponent, "ov-background-effects-panel", never, {}, {}, never, never>;
}
