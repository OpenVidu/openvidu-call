import { OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { PanelSettingsOptions } from '../../../models/panel.model';
import { OpenViduAngularConfigService } from '../../../services/config/openvidu-angular.config.service';
import { PanelService } from '../../../services/panel/panel.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class SettingsPanelComponent implements OnInit {
    private panelService;
    private libService;
    settingsOptions: typeof PanelSettingsOptions;
    selectedOption: PanelSettingsOptions;
    showSubtitles: boolean;
    private subtitlesSubs;
    panelSubscription: Subscription;
    constructor(panelService: PanelService, libService: OpenViduAngularConfigService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    close(): void;
    onSelectionChanged(e: any): void;
    private subscribeToDirectives;
    private subscribeToPanelToggling;
    static ɵfac: i0.ɵɵFactoryDeclaration<SettingsPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SettingsPanelComponent, "ov-settings-panel", never, {}, {}, never, never>;
}
