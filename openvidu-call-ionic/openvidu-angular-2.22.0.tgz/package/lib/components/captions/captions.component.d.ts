/// <reference types="node" />
import { ChangeDetectorRef, ElementRef, OnInit, QueryList } from '@angular/core';
import { Observable } from 'rxjs';
import { PanelService } from '../../services/panel/panel.service';
import { DocumentService } from '../../services/document/document.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class CaptionsComponent implements OnInit {
    private documentService;
    private panelService;
    private cd;
    textContainer: ElementRef;
    captionElementsRef: QueryList<ElementRef>;
    /**
     * @ignore
     */
    subtitleText: string;
    /**
     * @ignore
     */
    screenSize: string;
    /**
     * @ignore
     */
    settingsPanelOpened: boolean;
    private screenSizeSub;
    private panelTogglingSubscription;
    interval: NodeJS.Timer;
    fakeEvent: Observable<{
        connectionId: string;
        partial: string;
        text?: string;
    }>;
    captionElements: {
        connectionId: string;
        author: string;
        text: string;
    }[];
    private sample;
    captionsHeight: number;
    constructor(documentService: DocumentService, panelService: PanelService, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onSettingsCliked(): void;
    private subscribeToTranscription;
    private updateCaption;
    private adjustCaptionsToContainer;
    private startFakeEventWithSample;
    private subscribeToPanelToggling;
    private subscribeToScreenSize;
    private scrollToBottom;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaptionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaptionsComponent, "ov-captions", never, {}, {}, never, never>;
}
