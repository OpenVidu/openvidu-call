import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export interface DialogData {
    title: string;
    description: string;
    showActionButtons: boolean;
}
/**
 * @internal
 */
export declare class DialogTemplateComponent {
    dialogRef: MatDialogRef<DialogTemplateComponent>;
    data: DialogData;
    constructor(dialogRef: MatDialogRef<DialogTemplateComponent>, data: DialogData);
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogTemplateComponent, "ov-dialog-template", never, {}, {}, never, never>;
}
