import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class DeleteDialogComponent {
    dialogRef: MatDialogRef<DeleteDialogComponent>;
    constructor(dialogRef: MatDialogRef<DeleteDialogComponent>);
    close(succsess?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeleteDialogComponent, "app-delete-dialog", never, {}, {}, never, never>;
}
