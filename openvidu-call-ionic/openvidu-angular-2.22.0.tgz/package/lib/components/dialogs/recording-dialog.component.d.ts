import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class RecordingDialogComponent {
    dialogRef: MatDialogRef<RecordingDialogComponent>;
    data: any;
    src: string;
    type: string;
    constructor(dialogRef: MatDialogRef<RecordingDialogComponent>, data: any);
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordingDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RecordingDialogComponent, "app-recording-dialog", never, {}, {}, never, never>;
}
