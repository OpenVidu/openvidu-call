import { AfterViewInit, ChangeDetectorRef, EventEmitter, OnDestroy, OnInit, TemplateRef } from '@angular/core';
import { TokenService } from '../../services/token/token.service';
import { ChatService } from '../../services/chat/chat.service';
import { PanelService } from '../../services/panel/panel.service';
import { DocumentService } from '../../services/document/document.service';
import { OpenViduService } from '../../services/openvidu/openvidu.service';
import { LoggerService } from '../../services/logger/logger.service';
import { Session } from 'openvidu-browser';
import { ActionService } from '../../services/action/action.service';
import { DeviceService } from '../../services/device/device.service';
import { ChatMessage } from '../../models/chat.model';
import { ParticipantService } from '../../services/participant/participant.service';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import { ToolbarAdditionalButtonsDirective, ToolbarAdditionalPanelButtonsDirective } from '../../directives/template/openvidu-angular.directive';
import { PlatformService } from '../../services/platform/platform.service';
import { MatMenuTrigger } from '@angular/material/menu';
import { RecordingService } from '../../services/recording/recording.service';
import { RecordingStatus } from '../../models/recording.model';
import { TranslateService } from '../../services/translate/translate.service';
import { LayoutService } from '../../services/layout/layout.service';
import * as i0 from "@angular/core";
/**
 *
 * The **ToolbarComponent** is hosted inside of the {@link VideoconferenceComponent}.
 * It is in charge of displaying the participants controlls for handling the media, panels and more videoconference features.
 *
 * <div class="custom-table-container">
 * <div>
 *  <h3>API Directives</h3>
 *
 * This component allows us to show or hide certain HTML elements with the following {@link https://angular.io/guide/attribute-directives Angular attribute directives}
 * with the aim of fully customizing the ToolbarComponent.
 *
 * | **Name**                  | **Type**  | **Reference**                                   |
 * | :----------------------------: | :-------: | :---------------------------------------------: |
 * | **screenshareButton**       | `boolean` | {@link ToolbarScreenshareButtonDirective}       |
 * | **fullscreenButton**        | `boolean` | {@link ToolbarFullscreenButtonDirective}        |
 * | **backgroundEffectsButton** | `boolean` | {@link ToolbarBackgroundEffectsButtonDirective} |
 * | **leaveButton**             | `boolean` | {@link ToolbarLeaveButtonDirective}             |
 * | **chatPanelButton**         | `boolean` | {@link ToolbarChatPanelButtonDirective}         |
 * | **participantsPanelButton** | `boolean` | {@link ToolbarParticipantsPanelButtonDirective} |
 * | **displayLogo**             | `boolean` | {@link ToolbarDisplayLogoDirective}             |
 * | **displaySessionName**      | `boolean` | {@link ToolbarDisplaySessionNameDirective}      |
 *
 * <p class="component-link-text">
 * <span class="italic">See all {@link ApiDirectiveModule API Directives}</span>
 * </p>
 *
 * </div>
 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The ToolbarComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovToolbar**           |            {@link ToolbarDirective}           |
 *
 * </br>
 *
 * It is also providing us a way to **add additional buttons** to the default toolbar.
 * It will recognise the following directive in a child element.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |   ***ovToolbarAdditionalButtons**   |   {@link ToolbarAdditionalButtonsDirective}   |
 * |***ovToolbarAdditionalPanelButtons**   |   {@link ToolbarAdditionalPanelButtonsDirective}   |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
export declare class ToolbarComponent implements OnInit, OnDestroy, AfterViewInit {
    protected documentService: DocumentService;
    protected chatService: ChatService;
    protected panelService: PanelService;
    protected tokenService: TokenService;
    protected participantService: ParticipantService;
    protected openviduService: OpenViduService;
    protected oVDevicesService: DeviceService;
    protected actionService: ActionService;
    protected loggerSrv: LoggerService;
    private layoutService;
    private cd;
    private libService;
    private platformService;
    private recordingService;
    private translateService;
    /**
     * @ignore
     */
    toolbarAdditionalButtonsTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    toolbarAdditionalPanelButtonsTemplate: TemplateRef<any>;
    /**
     * @ignore
     */
    set externalAdditionalButtons(externalAdditionalButtons: ToolbarAdditionalButtonsDirective);
    /**
     * @ignore
     */
    set externalAdditionalPanelButtons(externalAdditionalPanelButtons: ToolbarAdditionalPanelButtonsDirective);
    /**
     * Provides event notifications that fire when leave button has been clicked.
     */
    onLeaveButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when camera toolbar button has been clicked.
     */
    onCameraButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when microphone toolbar button has been clicked.
     */
    onMicrophoneButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when fullscreen toolbar button has been clicked.
     */
    onFullscreenButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when screenshare toolbar button has been clicked.
     */
    onScreenshareButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when participants panel button has been clicked.
     */
    onParticipantsPanelButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when chat panel button has been clicked.
     */
    onChatPanelButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when activities panel button has been clicked.
     */
    onActivitiesPanelButtonClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when start recording button has been clicked.
     */
    onStartRecordingClicked: EventEmitter<void>;
    /**
     * Provides event notifications that fire when stop recording button has been clicked.
     */
    onStopRecordingClicked: EventEmitter<void>;
    /**
     * @ignore
     */
    menuTrigger: MatMenuTrigger;
    /**
     * @ignore
     */
    session: Session;
    /**
     * @ignore
     */
    unreadMessages: number;
    /**
     * @ignore
     */
    messageList: ChatMessage[];
    /**
     * @ignore
     */
    isScreenShareActive: boolean;
    /**
     * @ignore
     */
    isWebcamVideoActive: boolean;
    /**
     * @ignore
     */
    isAudioActive: boolean;
    /**
     * @ignore
     */
    isConnectionLost: boolean;
    /**
     * @ignore
     */
    hasVideoDevices: boolean;
    /**
     * @ignore
     */
    hasAudioDevices: boolean;
    /**
     * @ignore
     */
    isFullscreenActive: boolean;
    /**
     * @ignore
     */
    isChatOpened: boolean;
    /**
     * @ignore
     */
    isParticipantsOpened: boolean;
    /**
     * @ignore
     */
    isActivitiesOpened: boolean;
    /**
     * @ignore
     */
    isMinimal: boolean;
    /**
     * @ignore
     */
    showScreenshareButton: boolean;
    /**
     * @ignore
     */
    showFullscreenButton: boolean;
    /**
     * @ignore
     */
    showBackgroundEffectsButton: boolean;
    /**
     * @ignore
     */
    showLeaveButton: boolean;
    /**
     * @ignore
     */
    showRecordingButton: boolean;
    /**
     * @ignore
     */
    showSettingsButton: boolean;
    /**
     * @ignore
     */
    showMoreOptionsButton: boolean;
    /**
     * @ignore
     */
    showParticipantsPanelButton: boolean;
    /**
     * @ignore
     */
    showActivitiesPanelButton: boolean;
    /**
     * @ignore
     */
    showChatPanelButton: boolean;
    /**
     * @ignore
     */
    showLogo: boolean;
    /**
     * @ignore
     */
    showSessionName: boolean;
    /**
     * @ignore
     */
    showSubtitlesButton: boolean;
    /**
     * @ignore
     */
    subtitlesEnabled: boolean;
    /**
     * @ignore
     */
    videoMuteChanging: boolean;
    /**
     * @ignore
     */
    recordingStatus: RecordingStatus;
    /**
     * @ignore
     */
    _recordingStatus: typeof RecordingStatus;
    /**
     * @ignore
     */
    recordingTime: Date;
    /**
     * @ignore
     */
    isSessionCreator: boolean;
    /**
     * @ignore
     */
    screenSize: string;
    private log;
    private minimalSub;
    private panelTogglingSubscription;
    private chatMessagesSubscription;
    private localParticipantSubscription;
    private screenshareButtonSub;
    private fullscreenButtonSub;
    private backgroundEffectsButtonSub;
    private leaveButtonSub;
    private recordingButtonSub;
    private recordingSubscription;
    private activitiesPanelButtonSub;
    private participantsPanelButtonSub;
    private chatPanelButtonSub;
    private displayLogoSub;
    private displaySessionNameSub;
    private screenSizeSub;
    private settingsButtonSub;
    private subtitlesSubs;
    private currentWindowHeight;
    /**
     * @ignore
     */
    constructor(documentService: DocumentService, chatService: ChatService, panelService: PanelService, tokenService: TokenService, participantService: ParticipantService, openviduService: OpenViduService, oVDevicesService: DeviceService, actionService: ActionService, loggerSrv: LoggerService, layoutService: LayoutService, cd: ChangeDetectorRef, libService: OpenViduAngularConfigService, platformService: PlatformService, recordingService: RecordingService, translateService: TranslateService);
    /**
     * @ignore
     */
    sizeChange(event: any): void;
    /**
     * @ignore
     */
    keyDown(event: KeyboardEvent): boolean;
    ngOnInit(): Promise<void>;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    toggleMicrophone(): Promise<void>;
    /**
     * @ignore
     */
    toggleCamera(): Promise<void>;
    /**
     * @ignore
     */
    toggleScreenShare(): Promise<void>;
    /**
     * @ignore
     */
    leaveSession(): void;
    /**
     * @ignore
     */
    toggleRecording(): void;
    /**
     * @ignore
     */
    toggleBackgroundEffects(): void;
    /**
     * @ignore
     */
    toggleSubtitles(): void;
    /**
     * @ignore
     */
    toggleSettings(): void;
    /**
     * @ignore
     */
    toggleParticipantsPanel(): void;
    /**
     * @ignore
     */
    toggleChatPanel(): void;
    /**
     * @ignore
     */
    toggleFullscreen(): void;
    private toggleActivitiesPanel;
    protected subscribeToReconnection(): void;
    protected subscribeToMenuToggling(): void;
    protected subscribeToChatMessages(): void;
    protected subscribeToUserMediaProperties(): void;
    private subscribeToRecordingStatus;
    private subscribeToToolbarDirectives;
    private subscribeToScreenSize;
    private subscribeToSubtitlesToggling;
    private checkDisplayMoreOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToolbarComponent, "ov-toolbar", never, {}, { "onLeaveButtonClicked": "onLeaveButtonClicked"; "onCameraButtonClicked": "onCameraButtonClicked"; "onMicrophoneButtonClicked": "onMicrophoneButtonClicked"; "onFullscreenButtonClicked": "onFullscreenButtonClicked"; "onScreenshareButtonClicked": "onScreenshareButtonClicked"; "onParticipantsPanelButtonClicked": "onParticipantsPanelButtonClicked"; "onChatPanelButtonClicked": "onChatPanelButtonClicked"; "onActivitiesPanelButtonClicked": "onActivitiesPanelButtonClicked"; "onStartRecordingClicked": "onStartRecordingClicked"; "onStopRecordingClicked": "onStopRecordingClicked"; }, ["toolbarAdditionalButtonsTemplate", "toolbarAdditionalPanelButtonsTemplate", "externalAdditionalButtons", "externalAdditionalPanelButtons"], never>;
}
