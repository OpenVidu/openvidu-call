import { AfterViewInit, OnInit, EventEmitter } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { MatSelect } from '@angular/material/select';
import { StorageService } from '../../../services/storage/storage.service';
import { TranslateService } from '../../../services/translate/translate.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class LangSelectorComponent implements OnInit, AfterViewInit {
    private translateService;
    private storageSrv;
    onLangSelectorClicked: EventEmitter<void>;
    langSelected: {
        name: string;
        ISO: string;
    };
    languages: {
        name: string;
        ISO: string;
    }[];
    /**
     * @ignore
     */
    menuTrigger: MatMenuTrigger;
    /**
     * @ignore
     */
    matSelect: MatSelect;
    constructor(translateService: TranslateService, storageSrv: StorageService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    onLangSelected(lang: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LangSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LangSelectorComponent, "ov-lang-selector", never, {}, { "onLangSelectorClicked": "onLangSelectorClicked"; }, never, never>;
}
