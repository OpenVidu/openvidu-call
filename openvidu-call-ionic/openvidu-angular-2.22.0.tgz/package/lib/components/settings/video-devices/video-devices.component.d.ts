import { OnInit, OnDestroy, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs';
import { CustomDevice } from '../../../models/device.model';
import { DeviceService } from '../../../services/device/device.service';
import { OpenViduService } from '../../../services/openvidu/openvidu.service';
import { PanelService } from '../../../services/panel/panel.service';
import { ParticipantService } from '../../../services/participant/participant.service';
import { StorageService } from '../../../services/storage/storage.service';
import { VirtualBackgroundService } from '../../../services/virtual-background/virtual-background.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class VideoDevicesComponent implements OnInit, OnDestroy {
    private openviduService;
    protected panelService: PanelService;
    private storageSrv;
    private deviceSrv;
    protected participantService: ParticipantService;
    private backgroundService;
    onDeviceSelectorClicked: EventEmitter<void>;
    videoMuteChanging: boolean;
    isVideoMuted: boolean;
    cameraSelected: CustomDevice;
    hasVideoDevices: boolean;
    cameras: CustomDevice[];
    localParticipantSubscription: Subscription;
    constructor(openviduService: OpenViduService, panelService: PanelService, storageSrv: StorageService, deviceSrv: DeviceService, participantService: ParticipantService, backgroundService: VirtualBackgroundService);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): Promise<void>;
    toggleCam(): Promise<void>;
    onCameraSelected(event: any): Promise<void>;
    protected subscribeToParticipantMediaProperties(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VideoDevicesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VideoDevicesComponent, "ov-video-devices-select", never, {}, { "onDeviceSelectorClicked": "onDeviceSelectorClicked"; }, never, never>;
}
