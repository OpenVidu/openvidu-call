import { OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ParticipantService } from '../../../services/participant/participant.service';
import { StorageService } from '../../../services/storage/storage.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class NicknameInputComponent implements OnInit {
    private participantService;
    private storageSrv;
    nickname: string;
    localParticipantSubscription: Subscription;
    constructor(participantService: ParticipantService, storageSrv: StorageService);
    ngOnInit(): void;
    updateNickname(): void;
    private subscribeToParticipantProperties;
    static ɵfac: i0.ɵɵFactoryDeclaration<NicknameInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NicknameInputComponent, "ov-nickname-input", never, {}, {}, never, never>;
}
