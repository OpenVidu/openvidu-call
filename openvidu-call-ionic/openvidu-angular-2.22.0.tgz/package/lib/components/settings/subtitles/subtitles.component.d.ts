import { OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { LayoutService } from '../../../services/layout/layout.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class SubtitlesSettingComponent implements OnInit, OnDestroy {
    private layoutService;
    subtitlesEnabled: boolean;
    languagesAvailable: any[];
    subtitlesSubs: Subscription;
    langSelected: string;
    constructor(layoutService: LayoutService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onLangSelected(lang: string): void;
    toggleSubtitles(): void;
    private subscribeToSubtitles;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubtitlesSettingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubtitlesSettingComponent, "ov-subtitles-settings", never, {}, {}, never, never>;
}
