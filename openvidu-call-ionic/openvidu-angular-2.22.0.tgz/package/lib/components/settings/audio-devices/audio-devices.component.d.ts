import { EventEmitter, OnDestroy, OnInit } from '@angular/core';
import { DeviceService } from '../../../services/device/device.service';
import { OpenViduService } from '../../../services/openvidu/openvidu.service';
import { StorageService } from '../../../services/storage/storage.service';
import { CustomDevice } from '../../../models/device.model';
import { ParticipantService } from '../../../services/participant/participant.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class AudioDevicesComponent implements OnInit, OnDestroy {
    private openviduService;
    private deviceSrv;
    private storageSrv;
    private participantService;
    onDeviceSelectorClicked: EventEmitter<void>;
    hasAudioDevices: boolean;
    isAudioMuted: boolean;
    microphoneSelected: CustomDevice;
    microphones: CustomDevice[];
    private localParticipantSubscription;
    constructor(openviduService: OpenViduService, deviceSrv: DeviceService, storageSrv: StorageService, participantService: ParticipantService);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    toggleMic(): void;
    onMicrophoneSelected(event: any): Promise<void>;
    private subscribeToParticipantMediaProperties;
    static ɵfac: i0.ɵɵFactoryDeclaration<AudioDevicesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AudioDevicesComponent, "ov-audio-devices-select", never, {}, { "onDeviceSelectorClicked": "onDeviceSelectorClicked"; }, never, never>;
}
