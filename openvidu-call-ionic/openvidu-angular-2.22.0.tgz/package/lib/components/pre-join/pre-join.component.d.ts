import { OnDestroy, OnInit, EventEmitter } from '@angular/core';
import { CustomDevice } from '../../models/device.model';
import { ParticipantAbstractModel } from '../../models/participant.model';
import { CdkOverlayService } from '../../services/cdk-overlay/cdk-overlay.service';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import { LayoutService } from '../../services/layout/layout.service';
import { LoggerService } from '../../services/logger/logger.service';
import { PanelService } from '../../services/panel/panel.service';
import { ParticipantService } from '../../services/participant/participant.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class PreJoinComponent implements OnInit, OnDestroy {
    private layoutService;
    private loggerSrv;
    private participantService;
    protected panelService: PanelService;
    private libService;
    protected cdkSrv: CdkOverlayService;
    onJoinButtonClicked: EventEmitter<any>;
    cameras: CustomDevice[];
    microphones: CustomDevice[];
    cameraSelected: CustomDevice;
    microphoneSelected: CustomDevice;
    isVideoMuted: boolean;
    isAudioMuted: boolean;
    videoMuteChanging: boolean;
    localParticipant: ParticipantAbstractModel;
    windowSize: number;
    hasVideoDevices: boolean;
    hasAudioDevices: boolean;
    isLoading: boolean;
    nickname: string;
    /**
     * @ignore
     */
    showBackgroundEffectsButton: boolean;
    /**
     * @ignore
     */
    isMinimal: boolean;
    showLogo: boolean;
    private log;
    private localParticipantSubscription;
    private screenShareStateSubscription;
    private minimalSub;
    private displayLogoSub;
    private backgroundEffectsButtonSub;
    sizeChange(): void;
    constructor(layoutService: LayoutService, loggerSrv: LoggerService, participantService: ParticipantService, panelService: PanelService, libService: OpenViduAngularConfigService, cdkSrv: CdkOverlayService);
    ngOnInit(): void;
    ngOnDestroy(): Promise<void>;
    onDeviceSelectorClicked(): void;
    joinSession(): void;
    toggleBackgroundEffects(): void;
    private subscribeToLocalParticipantEvents;
    private subscribeToPrejoinDirectives;
    static ɵfac: i0.ɵɵFactoryDeclaration<PreJoinComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PreJoinComponent, "ov-pre-join", never, {}, { "onJoinButtonClicked": "onJoinButtonClicked"; }, never, never>;
}
