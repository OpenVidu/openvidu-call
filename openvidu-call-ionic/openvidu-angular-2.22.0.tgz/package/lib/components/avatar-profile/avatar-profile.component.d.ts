import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class AvatarProfileComponent {
    letter: string;
    set name(nickname: string);
    color: any;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<AvatarProfileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AvatarProfileComponent, "ov-avatar-profile", never, { "name": "name"; "color": "color"; }, {}, never, never>;
}
