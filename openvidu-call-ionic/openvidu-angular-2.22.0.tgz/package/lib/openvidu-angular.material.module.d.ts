import * as i0 from "@angular/core";
import * as i1 from "@angular/platform-browser/animations";
import * as i2 from "@angular/material/button";
import * as i3 from "@angular/material/card";
import * as i4 from "@angular/material/toolbar";
import * as i5 from "@angular/material/icon";
import * as i6 from "@angular/material/input";
import * as i7 from "@angular/material/form-field";
import * as i8 from "@angular/material/dialog";
import * as i9 from "@angular/material/tooltip";
import * as i10 from "@angular/material/badge";
import * as i11 from "@angular/material/grid-list";
import * as i12 from "@angular/material/select";
import * as i13 from "@angular/material/core";
import * as i14 from "@angular/material/progress-spinner";
import * as i15 from "@angular/material/slider";
import * as i16 from "@angular/material/sidenav";
import * as i17 from "@angular/material/snack-bar";
import * as i18 from "@angular/flex-layout";
import * as i19 from "@angular/material/menu";
import * as i20 from "@angular/material/divider";
import * as i21 from "@angular/material/list";
import * as i22 from "@angular/material/expansion";
import * as i23 from "@angular/material/slide-toggle";
export declare class AppMaterialModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppMaterialModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AppMaterialModule, never, [typeof i1.BrowserAnimationsModule], [typeof i2.MatButtonModule, typeof i3.MatCardModule, typeof i4.MatToolbarModule, typeof i5.MatIconModule, typeof i6.MatInputModule, typeof i7.MatFormFieldModule, typeof i8.MatDialogModule, typeof i9.MatTooltipModule, typeof i10.MatBadgeModule, typeof i11.MatGridListModule, typeof i12.MatSelectModule, typeof i13.MatOptionModule, typeof i14.MatProgressSpinnerModule, typeof i15.MatSliderModule, typeof i16.MatSidenavModule, typeof i17.MatSnackBarModule, typeof i18.FlexLayoutModule, typeof i19.MatMenuModule, typeof i20.MatDividerModule, typeof i21.MatListModule, typeof i22.MatExpansionModule, typeof i23.MatSlideToggleModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AppMaterialModule>;
}
