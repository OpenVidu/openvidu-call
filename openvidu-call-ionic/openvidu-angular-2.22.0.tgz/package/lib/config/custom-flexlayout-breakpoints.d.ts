import { LayoutDirective } from '@angular/flex-layout';
import * as i0 from "@angular/core";
export declare const CustomBreakPointsProvider: {
    provide: import("@angular/core").InjectionToken<import("@angular/flex-layout").BreakPoint | import("@angular/flex-layout").BreakPoint[]>;
    useValue: {
        alias: string;
        suffix: string;
        mediaQuery: string;
        overlapping: boolean;
        priority: number;
    }[];
    multi: boolean;
};
export declare class CustomLayoutExtensionDirective extends LayoutDirective {
    protected inputs: string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomLayoutExtensionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CustomLayoutExtensionDirective, "[fxLayout.landscape]", never, { "fxLayout.landscape": "fxLayout.landscape"; }, {}, never>;
}
