import { OverlayContainer } from '@angular/cdk/overlay';
import * as i0 from "@angular/core";
export declare class CdkOverlayContainer extends OverlayContainer {
    containerSelector: string;
    customClass: string;
    protected _createContainer(): void;
    setSelector(selector: string): void;
    private getElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<CdkOverlayContainer, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CdkOverlayContainer>;
}
