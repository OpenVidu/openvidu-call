import { PipeTransform } from '@angular/core';
import { TranslateService } from '../services/translate/translate.service';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class TranslatePipe implements PipeTransform {
    private translateService;
    constructor(translateService: TranslateService);
    transform(str: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TranslatePipe, "translate">;
}
