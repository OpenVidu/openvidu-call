import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class LinkifyPipe implements PipeTransform {
    private linkifer;
    constructor();
    transform(str: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkifyPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<LinkifyPipe, "linkify">;
}
