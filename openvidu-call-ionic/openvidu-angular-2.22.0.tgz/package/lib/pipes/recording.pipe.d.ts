import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * @internal
 */
export declare class DurationFromSecondsPipe implements PipeTransform {
    transform(durationInSeconds: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DurationFromSecondsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DurationFromSecondsPipe, "duration">;
}
/**
 * @internal
 */
export declare class SearchByStringPropertyPipe implements PipeTransform {
    transform(items: any[], props: {
        properties: string[];
        filter: string;
    }): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchByStringPropertyPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SearchByStringPropertyPipe, "searchByStringProperty">;
}
/**
 * @internal
 */
export declare class ThumbnailFromUrlPipe implements PipeTransform {
    transform(url: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThumbnailFromUrlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ThumbnailFromUrlPipe, "thumbnailUrl">;
}
