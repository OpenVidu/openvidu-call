import { PipeTransform } from '@angular/core';
import { StreamModel, ParticipantAbstractModel } from '../models/participant.model';
import { TranslateService } from '../services/translate/translate.service';
import * as i0 from "@angular/core";
export declare class ParticipantStreamsPipe implements PipeTransform {
    constructor();
    transform(participants: ParticipantAbstractModel[] | ParticipantAbstractModel): StreamModel[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ParticipantStreamsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ParticipantStreamsPipe, "streams">;
}
/**
 * @internal
 */
export declare class StreamTypesEnabledPipe implements PipeTransform {
    private translateService;
    constructor(translateService: TranslateService);
    transform(participant: ParticipantAbstractModel): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StreamTypesEnabledPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<StreamTypesEnabledPipe, "streamTypesEnabled">;
}
