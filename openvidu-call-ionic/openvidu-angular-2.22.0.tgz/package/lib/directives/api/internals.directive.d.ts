import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Load default OpenVidu logo if custom one is not exist
 * @internal
 */
export declare class LogoDirective {
    elementRef: ElementRef;
    defaultLogo: string;
    ovLogo: string;
    constructor(elementRef: ElementRef);
    loadDefaultLogo(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LogoDirective, "img[ovLogo]", never, { "ovLogo": "ovLogo"; }, {}, never>;
}
