import { AfterViewInit, OnDestroy, ElementRef } from '@angular/core';
import { RecordingInfo } from '../../models/recording.model';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import * as i0 from "@angular/core";
/**
 * The **recordingsList** directive allows show all recordings saved in your OpenVidu deployment in {@link AdminDashboardComponent}.
 *
 * Default: `[]`
 *
 * @example
 * <ov-admin-dashboard [recordingsList]="recordings"></ov-admin-dashboard>
 *
 */
export declare class AdminRecordingsListDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    set recordingsList(value: RecordingInfo[]);
    recordingsValue: RecordingInfo[];
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    clear(): void;
    update(value: RecordingInfo[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminRecordingsListDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AdminRecordingsListDirective, "ov-admin-dashboard[recordingsList]", never, { "recordingsList": "recordingsList"; }, {}, never>;
}
/**
 * The **error** directive allows show the authentication error in {@link AdminLoginComponent}.
 *
 * Default: `null`
 *
 * @example
 * <ov-admin-login [error]="error"></ov-admin-login>
 *
 */
export declare class AdminLoginDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    set error(value: any);
    errorValue: any;
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    clear(): void;
    update(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AdminLoginDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AdminLoginDirective, "ov-admin-login[error]", never, { "error": "error"; }, {}, never>;
}
