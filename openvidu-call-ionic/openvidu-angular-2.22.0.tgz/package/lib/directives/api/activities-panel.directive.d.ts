import { AfterViewInit, OnDestroy, ElementRef } from '@angular/core';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import * as i0 from "@angular/core";
/**
 * The **recordingActivity** directive allows show/hide the recording activity in {@link ActivitiesPanelComponent} activity panel component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `activitiesPanel` component:
 *
 * @example
 * <ov-videoconference [activitiesPanelRecordingActivity]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ActivitiesPanelComponent}.
 * @example
 * <ov-activities-panel [recordingActivity]="false"></ov-activities-panel>
 */
export declare class ActivitiesPanelRecordingActivityDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    set activitiesPanelRecordingActivity(value: boolean);
    set recordingList(value: boolean);
    recordingActivityValue: boolean;
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    clear(): void;
    update(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActivitiesPanelRecordingActivityDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ActivitiesPanelRecordingActivityDirective, "ov-videoconference[activitiesPanelRecordingActivity], ov-activities-panel[recordingActivity]", never, { "activitiesPanelRecordingActivity": "activitiesPanelRecordingActivity"; "recordingList": "recordingList"; }, {}, never>;
}
