import { AfterViewInit, OnDestroy, ElementRef } from '@angular/core';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import * as i0 from "@angular/core";
/**
 * The **muteButton** directive allows show/hide the muted button in participant panel item component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `participantPanelItem` component:
 *
 * @example
 * <ov-videoconference [participantPanelItemMuteButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ParticipantPanelItemComponent}.
 * @example
 * <ov-participant-panel-item [muteButton]="false"></ov-participant-panel-item>
 */
export declare class ParticipantPanelItemMuteButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    set participantPanelItemMuteButton(value: boolean);
    set muteButton(value: boolean);
    muteValue: boolean;
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    clear(): void;
    update(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ParticipantPanelItemMuteButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ParticipantPanelItemMuteButtonDirective, "ov-videoconference[participantPanelItemMuteButton], ov-participant-panel-item[muteButton]", never, { "participantPanelItemMuteButton": "participantPanelItemMuteButton"; "muteButton": "muteButton"; }, {}, never>;
}
