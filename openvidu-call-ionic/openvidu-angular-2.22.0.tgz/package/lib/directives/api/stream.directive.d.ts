import { AfterViewInit, ElementRef, OnDestroy } from '@angular/core';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import * as i0 from "@angular/core";
/**
 * The **displayParticipantName** directive allows show/hide the participants name in stream component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `stream` component:
 *
 * @example
 * <ov-videoconference [streamDisplayParticipantName]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link StreamComponent}.
 * @example
 * <ov-stream [displayParticipantName]="false"></ov-stream>
 */
export declare class StreamDisplayParticipantNameDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    set streamDisplayParticipantName(value: boolean);
    set displayParticipantName(value: boolean);
    displayParticipantNameValue: boolean;
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    update(value: boolean): void;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StreamDisplayParticipantNameDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<StreamDisplayParticipantNameDirective, "ov-videoconference[streamDisplayParticipantName], ov-stream[displayParticipantName]", never, { "streamDisplayParticipantName": "streamDisplayParticipantName"; "displayParticipantName": "displayParticipantName"; }, {}, never>;
}
/**
 * The **displayAudioDetection** directive allows show/hide the participants audio detection in stream component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `stream` component:
 *
 * @example
 * <ov-videoconference [streamDisplayAudioDetection]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link StreamComponent}.
 * @example
 * <ov-stream [displayAudioDetection]="false"></ov-stream>
 */
export declare class StreamDisplayAudioDetectionDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    set streamDisplayAudioDetection(value: boolean);
    set displayAudioDetection(value: boolean);
    displayAudioDetectionValue: boolean;
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    update(value: boolean): void;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StreamDisplayAudioDetectionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<StreamDisplayAudioDetectionDirective, "ov-videoconference[streamDisplayAudioDetection], ov-stream[displayAudioDetection]", never, { "streamDisplayAudioDetection": "streamDisplayAudioDetection"; "displayAudioDetection": "displayAudioDetection"; }, {}, never>;
}
/**
 * The **settingsButton** directive allows show/hide the participants settings button in stream component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `stream` component:
 *
 * @example
 * <ov-videoconference [streamSettingsButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link StreamComponent}.
 * @example
 * <ov-stream [settingsButton]="false"></ov-stream>
 */
export declare class StreamSettingsButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    set streamSettingsButton(value: boolean);
    set settingsButton(value: boolean);
    settingsValue: boolean;
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    update(value: boolean): void;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StreamSettingsButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<StreamSettingsButtonDirective, "ov-videoconference[streamSettingsButton], ov-stream[settingsButton]", never, { "streamSettingsButton": "streamSettingsButton"; "settingsButton": "settingsButton"; }, {}, never>;
}
