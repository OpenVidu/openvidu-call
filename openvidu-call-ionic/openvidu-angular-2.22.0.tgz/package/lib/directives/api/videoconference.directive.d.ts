import { ElementRef, OnDestroy, OnInit } from '@angular/core';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import { TranslateService } from '../../services/translate/translate.service';
import * as i0 from "@angular/core";
/**
 * The **minimal** directive applies a minimal UI hiding all controls except for cam and mic.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 *  Default: `false`
 *
 * @example
 * <ov-videoconference [minimal]="true"></ov-videoconference>
 */
export declare class MinimalDirective implements OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set minimal(value: boolean);
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    /**
     * @ignore
     */
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    clear(): void;
    /**
     * @ignore
     */
    update(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MinimalDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MinimalDirective, "ov-videoconference[minimal]", never, { "minimal": "minimal"; }, {}, never>;
}
/**
 * The **lang** directive allows et the UI language to a default language.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * **Default:** English `en`
 *
 * **Available:**
 *
 * * English: `en`
 * * Spanish: `es`
 * * German: `de`
 * * French: `fr`
 * * Chinese: `cn`
 * * Hindi: `hi`
 * * Italian: `it`
 * * Japanese: `ja`
 * * Netherlands: `nl`
 * * Portuguese: `pt`
 *
 * @example
 * <ov-videoconference [lang]="es"></ov-videoconference>
 */
export declare class LangDirective implements OnDestroy {
    elementRef: ElementRef;
    private translateService;
    /**
     * @ignore
     */
    set lang(value: string);
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, translateService: TranslateService);
    /**
     * @ignore
     */
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    clear(): void;
    /**
     * @ignore
     */
    update(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LangDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LangDirective, "ov-videoconference[lang]", never, { "lang": "lang"; }, {}, never>;
}
/**
 * The **participantName** directive sets the participant name. It can be useful for aplications which doesn't need the prejoin page.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * @example
 * <ov-videoconference [participantName]="'OpenVidu'"></ov-videoconference>
 */
export declare class ParticipantNameDirective implements OnInit {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    participantName: string;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    /**
     * @ignore
     */
    ngOnInit(): void;
    /**
     * @ignore
     */
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    clear(): void;
    /**
     * @ignore
     */
    update(value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ParticipantNameDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ParticipantNameDirective, "ov-videoconference[participantName]", never, { "participantName": "participantName"; }, {}, never>;
}
/**
 * The **prejoin** directive allows show/hide the prejoin page for selecting media devices.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * Default: `true`
 *
 * @example
 * <ov-videoconference [prejoin]="false"></ov-videoconference>
 */
export declare class PrejoinDirective implements OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set prejoin(value: boolean);
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    /**
     * @ignore
     */
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    clear(): void;
    /**
     * @ignore
     */
    update(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrejoinDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PrejoinDirective, "ov-videoconference[prejoin]", never, { "prejoin": "prejoin"; }, {}, never>;
}
/**
 * The **videoMuted** directive allows to join the session with camera muted/unmuted.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * Default: `false`
 *
 *
 * @example
 * <ov-videoconference [videoMuted]="true"></ov-videoconference>
 */
export declare class VideoMutedDirective implements OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set videoMuted(value: boolean);
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    /**
     * @ignore
     */
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    clear(): void;
    /**
     * @ignore
     */
    update(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VideoMutedDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<VideoMutedDirective, "ov-videoconference[videoMuted]", never, { "videoMuted": "videoMuted"; }, {}, never>;
}
/**
 * The **audioMuted** directive allows to join the session with microphone muted/unmuted.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * Default: `false`
 *
 * @example
 * <ov-videoconference [audioMuted]="true"></ov-videoconference>
 */
export declare class AudioMutedDirective implements OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set audioMuted(value: boolean);
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngOnDestroy(): void;
    /**
     * @ignore
     */
    clear(): void;
    /**
     * @ignore
     */
    update(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AudioMutedDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AudioMutedDirective, "ov-videoconference[audioMuted]", never, { "audioMuted": "audioMuted"; }, {}, never>;
}
