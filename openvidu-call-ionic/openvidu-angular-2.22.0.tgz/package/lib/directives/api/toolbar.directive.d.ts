import { AfterViewInit, ElementRef, OnDestroy } from '@angular/core';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import * as i0 from "@angular/core";
/**
 * The **screenshareButton** directive allows show/hide the screenshare toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarScreenshareButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [screenshareButton]="false"></ov-toolbar>
 */
export declare class ToolbarScreenshareButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarScreenshareButton(value: boolean);
    /**
     * @ignore
     */
    set screenshareButton(value: boolean);
    private screenshareValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarScreenshareButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarScreenshareButtonDirective, "ov-videoconference[toolbarScreenshareButton], ov-toolbar[screenshareButton]", never, { "toolbarScreenshareButton": "toolbarScreenshareButton"; "screenshareButton": "screenshareButton"; }, {}, never>;
}
/**
 * The **recordingButton** directive allows show/hide the start/stop recording toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarRecordingButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [recordingButton]="false"></ov-toolbar>
 *
 * @internal
 */
export declare class ToolbarRecordingButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarRecordingButton(value: boolean);
    /**
     * @ignore
     */
    set recordingButton(value: boolean);
    private recordingValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarRecordingButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarRecordingButtonDirective, "ov-videoconference[toolbarRecordingButton], ov-toolbar[recordingButton]", never, { "toolbarRecordingButton": "toolbarRecordingButton"; "recordingButton": "recordingButton"; }, {}, never>;
}
/**
 * The **fullscreenButton** directive allows show/hide the fullscreen toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarFullscreenButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [fullscreenButton]="false"></ov-toolbar>
 */
export declare class ToolbarFullscreenButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarFullscreenButton(value: boolean);
    /**
     * @ignore
     */
    set fullscreenButton(value: boolean);
    private fullscreenValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarFullscreenButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarFullscreenButtonDirective, "ov-videoconference[toolbarFullscreenButton], ov-toolbar[fullscreenButton]", never, { "toolbarFullscreenButton": "toolbarFullscreenButton"; "fullscreenButton": "fullscreenButton"; }, {}, never>;
}
/**
 * The **backgroundEffectsButton** directive allows show/hide the background effects toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarBackgroundEffectsButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [backgroundEffectsButton]="false"></ov-toolbar>
 */
export declare class ToolbarBackgroundEffectsButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarBackgroundEffectsButton(value: boolean);
    /**
     * @ignore
     */
    set backgroundEffectsButton(value: boolean);
    private backgroundEffectsValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarBackgroundEffectsButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarBackgroundEffectsButtonDirective, "ov-videoconference[toolbarBackgroundEffectsButton], ov-toolbar[backgroundEffectsButton]", never, { "toolbarBackgroundEffectsButton": "toolbarBackgroundEffectsButton"; "backgroundEffectsButton": "backgroundEffectsButton"; }, {}, never>;
}
/**
 * The **captionsButton** directive allows show/hide the captions toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarCaptionsButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [captionsButton]="false"></ov-toolbar>
 */
export declare class ToolbarCaptionsButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarCaptionsButton(value: boolean);
    /**
     * @ignore
     */
    set captionsButton(value: boolean);
    private captionsButtonValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarCaptionsButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarCaptionsButtonDirective, "ov-videoconference[toolbarCaptionsButton], ov-toolbar[captionsButton]", never, { "toolbarCaptionsButton": "toolbarCaptionsButton"; "captionsButton": "captionsButton"; }, {}, never>;
}
/**
 * The **settingsButton** directive allows show/hide the settings toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarSettingsButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [settingsButton]="false"></ov-toolbar>
 */
export declare class ToolbarSettingsButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarSettingsButton(value: boolean);
    /**
     * @ignore
     */
    set settingsButton(value: boolean);
    private settingsValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarSettingsButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarSettingsButtonDirective, "ov-videoconference[toolbarSettingsButton], ov-toolbar[settingsButton]", never, { "toolbarSettingsButton": "toolbarSettingsButton"; "settingsButton": "settingsButton"; }, {}, never>;
}
/**
 * The **leaveButton** directive allows show/hide the leave toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarLeaveButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [leaveButton]="false"></ov-toolbar>
 */
export declare class ToolbarLeaveButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarLeaveButton(value: boolean);
    /**
     * @ignore
     */
    set leaveButton(value: boolean);
    private leaveValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarLeaveButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarLeaveButtonDirective, "ov-videoconference[toolbarLeaveButton], ov-toolbar[leaveButton]", never, { "toolbarLeaveButton": "toolbarLeaveButton"; "leaveButton": "leaveButton"; }, {}, never>;
}
/**
 * The **participantsPanelButton** directive allows show/hide the participants panel toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarParticipantsPanelButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [participantsPanelButton]="false"></ov-toolbar>
 */
export declare class ToolbarParticipantsPanelButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarParticipantsPanelButton(value: boolean);
    /**
     * @ignore
     */
    set participantsPanelButton(value: boolean);
    private participantsPanelValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarParticipantsPanelButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarParticipantsPanelButtonDirective, "ov-videoconference[toolbarParticipantsPanelButton], ov-toolbar[participantsPanelButton]", never, { "toolbarParticipantsPanelButton": "toolbarParticipantsPanelButton"; "participantsPanelButton": "participantsPanelButton"; }, {}, never>;
}
/**
 * The **chatPanelButton** directive allows show/hide the chat panel toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarChatPanelButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [chatPanelButton]="false"></ov-toolbar>
 */
export declare class ToolbarChatPanelButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarChatPanelButton(value: boolean);
    /**
     * @ignore
     */
    set chatPanelButton(value: boolean);
    private toolbarChatPanelValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarChatPanelButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarChatPanelButtonDirective, "ov-videoconference[toolbarChatPanelButton], ov-toolbar[chatPanelButton]", never, { "toolbarChatPanelButton": "toolbarChatPanelButton"; "chatPanelButton": "chatPanelButton"; }, {}, never>;
}
/**
 * The **activitiesPanelButton** directive allows show/hide the activities panel toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarActivitiesPanelButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [activitiesPanelButton]="false"></ov-toolbar>
 *
 * @internal
 */
export declare class ToolbarActivitiesPanelButtonDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarActivitiesPanelButton(value: boolean);
    /**
     * @ignore
     */
    set activitiesPanelButton(value: boolean);
    private toolbarActivitiesPanelValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarActivitiesPanelButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarActivitiesPanelButtonDirective, "ov-videoconference[toolbarActivitiesPanelButton], ov-toolbar[activitiesPanelButton]", never, { "toolbarActivitiesPanelButton": "toolbarActivitiesPanelButton"; "activitiesPanelButton": "activitiesPanelButton"; }, {}, never>;
}
/**
 * The **displaySessionName** directive allows show/hide the session name.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarDisplaySessionName]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [displaySessionName]="false"></ov-toolbar>
 */
export declare class ToolbarDisplaySessionNameDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarDisplaySessionName(value: boolean);
    /**
     * @ignore
     */
    set displaySessionName(value: boolean);
    private displaySessionValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarDisplaySessionNameDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarDisplaySessionNameDirective, "ov-videoconference[toolbarDisplaySessionName], ov-toolbar[displaySessionName]", never, { "toolbarDisplaySessionName": "toolbarDisplaySessionName"; "displaySessionName": "displaySessionName"; }, {}, never>;
}
/**
 * The **displayLogo** directive allows show/hide the branding logo.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarDisplayLogo]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [displayLogo]="false"></ov-toolbar>
 */
export declare class ToolbarDisplayLogoDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    /**
     * @ignore
     */
    set toolbarDisplayLogo(value: boolean);
    /**
     * @ignore
     */
    set displayLogo(value: boolean);
    private displayLogoValue;
    /**
     * @ignore
     */
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private clear;
    private update;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarDisplayLogoDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ToolbarDisplayLogoDirective, "ov-videoconference[toolbarDisplayLogo], ov-toolbar[displayLogo]", never, { "toolbarDisplayLogo": "toolbarDisplayLogo"; "displayLogo": "displayLogo"; }, {}, never>;
}
