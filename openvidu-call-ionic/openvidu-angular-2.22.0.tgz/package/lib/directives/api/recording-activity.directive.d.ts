import { AfterViewInit, OnDestroy, ElementRef } from '@angular/core';
import { RecordingInfo } from '../../models/recording.model';
import { OpenViduAngularConfigService } from '../../services/config/openvidu-angular.config.service';
import * as i0 from "@angular/core";
/**
 * The **recordingsList** directive allows show the recordings available for the session in {@link RecordingActivityComponent}.
 *
 * Default: `[]`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `recordingActivity` component:
 *
 * @example
 * <ov-videoconference [recordingActivityRecordingsList]="list"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link RecordingActivityComponent}.
 * @example
 * <ov-recording-activity [recordingsList]="list"></ov-recording-activity>
 */
export declare class RecordingActivityRecordingsListDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    set recordingActivityRecordingsList(value: RecordingInfo[]);
    set recordingsList(value: RecordingInfo[]);
    recordingsValue: RecordingInfo[];
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    clear(): void;
    update(value: RecordingInfo[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordingActivityRecordingsListDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RecordingActivityRecordingsListDirective, "ov-videoconference[recordingActivityRecordingsList], ov-recording-activity[recordingsList]", never, { "recordingActivityRecordingsList": "recordingActivityRecordingsList"; "recordingsList": "recordingsList"; }, {}, never>;
}
/**
 * The **recordingError** directive allows to show any possible error with the recording in the {@link RecordingActivityComponent}.
 *
 * Default: `[]`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `recordingActivity` component:
 *
 * @example
 * <ov-videoconference [recordingActivityRecordingError]="error"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link RecordingActivityComponent}.
 * @example
 * <ov-recording-activity [recordingError]="error"></ov-recording-activity>
 */
export declare class RecordingActivityRecordingErrorDirective implements AfterViewInit, OnDestroy {
    elementRef: ElementRef;
    private libService;
    set recordingActivityRecordingError(value: any);
    set recordingError(value: any);
    recordingErrorValue: RecordingInfo[];
    constructor(elementRef: ElementRef, libService: OpenViduAngularConfigService);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    clear(): void;
    update(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RecordingActivityRecordingErrorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RecordingActivityRecordingErrorDirective, "ov-videoconference[recordingActivityRecordingError], ov-recording-activity[recordingError]", never, { "recordingActivityRecordingError": "recordingActivityRecordingError"; "recordingError": "recordingError"; }, {}, never>;
}
