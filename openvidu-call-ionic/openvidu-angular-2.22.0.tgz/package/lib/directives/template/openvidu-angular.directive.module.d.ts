import * as i0 from "@angular/core";
import * as i1 from "./openvidu-angular.directive";
export declare class OpenViduAngularDirectiveModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenViduAngularDirectiveModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OpenViduAngularDirectiveModule, [typeof i1.ChatPanelDirective, typeof i1.LayoutDirective, typeof i1.PanelDirective, typeof i1.AdditionalPanelsDirective, typeof i1.ParticipantPanelItemDirective, typeof i1.ParticipantsPanelDirective, typeof i1.StreamDirective, typeof i1.ToolbarDirective, typeof i1.ToolbarAdditionalButtonsDirective, typeof i1.ToolbarAdditionalPanelButtonsDirective, typeof i1.ParticipantPanelItemElementsDirective, typeof i1.ActivitiesPanelDirective, typeof i1.BackgroundEffectsPanelDirective], never, [typeof i1.ChatPanelDirective, typeof i1.LayoutDirective, typeof i1.PanelDirective, typeof i1.AdditionalPanelsDirective, typeof i1.ParticipantPanelItemDirective, typeof i1.ParticipantsPanelDirective, typeof i1.StreamDirective, typeof i1.ToolbarDirective, typeof i1.ToolbarAdditionalButtonsDirective, typeof i1.ToolbarAdditionalPanelButtonsDirective, typeof i1.ParticipantPanelItemElementsDirective, typeof i1.ActivitiesPanelDirective, typeof i1.BackgroundEffectsPanelDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OpenViduAngularDirectiveModule>;
}
