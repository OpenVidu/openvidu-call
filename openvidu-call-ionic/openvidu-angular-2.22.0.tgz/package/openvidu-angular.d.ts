/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="openvidu-angular" />
export * from './public-api';
