import * as i9 from '@angular/forms';
import { FormControl, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i1$3 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i10 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Directive, Injectable, Inject, Pipe, Component, Input, HostListener, EventEmitter, TemplateRef, ChangeDetectionStrategy, ContentChild, Output, ViewChild, ElementRef, ViewChildren, ViewContainerRef, NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { OverlayContainer } from '@angular/cdk/overlay';
import { __awaiter } from 'tslib';
import { BehaviorSubject, skip } from 'rxjs';
import * as i18 from '@angular/material/menu';
import { MatMenuTrigger, MatMenuModule } from '@angular/material/menu';
import * as i1 from '@angular/flex-layout';
import { BREAKPOINT, LayoutDirective as LayoutDirective$1, FlexLayoutModule } from '@angular/flex-layout';
import { BehaviorSubject as BehaviorSubject$1 } from 'rxjs/internal/BehaviorSubject';
import { OpenVidu, OpenViduErrorName } from 'openvidu-browser';
import * as i1$1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i3 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i1$2 from '@angular/material/snack-bar';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import * as i2 from '@angular/platform-browser';
import * as i15 from '@angular/material/toolbar';
import { MatToolbarModule } from '@angular/material/toolbar';
import * as i4 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i19 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i5 from '@angular/flex-layout/flex';
import * as i6 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i24 from '@angular/material/badge';
import { MatBadgeModule } from '@angular/material/badge';
import * as i2$1 from '@angular/flex-layout/extended';
import { Autolinker } from 'autolinker';
import * as i13 from '@angular/material/sidenav';
import { MatSidenavModule } from '@angular/material/sidenav';
import { LoremIpsum } from 'lorem-ipsum';
import { trigger, transition, style, animate } from '@angular/animations';
import * as i15$1 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i5$1 from '@angular/material/list';
import { MatListModule } from '@angular/material/list';
import * as i6$1 from '@angular/material/core';
import { MatOptionModule } from '@angular/material/core';
import * as i10$2 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i10$1 from '@angular/material/select';
import { MatSelect, MatSelectModule } from '@angular/material/select';
import * as i9$1 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i3$1 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import * as i5$2 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import * as i5$3 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatSliderModule } from '@angular/material/slider';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

var PanelType;
(function (PanelType) {
    PanelType["CHAT"] = "chat";
    PanelType["PARTICIPANTS"] = "participants";
    PanelType["BACKGROUND_EFFECTS"] = "background-effects";
    PanelType["ACTIVITIES"] = "activities";
    PanelType["SETTINGS"] = "settings";
})(PanelType || (PanelType = {}));
var PanelSettingsOptions;
(function (PanelSettingsOptions) {
    PanelSettingsOptions["GENERAL"] = "general";
    PanelSettingsOptions["AUDIO"] = "audio";
    PanelSettingsOptions["VIDEO"] = "video";
    PanelSettingsOptions["SUBTITLES"] = "subtitles";
})(PanelSettingsOptions || (PanelSettingsOptions = {}));

/**
 * The ***ovToolbar** directive allows to replace the default toolbar component with a custom one.
 * In the example below we've replaced the default toolbar and added the **toggleAudio** and **toggleVideo** buttons.
 * Here we are using the {@link OpenViduService} for publishing/unpublishing the audio and video.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-custom-toolbar#running-this-tutorial).
 *
 *```html
 *<ov-videoconference [tokens]="tokens">
 *	<div *ovToolbar style="text-align: center;">
 *		<button (click)="toggleVideo()">Toggle Video</button>
 *		<button (click)="toggleAudio()">Toggle Audio</button>
 *	</div>
 *</ov-videoconference>
 * ```
 *
 * ```javascript
 * export class ToolbarDirectiveComponent {
 *
 *	sessionId = 'toolbar-directive-example';
 *	tokens!: TokenModel;
 *
 *	publishVideo = true;
 *	publishAudio = true;
 *
 *	constructor(private httpClient: HttpClient, private openviduService: OpenViduService) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken()
 *		};
 *	}
 *
 *	toggleVideo() {
 *		this.publishVideo = !this.publishVideo;
 *		this.openviduService.publishVideo(this.publishVideo);
 *	}
 *
 *	toggleAudio() {
 *		this.publishAudio = !this.publishAudio;
 *		this.openviduService.publishAudio(this.publishAudio);
 *	}
 *
 *	async getToken(): Promise<string> {
 * 		// Returns an OpeVidu token
 * 	}
 *
 * }
 * ```
 *
 */
class ToolbarDirective {
    /**
     * @ignore
     */
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
ToolbarDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarDirective, selector: "[ovToolbar]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovToolbar]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovToolbarAdditionalButtons** directive allows to add additional buttons to center buttons group.
 * In the example below we've added the same buttons as the {@link ToolbarDirective}.
 * Here we are using the {@link ParticipantService} to check the audio or video status.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-toolbar-buttons#running-this-tutorial).
 *
 *```html
 *<ov-videoconference [tokens]="tokens" [toolbarDisplaySessionName]="false">
 *	<div *ovToolbarAdditionalButtons style="text-align: center;">
 *		<button mat-icon-button (click)="toggleVideo()">
 *			<mat-icon>videocam</mat-icon>
 *		</button>
 *		<button mat-icon-button (click)="toggleAudio()">
 *			<mat-icon>mic</mat-icon>
 *		</button>
 *	</div>
 *</ov-videoconference>
 * ```
 *
 * ```javascript
 * export class ToolbarAdditionalButtonsDirectiveComponent {
 *
    sessionId = "panel-directive-example";
    tokens!: TokenModel;

   
 *	sessionId = 'toolbar-additionalbtn-directive-example';
 *	tokens!: TokenModel;
 *
 *	constructor(
 *		private httpClient: HttpClient,
 *		private openviduService: OpenViduService,
 *		private participantService: ParticipantService
 *	) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken()
 *		};
 *	}
 *
 *	toggleVideo() {
 *		const publishVideo = !this.participantService.isMyVideoActive();
 *		this.openviduService.publishVideo(publishVideo);
 *	}
 *
 *	toggleAudio() {
 *		const publishAudio = !this.participantService.isMyAudioActive();
 *		this.openviduService.publishAudio(publishAudio);
 *	}
 *
 *	async getToken(): Promise<string> {
 * 		// Returns an OpeVidu token
 * 	}
 *
 * }
 * ```
 */
class ToolbarAdditionalButtonsDirective {
    /**
     * @ignore
     */
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
ToolbarAdditionalButtonsDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarAdditionalButtonsDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarAdditionalButtonsDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarAdditionalButtonsDirective, selector: "[ovToolbarAdditionalButtons]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarAdditionalButtonsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovToolbarAdditionalButtons]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovToolbarAdditionalPanelButtons** directive allows to add additional **panel buttons** to the toolbar.
 * In the example below we've added a simple button without any functionality. To learn how to toggle the panel check the {@link AdditionalPanelsDirective}.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-toolbar-panel-buttons#running-this-tutorial).
 *
 *```html
 *<ov-videoconference [tokens]="tokens" [toolbarDisplaySessionName]="false">
 *	<div *ovToolbarAdditionalPanelButtons style="text-align: center;">
 *		<button (click)="onButtonClicked()">MY PANEL</button>
 *	</div>
 *</ov-videoconference>
 * ```
 *
 * ```javascript
 * export class ToolbarAdditionalPanelButtonsDirectiveComponent {
 *
 *  sessionId = "toolbar-additionalPanelbtn";
 *  tokens!: TokenModel;
 *
 *  constructor(private httpClient: HttpClient) { }
 *
 * async ngOnInit() {
 *    this.tokens = {
 *     webcam: await this.getToken(),
 *      screen: await this.getToken(),
 *    };
 *  }
 *
 *  onButtonClicked() {
 *    alert('button clicked');
 *  }
 *
 *  async getToken(): Promise<string> {
 *    // Returns an OpeVidu token
 *  }
 *
 * }
 * ```
 */
class ToolbarAdditionalPanelButtonsDirective {
    /**
     * @ignore
     */
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
ToolbarAdditionalPanelButtonsDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarAdditionalPanelButtonsDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarAdditionalPanelButtonsDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarAdditionalPanelButtonsDirective, selector: "[ovToolbarAdditionalPanelButtons]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarAdditionalPanelButtonsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovToolbarAdditionalPanelButtons]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovPanel** directive allows to replace the default panels with your own custom panels. This directive also allows to insert elements
 * tagged with the {@link ChatPanelDirective}, {@link ParticipantsPanelDirective} and {@link AdditionalPanelsDirective}.
 *
 * In the example below we replace the entire {@link PanelComponent} using the ***ovPanel** directive. Inside of it, we customize
 * the {@link ParticipantsPanelComponent} and {@link ChatPanelcomponent} using their own directives.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-custom-panels#running-this-tutorial).
 *
 *```html
 *<ov-videoconference [tokens]="tokens">
 *	<ov-panel *ovPanel>
 *		<div *ovChatPanel id="my-chat-panel">This is my custom chat panel</div>
 *		<div *ovParticipantsPanel id="my-participants-panel">
 *			This is my custom participants panel
 *		</div>
 *	</ov-panel>
 *</ov-videoconference>
 * ```
 *
 * ```javascript
 * export class PanelDirectiveComponent {
 *
 *	sessionId = "panel-directive-example";
 *	tokens!: TokenModel;
 *
 *	constructor(private httpClient: HttpClient) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken(),
 *		};
 *	}
 *
 *	async getToken(): Promise<string> {
 *		// Returns an OpeVidu token
 *	}
 *
 * }
 * ```
 */
class PanelDirective {
    /**
     * @ignore
     */
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
PanelDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PanelDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
PanelDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: PanelDirective, selector: "[ovPanel]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PanelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovPanel]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovAdditionalPanels** directive allows to add more extra panels to the {@link PanelComponent}. In this example we add a new
 * panel alongside the default ones.
 *
 * To mimic the toggling behavior of the default panels, we need to add a new button in the {@link ToolbarComponent}
 * using the {@link ToolbarAdditionalPanelButtonsDirective}.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-additional-panels#running-this-tutorial).
 *
 *```html
 *<ov-videoconference [tokens]="tokens" [toolbarDisplaySessionName]="false">
 *	<div *ovToolbarAdditionalPanelButtons style="text-align: center;">
 *		<button mat-icon-button (click)="toggleMyPanel('my-panel')">
 *			<mat-icon>360</mat-icon>
 *		</button>
 *		<button mat-icon-button (click)="toggleMyPanel('my-panel2')">
 *			<mat-icon>star</mat-icon>
 *		</button>
 *	</div>
 *	<div *ovAdditionalPanels id="my-panels">
 *		<div id="my-panel1" *ngIf="showExternalPanel">
 *			<h2>NEW PANEL</h2>
 *			<p>This is my new additional panel</p>
 *		</div>
 *		<div id="my-panel2" *ngIf="showExternalPanel2">
 *			<h2>NEW PANEL 2</h2>
 *			<p>This is other new panel</p>
 *		</div>
 *	</div>
 *</ov-videoconference>
 * ```
 * <br/>
 *
 * We need to subscribe to the {@link ../injectables/PanelService.html#panelOpenedObs panelOpenedObs} Observable to listen to the panel status and update our boolean variables
 * (`showExternalPanel` and `showExternalPanel2`) in charge of showing or hiding them.
 *
 * ```javascript
 * export class AdditionalPanelsDirectiveComponent implements OnInit {
 *
 *	sessionId = "toolbar-additionalbtn-directive-example";
 *	tokens!: TokenModel;
 *
 *	showExternalPanel: boolean = false;
 *	showExternalPanel2: boolean = false;
 *
 *	constructor(
 *		private httpClient: HttpClient,
 *		private panelService: PanelService
 *	) { }
 *
 *	async ngOnInit() {
 *		this.subscribeToPanelToggling();
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken(),
 *		};
 *	}
 *
 *	subscribeToPanelToggling() {
 *		this.panelService.panelOpenedObs.subscribe(
 *			(ev: { opened: boolean; type?: PanelType | string }) => {
 *				this.showExternalPanel = ev.opened && ev.type === "my-panel";
 *				this.showExternalPanel2 = ev.opened && ev.type === "my-panel2";
 *			}
 *		);
 *	}
 *
 *	toggleMyPanel(type: string) {
 *		this.panelService.togglePanel(type);
 *	}
 *
 *	async getToken(): Promise<string> {
 *		// Returns an OpeVidu token
 *	}
 *
 * }
 * ```
 */
class AdditionalPanelsDirective {
    /**
     * @ignore
     */
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
AdditionalPanelsDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdditionalPanelsDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
AdditionalPanelsDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: AdditionalPanelsDirective, selector: "[ovAdditionalPanels]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdditionalPanelsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovAdditionalPanels]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovChatPanel** directive allows to replace the default chat panel template with a custom one.
 * In the example below we replace the chat template in a few lines of code.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-custom-chat-panel#running-this-tutorial).
 *
 * ```html
 *<ov-videoconference
 *	(onSessionCreated)="onSessionCreated($event)"
 *	[tokens]="tokens"
 *	[toolbarDisplaySessionName]="false">
 *	<div *ovChatPanel id="my-panel">
 *		<h3>Chat</h3>
 *		<div>
 *			<ul>
 *				<li *ngFor="let msg of messages">{{ msg }}</li>
 *			</ul>
 *		</div>
 *		<input value="Hello" #input />
 *		<button (click)="send(input.value)">Send</button>
 *	</div>
 *</ov-videoconference>
 *```
 * <br/>
 *
 * As we need to get the openvidu-browser **[Session](https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Session.html)**
 * object for sending messages to others, we can get it from the `onSessionCreated` event fired by the {@link VideoconferenceComponent}
 * when the session has been created.
 *
 * Once we have the session created, we can use the
 * [signal](https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Session.html#signal) method to send our messages.
 *
 * ```javascript
 * export class ChatPanelDirectiveComponent {
 *
 *	sessionId = "chat-panel-directive-example";
 *	tokens!: TokenModel;
 *
 *	session!: Session;
 *	messages: string[] = [];
 *
 *	constructor(private httpClient: HttpClient) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken(),
 *		};
 *	}
 *
 *	onSessionCreated(session: Session) {
 *		this.session = session;
 *		this.session.on(`signal:${Signal.CHAT}`, (event: any) => {
 *			const msg = JSON.parse(event.data).message;
 *			this.messages.push(msg);
 *		});
 *	}
 *
 *	send(message: string): void {
 *		const signalOptions: SignalOptions = {
 *			data: JSON.stringify({ message }),
 *			type: Signal.CHAT,
 *			to: undefined,
 *		};
 *		this.session.signal(signalOptions);
 *	}
 *
 *	async getToken(): Promise<string> {
 *		// Returns an OpeVidu token
 *	}
 *
 * }
 * ```
 *
 */
class ChatPanelDirective {
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
ChatPanelDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ChatPanelDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
ChatPanelDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ChatPanelDirective, selector: "[ovChatPanel]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ChatPanelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovChatPanel]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * backgroundEffectsPanel does not provide any customization for now
 * @internal
 */
class BackgroundEffectsPanelDirective {
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
BackgroundEffectsPanelDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: BackgroundEffectsPanelDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
BackgroundEffectsPanelDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: BackgroundEffectsPanelDirective, selector: "[ovBackgroundEffectsPanel]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: BackgroundEffectsPanelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovBackgroundEffectsPanel]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovActivitiesPanel** directive allows to replace the default activities panel template with a custom one.
 * In the example below we replace the activities template in a few lines of code.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-custom-activities-panel#running-this-tutorial).
 *
 * ```html
 *<ov-videoconference
 *	[tokens]="tokens"
 *	[toolbarRecordingButton]="false"
 *	[toolbarDisplaySessionName]="false">
 *	<div *ovActivitiesPanel id="my-panel">
 *		<h3>ACTIVITIES</h3>
 *		<div>
 *			CUSTOM ACTIVITIES
 *		</div>
 *	</div>
 *</ov-videoconference>
 *```
 * <br/>
 *
 * As we need to assign the OpenVidu Tokens to the {@link VideoconferenceComponent}, we request them on the ngOnInit Angular lifecycle hook.
 *
 * ```javascript
 * export class AppComponent implements OnInit {
 *
 *	sessionId = "activities-panel-directive-example";
 *	tokens!: TokenModel;
 *
 *	constructor(private httpClient: HttpClient) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken(),
 *		};
 *	}
 *
 *	async getToken(): Promise<string> {
 *		// Returns an OpeVidu token
 *	}
 *
 *}
 * ```
 *
 */
class ActivitiesPanelDirective {
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
ActivitiesPanelDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ActivitiesPanelDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
ActivitiesPanelDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ActivitiesPanelDirective, selector: "[ovActivitiesPanel]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ActivitiesPanelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovActivitiesPanel]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovParticipantsPanel** directive allows to replace the default participants panel template with a custom one.
 * In the example below we replace the participants template in a few lines of code.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-custom-participants-panel#running-this-tutorial).
 *
 * ```html
 *<ov-videoconference [tokens]="tokens" [toolbarDisplaySessionName]="false" (onSessionCreated)="subscribeToParticipants()">
 *	<div *ovParticipantsPanel id="my-panel">
 *		<ul id="local">
 *			<li>{{localParticipant.nickname}}</li>
 *		</ul>
 *		<ul id="remote">
 *			<li *ngFor="let p of remoteParticipants">{{p.nickname}}</li>
 *		</ul>
 *	</div>
 *</ov-videoconference>
 *```
 * <br/>
 *
 * We need to get the participants in our Session, so we use the {@link ParticipantService} to subscribe to the required Observables.
 * We'll get the local participant and the remote participants to update our custom participants panel on any change.
 *
 * ```javascript
 * export class ParticipantsPanelDirectiveComponent implements OnInit, OnDestroy {
 *
 *	sessionId = 'participants-panel-directive-example';
 *	tokens!: TokenModel;
 *
 *	localParticipant!: ParticipantAbstractModel;
 *	remoteParticipants!: ParticipantAbstractModel[];
 *	localParticipantSubs!: Subscription;
 *	remoteParticipantsSubs!: Subscription;
 *
 *	constructor(private httpClient: HttpClient, private participantService: ParticipantService) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken()
 *		};
 *	}
 *
 *	ngOnDestroy() {
 *		this.localParticipantSubs.unsubscribe();
 *		this.remoteParticipantsSubs.unsubscribe();
 *	}
 *
 *	subscribeToParticipants() {
 *		this.localParticipantSubs = this.participantService.localParticipantObs.subscribe((p) => {
 *			this.localParticipant = p;
 *		});
 *		this.remoteParticipantsSubs = this.participantService.remoteParticipantsObs.subscribe((participants) => {
 *			this.remoteParticipants = participants;
 *		});
 *	}
 *
 *	async getToken(): Promise<string> {
 *		// Returns an OpeVidu token
 *	}
 *
 * }
 * ```
 *
 */
class ParticipantsPanelDirective {
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
ParticipantsPanelDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantsPanelDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
ParticipantsPanelDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ParticipantsPanelDirective, selector: "[ovParticipantsPanel]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantsPanelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovParticipantsPanel]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovParticipantPanelItem** directive allows to replace the default participant panel item template in the {@link ParticipantsPanelComponent} with a custom one.
 *
 * With ***ovParticipantPanelItem** directive we can access the participant object from its context using the `let` keyword and referencing the `participant`
 * variable: `*ovParticipantPanelItem="let participant"`. Now we can access the {@link ParticipantAbstractModel} object.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-custom-participant-panel-item#running-this-tutorial).
 *
 * ```html
 *<ov-videoconference [tokens]="tokens" [toolbarDisplaySessionName]="false">
 *	<div *ovParticipantPanelItem="let participant" style="display: flex">
 *		<p>{{ participant.nickname }}</p>
 *		<button mat-icon-button [matMenuTriggerFor]="menu"><mat-icon>more_vert</mat-icon></button>
 *		<mat-menu #menu="matMenu">
 *			<button mat-menu-item>Button 1</button>
 *			<button mat-menu-item>Button 2</button>
 *		</mat-menu>
 *	</div>
 *</ov-videoconference>
 *```
 *
 * ```javascript
 * export class ParticipantPanelItemDirectiveComponent {
 *
 *	sessionId = 'participants-panel-directive-example';
 *	tokens!: TokenModel;
 *
 *	constructor(private httpClient: HttpClient) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken()
 *		};
 *	}
 *
 * 	async getToken(): Promise<string> {
 *		// Returns an OpeVidu token
 *	}
 *
 * }
 * ```
 *
 */
class ParticipantPanelItemDirective {
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
ParticipantPanelItemDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantPanelItemDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
ParticipantPanelItemDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ParticipantPanelItemDirective, selector: "[ovParticipantPanelItem]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantPanelItemDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovParticipantPanelItem]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovParticipantPanelItemElements** directive allows to add elements to the {@link ParticipantsPanelItemComponent}.
 * In the example below we add a simple button to disconnect from the session.
 *
 * With ***ovParticipantPanelItemElements** directive we can access the participant object from its context using
 * the `let` keyword and referencing the `participant` variable: `*ovParticipantPanelItem="let participant"`.
 * Now we can access the {@link ParticipantAbstractModel} object and enable the button just for the local participant.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-custom-participant-panel-item-element#running-this-tutorial).
 *
 * ```html
 *<ov-videoconference
 *	*ngIf="connected"
 *	[tokens]="tokens"
 *	[toolbarDisplaySessionName]="false">
 *	<div *ovParticipantPanelItemElements="let participant">
 *		<button *ngIf="participant.local" (click)="leaveSession()">
 *			Leave
 *		</button>
 *	</div>
 *</ov-videoconference>
 *<div *ngIf="!connected" style="text-align: center;">Session disconnected</div>
 *```
 *
 * ```javascript
 * export class ParticipantPanelItemElementsDirectiveComponent {
 *
 *	sessionId = "participants-panel-directive-example";
 *	tokens!: TokenModel;
 *
 *	connected = true;
 *
 *	constructor(private httpClient: HttpClient, private openviduService: OpenViduService) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken(),
 *		};
 *	}
 *
 *	leaveSession() {
 *		this.openviduService.disconnect();
 *		this.connected = false;
 *	}
 *
 * 	async getToken(): Promise<string> {
 *		// Returns an OpeVidu token
 *	}
 *
 * }
 * ```
 */
class ParticipantPanelItemElementsDirective {
    constructor(template, viewContainer) {
        this.template = template;
        this.viewContainer = viewContainer;
    }
}
ParticipantPanelItemElementsDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantPanelItemElementsDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
ParticipantPanelItemElementsDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ParticipantPanelItemElementsDirective, selector: "[ovParticipantPanelItemElements]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantPanelItemElementsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovParticipantPanelItemElements]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovLayout** directive allows to replace the default session layout with a custom one.
 *
 * As the deafult {@link StreamComponent} needs the participant stream, and as the participants streams extraction is not trivial,
 * openvidu-angular provides a {@link ParticipantStreamsPipe} for easy extraction of the stream of each participant. In the example
 * below you can see that on the HTML template, as the last component of the `*ngFor` statements (`| streams`).
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-custom-layout#running-this-tutorial).
 *
 * ```html
 *<ov-videoconference [tokens]="tokens" (onSessionCreated)="subscribeToParticipants()">
 *	<div *ovLayout>
 *		<div class="container">
 *			<div class="item" *ngFor="let stream of localParticipant | streams">
 *				<ov-stream [stream]="stream"></ov-stream>
 *			</div>
 *			<div class="item" *ngFor="let stream of remoteParticipants | streams">
 *				<ov-stream [stream]="stream"></ov-stream>
 *			</div>
 *		</div>
 *	</div>
 *</ov-videoconference>
 *```
 *
 * We need to get the participants in our Session, so we use the {@link ParticipantService} to subscribe to the required Observables.
 * We'll get the local participant and the remote participants to display their streams in our custom session layout.
 *
 * ```javascript
 * export class LayoutDirectiveComponent implements OnInit, OnDestroy {
 *
 * 	sessionId = 'layout-directive-example';
 *	tokens!: TokenModel;
 *
 *	localParticipant!: ParticipantAbstractModel;
 *	remoteParticipants!: ParticipantAbstractModel[];
 *	localParticipantSubs!: Subscription;
 *	remoteParticipantsSubs!: Subscription;
 *
 *	constructor(private httpClient: HttpClient, private participantService: ParticipantService) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken()
 *		};
 *	}
 *
 *	ngOnDestroy() {
 *		this.localParticipantSubs.unsubscribe();
 *		this.remoteParticipantsSubs.unsubscribe();
 *	}
 *
 *	subscribeToParticipants() {
 *		this.localParticipantSubs = this.participantService.localParticipantObs.subscribe((p) => {
 *			this.localParticipant = p;
 *		});
 *
 *		this.remoteParticipantsSubs = this.participantService.remoteParticipantsObs.subscribe((participants) => {
 *			this.remoteParticipants = participants;
 *		});
 *	}
 *
 * 	async getToken(): Promise<string> {
 *		// Returns an OpeVidu token
 *	}
 *
 * }
 * ```
 */
class LayoutDirective {
    constructor(template, container) {
        this.template = template;
        this.container = container;
    }
}
LayoutDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LayoutDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
LayoutDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: LayoutDirective, selector: "[ovLayout]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LayoutDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovLayout]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });
/**
 * The ***ovStream** directive allows to replace the default {@link StreamComponent} template injecting a custom one.
 * In the example below we customize the participant's nickname position and styles, replacing the default stream component.
 *
 * With ***ovStream** directive we can access to the stream object from its context using the `let` keyword and
 * referencing the `stream` variable: `*ovStream="let stream"`. Now we can access the {@link StreamModel} object.
 *
 * You can run the associated tutorial [here](https://docs.openvidu.io/en/stable/components/openvidu-custom-stream#running-this-tutorial).
 *
 * ```html
 *<ov-videoconference [tokens]="tokens">
 *	<div *ovStream="let stream">
 *		<ov-stream [stream]="stream" [displayParticipantName]="false"></ov-stream>
 *		<p>{{ stream.participant.nickname }}</p>
 *	</div>
 *</ov-videoconference>
 * ```
 *
 * ```javascript
 * export class StreamDirectiveComponent {
 *
 *	sessionId = 'toolbar-directive-example';
 *	tokens!: TokenModel;
 *
 *	constructor(private httpClient: HttpClient) { }
 *
 *	async ngOnInit() {
 *		this.tokens = {
 *			webcam: await this.getToken(),
 *			screen: await this.getToken()
 *		};
 *	}
 *
 * 	async getToken(): Promise<string> {
 *		// Returns an OpeVidu token
 *	}
 *
 * }
 * ```
 */
class StreamDirective {
    constructor(template, container) {
        this.template = template;
        this.container = container;
    }
}
StreamDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
StreamDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: StreamDirective, selector: "[ovStream]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ovStream]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }]; } });

var VideoType;
(function (VideoType) {
    VideoType["CAMERA"] = "CAMERA";
    VideoType["SCREEN"] = "SCREEN";
    VideoType["CUSTOM"] = "CUSTOM";
})(VideoType || (VideoType = {}));
/**
 * @internal
 */
var ScreenType;
(function (ScreenType) {
    ScreenType["WINDOW"] = "window";
    ScreenType["SCREEN"] = "screen";
})(ScreenType || (ScreenType = {}));

/**
 * @internal
 */
var OpenViduRole;
(function (OpenViduRole) {
    OpenViduRole["MODERATOR"] = "MODERATOR";
    OpenViduRole["PUBLISHER"] = "PUBLISHER";
})(OpenViduRole || (OpenViduRole = {}));
class ParticipantAbstractModel {
    constructor(props, model) {
        this.streams = new Map();
        this.id = props.id ? props.id : new Date().getTime().toString();
        this.local = props.local;
        this.nickname = props.nickname;
        this.colorProfile = !!props.colorProfile ? props.colorProfile : `hsl(${Math.random() * 360}, 100%, 80%)`;
        this.isMutedForcibly = typeof props.isMutedForcibly === 'boolean' ? props.isMutedForcibly : false;
        let streamModel = {
            connected: model ? model.connected : true,
            type: model ? model.type : VideoType.CAMERA,
            streamManager: model ? model.streamManager : null,
            videoEnlarged: model ? model.videoEnlarged : false,
            connectionId: model ? model.connectionId : null,
            participant: this
        };
        this.streams.set(streamModel.type, streamModel);
    }
    /**
     * @internal
     */
    addConnection(streamModel) {
        streamModel.participant = this;
        this.streams.set(streamModel.type, streamModel);
    }
    /**
     * @internal
     */
    hasAudioActive() {
        const cameraConnection = this.getCameraConnection();
        const screenConnection = this.getScreenConnection();
        if (cameraConnection.connected) {
            return this.isCameraAudioActive();
        }
        else if (screenConnection.connected) {
            return this.isScreenAudioActive();
        }
        return false;
    }
    /**
     * @internal
     */
    isCameraAudioActive() {
        var _a, _b;
        const cameraConnection = this.getCameraConnection();
        if (cameraConnection === null || cameraConnection === void 0 ? void 0 : cameraConnection.connected) {
            return (_b = (_a = cameraConnection.streamManager) === null || _a === void 0 ? void 0 : _a.stream) === null || _b === void 0 ? void 0 : _b.audioActive;
        }
        return false;
    }
    /**
     * @internal
     */
    isCameraVideoActive() {
        var _a, _b;
        const cameraConnection = this.getCameraConnection();
        return (cameraConnection === null || cameraConnection === void 0 ? void 0 : cameraConnection.connected) && ((_b = (_a = cameraConnection === null || cameraConnection === void 0 ? void 0 : cameraConnection.streamManager) === null || _a === void 0 ? void 0 : _a.stream) === null || _b === void 0 ? void 0 : _b.videoActive);
    }
    /**
     * @internal
     */
    isScreenAudioActive() {
        var _a, _b;
        const screenConnection = this.getScreenConnection();
        if (screenConnection === null || screenConnection === void 0 ? void 0 : screenConnection.connected) {
            return (_b = (_a = screenConnection === null || screenConnection === void 0 ? void 0 : screenConnection.streamManager) === null || _a === void 0 ? void 0 : _a.stream) === null || _b === void 0 ? void 0 : _b.audioActive;
        }
        return false;
    }
    /**
     * @internal
     */
    hasConnectionType(type) {
        return this.streams.has(type);
    }
    /**
     * @internal
     */
    getCameraConnection() {
        return this.streams.get(VideoType.CAMERA);
    }
    /**
     * @internal
     */
    getScreenConnection() {
        return this.streams.get(VideoType.SCREEN);
    }
    /**
     * @internal
     */
    getConnectionTypesActive() {
        let connType = [];
        if (this.isCameraActive())
            connType.push(VideoType.CAMERA);
        if (this.isScreenActive())
            connType.push(VideoType.SCREEN);
        return connType;
    }
    /**
     * @internal
     */
    setCameraConnectionId(connectionId) {
        this.getCameraConnection().connectionId = connectionId;
    }
    /**
     * @internal
     */
    setScreenConnectionId(connectionId) {
        this.getScreenConnection().connectionId = connectionId;
    }
    /**
     * @internal
     */
    removeConnection(connectionId) {
        const removeStream = this.getConnectionById(connectionId);
        this.streams.delete(removeStream.type);
        return removeStream;
    }
    /**
     * @internal
     */
    hasConnectionId(connectionId) {
        return Array.from(this.streams.values()).some((conn) => conn.connectionId === connectionId);
    }
    /**
     * @internal
     */
    getConnectionById(connectionId) {
        return Array.from(this.streams.values()).find((conn) => conn.connectionId === connectionId);
    }
    /**
     * @internal
     */
    getAvailableConnections() {
        return Array.from(this.streams.values()).filter((conn) => conn.connected);
    }
    /**
     * @internal
     */
    isLocal() {
        return this.local;
        // return Array.from(this.streams.values()).every((conn) => conn.local);
    }
    /**
     * @internal
     */
    setNickname(nickname) {
        this.nickname = nickname;
    }
    /**
     * @internal
     */
    getNickname() {
        return this.nickname;
    }
    /**
     * @internal
     */
    setCameraPublisher(publisher) {
        const cameraConnection = this.getCameraConnection();
        if (cameraConnection)
            cameraConnection.streamManager = publisher;
    }
    /**
     * @internal
     */
    setScreenPublisher(publisher) {
        const screenConnection = this.getScreenConnection();
        if (screenConnection)
            screenConnection.streamManager = publisher;
    }
    /**
     * @internal
     */
    setPublisher(connType, publisher) {
        const connection = this.streams.get(connType);
        if (connection) {
            connection.streamManager = publisher;
        }
    }
    /**
     * @internal
     */
    isCameraActive() {
        var _a;
        return (_a = this.getCameraConnection()) === null || _a === void 0 ? void 0 : _a.connected;
    }
    /**
     * @internal
     */
    enableCamera() {
        const cameraConnection = this.getCameraConnection();
        if (cameraConnection)
            cameraConnection.connected = true;
    }
    /**
     * @internal
     */
    disableCamera() {
        const cameraConnection = this.getCameraConnection();
        if (cameraConnection)
            cameraConnection.connected = false;
    }
    /**
     * @internal
     */
    isScreenActive() {
        var _a;
        return (_a = this.getScreenConnection()) === null || _a === void 0 ? void 0 : _a.connected;
    }
    /**
     * @internal
     */
    enableScreen() {
        const screenConnection = this.getScreenConnection();
        if (screenConnection)
            screenConnection.connected = true;
    }
    /**
     * @internal
     */
    disableScreen() {
        const screenConnection = this.getScreenConnection();
        if (screenConnection)
            screenConnection.connected = false;
    }
    /**
     * @internal
     */
    setAllVideoEnlarged(enlarged) {
        this.streams.forEach((conn) => (conn.videoEnlarged = enlarged));
    }
    /**
     * @internal
     */
    setCameraEnlarged(enlarged) {
        this.streams.get(VideoType.CAMERA).videoEnlarged = enlarged;
    }
    /**
     * @internal
     */
    setScreenEnlarged(enlarged) {
        this.streams.get(VideoType.SCREEN).videoEnlarged = enlarged;
    }
    /**
     * @internal
     */
    toggleVideoEnlarged(connectionId) {
        this.streams.forEach((conn) => {
            if (conn.connectionId === connectionId) {
                conn.videoEnlarged = !conn.videoEnlarged;
            }
        });
    }
    /**
     * @internal
     */
    someHasVideoEnlarged() {
        return Array.from(this.streams.values()).some((conn) => conn.videoEnlarged);
    }
    /**
     * @internal
     */
    setMutedForcibly(muted) {
        this.isMutedForcibly = muted;
    }
    /**
     * @internal
     */
    getRole() {
        var _a, _b, _c, _d;
        return (_d = (_c = (_b = (_a = this.streams.get(VideoType.CAMERA)) === null || _a === void 0 ? void 0 : _a.streamManager) === null || _b === void 0 ? void 0 : _b.stream) === null || _c === void 0 ? void 0 : _c.connection) === null || _d === void 0 ? void 0 : _d.role;
    }
}
/**
 * @internal
 */
class ParticipantModel extends ParticipantAbstractModel {
}

var RecordingStatus;
(function (RecordingStatus) {
    RecordingStatus["STARTING"] = "starting";
    RecordingStatus["STARTED"] = "started";
    RecordingStatus["STOPPING"] = "stopping";
    RecordingStatus["STOPPED"] = "stopped";
    RecordingStatus["FAILED"] = "failed";
    RecordingStatus["READY"] = "ready";
})(RecordingStatus || (RecordingStatus = {}));
;

/**
 * @internal
 */
var LayoutClass;
(function (LayoutClass) {
    LayoutClass["ROOT_ELEMENT"] = "OT_root";
    LayoutClass["BIG_ELEMENT"] = "OV_big";
    LayoutClass["SMALL_ELEMENT"] = "OV_small";
    LayoutClass["IGNORED_ELEMENT"] = "OV_ignored";
    LayoutClass["SIDENAV_CONTAINER"] = "sidenav-container";
    LayoutClass["NO_SIZE_ELEMENT"] = "no-size";
    LayoutClass["CLASS_NAME"] = "layout";
})(LayoutClass || (LayoutClass = {}));
/**
 * @internal
 */
var SidenavMode;
(function (SidenavMode) {
    SidenavMode["OVER"] = "over";
    SidenavMode["SIDE"] = "side";
})(SidenavMode || (SidenavMode = {}));
var LayoutAlignment;
(function (LayoutAlignment) {
    LayoutAlignment["START"] = "start";
    LayoutAlignment["CENTER"] = "center";
    LayoutAlignment["END"] = "end";
})(LayoutAlignment || (LayoutAlignment = {}));
/**
 * @internal
 */
class OpenViduLayout {
    /**
     * Update the layout container
     * module export layout
     */
    updateLayout(container, opts) {
        setTimeout(() => {
            this.layoutContainer = container;
            this.opts = opts;
            if (this.css(this.layoutContainer, 'display') === 'none') {
                return;
            }
            let id = this.layoutContainer.id;
            if (!id) {
                id = 'OT_' + this.cheapUUID();
                this.layoutContainer.id = id;
            }
            opts.containerHeight =
                this.getHeight(this.layoutContainer) -
                    this.getCSSNumber(this.layoutContainer, 'border-top') -
                    this.getCSSNumber(this.layoutContainer, 'border-bottom');
            opts.containerWidth =
                this.getWidth(this.layoutContainer) -
                    this.getCSSNumber(this.layoutContainer, 'border-left') -
                    this.getCSSNumber(this.layoutContainer, 'border-right');
            const children = Array.prototype.filter.call(this.layoutContainer.querySelectorAll(`#${id}>*:not(.${LayoutClass.IGNORED_ELEMENT})`), () => this.filterDisplayNone);
            const elements = children.map((element) => {
                const res = this.getChildDims(element);
                res.big = element.classList.contains(this.opts.bigClass);
                return res;
            });
            const layout = this.getLayout(opts, elements);
            layout.boxes.forEach((box, idx) => {
                const elem = children[idx];
                this.css(elem, 'position', 'absolute');
                const actualWidth = box.width -
                    -this.getCSSNumber(elem, 'margin-left') -
                    this.getCSSNumber(elem, 'margin-right') -
                    (this.css(elem, 'box-sizing') !== 'border-box'
                        ? this.getCSSNumber(elem, 'padding-left') +
                            this.getCSSNumber(elem, 'padding-right') +
                            this.getCSSNumber(elem, 'border-left') +
                            this.getCSSNumber(elem, 'border-right')
                        : 0);
                const actualHeight = box.height -
                    -this.getCSSNumber(elem, 'margin-top') -
                    this.getCSSNumber(elem, 'margin-bottom') -
                    (this.css(elem, 'box-sizing') !== 'border-box'
                        ? this.getCSSNumber(elem, 'padding-top') +
                            this.getCSSNumber(elem, 'padding-bottom') +
                            this.getCSSNumber(elem, 'border-top') +
                            this.getCSSNumber(elem, 'border-bottom')
                        : 0);
                this.positionElement(elem, box.left, box.top, actualWidth, actualHeight, this.opts.animate);
            });
        }, 50);
    }
    /**
     * Initialize the layout inside of the container with the options required
     * @param container
     * @param opts
     */
    initLayoutContainer(container, opts) {
        // this.opts = this.defaults(opts, {
        //   maxRatio: 3 / 2,
        //   minRatio: 9 / 16,
        //   fixedRatio: false,
        //   animate: false,
        //   bigClass: LayoutClass.BIG_ELEMENT,
        //   smallClass: LayoutClass.SMALL_ELEMENT,
        //   bigPercentage: 0.8,
        //   bigFixedRatio: false,
        //   bigMaxRatio: 3 / 2,
        //   bigMinRatio: 9 / 16,
        //   bigFirst: true,
        //   alignItems: 'center',
        //   bigAlignItems: 'center',
        //   smallAlignItems: 'center'
        // });
        this.opts = opts;
        this.layoutContainer = container;
        this.updateLayout(container, opts);
    }
    getLayoutContainer() {
        return this.layoutContainer;
    }
    /**
     * Set the layout configuration
     * @param options
     */
    // private setLayoutOptions(options: OpenViduLayoutOptions) {
    // 	this.opts = options;
    // }
    css(el, propertyName, value) {
        if (!!value) {
            // We are setting one css property
            el.style[propertyName] = value;
            return NaN;
        }
        else if (typeof propertyName === 'object') {
            // We are setting several CSS properties at once
            Object.keys(propertyName).forEach((key) => {
                this.css(el, key, propertyName[key]);
            });
            return NaN;
        }
        else {
            // We are getting the css property
            var computedStyle = /*(this.opts && this.opts.window) ||*/ window.getComputedStyle(el);
            var currentValue = computedStyle.getPropertyValue(propertyName);
            if (currentValue === '') {
                currentValue = el.style[propertyName];
            }
            return currentValue;
        }
    }
    height(el) {
        if (el.offsetHeight > 0) {
            return `${el.offsetHeight}px`;
        }
        return this.css(el, 'height');
    }
    width(el) {
        if (el.offsetWidth > 0) {
            return `${el.offsetWidth}px`;
        }
        return this.css(el, 'width');
    }
    defaults(custom, defaults) {
        var res = defaults;
        Object.keys(defaults).forEach((key) => {
            if (custom.hasOwnProperty(key)) {
                res[key] = custom[key];
            }
        });
        return res;
    }
    /**
     * @hidden
     */
    fixAspectRatio(elem, width) {
        const sub = elem.querySelector(`.${LayoutClass.ROOT_ELEMENT}`);
        if (sub) {
            // If this is the parent of a subscriber or publisher then we need
            // to force the mutation observer on the publisher or subscriber to
            // trigger to get it to fix it's layout
            const oldWidth = sub.style.width;
            sub.style.width = `${width}px`;
            // sub.style.height = height + 'px';
            sub.style.width = oldWidth || '';
        }
    }
    /**
     * @hidden
     */
    positionElement(elem, x, y, width, height, animate) {
        const targetPosition = {
            left: `${x}px`,
            top: `${y}px`,
            width: `${width}px`,
            height: `${height}px`
        };
        this.fixAspectRatio(elem, width);
        if (animate) {
            setTimeout(() => {
                // animation added in css transition: all .1s linear;
                elem.style.left = targetPosition.left;
                elem.style.top = targetPosition.top;
                elem.style.width = targetPosition.width;
                elem.style.height = targetPosition.height;
                this.fixAspectRatio(elem, width);
            }, 10);
        }
        else {
            this.css(elem, targetPosition);
            if (!elem.classList.contains(LayoutClass.CLASS_NAME)) {
                elem.classList.add(LayoutClass.CLASS_NAME);
            }
        }
        this.fixAspectRatio(elem, width);
    }
    /**
     * @hidden
     */
    getChildDims(child) {
        if (child) {
            if (child.videoHeight && child.videoWidth) {
                return {
                    height: child.videoHeight,
                    width: child.videoWidth
                };
            }
            const video = child.querySelector('video');
            if (video && video.videoHeight && video.videoWidth) {
                return {
                    height: video.videoHeight,
                    width: video.videoWidth
                };
            }
        }
        return {
            height: 480,
            width: 640
        };
    }
    /**
     * @hidden
     */
    getCSSNumber(elem, prop) {
        const cssStr = this.css(elem, prop);
        return cssStr ? parseInt(cssStr.toString(), 10) : 0;
    }
    /**
     * @hidden
     */
    // Really cheap UUID function
    cheapUUID() {
        return (Math.random() * 100000000).toFixed(0);
    }
    /**
     * @hidden
     */
    getHeight(elem) {
        const heightStr = this.height(elem);
        return heightStr ? parseInt(heightStr.toString(), 10) : 0;
    }
    /**
     * @hidden
     */
    getWidth(elem) {
        const widthStr = this.width(elem);
        return widthStr ? parseInt(widthStr.toString(), 10) : 0;
    }
    /**
     * @hidden
     */
    // private arrange(
    //   children: HTMLVideoElement[],
    //   containerWidth: number,
    //   containerHeight: number,
    //   offsetLeft: number,
    //   offsetTop: number,
    //   fixedRatio: boolean,
    //   minRatio: number,
    //   maxRatio: number,
    //   animate: any
    // ) {
    // const boxes = this.getLayout(
    //   {
    //     containerWidth,
    //     containerHeight,
    //     minRatio,
    //     maxRatio,
    //     fixedRatio,
    //   },
    //   children.map((child) => this.getVideoRatio(child))
    // );
    // boxes.forEach((box, idx) => {
    //   const elem = children[idx];
    //   this.css(elem, 'position', 'absolute');
    //   const actualWidth =
    //     box.width -
    //     this.getCSSNumber(elem, 'paddingLeft') -
    //     this.getCSSNumber(elem, 'paddingRight') -
    //     this.getCSSNumber(elem, 'marginLeft') -
    //     this.getCSSNumber(elem, 'marginRight') -
    //     this.getCSSNumber(elem, 'borderLeft') -
    //     this.getCSSNumber(elem, 'borderRight');
    //   const actualHeight =
    //     box.height -
    //     this.getCSSNumber(elem, 'paddingTop') -
    //     this.getCSSNumber(elem, 'paddingBottom') -
    //     this.getCSSNumber(elem, 'marginTop') -
    //     this.getCSSNumber(elem, 'marginBottom') -
    //     this.getCSSNumber(elem, 'borderTop') -
    //     this.getCSSNumber(elem, 'borderBottom');
    //   this.positionElement(
    //     elem,
    //     box.left + offsetLeft,
    //     box.top + offsetTop,
    //     actualWidth,
    //     actualHeight,
    //     animate
    //   );
    // });
    // }
    /**
     * @hidden
     */
    // private attachElements(
    //   bigOnes: HTMLVideoElement[],
    //   normalOnes: HTMLVideoElement[],
    //   smallOnes: HTMLVideoElement[]
    // ) {
    //   const containerHeight =
    //     this.getHeight(this.layoutContainer) -
    //     this.getCSSNumber(this.layoutContainer, 'borderTop') -
    //     this.getCSSNumber(this.layoutContainer, 'borderBottom');
    //   const containerWidth =
    //     this.getWidth(this.layoutContainer) -
    //     this.getCSSNumber(this.layoutContainer, 'borderLeft') -
    //     this.getCSSNumber(this.layoutContainer, 'borderRight');
    //   const offsetLeft = 0;
    //   const offsetTop = 0;
    //   if (this.existBigAndNormalOnes(bigOnes, normalOnes, smallOnes)) {
    //     const smallOnesAux = smallOnes.length > 0 ? smallOnes : normalOnes;
    //     const bigOnesAux = bigOnes.length > 0 ? bigOnes : normalOnes;
    //     this.arrangeBigAndSmallOnes(bigOnesAux, smallOnesAux, {
    //       containerHeight,
    //       containerWidth,
    //     });
    //   } else if (this.onlyExistBigOnes(bigOnes, normalOnes, smallOnes)) {
    //     // We only have one bigOne just center it
    //     this.arrange(
    //       bigOnes,
    //       containerWidth,
    //       containerHeight,
    //       0,
    //       0,
    //       this.opts.bigFixedRatio,
    //       this.opts.bigMinRatio,
    //       this.opts.bigMaxRatio,
    //       this.opts.animate
    //     );
    //   } else if (
    //     this.existBigAndNormalAndSmallOnes(bigOnes, normalOnes, smallOnes)
    //   ) {
    //     this.arrangeBigAndSmallOnes(bigOnes, normalOnes.concat(smallOnes), {
    //       containerHeight,
    //       containerWidth,
    //     });
    //   } else {
    //     const normalOnesAux = normalOnes.concat(smallOnes);
    //     this.arrange(
    //       normalOnesAux,
    //       containerWidth - offsetLeft,
    //       containerHeight - offsetTop,
    //       offsetLeft,
    //       offsetTop,
    //       this.opts.fixedRatio,
    //       this.opts.minRatio,
    //       this.opts.maxRatio,
    //       this.opts.animate
    //     );
    //   }
    // }
    /**
     * @hidden
     */
    // private arrangeBigAndSmallOnes(
    //   bigOnesAux: HTMLVideoElement[],
    //   smallOnesAux: HTMLVideoElement[],
    //   data: { containerHeight: number; containerWidth: number }
    // ) {
    //   const { containerWidth, containerHeight } = data;
    //   let offsetLeft = 0;
    //   let offsetTop = 0;
    //   const availableRatio = containerHeight / containerWidth;
    //   let bigOffsetTop = 0;
    //   let bigOffsetLeft = 0;
    //   let bigWidth, bigHeight;
    //   if (availableRatio > this.getVideoRatio(bigOnesAux[0])) {
    //     // We are tall, going to take up the whole width and arrange small
    //     // guys at the bottom
    //     bigWidth = containerWidth;
    //     bigHeight = Math.floor(containerHeight * this.opts.bigPercentage);
    //     offsetTop = bigHeight;
    //     bigOffsetTop = containerHeight - offsetTop;
    //   } else {
    //     // We are wide, going to take up the whole height and arrange the small
    //     // guys on the right
    //     bigHeight = containerHeight;
    //     bigWidth = Math.floor(containerWidth * this.opts.bigPercentage);
    //     offsetLeft = bigWidth;
    //     bigOffsetLeft = containerWidth - offsetLeft;
    //   }
    //   if (this.opts.bigFirst) {
    //     this.arrange(
    //       bigOnesAux,
    //       bigWidth,
    //       bigHeight,
    //       0,
    //       0,
    //       this.opts.bigFixedRatio,
    //       this.opts.bigMinRatio,
    //       this.opts.bigMaxRatio,
    //       this.opts.animate
    //     );
    //     this.arrange(
    //       smallOnesAux,
    //       containerWidth - offsetLeft,
    //       containerHeight - offsetTop,
    //       offsetLeft,
    //       offsetTop,
    //       this.opts.fixedRatio,
    //       this.opts.minRatio,
    //       this.opts.maxRatio,
    //       this.opts.animate
    //     );
    //   } else {
    //     this.arrange(
    //       smallOnesAux,
    //       containerWidth - offsetLeft,
    //       containerHeight - offsetTop,
    //       0,
    //       0,
    //       this.opts.fixedRatio,
    //       this.opts.minRatio,
    //       this.opts.maxRatio,
    //       this.opts.animate
    //     );
    //     this.arrange(
    //       bigOnesAux,
    //       bigWidth,
    //       bigHeight,
    //       bigOffsetLeft,
    //       bigOffsetTop,
    //       this.opts.bigFixedRatio,
    //       this.opts.bigMinRatio,
    //       this.opts.bigMaxRatio,
    //       this.opts.animate
    //     );
    //   }
    // }
    /**
     * @hidden
     */
    // private existBigAndNormalOnes(
    //   bigOnes: HTMLVideoElement[],
    //   normalOnes: HTMLVideoElement[],
    //   smallOnes: HTMLVideoElement[]
    // ) {
    //   return (
    //     (bigOnes.length > 0 && normalOnes.length > 0 && smallOnes.length === 0) ||
    //     (bigOnes.length > 0 && normalOnes.length === 0 && smallOnes.length > 0) ||
    //     (bigOnes.length === 0 && normalOnes.length > 0 && smallOnes.length > 0)
    //   );
    // }
    /**
     * @hidden
     */
    // private onlyExistBigOnes(
    //   bigOnes: HTMLVideoElement[],
    //   normalOnes: HTMLVideoElement[],
    //   smallOnes: HTMLVideoElement[]
    // ): boolean {
    //   return (
    //     bigOnes.length > 0 && normalOnes.length === 0 && smallOnes.length === 0
    //   );
    // }
    /**
     * @hidden
     */
    // private existBigAndNormalAndSmallOnes(
    //   bigOnes: HTMLVideoElement[],
    //   normalOnes: HTMLVideoElement[],
    //   smallOnes: HTMLVideoElement[]
    // ): boolean {
    //   return bigOnes.length > 0 && normalOnes.length > 0 && smallOnes.length > 0;
    // }
    /**
     * @hidden
     */
    filterDisplayNone(element) {
        return this.css(element, 'display') !== 'none';
    }
    /**
     *
     * --------------------------------------------------------------------------------
     *
     * GET LAYOUT
     *
     *
     */
    /**
     * @hidden
     */
    getBestDimensions(minRatio, maxRatio, width, height, count, maxWidth, maxHeight) {
        let maxArea;
        let targetCols;
        let targetRows;
        let targetHeight;
        let targetWidth;
        let tWidth;
        let tHeight;
        let tRatio;
        // Iterate through every possible combination of rows and columns
        // and see which one has the least amount of whitespace
        for (let i = 1; i <= count; i++) {
            const cols = i;
            const rows = Math.ceil(count / cols);
            // Try taking up the whole height and width
            tHeight = Math.floor(height / rows);
            tWidth = Math.floor(width / cols);
            tRatio = tHeight / tWidth;
            if (tRatio > maxRatio) {
                // We went over decrease the height
                tRatio = maxRatio;
                tHeight = tWidth * tRatio;
            }
            else if (tRatio < minRatio) {
                // We went under decrease the width
                tRatio = minRatio;
                tWidth = tHeight / tRatio;
            }
            tWidth = Math.min(maxWidth, tWidth);
            tHeight = Math.min(maxHeight, tHeight);
            const area = tWidth * tHeight * count;
            // If this width and height takes up the most space then we're going with that
            if (maxArea === undefined || area >= maxArea) {
                if (!(area === maxArea && count % (cols * rows) > count % (targetRows * targetCols))) {
                    // Favour even numbers of participants in each row, eg. 2 on each row
                    // instead of 3 in one row and then 1 on the next
                    maxArea = area;
                    targetHeight = tHeight;
                    targetWidth = tWidth;
                    targetCols = cols;
                    targetRows = rows;
                }
            }
        }
        return {
            maxArea,
            targetCols,
            targetRows,
            targetHeight,
            targetWidth,
            ratio: targetHeight / targetWidth
        };
    }
    getVideoRatio(element) {
        return element.height / element.width;
    }
    getLayout(opts, elements) {
        const { maxRatio = 3 / 2, minRatio = 9 / 16, fixedRatio = false, bigPercentage = 0.8, minBigPercentage = 0, bigFixedRatio = false, bigMaxRatio = 3 / 2, bigMinRatio = 9 / 16, bigFirst = true, containerWidth = 640, containerHeight = 480, alignItems = 'center', bigAlignItems = 'center', smallAlignItems = 'center', maxWidth = Infinity, maxHeight = Infinity, smallMaxWidth = Infinity, smallMaxHeight = Infinity, bigMaxWidth = Infinity, bigMaxHeight = Infinity, scaleLastRow = true, bigScaleLastRow = true } = opts;
        const availableRatio = containerHeight / containerWidth;
        let offsetLeft = 0;
        let offsetTop = 0;
        let bigOffsetTop = 0;
        let bigOffsetLeft = 0;
        const bigIndices = [];
        let bigBoxes = [];
        let smallBoxes = [];
        let areas = { big: null, small: null };
        // Move to Get Layout
        const smallOnes = elements.filter((element) => !element.big);
        const bigOnes = elements.filter((element, idx) => {
            if (element.big) {
                bigIndices.push(idx);
                return true;
            }
            return false;
        });
        //TODO: Habia un codigo personalizado que servía para
        //TODO: tener videos grandes, pequeños y normales
        //.filter((x) => !smallOnes.includes(x));
        // const normalOnes: HTMLVideoElement[] = Array.prototype.filter
        //   .call(
        //     this.layoutContainer.querySelectorAll(
        //       `#${id}>*:not(.${this.opts.bigClass})`
        //     ),
        //     () => this.filterDisplayNone
        //   )
        //   .filter((x) => !smallOnes.includes(x));
        // this.attachElements(bigOnes, normalOnes, smallOnes);
        if (bigOnes.length > 0 && smallOnes.length > 0) {
            let bigWidth;
            let bigHeight;
            let showBigFirst = bigFirst;
            if (availableRatio > this.getVideoRatio(bigOnes[0])) {
                // We are tall, going to take up the whole width and arrange small
                // guys at the bottom
                bigWidth = containerWidth;
                bigHeight = Math.floor(containerHeight * bigPercentage);
                if (minBigPercentage > 0) {
                    // Find the best size for the big area
                    let bigDimensions;
                    if (!bigFixedRatio) {
                        bigDimensions = this.getBestDimensions(bigMinRatio, bigMaxRatio, bigWidth, bigHeight, bigOnes.length, bigMaxWidth, bigMaxHeight);
                    }
                    else {
                        // Use the ratio of the first video element we find to approximate
                        const ratio = bigOnes[0].height / bigOnes[0].width;
                        bigDimensions = this.getBestDimensions(ratio, ratio, bigWidth, bigHeight, bigOnes.length, bigMaxWidth, bigMaxHeight);
                    }
                    bigHeight = Math.max(containerHeight * minBigPercentage, Math.min(bigHeight, bigDimensions.targetHeight * bigDimensions.targetRows));
                    // Don't awkwardly scale the small area bigger than we need to and end up with floating
                    // videos in the middle
                    const smallDimensions = this.getBestDimensions(minRatio, maxRatio, containerWidth, containerHeight - bigHeight, smallOnes.length, smallMaxWidth, smallMaxHeight);
                    bigHeight = Math.max(bigHeight, containerHeight - smallDimensions.targetRows * smallDimensions.targetHeight);
                }
                offsetTop = bigHeight;
                bigOffsetTop = containerHeight - offsetTop;
                if (bigFirst === 'column') {
                    showBigFirst = false;
                }
                else if (bigFirst === 'row') {
                    showBigFirst = true;
                }
            }
            else {
                // We are wide, going to take up the whole height and arrange the small
                // guys on the right
                bigHeight = containerHeight;
                bigWidth = Math.floor(containerWidth * bigPercentage);
                if (minBigPercentage > 0) {
                    // Find the best size for the big area
                    let bigDimensions;
                    if (!bigFixedRatio) {
                        bigDimensions = this.getBestDimensions(bigMinRatio, bigMaxRatio, bigWidth, bigHeight, bigOnes.length, bigMaxWidth, bigMaxHeight);
                    }
                    else {
                        // Use the ratio of the first video element we find to approximate
                        const ratio = bigOnes[0].height / bigOnes[0].width;
                        bigDimensions = this.getBestDimensions(ratio, ratio, bigWidth, bigHeight, bigOnes.length, bigMaxWidth, bigMaxHeight);
                    }
                    bigWidth = Math.max(containerWidth * minBigPercentage, Math.min(bigWidth, bigDimensions.targetWidth * bigDimensions.targetCols));
                    // Don't awkwardly scale the small area bigger than we need to and end up with floating
                    // videos in the middle
                    const smallDimensions = this.getBestDimensions(minRatio, maxRatio, containerWidth - bigWidth, containerHeight, smallOnes.length, smallMaxWidth, smallMaxHeight);
                    bigWidth = Math.max(bigWidth, containerWidth - smallDimensions.targetCols * smallDimensions.targetWidth);
                }
                offsetLeft = bigWidth;
                bigOffsetLeft = containerWidth - offsetLeft;
                if (bigFirst === 'column') {
                    showBigFirst = true;
                }
                else if (bigFirst === 'row') {
                    showBigFirst = false;
                }
            }
            if (showBigFirst) {
                areas.big = {
                    top: 0,
                    left: 0,
                    width: bigWidth,
                    height: bigHeight
                };
                areas.small = {
                    top: offsetTop,
                    left: offsetLeft,
                    width: containerWidth - offsetLeft,
                    height: containerHeight - offsetTop
                };
            }
            else {
                areas.big = {
                    left: bigOffsetLeft,
                    top: bigOffsetTop,
                    width: bigWidth,
                    height: bigHeight
                };
                areas.small = {
                    top: 0,
                    left: 0,
                    width: containerWidth - offsetLeft,
                    height: containerHeight - offsetTop
                };
            }
        }
        else if (bigOnes.length > 0 && smallOnes.length === 0) {
            // We only have one bigOne just center it
            areas.big = {
                top: 0,
                left: 0,
                width: containerWidth,
                height: containerHeight
            };
        }
        else {
            areas.small = {
                top: offsetTop,
                left: offsetLeft,
                width: containerWidth - offsetLeft,
                height: containerHeight - offsetTop
            };
        }
        if (areas.big) {
            bigBoxes = this.getLayoutAux({
                containerWidth: areas.big.width,
                containerHeight: areas.big.height,
                offsetLeft: areas.big.left,
                offsetTop: areas.big.top,
                fixedRatio: bigFixedRatio,
                minRatio: bigMinRatio,
                maxRatio: bigMaxRatio,
                alignItems: bigAlignItems,
                maxWidth: bigMaxWidth,
                maxHeight: bigMaxHeight,
                scaleLastRow: bigScaleLastRow
            }, bigOnes);
        }
        if (areas.small) {
            smallBoxes = this.getLayoutAux({
                containerWidth: areas.small.width,
                containerHeight: areas.small.height,
                offsetLeft: areas.small.left,
                offsetTop: areas.small.top,
                fixedRatio,
                minRatio,
                maxRatio,
                alignItems: areas.big ? smallAlignItems : alignItems,
                maxWidth: areas.big ? smallMaxWidth : maxWidth,
                maxHeight: areas.big ? smallMaxHeight : maxHeight,
                scaleLastRow
            }, smallOnes);
        }
        const boxes = [];
        let bigBoxesIdx = 0;
        let smallBoxesIdx = 0;
        // Rebuild the array in the right order based on where the bigIndices should be
        elements.forEach((element, idx) => {
            if (bigIndices.indexOf(idx) > -1) {
                boxes[idx] = bigBoxes[bigBoxesIdx];
                bigBoxesIdx += 1;
            }
            else {
                boxes[idx] = smallBoxes[smallBoxesIdx];
                smallBoxesIdx += 1;
            }
        });
        return { boxes, areas };
    }
    getLayoutAux(opts, elements) {
        const { maxRatio = 3 / 2, minRatio = 9 / 16, fixedRatio = false, containerWidth = 640, containerHeight = 480, offsetLeft = 0, offsetTop = 0, alignItems = 'center', maxWidth = Infinity, maxHeight = Infinity, scaleLastRow = true } = opts;
        const ratios = elements.map((element) => element.height / element.width);
        const count = ratios.length;
        let dimensions;
        if (!fixedRatio) {
            dimensions = this.getBestDimensions(minRatio, maxRatio, containerWidth, containerHeight, count, maxWidth, maxHeight);
        }
        else {
            // Use the ratio of the first video element we find to approximate
            const ratio = ratios.length > 0 ? ratios[0] : null;
            dimensions = this.getBestDimensions(ratio, ratio, containerWidth, containerHeight, count, maxWidth, maxHeight);
        }
        // Loop through each stream in the container and place it inside
        let x = 0;
        let y = 0;
        const rows = [];
        let row;
        const boxes = [];
        // Iterate through the children and create an array with a new item for each row
        // and calculate the width of each row so that we know if we go over the size and need
        // to adjust
        for (let i = 0; i < ratios.length; i++) {
            if (i % dimensions.targetCols === 0) {
                // This is a new row
                row = {
                    ratios: [],
                    width: 0,
                    height: 0
                };
                rows.push(row);
            }
            const ratio = ratios[i];
            row.ratios.push(ratio);
            let targetWidth = dimensions.targetWidth;
            const targetHeight = dimensions.targetHeight;
            // If we're using a fixedRatio then we need to set the correct ratio for this element
            if (fixedRatio) {
                targetWidth = targetHeight / ratio;
            }
            row.width += targetWidth;
            row.height = targetHeight;
        }
        // Calculate total row height adjusting if we go too wide
        let totalRowHeight = 0;
        let remainingShortRows = 0;
        for (let i = 0; i < rows.length; i++) {
            row = rows[i];
            if (row.width > containerWidth) {
                // Went over on the width, need to adjust the height proportionally
                row.height = Math.floor(row.height * (containerWidth / row.width));
                row.width = containerWidth;
            }
            else if (row.width < containerWidth && row.height < maxHeight) {
                remainingShortRows += 1;
            }
            totalRowHeight += row.height;
        }
        if (scaleLastRow && totalRowHeight < containerHeight && remainingShortRows > 0) {
            // We can grow some of the rows, we're not taking up the whole height
            let remainingHeightDiff = containerHeight - totalRowHeight;
            totalRowHeight = 0;
            for (let i = 0; i < rows.length; i++) {
                row = rows[i];
                if (row.width < containerWidth) {
                    // Evenly distribute the extra height between the short rows
                    let extraHeight = remainingHeightDiff / remainingShortRows;
                    if (extraHeight / row.height > (containerWidth - row.width) / row.width) {
                        // We can't go that big or we'll go too wide
                        extraHeight = Math.floor(((containerWidth - row.width) / row.width) * row.height);
                    }
                    row.width += Math.floor((extraHeight / row.height) * row.width);
                    row.height += extraHeight;
                    remainingHeightDiff -= extraHeight;
                    remainingShortRows -= 1;
                }
                totalRowHeight += row.height;
            }
        }
        // vertical centering
        switch (alignItems) {
            case 'start':
                y = 0;
                break;
            case 'end':
                y = containerHeight - totalRowHeight;
                break;
            case 'center':
            default:
                y = (containerHeight - totalRowHeight) / 2;
                break;
        }
        // Iterate through each row and place each child
        for (let i = 0; i < rows.length; i++) {
            row = rows[i];
            let rowMarginLeft;
            switch (alignItems) {
                case 'start':
                    rowMarginLeft = 0;
                    break;
                case 'end':
                    rowMarginLeft = containerWidth - row.width;
                    break;
                case 'center':
                default:
                    rowMarginLeft = (containerWidth - row.width) / 2;
                    break;
            }
            x = rowMarginLeft;
            let targetHeight;
            for (let j = 0; j < row.ratios.length; j++) {
                const ratio = row.ratios[j];
                let targetWidth = dimensions.targetWidth;
                targetHeight = row.height;
                // If we're using a fixedRatio then we need to set the correct ratio for this element
                if (fixedRatio) {
                    targetWidth = Math.floor(targetHeight / ratio);
                }
                else if (targetHeight / targetWidth !== dimensions.targetHeight / dimensions.targetWidth) {
                    // We grew this row, we need to adjust the width to account for the increase in height
                    targetWidth = Math.floor((dimensions.targetWidth / dimensions.targetHeight) * targetHeight);
                }
                boxes.push({
                    left: x + offsetLeft,
                    top: y + offsetTop,
                    width: targetWidth,
                    height: targetHeight
                });
                x += targetWidth;
            }
            y += targetHeight;
        }
        return boxes;
    }
}

/**
 * @internal
 */
class DocumentService {
    constructor(media) {
        this.media = media;
        this.screenSizeObs = this.media.asObservable();
    }
    getHTMLElementByClassName(element, className) {
        while (!!element && element !== document.body) {
            if (element.className.includes(className)) {
                return element;
            }
            element = element.parentElement;
        }
        return null;
    }
    toggleFullscreen(elementId) {
        const document = window.document;
        const fs = document.getElementById(elementId);
        if (!document.fullscreenElement &&
            !document.mozFullScreenElement &&
            !document.webkitFullscreenElement &&
            !document.msFullscreenElement) {
            if (fs.requestFullscreen) {
                fs.requestFullscreen();
            }
            else if (fs.msRequestFullscreen) {
                fs.msRequestFullscreen();
            }
            else if (fs.mozRequestFullScreen) {
                fs.mozRequestFullScreen();
            }
            else if (fs.webkitRequestFullscreen) {
                fs.webkitRequestFullscreen();
            }
        }
        else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
            else if (document.msExitFullscreen) {
                document.msExitFullscreen();
            }
            else if (document.mozCancelFullScreen) {
                document.mozCancelFullScreen();
            }
            else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            }
        }
    }
    isSmallElement(element) {
        return element === null || element === void 0 ? void 0 : element.className.includes(LayoutClass.SMALL_ELEMENT);
    }
}
DocumentService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DocumentService, deps: [{ token: i1.MediaObserver }], target: i0.ɵɵFactoryTarget.Injectable });
DocumentService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DocumentService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DocumentService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: i1.MediaObserver }]; } });

/**
 * @internal
 */
var Signal;
(function (Signal) {
    Signal["NICKNAME_CHANGED"] = "nicknameChanged";
    Signal["CHAT"] = "chat";
})(Signal || (Signal = {}));

// import { version } from '../../../../package.json';
/**
 * @internal
 */
class OpenViduAngularConfigService {
    constructor(config) {
        this.minimal = new BehaviorSubject(false);
        this.participantName = new BehaviorSubject('');
        this.prejoin = new BehaviorSubject(true);
        this.videoMuted = new BehaviorSubject(false);
        this.audioMuted = new BehaviorSubject(false);
        this.screenshareButton = new BehaviorSubject(true);
        this.fullscreenButton = new BehaviorSubject(true);
        this.subtitlesButton = new BehaviorSubject(true);
        this.toolbarSettingsButton = new BehaviorSubject(true);
        this.leaveButton = new BehaviorSubject(true);
        this.participantsPanelButton = new BehaviorSubject(true);
        this.chatPanelButton = new BehaviorSubject(true);
        this.activitiesPanelButton = new BehaviorSubject(true);
        this.displaySessionName = new BehaviorSubject(true);
        this.displayLogo = new BehaviorSubject(true);
        this.displayParticipantName = new BehaviorSubject(true);
        this.displayAudioDetection = new BehaviorSubject(true);
        this.streamSettingsButton = new BehaviorSubject(true);
        this.participantItemMuteButton = new BehaviorSubject(true);
        this.backgroundEffectsButton = new BehaviorSubject(true);
        this.recordingsList = new BehaviorSubject([]);
        this.recordingButton = new BehaviorSubject(true);
        this.recordingActivity = new BehaviorSubject(true);
        this.recordingError = new BehaviorSubject(null);
        this.adminRecordingsList = new BehaviorSubject([]);
        this.adminLoginError = new BehaviorSubject(null);
        this.configuration = config;
        console.log(this.configuration);
        if (this.isProduction())
            console.log('OpenVidu Angular Production Mode');
        this.minimalObs = this.minimal.asObservable();
        this.participantNameObs = this.participantName.asObservable();
        this.prejoinObs = this.prejoin.asObservable();
        this.videoMutedObs = this.videoMuted.asObservable();
        this.audioMutedObs = this.audioMuted.asObservable();
        //Toolbar observables
        this.screenshareButtonObs = this.screenshareButton.asObservable();
        this.fullscreenButtonObs = this.fullscreenButton.asObservable();
        this.backgroundEffectsButtonObs = this.backgroundEffectsButton.asObservable();
        this.leaveButtonObs = this.leaveButton.asObservable();
        this.participantsPanelButtonObs = this.participantsPanelButton.asObservable();
        this.chatPanelButtonObs = this.chatPanelButton.asObservable();
        this.activitiesPanelButtonObs = this.activitiesPanelButton.asObservable();
        this.displaySessionNameObs = this.displaySessionName.asObservable();
        this.displayLogoObs = this.displayLogo.asObservable();
        this.recordingButtonObs = this.recordingButton.asObservable();
        this.toolbarSettingsButtonObs = this.toolbarSettingsButton.asObservable();
        this.subtitlesButtonObs = this.subtitlesButton.asObservable();
        //Stream observables
        this.displayParticipantNameObs = this.displayParticipantName.asObservable();
        this.displayAudioDetectionObs = this.displayAudioDetection.asObservable();
        this.streamSettingsButtonObs = this.streamSettingsButton.asObservable();
        // Participant item observables
        this.participantItemMuteButtonObs = this.participantItemMuteButton.asObservable();
        // Recording activity observables
        this.recordingActivityObs = this.recordingActivity.asObservable();
        this.recordingsListObs = this.recordingsList.asObservable();
        this.recordingErrorObs = this.recordingError.asObservable();
        // Admin dashboard
        this.adminRecordingsListObs = this.adminRecordingsList.asObservable();
        this.adminLoginErrorObs = this.adminLoginError.asObservable();
    }
    getConfig() {
        return this.configuration;
    }
    isProduction() {
        var _a;
        return ((_a = this.configuration) === null || _a === void 0 ? void 0 : _a.production) || false;
    }
    hasParticipantFactory() {
        return typeof this.getConfig().participantFactory === 'function';
    }
    getParticipantFactory() {
        return this.getConfig().participantFactory;
    }
}
OpenViduAngularConfigService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularConfigService, deps: [{ token: 'OPENVIDU_ANGULAR_CONFIG' }], target: i0.ɵɵFactoryTarget.Injectable });
OpenViduAngularConfigService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularConfigService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularConfigService, decorators: [{
            type: Injectable
        }], ctorParameters: function () {
        return [{ type: undefined, decorators: [{
                        type: Inject,
                        args: ['OPENVIDU_ANGULAR_CONFIG']
                    }] }];
    } });

/**
 * @internal
 */
class LoggerService {
    constructor(openviduAngularConfigSrv) {
        this.openviduAngularConfigSrv = openviduAngularConfigSrv;
        this.LOG_FNS = [];
        this.MSG_PREFIXES = [
            ['[', ']'],
            ['[', '] WARN: '],
            ['[', '] ERROR: ']
        ];
    }
    getLoggerFns(prefix) {
        this.log = window.console;
        this.LOG_FNS = [this.log.log, this.log.warn, this.log.error];
        const loggerFns = this.LOG_FNS.map((logTemplFn, i) => {
            return logTemplFn.bind(this.log, this.MSG_PREFIXES[i][0] + prefix + this.MSG_PREFIXES[i][1]);
        });
        return loggerFns;
    }
    get(prefix) {
        const prodMode = this.openviduAngularConfigSrv.isProduction();
        const loggerService = this;
        return {
            d: function (...args) {
                if (!prodMode) {
                    loggerService.getLoggerFns(prefix)[0].apply(this.log, arguments);
                }
            },
            w: function (...args) {
                loggerService.getLoggerFns(prefix)[1].apply(this.log, arguments);
            },
            e: function (...args) {
                loggerService.getLoggerFns(prefix)[2].apply(this.log, arguments);
            }
        };
    }
}
LoggerService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LoggerService, deps: [{ token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Injectable });
LoggerService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LoggerService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LoggerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: OpenViduAngularConfigService }]; } });

/**
 * @internal
 */
var CameraType;
(function (CameraType) {
    CameraType["FRONT"] = "FRONT";
    CameraType["BACK"] = "BACK";
})(CameraType || (CameraType = {}));
/**
 * @internal
 */
var DeviceType;
(function (DeviceType) {
    DeviceType["AUDIO_INPUT"] = "audioinput";
    DeviceType["VIDEO_INPUT"] = "videoinput";
})(DeviceType || (DeviceType = {}));

/**
 * @internal
 */
var OpenViduEdition;
(function (OpenViduEdition) {
    OpenViduEdition["CE"] = "CE";
    OpenViduEdition["PRO"] = "PRO";
    OpenViduEdition["ENTERPRISE"] = "ENTERPRISE";
})(OpenViduEdition || (OpenViduEdition = {}));

/**
 * @internal
 */
class PlatformService {
    constructor() { }
    isMobile() {
        return this.isAndroid() || this.isIos();
    }
    isFirefox() {
        return /Firefox[\/\s](\d+\.\d+)/.test(navigator.userAgent);
    }
    isAndroid() {
        return /\b(\w*Android\w*)\b/.test(navigator.userAgent) && /\b(\w*Mobile\w*)\b/.test(navigator.userAgent);
    }
    isIos() {
        return this.isIPhoneOrIPad(navigator === null || navigator === void 0 ? void 0 : navigator.userAgent);
    }
    isIPhoneOrIPad(userAgent) {
        const isIPad = /\b(\w*Macintosh\w*)\b/.test(userAgent);
        const isIPhone = /\b(\w*iPhone\w*)\b/.test(userAgent) && /\b(\w*Mobile\w*)\b/.test(userAgent);
        // && /\b(\w*iPhone\w*)\b/.test(navigator.platform);
        const isTouchable = 'ontouchend' in document;
        return (isIPad || isIPhone) && isTouchable;
    }
    isSafariIos() {
        return this.isIos() && this.isIOSWithSafari(navigator === null || navigator === void 0 ? void 0 : navigator.userAgent);
    }
    isIOSWithSafari(userAgent) {
        return (/\b(\w*Apple\w*)\b/.test(navigator.vendor) &&
            /\b(\w*Safari\w*)\b/.test(userAgent) &&
            !/\b(\w*CriOS\w*)\b/.test(userAgent) &&
            !/\b(\w*FxiOS\w*)\b/.test(userAgent));
    }
}
PlatformService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PlatformService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
PlatformService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PlatformService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PlatformService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class ParticipantService {
    /**
     * @internal
     */
    constructor(openviduAngularConfigSrv, loggerSrv) {
        this.openviduAngularConfigSrv = openviduAngularConfigSrv;
        this.loggerSrv = loggerSrv;
        this._localParticipant = new BehaviorSubject(null);
        this._remoteParticipants = new BehaviorSubject([]);
        this.remoteParticipants = [];
        this.log = this.loggerSrv.get('ParticipantService');
        this.localParticipantObs = this._localParticipant.asObservable();
        this.remoteParticipantsObs = this._remoteParticipants.asObservable();
    }
    /**
     * @internal
     */
    initLocalParticipant(props) {
        this.localParticipant = this.newParticipant(props);
        this.updateLocalParticipant();
    }
    getLocalParticipant() {
        return this.localParticipant;
    }
    /**
     * @internal
     */
    getMyCameraPublisher() {
        return this.localParticipant.getCameraConnection().streamManager;
    }
    /**
     * @internal
     */
    setMyCameraPublisher(publisher) {
        this.localParticipant.setCameraPublisher(publisher);
    }
    /**
     * @internal
     */
    setMyCameraConnectionId(connectionId) {
        this.localParticipant.setCameraConnectionId(connectionId);
    }
    /**
     * @internal
     */
    getMyScreenPublisher() {
        var _a;
        return (_a = this.localParticipant.getScreenConnection()) === null || _a === void 0 ? void 0 : _a.streamManager;
    }
    /**
     * @internal
     */
    setMyScreenPublisher(publisher) {
        this.localParticipant.setScreenPublisher(publisher);
    }
    /**
     * @internal
     */
    setMyScreenConnectionId(connectionId) {
        this.localParticipant.setScreenConnectionId(connectionId);
    }
    /**
     * @internal
     */
    enableWebcamStream() {
        this.localParticipant.enableCamera();
        this.updateLocalParticipant();
    }
    /**
     * @internal
     */
    disableWebcamStream() {
        this.localParticipant.disableCamera();
        this.updateLocalParticipant();
    }
    /**
     * @internal
     */
    activeMyScreenShare(screenPublisher) {
        this.log.d('Enabling screen publisher');
        const steramModel = {
            type: VideoType.SCREEN,
            videoEnlarged: true,
            streamManager: screenPublisher,
            connected: true,
            connectionId: ''
        };
        this.resetRemoteStreamsToNormalSize();
        this.resetMyStreamsToNormalSize();
        this.localParticipant.addConnection(steramModel);
        this.updateLocalParticipant();
    }
    /**
     * @internal
     */
    disableScreenStream() {
        this.localParticipant.disableScreen();
        this.updateLocalParticipant();
    }
    /**
     * @internal
     */
    setMyNickname(nickname) {
        this.localParticipant.setNickname(nickname);
        this.updateLocalParticipant();
    }
    /**
     * @internal
     */
    getMyNickname() {
        return this.localParticipant.nickname;
    }
    getMyRole() {
        return this.localParticipant.getRole();
    }
    /**
     * @internal
     */
    toggleMyVideoEnlarged(connectionId) {
        this.localParticipant.toggleVideoEnlarged(connectionId);
    }
    /**
     * @internal
     */
    resetMyStreamsToNormalSize() {
        if (this.localParticipant.someHasVideoEnlarged()) {
            this.localParticipant.setAllVideoEnlarged(false);
            this.updateLocalParticipant();
        }
    }
    /**
     * @internal
     */
    clear() {
        this.disableScreenStream();
        this.remoteParticipants = [];
        this.updateRemoteParticipants();
        this.updateLocalParticipant();
    }
    /**
     * @internal
     */
    isMyCameraActive() {
        return this.localParticipant.isCameraActive();
    }
    isMyVideoActive() {
        return this.localParticipant.isCameraVideoActive();
    }
    isMyAudioActive() {
        var _a;
        return (_a = this.localParticipant) === null || _a === void 0 ? void 0 : _a.hasAudioActive();
    }
    /**
     * @internal
     */
    isMyScreenActive() {
        return this.localParticipant.isScreenActive();
    }
    /**
     * @internal
     */
    isOnlyMyCameraActive() {
        return this.isMyCameraActive() && !this.isMyScreenActive();
    }
    /**
     * @internal
     */
    isOnlyMyScreenActive() {
        return this.isMyScreenActive() && !this.isMyCameraActive();
    }
    /**
     * @internal
     */
    haveICameraAndScreenActive() {
        return this.isMyCameraActive() && this.isMyScreenActive();
    }
    /**
     * @internal
     */
    hasScreenAudioActive() {
        return this.localParticipant.isScreenAudioActive();
    }
    /**
     * Force to update the local participant object and fire a new {@link localParticipantObs} Observable event.
     */
    updateLocalParticipant() {
        this._localParticipant.next(Object.assign(Object.create(this.localParticipant), this.localParticipant));
    }
    /**
     * REMOTE USERS
     */
    /**
     * @internal
     */
    addRemoteConnection(connectionId, data, subscriber) {
        const type = this.getTypeConnectionData(data);
        const streamModel = {
            type,
            videoEnlarged: type === VideoType.SCREEN,
            streamManager: subscriber,
            connected: true,
            connectionId
        };
        // Avoiding create a new participant if participantId param is not exist in connection data
        // participant Id is necessary for allowing to have multiple connection in one participant
        const participantId = this.getParticipantIdFromData(data) || connectionId;
        const participantAdded = this.getRemoteParticipantById(participantId);
        if (!!participantAdded) {
            this.log.d('Adding connection to existing participant: ', participantId);
            if (participantAdded.hasConnectionType(streamModel.type)) {
                this.log.d('Participant has publisher, updating it');
                participantAdded.setPublisher(streamModel.type, subscriber);
            }
            else {
                this.log.d('Participant has not publisher, adding it');
                if (streamModel.type === VideoType.SCREEN) {
                    this.resetRemoteStreamsToNormalSize();
                    this.resetMyStreamsToNormalSize();
                }
                participantAdded.addConnection(streamModel);
            }
        }
        else {
            this.log.w('Creating new participant with id: ', participantId);
            const props = {
                nickname: this.getNicknameFromConnectionData(data),
                local: false,
                id: participantId
            };
            const remoteParticipant = this.newParticipant(props, streamModel);
            this.remoteParticipants.push(remoteParticipant);
        }
        this.updateRemoteParticipants();
    }
    getRemoteParticipants() {
        return this.remoteParticipants;
    }
    /**
     * @internal
     */
    resetRemoteStreamsToNormalSize() {
        this.remoteParticipants.forEach((participant) => participant.setAllVideoEnlarged(false));
        this.updateRemoteParticipants();
    }
    /**
     * @internal
     */
    removeConnectionByConnectionId(connectionId) {
        this.log.w('Deleting connection: ', connectionId);
        let participant;
        if (this.localParticipant.hasConnectionId(connectionId)) {
            participant = this.localParticipant;
        }
        else {
            participant = this.getRemoteParticipantByConnectionId(connectionId);
        }
        if (participant) {
            const removeStream = participant.removeConnection(connectionId);
            //TODO: Timeout of X seconds?? Its possible sometimes the connections map was empty but must not be deleted
            if (participant.streams.size === 0) {
                // Remove participants without connections
                this.remoteParticipants = this.remoteParticipants.filter((p) => p !== participant);
            }
            if (removeStream.type === VideoType.SCREEN) {
                const remoteScreens = this.remoteParticipants.filter((p) => p.isScreenActive());
                if (remoteScreens.length > 0) {
                    // Enlarging the last screen connection active
                    const lastScreenActive = remoteScreens[remoteScreens.length - 1];
                    lastScreenActive.setScreenEnlarged(true);
                }
                else if (this.localParticipant.isScreenActive()) {
                    // Enlarging my screen if thereare not any remote screen active
                    this.localParticipant.setScreenEnlarged(true);
                }
            }
            this.updateRemoteParticipants();
        }
    }
    /**
     * @internal
     */
    getRemoteParticipantByConnectionId(connectionId) {
        return this.remoteParticipants.find((p) => p.hasConnectionId(connectionId));
    }
    getRemoteParticipantById(id) {
        return this.remoteParticipants.find((p) => p.id === id);
    }
    /**
     * @internal
     */
    someoneIsSharingScreen() {
        return this.remoteParticipants.some((p) => p.someHasVideoEnlarged());
    }
    /**
     * @internal
     */
    toggleRemoteVideoEnlarged(connectionId) {
        const participant = this.getRemoteParticipantByConnectionId(connectionId);
        participant === null || participant === void 0 ? void 0 : participant.toggleVideoEnlarged(connectionId);
    }
    /**
     * @internal
     */
    getNicknameFromConnectionData(data) {
        try {
            return JSON.parse(data).clientData;
        }
        catch (error) {
            return 'OpenVidu_User';
        }
    }
    /**
     * @internal
     */
    setRemoteNickname(connectionId, nickname) {
        const participant = this.getRemoteParticipantByConnectionId(connectionId);
        if (participant) {
            participant.setNickname(nickname);
            this.updateRemoteParticipants();
        }
    }
    /**
     * @internal
     */
    setRemoteMutedForcibly(id, value) {
        const participant = this.getRemoteParticipantById(id);
        if (participant) {
            participant.setMutedForcibly(value);
            this.updateRemoteParticipants();
        }
    }
    /**
     * Force to update the remote participants object and fire a new {@link remoteParticipantsObs} Observable event.
     */
    updateRemoteParticipants() {
        this._remoteParticipants.next([...this.remoteParticipants]);
    }
    getTypeConnectionData(data) {
        try {
            return JSON.parse(data).type;
        }
        catch (error) {
            return VideoType.CAMERA;
        }
    }
    getParticipantIdFromData(data) {
        try {
            return JSON.parse(data).participantId;
        }
        catch (error) {
            return '';
        }
    }
    newParticipant(props, streamModel) {
        if (this.openviduAngularConfigSrv.hasParticipantFactory()) {
            return this.openviduAngularConfigSrv.getParticipantFactory().apply(this, [props, streamModel]);
        }
        return new ParticipantModel(props, streamModel);
    }
}
ParticipantService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantService, deps: [{ token: OpenViduAngularConfigService }, { token: LoggerService }], target: i0.ɵɵFactoryTarget.Injectable });
ParticipantService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: OpenViduAngularConfigService }, { type: LoggerService }]; } });

/**
 * @internal
 */
var Storage;
(function (Storage) {
    Storage["USER_NICKNAME"] = "openviduCallNickname";
    Storage["VIDEO_DEVICE"] = "openviduCallVideoDevice";
    Storage["AUDIO_DEVICE"] = "openviduCallAudioDevice";
    Storage["AUDIO_MUTED"] = "openviduCallAudioMuted";
    Storage["VIDEO_MUTED"] = "openviduCallVideoMuted";
    Storage["LANG"] = "openviduCallLang";
})(Storage || (Storage = {}));

/**
 * @internal
 */
class StorageService {
    constructor(loggerSrv) {
        this.loggerSrv = loggerSrv;
        this.storage = window.localStorage;
        this.log = this.loggerSrv.get('StorageService');
    }
    getNickname() {
        return this.get(Storage.USER_NICKNAME);
    }
    setNickname(name) {
        this.set(Storage.USER_NICKNAME, name);
    }
    getVideoDevice() {
        return this.get(Storage.VIDEO_DEVICE);
    }
    setVideoDevice(device) {
        this.set(Storage.VIDEO_DEVICE, device);
    }
    getAudioDevice() {
        return this.get(Storage.AUDIO_DEVICE);
    }
    setAudioDevice(device) {
        this.set(Storage.AUDIO_DEVICE, device);
    }
    isVideoMuted() {
        return this.get(Storage.VIDEO_MUTED) === 'true';
    }
    setVideoMuted(muted) {
        this.set(Storage.VIDEO_MUTED, `${muted}`);
    }
    isAudioMuted() {
        return this.get(Storage.AUDIO_MUTED) === 'true';
    }
    setAudioMuted(muted) {
        this.set(Storage.AUDIO_MUTED, `${muted}`);
    }
    setLang(lang) {
        this.set(Storage.LANG, lang);
    }
    getLang() {
        return this.get(Storage.LANG);
    }
    set(key, item) {
        const value = JSON.stringify({ item: item });
        // this.log.d('Storing on localStorage "' + key + '" with value "' + value + '"');
        this.storage.setItem(key, value);
    }
    get(key) {
        const value = JSON.parse(this.storage.getItem(key));
        return (value === null || value === void 0 ? void 0 : value.item) ? value.item : null;
    }
    clear() {
        this.log.d('Clearing localStorage');
        this.storage.clear();
    }
}
StorageService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StorageService, deps: [{ token: LoggerService }], target: i0.ɵɵFactoryTarget.Injectable });
StorageService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StorageService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: LoggerService }]; } });

/**
 * @internal
 */
class DeviceService {
    constructor(loggerSrv, platformSrv, storageSrv, libSrv) {
        this.loggerSrv = loggerSrv;
        this.platformSrv = platformSrv;
        this.storageSrv = storageSrv;
        this.libSrv = libSrv;
        this.OV = null;
        this.cameras = [];
        this.microphones = [];
        this.deviceAccessDeniedError = false;
        this.log = this.loggerSrv.get('DevicesService');
    }
    /**
     * Initialize media devices and devices selected checking in local storage (if exists) or
     * first devices found by default
     */
    forceInitDevices() {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            this.clear();
            try {
                this.OV = new OpenVidu();
                this.devices = yield this.OV.getDevices();
                if ((_a = this.devices) === null || _a === void 0 ? void 0 : _a.some(device => !device.deviceId || !device.label)) {
                    // Forcing media permissions request.
                    // Sometimes, browser doesn't request the media permissions.
                    yield this.OV.getUserMedia({ audioSource: undefined, videoSource: undefined });
                }
                yield this.initializeDevices();
                this.updateAudioDeviceSelected();
                this.updateVideoDeviceSelected();
                this._isVideoMuted = this.storageSrv.isVideoMuted() || this.libSrv.videoMuted.getValue();
                this._isAudioMuted = this.storageSrv.isAudioMuted() || this.libSrv.audioMuted.getValue();
                this.log.d('Media devices', this.cameras, this.microphones);
            }
            catch (error) {
                this.deviceAccessDeniedError = error.name === OpenViduErrorName.DEVICE_ACCESS_DENIED;
            }
        });
    }
    /**
     * Initialize only the media devices available
     */
    initializeDevices() {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            if ((_a = this.devices) === null || _a === void 0 ? void 0 : _a.some(device => !device.deviceId || !device.label)) {
                this.devices = yield ((_b = this.OV) === null || _b === void 0 ? void 0 : _b.getDevices());
            }
            this.initializeCustomDevices();
        });
    }
    initializeCustomDevices(updateSelected = true) {
        const FIRST_POSITION = 0;
        const defaultMicrophones = this.devices.filter((device) => device.kind === DeviceType.AUDIO_INPUT);
        const defaultCameras = this.devices.filter((device) => device.kind === DeviceType.VIDEO_INPUT);
        if (defaultMicrophones.length > 0) {
            this.microphones = [];
            defaultMicrophones.forEach((device) => {
                this.microphones.push({ label: device.label, device: device.deviceId });
            });
        }
        if (defaultCameras.length > 0) {
            this.cameras = [];
            defaultCameras.forEach((device, index) => {
                const myDevice = {
                    label: device.label,
                    device: device.deviceId,
                    type: CameraType.BACK
                };
                if (this.platformSrv.isMobile()) {
                    // We assume front video device has 'front' in its label in Mobile devices
                    if (myDevice.label.toLowerCase().includes(CameraType.FRONT.toLowerCase())) {
                        myDevice.type = CameraType.FRONT;
                    }
                }
                else {
                    // We assume first device is web camera in Browser Desktop
                    if (index === FIRST_POSITION) {
                        myDevice.type = CameraType.FRONT;
                    }
                }
                this.cameras.push(myDevice);
            });
        }
    }
    updateAudioDeviceSelected() {
        // Setting microphone selected
        if (this.microphones.length > 0) {
            const storageMicrophone = this.getMicrophoneFromStogare();
            if (!!storageMicrophone) {
                this.microphoneSelected = storageMicrophone;
            }
            else if (this.microphones.length > 0) {
                if (this.deviceAccessDeniedError && this.microphones.length > 1) {
                    // We assume that the default device is already in use
                    // Assign an alternative device with the aim of avoiding the DEVICE_ALREADY_IN_USE error
                    this.microphoneSelected = this.microphones[1];
                }
                else {
                    this.microphoneSelected = this.microphones[0];
                }
            }
        }
    }
    updateVideoDeviceSelected() {
        // Setting camera selected
        if (this.cameras.length > 0) {
            const storageCamera = this.getCameraFromStorage();
            if (!!storageCamera) {
                this.cameraSelected = storageCamera;
            }
            else if (this.cameras.length > 0) {
                if (this.deviceAccessDeniedError && this.cameras.length > 1) {
                    // We assume that the default device is already in use
                    // Assign an alternative device with the aim of avoiding the DEVICE_ALREADY_IN_USE error
                    this.cameraSelected = this.cameras[1];
                }
                else {
                    this.cameraSelected = this.cameras[0];
                }
            }
        }
    }
    isVideoMuted() {
        return this.hasVideoDeviceAvailable() && this._isVideoMuted;
    }
    isAudioMuted() {
        return this.hasAudioDeviceAvailable() && this._isAudioMuted;
    }
    getCameraSelected() {
        return this.cameraSelected;
    }
    getMicrophoneSelected() {
        return this.microphoneSelected;
    }
    setCameraSelected(deviceField) {
        this.cameraSelected = this.getCameraByDeviceField(deviceField);
        this.saveCameraToStorage(this.cameraSelected);
    }
    setMicSelected(deviceField) {
        this.microphoneSelected = this.getMicrophoneByDeviceField(deviceField);
        this.saveMicrophoneToStorage(this.microphoneSelected);
    }
    needUpdateVideoTrack(newVideoSource) {
        var _a;
        return ((_a = this.cameraSelected) === null || _a === void 0 ? void 0 : _a.device) !== newVideoSource;
    }
    needUpdateAudioTrack(newAudioSource) {
        var _a;
        return ((_a = this.microphoneSelected) === null || _a === void 0 ? void 0 : _a.device) !== newAudioSource;
    }
    getCameras() {
        return this.cameras;
    }
    getMicrophones() {
        return this.microphones;
    }
    hasVideoDeviceAvailable() {
        return !this.videoDevicesDisabled && this.cameras.length > 0;
    }
    hasAudioDeviceAvailable() {
        return !this.audioDevicesDisabled && this.microphones.length > 0;
    }
    cameraNeedsMirror(deviceField) {
        var _a;
        return ((_a = this.getCameraByDeviceField(deviceField)) === null || _a === void 0 ? void 0 : _a.type) === CameraType.FRONT;
    }
    areEmptyLabels() {
        return !!this.cameras.find((device) => device.label === '') || !!this.microphones.find((device) => device.label === '');
    }
    disableVideoDevices() {
        this.videoDevicesDisabled = true;
    }
    disableAudioDevices() {
        this.audioDevicesDisabled = true;
    }
    clear() {
        this.OV = null;
        this.devices = [];
        this.cameras = [];
        this.microphones = [];
        this.cameraSelected = null;
        this.microphoneSelected = null;
        this.videoDevicesDisabled = false;
        this.audioDevicesDisabled = false;
    }
    getCameraByDeviceField(deviceField) {
        return this.cameras.find((opt) => opt.device === deviceField || opt.label === deviceField);
    }
    getMicrophoneByDeviceField(deviceField) {
        return this.microphones.find((opt) => opt.device === deviceField || opt.label === deviceField);
    }
    getMicrophoneFromStogare() {
        const storageDevice = this.storageSrv.getAudioDevice();
        if (!!storageDevice && this.microphones.some((device) => device.device === storageDevice.device)) {
            return storageDevice;
        }
    }
    getCameraFromStorage() {
        const storageDevice = this.storageSrv.getVideoDevice();
        if (!!storageDevice && this.cameras.some((device) => device.device === storageDevice.device)) {
            return storageDevice;
        }
    }
    saveCameraToStorage(cam) {
        this.storageSrv.setVideoDevice(cam);
    }
    saveMicrophoneToStorage(mic) {
        this.storageSrv.setAudioDevice(mic);
    }
}
DeviceService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DeviceService, deps: [{ token: LoggerService }, { token: PlatformService }, { token: StorageService }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Injectable });
DeviceService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DeviceService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DeviceService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: LoggerService }, { type: PlatformService }, { type: StorageService }, { type: OpenViduAngularConfigService }]; } });

/**
 * @internal
 */
class TokenService {
    constructor() {
        this.webcamToken = '';
        this.screenToken = '';
    }
    setWebcamToken(token) {
        this.webcamToken = token;
    }
    setScreenToken(token) {
        this.screenToken = token;
    }
    getWebcamToken() {
        return this.webcamToken;
    }
    getScreenToken() {
        return this.screenToken;
    }
}
TokenService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: TokenService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
TokenService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: TokenService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: TokenService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return []; } });

class OpenViduService {
    /**
     * @internal
     */
    constructor(openviduAngularConfigSrv, platformService, loggerSrv, participantService, deviceService, tokenService) {
        this.openviduAngularConfigSrv = openviduAngularConfigSrv;
        this.platformService = platformService;
        this.loggerSrv = loggerSrv;
        this.participantService = participantService;
        this.deviceService = deviceService;
        this.tokenService = tokenService;
        this.videoSource = undefined;
        this.audioSource = undefined;
        this.log = this.loggerSrv.get('OpenViduService');
    }
    /**
     * @internal
     */
    initialize() {
        this.OV = new OpenVidu();
        this.OV.setAdvancedConfiguration({
            publisherSpeakingEventsOptions: {
                interval: 50
            }
        });
        if (this.openviduAngularConfigSrv.isProduction())
            this.OV.enableProdMode();
        this.webcamSession = this.OV.initSession();
        // Initialize screen session only if it is not mobile platform
        if (!this.platformService.isMobile()) {
            this.OVScreen = new OpenVidu();
            if (this.openviduAngularConfigSrv.isProduction())
                this.OVScreen.enableProdMode();
            this.screenSession = this.OVScreen.initSession();
        }
    }
    /**
     * @internal
     */
    isOpenViduCE() {
        return this.ovEdition === OpenViduEdition.CE;
    }
    /**
     * @internal
     */
    setOpenViduEdition(edition) {
        this.ovEdition = edition;
    }
    isSessionConnected() {
        return !!this.webcamSession.connection;
    }
    /**
     * @internal
     */
    clear() {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            this.videoSource = undefined;
            this.audioSource = undefined;
            yield ((_b = (_a = this.participantService.getMyCameraPublisher()) === null || _a === void 0 ? void 0 : _a.stream) === null || _b === void 0 ? void 0 : _b.disposeMediaStream());
            yield ((_d = (_c = this.participantService.getMyScreenPublisher()) === null || _c === void 0 ? void 0 : _c.stream) === null || _d === void 0 ? void 0 : _d.disposeMediaStream());
        });
    }
    /**
     *
     * Returns the local Session. See {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Session.html  Session} object.
     */
    getSession() {
        return this.getWebcamSession();
    }
    /**
     * @internal
     */
    getWebcamSession() {
        return this.webcamSession;
    }
    /**
     * @internal
     */
    isWebcamSessionConnected() {
        return !!this.webcamSession.capabilities;
    }
    /**
     * @internal
     */
    getScreenSession() {
        return this.screenSession;
    }
    /**
     * @internal
     */
    isScreenSessionConnected() {
        return !!this.screenSession.capabilities;
    }
    /**
     * @internal
     */
    connectSession(session, token) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!!token && session) {
                const nickname = this.participantService.getMyNickname();
                const participantId = this.participantService.getLocalParticipant().id;
                if (session === this.webcamSession) {
                    this.log.d('Connecting webcam session');
                    yield this.webcamSession.connect(token, {
                        clientData: nickname,
                        participantId,
                        type: VideoType.CAMERA
                    });
                    this.participantService.setMyCameraConnectionId(this.webcamSession.connection.connectionId);
                }
                else if (session === this.screenSession) {
                    this.log.d('Connecting screen session');
                    yield this.screenSession.connect(token, {
                        clientData: `${nickname}_${VideoType.SCREEN}`,
                        participantId,
                        type: VideoType.SCREEN
                    });
                    this.participantService.setMyScreenConnectionId(this.screenSession.connection.connectionId);
                }
            }
        });
    }
    /**
     * Leaves the session, destroying all local streams and clean all participant data.
     */
    disconnect() {
        this.disconnectSession(this.webcamSession);
        this.disconnectSession(this.screenSession);
    }
    /**
     * @internal
     * Initialize a publisher checking devices saved on storage or if participant have devices available.
     */
    initDefaultPublisher() {
        return __awaiter(this, void 0, void 0, function* () {
            const hasVideoDevices = this.deviceService.hasVideoDeviceAvailable();
            const hasAudioDevices = this.deviceService.hasAudioDeviceAvailable();
            const isVideoActive = !this.deviceService.isVideoMuted();
            const isAudioActive = !this.deviceService.isAudioMuted();
            let videoSource = false;
            let audioSource = false;
            if (hasVideoDevices) {
                // Video is active, assign the device selected
                videoSource = this.deviceService.getCameraSelected().device;
            }
            else if (!isVideoActive && hasVideoDevices) {
                // Video is muted, assign the default device
                // videoSource = undefined;
            }
            if (hasAudioDevices) {
                // Audio is active, assign the device selected
                audioSource = this.deviceService.getMicrophoneSelected().device;
            }
            else if (!isAudioActive && hasAudioDevices) {
                // Audio is muted, assign the default device
                // audioSource = undefined;
            }
            const mirror = this.deviceService.getCameraSelected() && this.deviceService.getCameraSelected().type === CameraType.FRONT;
            const properties = {
                videoSource,
                audioSource,
                publishVideo: isVideoActive,
                publishAudio: isAudioActive,
                mirror
            };
            if (hasVideoDevices || hasAudioDevices) {
                const publisher = yield this.initPublisher(undefined, properties);
                this.participantService.setMyCameraPublisher(publisher);
                this.participantService.updateLocalParticipant();
                return publisher;
            }
            else {
                this.participantService.setMyCameraPublisher(null);
            }
        });
    }
    /**
     * @internal
     */
    initPublisher(targetElement, properties) {
        return __awaiter(this, void 0, void 0, function* () {
            this.log.d('Initializing publisher with properties: ', properties);
            return yield this.OV.initPublisherAsync(targetElement, properties);
        });
    }
    /**
     * @internal
     */
    publish(publisher) {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            if (!!publisher) {
                if (publisher === this.participantService.getMyCameraPublisher()) {
                    if ((_b = (_a = this.webcamSession) === null || _a === void 0 ? void 0 : _a.capabilities) === null || _b === void 0 ? void 0 : _b.publish) {
                        return yield this.webcamSession.publish(publisher);
                    }
                    this.log.e('Webcam publisher cannot be published');
                }
                else if (publisher === this.participantService.getMyScreenPublisher()) {
                    if ((_d = (_c = this.screenSession) === null || _c === void 0 ? void 0 : _c.capabilities) === null || _d === void 0 ? void 0 : _d.publish) {
                        return yield this.screenSession.publish(publisher);
                    }
                    this.log.e('Screen publisher cannot be published');
                }
            }
        });
    }
    /**
     * @internal
     */
    unpublish(publisher) {
        if (!!publisher) {
            if (publisher === this.participantService.getMyCameraPublisher()) {
                this.publishAudioAux(this.participantService.getMyScreenPublisher(), this.participantService.isMyAudioActive());
                this.webcamSession.unpublish(publisher);
            }
            else if (publisher === this.participantService.getMyScreenPublisher()) {
                this.screenSession.unpublish(publisher);
            }
        }
    }
    /**
     * Publish or unpublish the video stream (if available).
     * It hides the camera muted stream if screen is sharing.
     * See openvidu-browser {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Publisher.html#publishVideo publishVideo}
     */
    publishVideo(publish) {
        return __awaiter(this, void 0, void 0, function* () {
            const publishAudio = this.participantService.isMyAudioActive();
            // Disabling webcam
            if (this.participantService.haveICameraAndScreenActive()) {
                yield this.publishVideoAux(this.participantService.getMyCameraPublisher(), publish);
                this.participantService.disableWebcamStream();
                this.unpublish(this.participantService.getMyCameraPublisher());
                this.publishAudioAux(this.participantService.getMyScreenPublisher(), publishAudio);
            }
            else if (this.participantService.isOnlyMyScreenActive()) {
                // Enabling webcam
                const hasAudio = this.participantService.hasScreenAudioActive();
                if (!this.isWebcamSessionConnected()) {
                    //TODO: should be the token in the participant?
                    yield this.connectSession(this.getWebcamSession(), this.tokenService.getWebcamToken());
                }
                yield this.publish(this.participantService.getMyCameraPublisher());
                yield this.publishVideoAux(this.participantService.getMyCameraPublisher(), true);
                this.publishAudioAux(this.participantService.getMyScreenPublisher(), false);
                this.publishAudioAux(this.participantService.getMyCameraPublisher(), hasAudio);
                this.participantService.enableWebcamStream();
            }
            else {
                // Muting/unmuting webcam
                yield this.publishVideoAux(this.participantService.getMyCameraPublisher(), publish);
            }
        });
    }
    /**
     * @internal
     */
    publishVideoAux(publisher, publish) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            if (!!publisher) {
                let resource = true;
                if (publish) {
                    // Forcing restoration with a custom media stream (the older one instead the default)
                    const currentDeviceId = (_a = this.deviceService.getCameraSelected()) === null || _a === void 0 ? void 0 : _a.device;
                    const mediaStream = yield this.createMediaStream({ videoSource: currentDeviceId, audioSource: false });
                    resource = mediaStream.getVideoTracks()[0];
                }
                yield publisher.publishVideo(publish, resource);
                this.participantService.updateLocalParticipant();
            }
        });
    }
    /**
     * Publish or unpublish the audio stream (if available).
     * See openvidu-browser {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Publisher.html#publishAudio publishAudio}.
     */
    publishAudio(publish) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.participantService.isMyCameraActive()) {
                if (this.participantService.isMyScreenActive() && this.participantService.hasScreenAudioActive()) {
                    this.publishAudioAux(this.participantService.getMyScreenPublisher(), false);
                }
                this.publishAudioAux(this.participantService.getMyCameraPublisher(), publish);
            }
            else {
                this.publishAudioAux(this.participantService.getMyScreenPublisher(), publish);
            }
        });
    }
    /**
     * Share or unshare the screen.
     * Hide the camera muted stream when screen is sharing.
     */
    toggleScreenshare() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.participantService.haveICameraAndScreenActive()) {
                // Disabling screenShare
                this.participantService.disableScreenStream();
                this.unpublish(this.participantService.getMyScreenPublisher());
            }
            else if (this.participantService.isOnlyMyCameraActive()) {
                // I only have the camera published
                const hasAudioDevicesAvailable = this.deviceService.hasAudioDeviceAvailable();
                const willWebcamBePresent = this.participantService.isMyCameraActive() && this.participantService.isMyVideoActive();
                const hasAudio = willWebcamBePresent ? false : hasAudioDevicesAvailable && this.participantService.isMyAudioActive();
                const properties = {
                    videoSource: ScreenType.SCREEN,
                    audioSource: hasAudioDevicesAvailable ? this.deviceService.getMicrophoneSelected().device : false,
                    publishVideo: true,
                    publishAudio: hasAudio,
                    mirror: false
                };
                const screenPublisher = yield this.initPublisher(undefined, properties);
                screenPublisher.once('accessAllowed', () => __awaiter(this, void 0, void 0, function* () {
                    // Listen to event fired when native stop button is clicked
                    screenPublisher.stream
                        .getMediaStream()
                        .getVideoTracks()[0]
                        .addEventListener('ended', () => __awaiter(this, void 0, void 0, function* () {
                        this.log.d('Clicked native stop button. Stopping screen sharing');
                        yield this.toggleScreenshare();
                    }));
                    // Enabling screenShare
                    this.participantService.activeMyScreenShare(screenPublisher);
                    if (!this.isScreenSessionConnected()) {
                        yield this.connectSession(this.getScreenSession(), this.tokenService.getScreenToken());
                    }
                    yield this.publish(this.participantService.getMyScreenPublisher());
                    if (!this.participantService.isMyVideoActive()) {
                        // Disabling webcam
                        this.participantService.disableWebcamStream();
                        this.unpublish(this.participantService.getMyCameraPublisher());
                    }
                }));
                screenPublisher.once('accessDenied', (error) => {
                    return Promise.reject(error);
                });
            }
            else {
                // I only have my screenshare active and I have no camera or it is muted
                const hasAudio = this.participantService.hasScreenAudioActive();
                // Enable webcam
                if (!this.isWebcamSessionConnected()) {
                    yield this.connectSession(this.getWebcamSession(), this.tokenService.getWebcamToken());
                }
                yield this.publish(this.participantService.getMyCameraPublisher());
                this.publishAudioAux(this.participantService.getMyCameraPublisher(), hasAudio);
                this.participantService.enableWebcamStream();
                // Disabling screenshare
                this.participantService.disableScreenStream();
                this.unpublish(this.participantService.getMyScreenPublisher());
            }
        });
    }
    /**
     * @internal
     */
    publishAudioAux(publisher, value) {
        if (!!publisher) {
            publisher.publishAudio(value);
            this.participantService.updateLocalParticipant();
        }
    }
    /**
     * @internal
     */
    sendSignal(type, connections, data) {
        const signalOptions = {
            data: JSON.stringify(data),
            type,
            to: connections && connections.length > 0 ? connections : undefined
        };
        this.webcamSession.signal(signalOptions);
    }
    /**
     * @internal
     */
    replaceTrack(videoType, props) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                this.log.d(`Replacing ${videoType} track`, props);
                if (videoType === VideoType.CAMERA) {
                    let mediaStream;
                    const isReplacingAudio = !!props.audioSource;
                    const isReplacingVideo = !!props.videoSource;
                    if (isReplacingVideo) {
                        mediaStream = yield this.createMediaStream(props);
                        // Replace video track
                        const videoTrack = mediaStream.getVideoTracks()[0];
                        yield this.participantService.getMyCameraPublisher().replaceTrack(videoTrack);
                    }
                    else if (isReplacingAudio) {
                        mediaStream = yield this.createMediaStream(props);
                        // Replace audio track
                        const audioTrack = mediaStream.getAudioTracks()[0];
                        yield this.participantService.getMyCameraPublisher().replaceTrack(audioTrack);
                    }
                }
                else if (videoType === VideoType.SCREEN) {
                    try {
                        let newScreenMediaStream = yield this.OVScreen.getUserMedia(props);
                        this.participantService.getMyScreenPublisher().stream.getMediaStream().getVideoTracks()[0].stop();
                        yield this.participantService.getMyScreenPublisher().replaceTrack(newScreenMediaStream.getVideoTracks()[0]);
                    }
                    catch (error) {
                        this.log.w('Cannot create the new MediaStream', error);
                    }
                }
            }
            catch (error) {
                this.log.e('Error replacing track ', error);
            }
        });
    }
    destroyPublisher(publisher) {
        if (!!publisher) {
            if (publisher.stream.getWebRtcPeer()) {
                publisher.stream.disposeWebRtcPeer();
            }
            publisher.stream.disposeMediaStream();
            if (publisher.id === this.participantService.getMyCameraPublisher().id) {
                this.participantService.setMyCameraPublisher(publisher);
            }
            else if (publisher.id === this.participantService.getMyScreenPublisher().id) {
                this.participantService.setMyScreenPublisher(publisher);
            }
        }
    }
    createMediaStream(pp) {
        return __awaiter(this, void 0, void 0, function* () {
            let mediaStream;
            const isFirefoxPlatform = this.platformService.isFirefox();
            const isReplacingAudio = !!pp.audioSource;
            const isReplacingVideo = !!pp.videoSource;
            try {
                mediaStream = yield this.OV.getUserMedia(pp);
            }
            catch (error) {
                if (error.name === OpenViduErrorName.DEVICE_ACCESS_DENIED) {
                    if (isFirefoxPlatform) {
                        this.log.w('The device requested is not available. Restoring the older one');
                        // The track requested is not available so we are getting the old tracks ids for recovering the track
                        if (isReplacingVideo) {
                            pp.videoSource = this.deviceService.getCameraSelected().device;
                        }
                        else if (isReplacingAudio) {
                            pp.audioSource = this.deviceService.getMicrophoneSelected().device;
                        }
                        mediaStream = yield this.OV.getUserMedia(pp);
                        // TODO show error alert informing that the new device is not available
                    }
                }
            }
            finally {
                return mediaStream;
            }
        });
    }
    /**
     * @internal
     */
    needSendNicknameSignal() {
        let oldNickname;
        try {
            const connData = JSON.parse(this.webcamSession.connection.data.split('%/%')[0]);
            oldNickname = connData.clientData;
        }
        catch (error) {
            this.log.e(error);
        }
        return oldNickname !== this.participantService.getMyNickname();
    }
    /**
     * @internal
     */
    isMyOwnConnection(connectionId) {
        var _a, _b, _c, _d;
        return (((_b = (_a = this.webcamSession) === null || _a === void 0 ? void 0 : _a.connection) === null || _b === void 0 ? void 0 : _b.connectionId) === connectionId || ((_d = (_c = this.screenSession) === null || _c === void 0 ? void 0 : _c.connection) === null || _d === void 0 ? void 0 : _d.connectionId) === connectionId);
    }
    /**
     *
     * Returns the remote connections of the Session.
     * See {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Connection.html  Connection} object.
     */
    getRemoteConnections() {
        // Avoid screen connections
        const remoteCameraConnections = Array.from(this.webcamSession.remoteConnections.values()).filter((conn) => {
            let type;
            type = JSON.parse(conn.data).type;
            return type !== VideoType.SCREEN;
        });
        return remoteCameraConnections;
    }
    disconnectSession(session) {
        var _a, _b, _c, _d;
        if (session) {
            if (session.sessionId === ((_a = this.webcamSession) === null || _a === void 0 ? void 0 : _a.sessionId)) {
                this.log.d('Disconnecting webcam session');
                (_b = this.webcamSession) === null || _b === void 0 ? void 0 : _b.disconnect();
                this.webcamSession = null;
            }
            else if (session.sessionId === ((_c = this.screenSession) === null || _c === void 0 ? void 0 : _c.sessionId)) {
                this.log.d('Disconnecting screen session');
                (_d = this.screenSession) === null || _d === void 0 ? void 0 : _d.disconnect();
                this.screenSession = null;
            }
        }
    }
}
OpenViduService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduService, deps: [{ token: OpenViduAngularConfigService }, { token: PlatformService }, { token: LoggerService }, { token: ParticipantService }, { token: DeviceService }, { token: TokenService }], target: i0.ɵɵFactoryTarget.Injectable });
OpenViduService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: OpenViduAngularConfigService }, { type: PlatformService }, { type: LoggerService }, { type: ParticipantService }, { type: DeviceService }, { type: TokenService }]; } });

class PanelService {
    /**
     * @internal
     */
    constructor(loggerSrv) {
        this.loggerSrv = loggerSrv;
        this.isExternalOpened = false;
        this._panelOpened = new BehaviorSubject({ opened: false });
        this.panelMap = new Map();
        this.log = this.loggerSrv.get('PanelService');
        this.panelOpenedObs = this._panelOpened.asObservable();
        Object.values(PanelType).forEach((panel) => this.panelMap.set(panel, false));
    }
    /**
     * Open or close the panel type received. Calling this method with the panel opened and the same type panel, will close the panel.
     * If the type is differente, it will switch to the properly panel.
     */
    togglePanel(type, expand) {
        let nextOpenedValue = false;
        if (this.panelMap.has(type)) {
            this.log.d(`Toggling ${type} menu`);
            this.panelMap.forEach((opened, panel) => {
                if (panel === type) {
                    // Toggle panel
                    this.panelMap.set(panel, !opened);
                    nextOpenedValue = !opened;
                }
                else {
                    // Close others
                    this.panelMap.set(panel, false);
                }
            });
        }
        else {
            // Panel is external
            this.log.d('Toggling external panel');
            // Close all panels
            this.panelMap.forEach((_, panel) => this.panelMap.set(panel, false));
            // Opening when external panel is closed or is opened with another type
            this.isExternalOpened = !this.isExternalOpened || this.externalType !== type;
            this.externalType = !this.isExternalOpened ? '' : type;
            nextOpenedValue = this.isExternalOpened;
        }
        const oldType = this._panelOpened.getValue().type;
        this._panelOpened.next({ opened: nextOpenedValue, type, expand, oldType });
    }
    /**
     * @internal
     */
    isPanelOpened() {
        const anyOpened = Array.from(this.panelMap.values()).some((opened) => opened);
        return anyOpened || this.isExternalPanelOpened();
    }
    /**
     * Closes the panel (if opened)
     */
    closePanel() {
        this.panelMap.forEach((_, panel) => this.panelMap.set(panel, false));
        this._panelOpened.next({ opened: false });
    }
    /**
     * Whether the chat panel is opened or not.
     */
    isChatPanelOpened() {
        return !!this.panelMap.get(PanelType.CHAT);
    }
    /**
     * Whether the participants panel is opened or not.
     */
    isParticipantsPanelOpened() {
        return !!this.panelMap.get(PanelType.PARTICIPANTS);
    }
    /**
     * Whether the activities panel is opened or not.
     */
    isActivitiesPanelOpened() {
        return !!this.panelMap.get(PanelType.ACTIVITIES);
    }
    /**
     * Whether the settings panel is opened or not.
     */
    isSettingsPanelOpened() {
        return !!this.panelMap.get(PanelType.SETTINGS);
    }
    /**
     * Whether the background effects panel is opened or not.
     */
    isBackgroundEffectsPanelOpened() {
        return !!this.panelMap.get(PanelType.BACKGROUND_EFFECTS);
    }
    isExternalPanelOpened() {
        return this.isExternalOpened;
    }
}
PanelService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PanelService, deps: [{ token: LoggerService }], target: i0.ɵɵFactoryTarget.Injectable });
PanelService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PanelService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PanelService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: LoggerService }]; } });

var ADMIN$9 = {
    LOGIN: "Login",
    SECRET: "Secret",
    SECRET_REQURED: "Secret is required",
    DASHBOARD: "Dashboard",
    NO_RECORDINGS: "There are no recordings",
    SEARCH: "Search a recording",
    DATE: "Date",
    DURATION: "Duration",
    SIZE: "Size",
    STATUS: "Status",
    NAME: "Name",
    SESSION: "Session",
    OUTPUT: "Output mode",
    POWERED_BY: "Powered by"
};
var PREJOIN$9 = {
    NICKNAME_SECTION: "Set your nickname",
    NICKNAME: "Nickname",
    DEVICE_SECTION: "Choose your devices",
    VIDEO_DEVICE: "Video device",
    AUDIO_DEVICE: "Audio device",
    JOIN: "Join session",
    PREPARING: "Preparing session..."
};
var TOOLBAR$9 = {
    MUTE_AUDIO: "Mute your audio",
    UNMUTE_AUDIO: "Unmute your audio",
    MUTE_VIDEO: "Mute your video",
    UNMUTE_VIDEO: "Unmute your video",
    ENABLE_SCREEN: "Enable screen share",
    DISABLE_SCREEN: "Disable screen share",
    MORE_OPTIONS: "More options",
    FULLSCREEN: "Fullscreen",
    EXIT_FULLSCREEN: "Exit fullscreen",
    ENABLE_SUBTITLES: "Enable subtitles",
    DISABLE_SUBTITLES: "Disable subtitles",
    BACKGROUND: "Background effects",
    START_RECORDING: "Start recording",
    STOP_RECORDING: "Stop recording",
    SETTINGS: "Settings",
    LEAVE: "Leave the session",
    PARTICIPANTS: "Participants",
    CHAT: "Chat",
    ACTIVITIES: "Activities"
};
var STREAM$9 = {
    SETTINGS: "Settings",
    MUTE_SOUND: "Mute sound",
    UNMUTE_SOUND: "Unmute sound",
    ZOOM_IN: "Zoom in",
    ZOOM_OUT: "Zoom out",
    REPLACE_SCREEN: "Replace screen"
};
var PANEL$9 = {
    CLOSE: "Close",
    CHAT: {
        TITLE: "Chat",
        YOU: "You",
        SUBTITLE: "Messages will be removed at the end of the session",
        PLACEHOLDER: "Send a message...",
        SEND: "Send"
    },
    PARTICIPANTS: {
        TITLE: "Participants",
        CAMERA: "CAMERA",
        SCREEN: "SCREEN"
    },
    SETTINGS: {
        TITLE: "Settings",
        GENERAL: "General",
        VIDEO: "Video",
        AUDIO: "Audio",
        LANGUAGE: "Language",
        SUBTITLE: "Subtitles"
    },
    BACKGROUND: {
        TITLE: "Background effects",
        BLURRED_SECTION: "No effects and blurred background",
        NO_EFFECTS: "No background effect",
        BLURRED_EFFECT: "Blurred background",
        IMAGES_SECTION: "Background images"
    },
    RECORDING: {
        TITLE: "Recording",
        SUBTITLE: "Record your meeting for posterity",
        CONTENT_TITLE: "Record your video call",
        CONTENT_SUBTITLE: "When recording has finished you will be able to download it with ease",
        STARTING: "Starting recording",
        STOPPING: "Stopping recording",
        PLAY: "Play",
        DELETE: "Delete",
        CANCEL: "Cancel",
        RESTORE: "Restore",
        DELETE_QUESTION: "Are you sure you want to delete the recording?",
        DOWNLOAD: "Download",
        RECORDINGS: "RECORDINGS",
        NO_MODERATOR: "Only the MODERATOR can start the recording"
    }
};
var ERRORS$9 = {
    SESSION: "There was an error connecting to the session",
    CONNECTION: "Connection lost",
    RECONNECT: "Oops! Trying to reconnect to the session...",
    TOGGLE_CAMERA: "There was an error toggling camera",
    TOGGLE_MICROPHONE: "There was an error toggling microhpone",
    SCREEN_SHARING: "Error sharing screen",
    SCREEN_SUPPORT: "Your browser does not support screen sharing",
    MEDIA_ACCESS: "Access to media devices was not allowed.",
    DEVICE_NOT_FOUND: "No video or audio devices have been found. Please, connect at least one."
};
var en = {
    ADMIN: ADMIN$9,
    PREJOIN: PREJOIN$9,
    TOOLBAR: TOOLBAR$9,
    STREAM: STREAM$9,
    PANEL: PANEL$9,
    ERRORS: ERRORS$9
};

var en$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN$9,
    PREJOIN: PREJOIN$9,
    TOOLBAR: TOOLBAR$9,
    STREAM: STREAM$9,
    PANEL: PANEL$9,
    ERRORS: ERRORS$9,
    'default': en
});

var ADMIN$8 = {
    LOGIN: "Iniciar sesión",
    SECRET: "Contraseña",
    SECRET_REQURED: "Contraseña obligatoria",
    DASHBOARD: "Panel",
    NO_RECORDINGS: "No se han encontrado grabaciones",
    SEARCH: "Busca una grabación",
    DATE: "Fecha",
    DURATION: "Duración",
    SIZE: "Tamaño",
    STATUS: "Estado",
    NAME: "Nombre",
    SESSION: "Sesión",
    OUTPUT: "Modo",
    POWERED_BY: "Construido por"
};
var PREJOIN$8 = {
    NICKNAME_SECTION: "Elige tu nombre",
    NICKNAME: "Nombre",
    DEVICE_SECTION: "Elige tus dispositivos",
    VIDEO_DEVICE: "Dispositivo de video",
    AUDIO_DEVICE: "Dispositivo de audio",
    PREPARING: "Preparando la session ...",
    JOIN: "Unirme ahora"
};
var TOOLBAR$8 = {
    MUTE_AUDIO: "Silenciar tu audio",
    UNMUTE_AUDIO: "Activar tu audio",
    MUTE_VIDEO: "Silenciar tu video",
    UNMUTE_VIDEO: "Activar tu video",
    ENABLE_SCREEN: "Compartir pantalla",
    DISABLE_SCREEN: "Dejar de compartir pantalla",
    MORE_OPTIONS: "Más opciones",
    EXIT_FULLSCREEN: "Quitar pantalla completa",
    FULLSCREEN: "Pantalla completa",
    ENABLE_SUBTITLES: "Activar subtítulos",
    DISABLE_SUBTITLES: "Desactivar subtítulos",
    BACKGROUND: "Efectos de fondo",
    START_RECORDING: "Iniciar grabación",
    STOP_RECORDING: "Detener grabación",
    SETTINGS: "Configuración",
    LEAVE: "Salir de la sesión",
    PARTICIPANTS: "Participantes",
    CHAT: "Chat",
    ACTIVITIES: "Actividades"
};
var STREAM$8 = {
    SETTINGS: "Ajustes",
    MUTE_SOUND: "Silenciar sonido",
    UNMUTE_SOUND: "Activar sonido",
    ZOOM_IN: "Aumentar tamaño",
    ZOOM_OUT: "Disminuir tamaño",
    REPLACE_SCREEN: "Reemplazar pantalla"
};
var PANEL$8 = {
    CLOSE: "Cerrar",
    CHAT: {
        TITLE: "Chat",
        YOU: "Tú",
        SUBTITLE: "Los mensajes se borrarán al finalizar la sesión",
        PLACEHOLDER: "Enviar mensaje...",
        SEND: "Enviar"
    },
    PARTICIPANTS: {
        TITLE: "Participantes",
        CAMERA: "CÁMARA",
        SCREEN: "PANTALLA"
    },
    SETTINGS: {
        TITLE: "Configuración",
        GENERAL: "General",
        VIDEO: "Video",
        AUDIO: "Audio",
        LANGUAGE: "Idioma",
        SUBTITLE: "Subtítulos"
    },
    BACKGROUND: {
        TITLE: "Efectos de fondo",
        BLURRED_SECTION: "Sin efectos y fondo desenfocado",
        NO_EFFECTS: "Sin efecto",
        BLURRED_EFFECT: "Fondo desenfocado",
        IMAGES_SECTION: "Imágenes de fondo"
    },
    RECORDING: {
        TITLE: "Grabación",
        SUBTITLE: "Graba tus llamadas para la posteridad",
        CONTENT_TITLE: "Graba tu video conferencia",
        CONTENT_SUBTITLE: "Cuando la grabación haya finalizado, podrás descargarla con facilidad",
        STARTING: "Iniciando grabación",
        STOPPING: "Parando grabación",
        PLAY: "Reproducir",
        DELETE: "Borrar",
        CANCEL: "Cancelar",
        DELETE_QUESTION: "¿Estás seguro/a de que deseas borrar la grabación?",
        DOWNLOAD: "Descargar",
        RECORDINGS: "GRABACIONES",
        NO_MODERATOR: "Sólo el MODERADOR puede iniciar la grabación"
    }
};
var ERRORS$8 = {
    SESSION: "Hubo un error al conectar a la sesión",
    CONNECTION: "Sin conexión",
    RECONNECT: "Intentando reconectar a la sesión...",
    TOGGLE_CAMERA: "Hubo un error cambiando la cámara",
    TOGGLE_MICROPHONE: "Hubo un error cambiando el micrófono",
    SCREEN_SHARING: "Hubo un error compartiendo pantalla",
    SCREEN_SUPPORT: "Tu navegador no soporta la pantalla compartida",
    MEDIA_ACCESS: "No se ha podido acceder a tus dispositivos",
    DEVICE_NOT_FOUND: "No se han encontrado dispositivos de audio o video. Por favor, conecta al menos uno."
};
var es = {
    ADMIN: ADMIN$8,
    PREJOIN: PREJOIN$8,
    TOOLBAR: TOOLBAR$8,
    STREAM: STREAM$8,
    PANEL: PANEL$8,
    ERRORS: ERRORS$8
};

var es$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN$8,
    PREJOIN: PREJOIN$8,
    TOOLBAR: TOOLBAR$8,
    STREAM: STREAM$8,
    PANEL: PANEL$8,
    ERRORS: ERRORS$8,
    'default': es
});

var ADMIN$7 = {
    LOGIN: "Anmeldung",
    SECRET: "Geheimnis",
    SECRET_REQURED: "Geheimnis ist erforderlich",
    DASHBOARD: "Armaturenbrett",
    NO_RECORDINGS: "Aufnahmen gibt es nicht",
    SEARCH: "Suchen Sie eine Aufzeichnung",
    DATE: "Datum",
    DURATION: "Dauer",
    SIZE: "Größe",
    STATUS: "Status",
    NAME: "Name",
    SESSION: "Sitzung",
    OUTPUT: "Ausgabemodus",
    POWERED_BY: "Unterstützt von"
};
var PREJOIN$7 = {
    NICKNAME_SECTION: "Legen Sie Ihren Spitznamen fest",
    NICKNAME: "Spitzname",
    DEVICE_SECTION: "Wählen Sie Ihre Geräte",
    VIDEO_DEVICE: "Videogerät",
    AUDIO_DEVICE: "Audiogerät",
    JOIN: "Sitzung beitreten",
    PREPARING: "Sitzung vorbereiten..."
};
var TOOLBAR$7 = {
    MUTE_AUDIO: "Stummschalten des Audios",
    UNMUTE_AUDIO: "Stummschaltung für Audio aufheben",
    MUTE_VIDEO: "Stummschalten des Videos",
    UNMUTE_VIDEO: "Heben Sie die Stummschaltung Ihres Videos auf",
    ENABLE_SCREEN: "Bildschirmfreigabe aktivieren",
    DISABLE_SCREEN: "Bildschirmfreigabe deaktivieren",
    MORE_OPTIONS: "Weitere Optionen",
    FULLSCREEN: "Vollbild",
    EXIT_FULLSCREEN: "Vollbildmodus beenden",
    ENABLE_SUBTITLES: "Untertitel aktivieren",
    DISABLE_SUBTITLES: "Untertitel deaktivieren",
    BACKGROUND: "Hintergrund-Effekte",
    START_RECORDING: "Aufzeichnung starten",
    STOP_RECORDING: "Aufzeichnung stoppen",
    SETTINGS: "Einstellungen",
    LEAVE: "Die Sitzung verlassen",
    PARTICIPANTS: "Teilnehmer",
    CHAT: "Chat",
    ACTIVITIES: "Aktivitäten"
};
var STREAM$7 = {
    SETTINGS: "Einstellungen",
    MUTE_SOUND: "Ton stummschalten",
    UNMUTE_SOUND: "Stummschaltung aufheben",
    ZOOM_IN: "Vergrößern",
    ZOOM_OUT: "Herauszoomen",
    REPLACE_SCREEN: "Bildschirm austauschen"
};
var PANEL$7 = {
    CLOSE: "Schließen",
    CHAT: {
        TITLE: "Chat",
        YOU: "Sie",
        SUBTITLE: "Nachrichten werden am Ende der Sitzung entfernt",
        PLACEHOLDER: "Eine Nachricht senden...",
        SEND: "Senden"
    },
    PARTICIPANTS: {
        TITLE: "Teilnehmer",
        CAMERA: "KAMERA",
        SCREEN: "BILDSCHIRM"
    },
    SETTINGS: {
        TITLE: "Einstellungen",
        GENERAL: "Allgemein",
        VIDEO: "Video",
        AUDIO: "Audio",
        LANGUAGE: "Sprache",
        SUBTITLE: "Untertitel"
    },
    BACKGROUND: {
        TITLE: "Hintergrund-Effekte",
        BLURRED_SECTION: "Keine Effekte und unscharfer Hintergrund",
        NO_EFFECTS: "Kein Hintergrundeffekt",
        BLURRED_EFFECT: "Unscharfer Hintergrund",
        IMAGES_SECTION: "Hintergrundbilder"
    },
    RECORDING: {
        TITLE: "Aufnahme",
        SUBTITLE: "Zeichnen Sie Ihr Meeting für die Nachwelt auf",
        CONTENT_TITLE: "Ihr Videogespräch aufzeichnen",
        CONTENT_SUBTITLE: "Wenn die Aufzeichnung beendet ist, können Sie sie ganz einfach herunterladen",
        STARTING: "Aufzeichnung starten",
        STOPPING: "Aufnahme stoppen",
        PLAY: "Spielen",
        DELETE: "Löschen",
        CANCEL: "Absagen",
        DELETE_QUESTION: "Möchten Sie die Aufzeichnung wirklich löschen?",
        DOWNLOAD: "Download",
        RECORDINGS: "AUFZEICHNUNGEN",
        NO_MODERATOR: "Nur der MODERATOR kann die Aufzeichnung starten"
    }
};
var ERRORS$7 = {
    SESSION: "Es ist ein Fehler beim Verbinden mit der Sitzung aufgetreten",
    CONNECTION: "Verbindung verloren",
    RECONNECT: "Ich versuche, die Verbindung zur Sitzung wiederherzustellen...",
    TOGGLE_CAMERA: "Es gab einen Fehler beim Umschalten der Kamera",
    TOGGLE_MICROPHONE: "Es ist ein Fehler beim Umschalten des Mikrofons aufgetreten",
    SCREEN_SHARING: "Fehler beim Teilen des Bildschirms",
    SCREEN_SUPPORT: "Ihr Browser unterstützt keine Bildschirmfreigabe",
    MEDIA_ACCESS: "Der Zugriff auf Mediengeräte war nicht erlaubt.",
    DEVICE_NOT_FOUND: "Es wurden keine Video- oder Audiogeräte gefunden. Bitte schließen Sie mindestens eines an."
};
var de = {
    ADMIN: ADMIN$7,
    PREJOIN: PREJOIN$7,
    TOOLBAR: TOOLBAR$7,
    STREAM: STREAM$7,
    PANEL: PANEL$7,
    ERRORS: ERRORS$7
};

var de$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN$7,
    PREJOIN: PREJOIN$7,
    TOOLBAR: TOOLBAR$7,
    STREAM: STREAM$7,
    PANEL: PANEL$7,
    ERRORS: ERRORS$7,
    'default': de
});

var ADMIN$6 = {
    LOGIN: "Connexion",
    SECRET: "Secret",
    SECRET_REQURED: "Le secret est requis",
    DASHBOARD: "Tableau de bord",
    NO_RECORDINGS: "Il n'y a pas d'enregistrements",
    SEARCH: "Rechercher un enregistrement",
    DATE: "Date",
    DURATION: "Durée",
    SIZE: "Taille",
    STATUS: "Statut",
    NAME: "Nom",
    SESSION: "Session",
    OUTPUT: "Mode de sortie",
    POWERED_BY: "Alimenté par"
};
var PREJOIN$6 = {
    NICKNAME_SECTION: "Définir votre surnom",
    NICKNAME: "Surnom",
    DEVICE_SECTION: "Choisissez vos appareils",
    VIDEO_DEVICE: "Périphérique vidéo",
    AUDIO_DEVICE: "Périphérique audio",
    JOIN: "Joindre une session",
    PREPARING: "Préparation de la session ..."
};
var TOOLBAR$6 = {
    MUTE_AUDIO: "Mettez votre audio en sourdine",
    UNMUTE_AUDIO: "Désactiver le son",
    MUTE_VIDEO: "Couper le son de votre vidéo",
    UNMUTE_VIDEO: "Unmute your video",
    ENABLE_SCREEN: "Activer le partage d'écran",
    DISABLE_SCREEN: "Désactiver le partage d'écran",
    MORE_OPTIONS: "Plus d'options",
    FULLSCREEN: "Plein écran",
    EXIT_FULLSCREEN: "Quitter le plein écran",
    ENABLE_SUBTITLES: "Activer les sous-titres",
    DISABLE_SUBTITLES: "Désactiver les sous-titres",
    BACKGROUND: "Effets de fond",
    START_RECORDING: "démarrer l'enregistrement",
    STOP_RECORDING: "Arrêter l'enregistrement",
    SETTINGS: "Paramètres",
    LEAVE: "Quitter la session",
    PARTICIPANTS: "Participants",
    CHAT: "Chat",
    ACTIVITES: "Activités"
};
var STREAM$6 = {
    SETTINGS: "Paramètres",
    MUTE_SOUND: "Couper le son",
    UNMUTE_SOUND: "Désactiver le son",
    ZOOM_IN: "Zoom avant",
    ZOOM_OUT: "Zoom arrière",
    REPLACE_SCREEN: "Remplacer l'écran"
};
var PANEL$6 = {
    CLOSE: "Fermer",
    CHAT: {
        TITLE: "Chat",
        YOU: "Vous",
        SUBTITLE: "Les messages seront supprimés à la fin de la session",
        PLACEHOLDER: "Envoyer un message...",
        SEND: "Envoyer"
    },
    PARTICIPANTS: {
        TITLE: "Participants",
        CAMERA: "CAMÉRA",
        SCREEN: "ÉCRAN"
    },
    SETTINGS: {
        TITLE: "Paramètres",
        GENERAL: "Général",
        VIDEO: "Vidéo",
        AUDIO: "l'audio",
        LANGUAGE: "Langue",
        SUBTITLE: "Les sous-titres"
    },
    BACKGROUND: {
        TITLE: "Effets de fond",
        BLURRED_SECTION: "Aucun effet et arrière-plan flou",
        NO_EFFECTS: "Aucun effet de fond",
        BLURRED_EFFECT: "Arrière-plan flou",
        IMAGES_SECTION: "Images d'arrière-plan"
    },
    RECORDING: {
        TITLE: "Enregistrement",
        SUBTITLE: "Enregistrez votre réunion pour la postérité",
        CONTENT_TITLE: "Enregistrez votre appel vidéo",
        CONTENT_SUBTITLE: "Une fois l'enregistrement terminé, vous pourrez le télécharger facilement",
        STARTING: "Début de l'enregistrement",
        STOPPING: "Arrêt de l'enregistrement",
        PLAY: "Jouer",
        DELETE: "Effacer",
        CANCEL: "Annuler",
        DELETE_QUESTION: "Voulez-vous vraiment supprimer l'enregistrement ?",
        DOWNLOAD: "Télécharger",
        RECORDINGS: "ENREGISTREMENTS",
        NO_MODERATOR: "Seul le MODERATEUR peut lancer l'enregistrement"
    }
};
var ERRORS$6 = {
    SESSION: "There was an error connecting to the session",
    CONNECTION: "Connexion perdue",
    RECONNECT: "Oups ! Tentative de reconnexion à la session...",
    TOGGLE_CAMERA: "There was an error toggle camera",
    TOGGLE_MICROPHONE: "There was an error toggling microhpone",
    SCREEN_SHARING: "Erreur de partage d'écran",
    SCREEN_SUPPORT: "Votre navigateur ne prend pas en charge le partage d'écran",
    MEDIA_ACCESS: "L'accès aux périphériques médias n'a pas été autorisé",
    DEVICE_NOT_FOUND: "Aucun périphérique vidéo ou audio n'a été trouvé. Veuillez en connecter au moins un."
};
var fr = {
    ADMIN: ADMIN$6,
    PREJOIN: PREJOIN$6,
    TOOLBAR: TOOLBAR$6,
    STREAM: STREAM$6,
    PANEL: PANEL$6,
    ERRORS: ERRORS$6
};

var fr$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN$6,
    PREJOIN: PREJOIN$6,
    TOOLBAR: TOOLBAR$6,
    STREAM: STREAM$6,
    PANEL: PANEL$6,
    ERRORS: ERRORS$6,
    'default': fr
});

var ADMIN$5 = {
    LOGIN: "登录",
    SECRET: "秘密",
    SECRET_REQURED: "必须提供秘密",
    DASHBOARD: "仪表板",
    NO_RECORDINGS: "没有录音",
    SEARCH: "搜索录音",
    DATE: "日期",
    DURATION: "期间",
    SIZE: "尺寸",
    STATUS: "地位",
    NAME: "姓名",
    SESSION: "会议",
    OUTPUT: "输出方式",
    POWERED_BY: "动力 b"
};
var PREJOIN$5 = {
    NICKNAME_SECTION: "设置你的绰号",
    NICKNAME: "昵称",
    DEVICE_SECTION: "选择你的设备",
    VIDEO_DEVICE: "视频设备",
    AUDIO_DEVICE: "音频设备",
    JOIN: "加入会话",
    PREPARING: "筹备会议"
};
var TOOLBAR$5 = {
    MUTE_AUDIO: "将你的音频静音",
    UNMUTE_AUDIO: "取消音频静音",
    MUTE_VIDEO: "将你的视频静音",
    UNMUTE_VIDEO: "取消你的视频静音",
    ENABLE_SCREEN: "启用屏幕共享",
    DISABLE_SCREEN: "禁用屏幕共享",
    MORE_OPTIONS: "更多选项",
    FULLSCREEN: "全屏",
    EXIT_FULLSCREEN: "退出全屏",
    ENABLE_SUBTITLES: "启用字幕",
    DISABLE_SUBTITLES: "禁用字幕",
    BACKGROUND: "背景效果",
    START_RECORDING: "开始录音",
    STOP_RECORDING: "停止录制",
    SETTINGS: "设置",
    LEAVE: "离开会议",
    PARTICIPANTS: "参与者",
    CHAT: "聊天",
    ACTIVITIES: "活动"
};
var STREAM$5 = {
    SETTINGS: "设置",
    MUTE_SOUND: "静音",
    UNMUTE_SOUND: "取消静音",
    ZOOM_IN: "放大",
    ZOOM_OUT: "缩小",
    REPLACE_SCREEN: "更换屏幕"
};
var PANEL$5 = {
    CLOSE: "关闭",
    CHAT: {
        TITLE: "聊天",
        YOU: "你",
        SUBTITLE: "信息将在会议结束时被删除",
        PLACEHOLDER: "发送消息...",
        SEND: "发送"
    },
    PARTICIPANTS: {
        TITLE: "参与者",
        CAMERA: "摄像头",
        SCREEN: "屏幕"
    },
    SETTINGS: {
        TITLE: "设置",
        GENERAL: "一般的",
        VIDEO: "视频",
        AUDIO: "声音的",
        LANGUAGE: "语",
        SUBTITLE: "字幕"
    },
    BACKGROUND: {
        TITLE: "背景效果",
        BLURRED_SECTION: "没有效果和模糊的背景",
        NO_EFFECTS: "没有背景效果",
        BLURRED_EFFECT: "模糊的背景",
        IMAGES_SECTION: "背景图像"
    },
    RECORDING: {
        TITLE: "录音",
        SUBTITLE: "为后人记录你的会议",
        CONTENT_TITLE: "记录你的视频通话",
        CONTENT_SUBTITLE: "当录音完成后，你将可以轻松地下载它",
        STARTING: "开始录音",
        STOPPING: "停止录制",
        PLAY: "玩",
        DELETE: "删除",
        CANCEL: "取消",
        DELETE_QUESTION: "您确定要删除录音吗",
        DOWNLOAD: "下载",
        RECORDINGS: "录制",
        NO_MODERATOR: "只有主持人可以开始录音"
    }
};
var ERRORS$5 = {
    SESSION: "连接到会话时有错误",
    CONNECTION: "连接丢失",
    RECONNECT: "试图重新连接到会话",
    TOGGLE_CAMERA: "切换相机时出现错误",
    TOGGLE_MICROPHONE: "切换麦克风时出现错误",
    SCREEN_SHARING: "分享屏幕出错",
    SCREEN_SUPPORT: "您的浏览器不支持屏幕共享",
    MEDIA_ACCESS: "不允许访问媒体设备",
    DEVICE_NOT_FOUND: "没有找到视频或音频设备 请至少连接一个"
};
var cn = {
    ADMIN: ADMIN$5,
    PREJOIN: PREJOIN$5,
    TOOLBAR: TOOLBAR$5,
    STREAM: STREAM$5,
    PANEL: PANEL$5,
    ERRORS: ERRORS$5
};

var cn$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN$5,
    PREJOIN: PREJOIN$5,
    TOOLBAR: TOOLBAR$5,
    STREAM: STREAM$5,
    PANEL: PANEL$5,
    ERRORS: ERRORS$5,
    'default': cn
});

var ADMIN$4 = {
    LOGIN: "लॉग इन करें",
    SECRET: "गुप्त",
    SECRET_REQURED: "रहस्य की आवश्यकता है",
    DASHBOARD: "डैशबोर्ड",
    NO_RECORDINGS: "रिकॉर्डिंग नहीं हैं",
    SEARCH: "एक रिकॉर्डिंग खोजें",
    DATE: "दिनांक",
    DURATION: "अवधि",
    SIZE: "आकार",
    STATUS: "दर्जा",
    NAME: "नाम",
    SESSION: "सत्र",
    OUTPUT: "आउटपुट मोड",
    POWERED_BY: "द्वारा संचालित"
};
var PREJOIN$4 = {
    NICKNAME_SECTION: "अपना निकनेम सेट करें",
    NICKNAME: "निकनेम",
    DEVICE_SECTION: "अपने डिवाइस चुनें",
    VIDEO_DEVICE: "वीडियो डिवाइस",
    AUDIO_DEVICE: "ऑडियो डिवाइस",
    JOIN: "सत्र में शामिल हों",
    PREPARING: "सत्र तैयार कर रहा है ..."
};
var TOOLBAR$4 = {
    MUTE_AUDIO: "अपनी ऑडियो को मौन करें",
    UNMUTE_AUDIO: "अपनी ऑडियो को अनमौन करें",
    MUTE_VIDEO: "अपनी वीडियो को मौन करें",
    UNMUTE_VIDEO: "अपनी वीडियो को अनमौन करें",
    ENABLE_SCREEN: "स्क्रीन शेयर सक्षम करें",
    DISABLE_SCREEN: "स्क्रीन शेयर अक्षम करें",
    MORE_OPTIONS: "अधिक विकल्प",
    FULLSCREEN: "पूर्ण स्क्रीन",
    EXIT_FULLSCREEN: "पूर्ण स्क्रीन से बाहर निकलें",
    ENABLE_SUBTITLES: "उपशीर्षक सक्षम करें",
    DISABLE_SUBTITLES: "उपशीर्षक अक्षम करें",
    BACKGROUND: "पृष्ठभूमि प्रभाव",
    START_RECORDING: "रिकॉर्डिंग प्रारंभ करें",
    STOP_RECORDING: "रिकॉर्डिंग रोकें",
    SETTINGS: "सेटिंग्स",
    LEAVE: "सत्र छोड़ें",
    PARTICIPANTS: "सदस्य",
    CHAT: "बातचीत",
    ACTIVITIES: "गतिविधियाँ"
};
var STREAM$4 = {
    SETTINGS: "सेटिंग्स",
    MUTE_SOUND: "ध्वनि बंद करें",
    UNMUTE_SOUND: "ध्वनि चालू करें",
    ZOOM_IN: "ज़ूम इन करें",
    ZOOM_OUT: "ज़ूम आउट करें",
    REPLACE_SCREEN: "स्क्रीन को बदलें"
};
var PANEL$4 = {
    CLOSE: "बंद करें",
    CHAT: {
        TITLE: "बातचीत",
        YOU: "आप",
        SUBTITLE: "सत्र समाप्त होने पर संदेश हटा दिए जाएंगे",
        PLACEHOLDER: "एक संदेश भेजें ...",
        SEND: "भेजें"
    },
    PARTICIPANTS: {
        TITLE: "सदस्य",
        CAMERA: "कैमरा",
        SCREEN: "स्क्रीन"
    },
    SETTINGS: {
        TITLE: "सेटिंग्स",
        GENERAL: "सामान्य",
        VIDEO: "वीडियो",
        AUDIO: "ऑडियो",
        LANGUAGE: "भाषा",
        SUBTITLE: "उपशीर्षक"
    },
    BACKGROUND: {
        TITLE: "पृष्ठभूमि प्रभाव",
        BLURRED_SECTION: "कोई प्रभाव नहीं है और पृष्ठभूमि धुंधली है",
        NO_EFFECTS: "कोई पृष्ठभूमि प्रभाव नहीं है",
        BLURRED_EFFECT: "पृष्ठभूमि धुंधली है",
        IMAGES_SECTION: "पृष्ठभूमि छवियां"
    },
    RECORDING: {
        TITLE: "रिकॉर्डिंग",
        SUBTITLE: "अपनी बैठक को भावी पीढ़ी के लिए रिकॉर्ड करें",
        CONTENT_TITLE: "अपना वीडियो कॉल रिकॉर्ड करें",
        CONTENT_SUBTITLE: "रिकॉर्डिंग समाप्त हो जाने पर आप इसे आसानी से डाउनलोड कर सकेंगे",
        STARTING: "रिकॉर्डिंग शुरू कर रहा है",
        STOPPING: "रिकॉर्डिंग बंद करना",
        PLAY: "खेलें",
        DELETE: "मिटाना",
        CANCEL: "रद्द करना",
        DELETE_QUESTION: "क्या आप वाकई रिकॉर्डिंग हटाना चाहते हैं",
        DOWNLOAD: "डाउनलोड",
        RECORDINGS: "रिकॉर्डिंग",
        NO_MODERATOR: "केवल मॉडरेटर ही रिकॉर्डिंग शुरू कर सकता है"
    }
};
var ERRORS$4 = {
    SESSION: "सत्र से जुड़ने में त्रुटि हुई",
    CONNECTION: "कनेक्शन खो गया",
    RECONNECT: "ओह! सत्र से फिर से कनेक्ट करने का प्रयास कर रहा है",
    TOGGLE_CAMERA: "कैमरा टॉगल करने में त्रुटि हुई",
    TOGGLE_MICROPHONE: "माइक्रोफ़ोन को चालू करने में त्रुटि हुई",
    SCREEN_SHARING: "स्क्रीन साझा करने में त्रुटि",
    SCREEN_SUPPORT: "आपका ब्राउज़र स्क्रीन साझाकरण का समर्थन नहीं करता",
    MEDIA_ACCESS: "मीडिया उपकरणों तक पहुंच की अनुमति नहीं थी।",
    DEVICE_NOT_FOUND: "कोई वीडियो या ऑडियो डिवाइस नहीं मिला। कृपया, कम से कम एक कनेक्ट करें।"
};
var hi = {
    ADMIN: ADMIN$4,
    PREJOIN: PREJOIN$4,
    TOOLBAR: TOOLBAR$4,
    STREAM: STREAM$4,
    PANEL: PANEL$4,
    ERRORS: ERRORS$4
};

var hi$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN$4,
    PREJOIN: PREJOIN$4,
    TOOLBAR: TOOLBAR$4,
    STREAM: STREAM$4,
    PANEL: PANEL$4,
    ERRORS: ERRORS$4,
    'default': hi
});

var ADMIN$3 = {
    LOGIN: "ログイン",
    SECRET: "ひみつ",
    SECRET_REQURED: "秘密が必要です",
    DASHBOARD: "ダッシュボード",
    NO_RECORDINGS: "録音はありません",
    SEARCH: "録音を検索する",
    DATE: "日にち",
    DURATION: "間隔",
    SIZE: "サイズ",
    STATUS: "状態",
    NAME: "名前",
    SESSION: "セッション",
    OUTPUT: "出力モード",
    POWERED_BY: "搭載"
};
var PREJOIN$3 = {
    NICKNAME_SECTION: "ニックネームを設定してください",
    NICKNAME: "ニックネーム",
    DEVICE_SECTION: "デバイスを選択してください",
    VIDEO_DEVICE: "ビデオデバイス",
    AUDIO_DEVICE: "オーディオデバイス",
    JOIN: "セッションに参加する",
    PREPARING: "セッションの準備中..."
};
var TOOLBAR$3 = {
    MUTE_AUDIO: "オーディオをミュートする",
    UNMUTE_AUDIO: "オーディオをミュートしない",
    MUTE_VIDEO: "ビデオをミュートする",
    UNMUTE_VIDEO: "ビデオをミュートしない",
    ENABLE_SCREEN: "スクリーン共有を有効にする",
    DISABLE_SCREEN: "スクリーン共有を無効にする",
    MORE_OPTIONS: "その他のオプション",
    FULLSCREEN: "フルスクリーン",
    EXIT_FULLSCREEN: "フルスクリーンを終了する",
    ENABLE_SUBTITLES: "字幕を有効にする",
    DISABLE_SUBTITLES: "字幕を無効にする",
    BACKGROUND: "背景効果",
    START_RECORDING: "録画開始",
    STOP_RECORDING: "録画の停止",
    SETTINGS: "設定",
    LEAVE: "セッションを終了する",
    PARTICIPANTS: "参加者",
    CHAT: "チャット",
    ACTIVITIES: "アクティビティ"
};
var STREAM$3 = {
    SETTINGS: "設定",
    MUTE_SOUND: "サウンドをミュートする",
    UNMUTE_SOUND: "サウンドをミュートしない",
    ZOOM_IN: "拡大する",
    ZOOM_OUT: "縮小する",
    REPLACE_SCREEN: "スクリーンを入れ替える"
};
var PANEL$3 = {
    CLOSE: "閉じる",
    CHAT: {
        TITLE: "チャット",
        YOU: "あなた",
        SUBTITLE: "メッセージはセッション終了時に削除されます",
        PLACEHOLDER: "メッセージを送信...",
        SEND: "送信する"
    },
    PARTICIPANTS: {
        TITLE: "参加者",
        CAMERA: "カメラ",
        SCREEN: "スクリーン"
    },
    SETTINGS: {
        TITLE: "設定",
        GENERAL: "全般的",
        VIDEO: "ビデオ",
        AUDIO: "オーディオ",
        LANGUAGE: "言語",
        SUBTITLE: "字幕"
    },
    BACKGROUND: {
        TITLE: "背景効果",
        BLURRED_SECTION: "エフェクトなし、ぼやけた背景",
        NO_EFFECTS: "背景エフェクトなし",
        BLURRED_EFFECT: "ぼやけた背景",
        IMAGES_SECTION: "背景画像"
    },
    RECORDING: {
        TITLE: "レコーディング",
        SUBTITLE: "会議を録音して後世に残す",
        CONTENT_TITLE: "ビデオ通話を録音する",
        CONTENT_SUBTITLE: "録音が完了したら、簡単にダウンロードできます",
        STARTING: "録画開始",
        STOPPING: "録音を停止します",
        PLAY: "遊ぶ",
        DELETE: "消去",
        CANCEL: "キャンセル",
        DELETE_QUESTION: "録音を削除してもよろしいですか",
        DOWNLOAD: "ダウンロード",
        RECORDINGS: "録画",
        NO_MODERATOR: "録音を開始できるのは、モデレーターのみです"
    }
};
var ERRORS$3 = {
    SESSION: "セッションへの接続にエラーが発生しました",
    CONNECTION: "接続が失われました",
    RECONNECT: "セッションへの再接続を試みています",
    TOGGLE_CAMERA: "カメラのトグルエラーが発生しました",
    TOGGLE_MICROPHONE: "マイクロフォンのトグルにエラーが発生しました",
    SCREEN_SHARING: "画面共有にエラーが発生しました",
    SCREEN_SUPPORT: "お使いのブラウザは画面共有に対応していません",
    MEDIA_ACCESS: "メディアデバイスへのアクセスが許可されませんでした",
    DEVICE_NOT_FOUND: "ビデオまたはオーディオデバイスが見つかりませんでした 最低1台は接続してください"
};
var ja = {
    ADMIN: ADMIN$3,
    PREJOIN: PREJOIN$3,
    TOOLBAR: TOOLBAR$3,
    STREAM: STREAM$3,
    PANEL: PANEL$3,
    ERRORS: ERRORS$3
};

var ja$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN$3,
    PREJOIN: PREJOIN$3,
    TOOLBAR: TOOLBAR$3,
    STREAM: STREAM$3,
    PANEL: PANEL$3,
    ERRORS: ERRORS$3,
    'default': ja
});

var ADMIN$2 = {
    LOGIN: "Login",
    SECRET: "Segreto",
    SECRET_REQURED: "Il segreto è richiesto",
    DASHBOARD: "Pannello di controllo",
    NO_RECORDINGS: "Non ci sono registrazioni",
    SEARCH: "Cerca una registrazione",
    DATE: "Data",
    DURATION: "Durata",
    SIZE: "Dimensione",
    STATUS: "Stato",
    NAME: "Nome",
    SESSION: "Sessione",
    OUTPUT: "Modalità di uscita",
    POWERED_BY: "Offerto da"
};
var PREJOIN$2 = {
    NICKNAME_SECTION: "Imposta il tuo soprannome",
    NICKNAME: "Soprannome",
    DEVICE_SECTION: "Scegli i tuoi dispositivi",
    VIDEO_DEVICE: "Dispositivo video",
    AUDIO_DEVICE: "Dispositivo audio",
    JOIN: "Unisciti alla sessione",
    PREPARING: "Preparazione della sessione in corso..."
};
var TOOLBAR$2 = {
    MUTE_AUDIO: "Disattiva l'audio",
    UNMUTE_AUDIO: "Attiva l'audio",
    MUTE_VIDEO: "Disattiva il video",
    UNMUTE_VIDEO: "Attiva il video",
    ENABLE_SCREEN: "Abilita la condivisione dello schermo",
    DISABLE_SCREEN: "Disabilita la condivisione dello schermo",
    MORE_OPTIONS: "Altre opzioni",
    FULLSCREEN: "Schermo intero",
    EXIT_FULLSCREEN: "Esci dallo schermo intero",
    ENABLE_SUBTITLES: "Abilita i sottotitoli",
    DISABLE_SUBTITLES: "Disabilita i sottotitoli",
    BACKGROUND: "Effetti di sfondo",
    START_RECORDING: "Avvia registrazione",
    STOP_RECORDING: "Interrompi registrazione",
    SETTINGS: "Impostazioni",
    LEAVE: "Abbandona la sessione",
    PARTICIPANTS: "Partecipanti",
    CHAT: "Chat",
    ACTIVITIES: "Attività"
};
var STREAM$2 = {
    SETTINGS: "Impostazioni",
    MUTE_SOUND: "Disattiva l'audio",
    UNMUTE_SOUND: "Attiva l'audio",
    ZOOM_IN: "Ingrandisci",
    ZOOM_OUT: "Riduci",
    REPLACE_SCREEN: "Sostituisci lo schermo"
};
var PANEL$2 = {
    CLOSE: "Chiudi",
    CHAT: {
        TITLE: "Chat",
        YOU: "Tu",
        SUBTITLE: "I messaggi verranno rimossi alla fine della sessione",
        PLACEHOLDER: "Invia un messaggio...",
        SEND: "Invia"
    },
    PARTICIPANTS: {
        TITLE: "Partecipanti",
        CAMERA: "CAMERA",
        SCREEN: "SCREEN"
    },
    SETTINGS: {
        TITLE: "Impostazioni",
        GENERAL: "Generale",
        VIDEO: "video",
        AUDIO: "Audio",
        LANGUAGE: "Lingua",
        SUBTITLE: "Sottotitoli"
    },
    BACKGROUND: {
        TITLE: "Effetti di sfondo",
        BLURRED_SECTION: "Nessun effetto e sfondo sfocato",
        NO_EFFECTS: "Nessun effetto di sfondo",
        BLURRED_EFFECT: "Sfondo sfocato",
        IMAGES_SECTION: "Immagini di sfondo"
    },
    RECORDING: {
        TITLE: "Registrazione",
        SUBTITLE: "Registra la tua riunione per i posteri",
        CONTENT_TITLE: "Registra la tua videochiamata",
        CONTENT_SUBTITLE: "Al termine della registrazione potrete scaricarla con facilità",
        STARTING: "Avvio della registrazione",
        STOPPING: "Interruzione della registrazione",
        PLAY: "Giocare a",
        DELETE: "Elimina",
        CANCEL: "Annulla",
        DELETE_QUESTION: "Sei sicuro di voler eliminare la registrazione?",
        DOWNLOAD: "Scarica",
        RECORDINGS: "REGISTRAZIONI",
        NO_MODERATOR: "Solo il MODERATORE può avviare la registrazione"
    }
};
var ERRORS$2 = {
    SESSION: "Si è verificato un errore di connessione alla sessione",
    CONNECTION: "Connessione persa",
    RECONNECT: "Oops! Si sta cercando di riconnettersi alla sessione...",
    TOGGLE_CAMERA: "Si è verificato un errore nell'attivazione della telecamera",
    TOGGLE_MICROPHONE: "Si è verificato un errore nell'attivazione del microfono",
    SCREEN_SHARING: "Errore nella condivisione dello schermo",
    SCREEN_SUPPORT: "Il browser non supporta la condivisione dello schermo",
    MEDIA_ACCESS: "L'accesso ai dispositivi multimediali non è stato consentito",
    DEVICE_NOT_FOUND: "Non sono stati trovati dispositivi video o audio. Si prega di collegarne almeno uno"
};
var it = {
    ADMIN: ADMIN$2,
    PREJOIN: PREJOIN$2,
    TOOLBAR: TOOLBAR$2,
    STREAM: STREAM$2,
    PANEL: PANEL$2,
    ERRORS: ERRORS$2
};

var it$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN$2,
    PREJOIN: PREJOIN$2,
    TOOLBAR: TOOLBAR$2,
    STREAM: STREAM$2,
    PANEL: PANEL$2,
    ERRORS: ERRORS$2,
    'default': it
});

var ADMIN$1 = {
    LOGIN: "Log in",
    SECRET: "Geheim",
    SECRET_REQURED: "Geheim is vereist",
    DASHBOARD: "Dashboard",
    NO_RECORDINGS: "Er zijn geen opnames",
    SEARCH: "Een opname zoeken",
    DATE: "Datum",
    DURATION: "Looptijd",
    SIZE: "Maat",
    STATUS: "Toestand",
    NAME: "Naam",
    SESSION: "Sessie",
    OUTPUT: "Uitgangsmodus",
    POWERED_BY: "Aangedreven door"
};
var PREJOIN$1 = {
    NICKNAME_SECTION: "Stel je bijnaam in",
    NICKNAME: "Bijnaam",
    DEVICE_SECTION: "Kies je apparaten",
    VIDEO_DEVICE: "Videospeler",
    AUDIO_DEVICE: "Audiospeler",
    JOIN: "Deelnemen aan sessie",
    PREPARING: "Sessie voorbereiden ..."
};
var TOOLBAR$1 = {
    MUTE_AUDIO: "Audio dempen",
    UNMUTE_AUDIO: "Audio niet meer dempen",
    MUTE_VIDEO: "Video dempen",
    UNMUTE_VIDEO: "Video niet meer dempen",
    ENABLE_SCREEN: "Scherm delen inschakelen",
    DISABLE_SCREEN: "Scherm delen uitschakelen",
    MORE_OPTIONS: "Meer opties",
    FULLSCREEN: "Volledig scherm",
    EXIT_FULLSCREEN: "Volledig scherm verlaten",
    ENABLE_SUBTITLES: "Ondertiteling inschakelen",
    DISABLE_SUBTITLES: "Ondertiteling uitschakelen",
    BACKGROUND: "Achtergrondeffecten",
    START_RECORDING: "Start opname",
    STOP_RECORDING: "Stop opname",
    SETTINGS: "Instellingen",
    LEAVE: "Verlaat de sessie",
    PARTICIPANTS: "Deelnemers",
    CHAT: "Chat",
    ACTIVITIES: "Activiteiten"
};
var STREAM$1 = {
    SETTINGS: "Instellingen",
    MUTE_SOUND: "Geluid dempen",
    UNMUTE_SOUND: "Geluid niet meer dempen",
    ZOOM_IN: "Inzoomen",
    ZOOM_OUT: "Uitzoomen",
    REPLACE_SCREEN: "Vervang scherm"
};
var PANEL$1 = {
    CLOSE: "Sluiten",
    CHAT: {
        TITLE: "Chat",
        YOU: "Jij",
        SUBTITLE: "Berichten worden aan het einde van de sessie verwijderd",
        PLACEHOLDER: "Stuur een bericht ...",
        SEND: "Versturen"
    },
    PARTICIPANTS: {
        TITLE: "Deelnemers",
        CAMERA: "CAMERA",
        SCREEN: "SCHERM"
    },
    SETTINGS: {
        TITLE: "Instellingen",
        GENERAL: "Algemeen",
        VIDEO: "Video",
        AUDIO: "Audio",
        LANGUAGE: "Taal",
        SUBTITLE: "Ondertitels"
    },
    BACKGROUND: {
        TITLE: "Achtergrondeffecten",
        BLURRED_SECTION: "Geen effecten en onscherpe achtergrond",
        NO_EFFECTS: "Geen achtergrondeffect",
        BLURRED_EFFECT: "Onscherpe achtergrond",
        IMAGES_SECTION: "Achtergrondafbeeldingen"
    },
    RECORDING: {
        TITLE: "Opname",
        SUBTITLE: "Neem uw vergadering op voor het nageslacht",
        CONTENT_TITLE: "Neem uw videogesprek op",
        CONTENT_SUBTITLE: "Als de opname klaar is kunt u deze met gemak downloaden",
        STARTING: "Beginnen met opnemen",
        STOPPING: "Opname stoppen",
        PLAY: "Toneelstuk",
        DELETE: "Verwijderen",
        CANCEL: "Annuleren",
        DELETE_QUESTION: "Weet je zeker dat je de opname wilt verwijderen?",
        DOWNLOAD: "Downloaden",
        RECORDINGS: "OPNAME",
        NO_MODERATOR: "Alleen de MOEDERATOR kan de opname starten"
    }
};
var ERRORS$1 = {
    SESSION: "Er is een fout opgetreden bij het verbinden met de sessie",
    CONNECTION: "Verbinding verloren",
    RECONNECT: "Proberen opnieuw verbinding te maken met de sessie...",
    TOGGLE_CAMERA: "Er is een fout opgetreden bij het overschakelen naar een andere camera",
    TOGGLE_MICROPHONE: "Er is een fout opgetreden bij het overschakelen naar een microfoon",
    SCREEN_SHARING: "Fout bij het delen van het scherm",
    SCREEN_SUPPORT: "Uw browser ondersteunt het delen van schermen niet",
    MEDIA_ACCESS: "Toegang tot media-apparaten was niet toegestaan.",
    DEVICE_NOT_FOUND: "Er zijn geen video- of audioapparaten gevonden. Sluit er alstublieft ten minste één aan."
};
var nl = {
    ADMIN: ADMIN$1,
    PREJOIN: PREJOIN$1,
    TOOLBAR: TOOLBAR$1,
    STREAM: STREAM$1,
    PANEL: PANEL$1,
    ERRORS: ERRORS$1
};

var nl$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN$1,
    PREJOIN: PREJOIN$1,
    TOOLBAR: TOOLBAR$1,
    STREAM: STREAM$1,
    PANEL: PANEL$1,
    ERRORS: ERRORS$1,
    'default': nl
});

var ADMIN = {
    LOGIN: "Conecte-se",
    SECRET: "Segredo",
    SECRET_REQURED: "O segredo é obrigatório",
    DASHBOARD: "Painel",
    NO_RECORDINGS: "Não há gravações",
    SEARCH: "Pesquisar uma gravação",
    DATE: "Encontro",
    DURATION: "Duração",
    SIZE: "Tamanho",
    STATUS: "Status",
    NAME: "Nome",
    SESSION: "Sessão",
    OUTPUT: "Modo de saída",
    POWERED_BY: "Distribuído por"
};
var PREJOIN = {
    NICKNAME_SECTION: "Defina seu apelido",
    NICKNAME: "Apelido",
    DEVICE_SECTION: "Escolha seus dispositivos",
    VIDEO_DEVICE: "Dispositivo de vídeo",
    AUDIO_DEVICE: "Dispositivo de áudio",
    JOIN: "Entrar na sessão",
    PREPARING: "Preparando sessão..."
};
var TOOLBAR = {
    MUTE_AUDIO: "Mute seu áudio",
    UNMUTE_AUDIO: "Desmute seu áudio",
    MUTE_VIDEO: "Mute seu vídeo",
    UNMUTE_VIDEO: "Desmute seu vídeo",
    ENABLE_SCREEN: "Habilitar compartilhamento de tela",
    DISABLE_SCREEN: "Desabilitar compartilhamento de tela",
    MORE_OPTIONS: "Mais opções",
    FULLSCREEN: "Tela cheia",
    EXIT_FULLSCREEN: "Sair da tela cheia",
    ENABLE_SUBTITLES: "Ativar legendas",
    DISABLE_SUBTITLES: "Desativar legendas",
    BACKGROUND: "Efeitos de fundo",
    START_RECORDING: "Iniciar_gravação",
    STOP_RECORDING: "Parar de gravar",
    SETTINGS: "Configurações",
    LEAVE: "Sair da sessão",
    PARTICIPANTS: "Participantes",
    CHAT: "Chat",
    ACTIVITIES: "Actividades"
};
var STREAM = {
    SETTINGS: "Configurações",
    MUTE_SOUND: "Mudo",
    UNMUTE_SOUND: "Com som",
    ZOOM_IN: "Aumentar zoom",
    ZOOM_OUT: "Diminuir zoom",
    REPLACE_SCREEN: "Trocar tela"
};
var PANEL = {
    CLOSE: "Fechar",
    CHAT: {
        TITLE: "Chat",
        YOU: "Você",
        SUBTITLE: "As mensagens serão removidas no final da sessão",
        PLACEHOLDER: "Enviar uma mensagem...",
        SEND: "Enviar"
    },
    PARTICIPANTS: {
        TITLE: "Participantes",
        CAMERA: "CÂMERA",
        SCREEN: "TELA"
    },
    SETTINGS: {
        TITLE: "Configurações",
        GENERAL: "Em geral",
        VIDEO: "Vídeo",
        AUDIO: "Áudio",
        LANGUAGE: "Linguagem",
        SUBTITLE: "Legendas"
    },
    BACKGROUND: {
        TITLE: "Efeitos de fundo",
        BLURRED_SECTION: "Sem efeitos e fundo desfocado",
        NO_EFFECTS: "Sem efeito de fundo",
        BLURRED_EFFECT: "Fundo desfocado",
        IMAGES_SECTION: "Imagens de fundo"
    },
    RECORDING: {
        TITLE: "Gravação",
        SUBTITLE: "Grave a sua reunião para a posteridade",
        CONTENT_TITLE: "Grave a sua videochamada",
        CONTENT_SUBTITLE: "Quando a gravação tiver terminado, poderá descarregá-la com facilidade",
        STARTING: "Começar a gravação",
        STOPPING: "Parando a gravação",
        PLAY: "Toque",
        DELETE: "Excluir",
        CANCEL: "Cancelar",
        DELETE_QUESTION: "Tem certeza de que deseja excluir a gravação?",
        DOWNLOAD: "Download",
        RECORDINGS: "GRAVAÇÕES",
        NO_MODERATOR: "Só o MODERADOR pode iniciar a gravação"
    }
};
var ERRORS = {
    SESSION: "Houve um erro de ligação à sessão",
    CONNECTION: "Ligação perdida",
    RECONNECT: "A tentar restabelecer a ligação à sessão...",
    TOGGLE_CAMERA: "Houve um erro ao alternar a câmara",
    TOGGLE_MICROPHONE: "Houve um erro ao alternar microhpone",
    SCREEN_SHARING: "ecrã_partilha de erros",
    SCREEN_SUPPORT: "O seu browser não suporta a partilha de ecrãs",
    MEDIA_ACCESS: "Não foi permitido o acesso a dispositivos de media",
    DEVICE_NOT_FOUND: "Nenhum dispositivo de vídeo ou áudio foi encontrado. Por favor, ligue pelo menos um"
};
var pt = {
    ADMIN: ADMIN,
    PREJOIN: PREJOIN,
    TOOLBAR: TOOLBAR,
    STREAM: STREAM,
    PANEL: PANEL,
    ERRORS: ERRORS
};

var pt$1 = /*#__PURE__*/Object.freeze({
    __proto__: null,
    ADMIN: ADMIN,
    PREJOIN: PREJOIN,
    TOOLBAR: TOOLBAR,
    STREAM: STREAM,
    PANEL: PANEL,
    ERRORS: ERRORS,
    'default': pt
});

/**
 * @internal
 */
class TranslateService {
    constructor(storageService) {
        this.storageService = storageService;
        this.availableLanguages = { en: en$1, es: es$1, de: de$1, fr: fr$1, cn: cn$1, hi: hi$1, it: it$1, ja: ja$1, nl: nl$1, pt: pt$1 };
        this.langTitles = [
            { name: 'English', ISO: 'en' },
            { name: 'Español', ISO: 'es' },
            { name: 'Deutsch', ISO: 'de' },
            { name: 'Français', ISO: 'fr' },
            { name: '中国', ISO: 'cn' },
            { name: 'हिन्दी', ISO: 'hi' },
            { name: 'Italiano', ISO: 'it' },
            { name: 'やまと', ISO: 'ja' },
            { name: 'Dutch', ISO: 'nl' },
            { name: 'Português', ISO: 'pt' }
        ];
        const iso = this.storageService.getLang() || 'en';
        this.langSelected = this.langTitles.find((lang) => lang.ISO === iso);
        this.currentLang = this.availableLanguages[this.langSelected.ISO];
    }
    setLanguage(lang) {
        if (this.langTitles.some(l => l.ISO === lang)) {
            this.currentLang = this.availableLanguages[lang];
            this.langSelected = this.langTitles.find((l) => l.ISO === lang);
        }
    }
    getLangSelected() {
        return this.langSelected;
    }
    getLanguagesInfo() {
        return this.langTitles;
    }
    translate(key) {
        let result = this.currentLang;
        key.split('.').forEach((prop) => {
            try {
                result = result[prop];
            }
            catch (error) {
                return '';
            }
        });
        return result;
    }
}
TranslateService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: TranslateService, deps: [{ token: StorageService }], target: i0.ɵɵFactoryTarget.Injectable });
TranslateService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: TranslateService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: TranslateService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: StorageService }]; } });

/**
 * @internal
 */
class TranslatePipe {
    constructor(translateService) {
        this.translateService = translateService;
    }
    transform(str) {
        return this.translateService.translate(str);
    }
}
TranslatePipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: TranslatePipe, deps: [{ token: TranslateService }], target: i0.ɵɵFactoryTarget.Pipe });
TranslatePipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: TranslatePipe, name: "translate", pure: false });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: TranslatePipe, decorators: [{
            type: Pipe,
            args: [{ name: 'translate', pure: false }]
        }], ctorParameters: function () { return [{ type: TranslateService }]; } });

/**
 * @internal
 */
class DeleteDialogComponent {
    constructor(dialogRef) {
        this.dialogRef = dialogRef;
    }
    close(succsess = false) {
        this.dialogRef.close(succsess);
    }
}
DeleteDialogComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DeleteDialogComponent, deps: [{ token: i1$1.MatDialogRef }], target: i0.ɵɵFactoryTarget.Component });
DeleteDialogComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: DeleteDialogComponent, selector: "app-delete-dialog", ngImport: i0, template: `
		<div mat-dialog-content>{{'PANEL.RECORDING.DELETE_QUESTION' | translate}}</div>
		<div mat-dialog-actions>
			<button mat-button (click)="close()">{{'PANEL.RECORDING.CANCEL' | translate }}</button>
			<button mat-button cdkFocusInitial (click)="close(true)" id="delete-recording-confirm-btn">{{'PANEL.RECORDING.DELETE' | translate}}</button>
		</div>
	`, isInline: true, styles: [""], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }], directives: [{ type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]" }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DeleteDialogComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'app-delete-dialog',
                    template: `
		<div mat-dialog-content>{{'PANEL.RECORDING.DELETE_QUESTION' | translate}}</div>
		<div mat-dialog-actions>
			<button mat-button (click)="close()">{{'PANEL.RECORDING.CANCEL' | translate }}</button>
			<button mat-button cdkFocusInitial (click)="close(true)" id="delete-recording-confirm-btn">{{'PANEL.RECORDING.DELETE' | translate}}</button>
		</div>
	`,
                    styles: [``]
                }]
        }], ctorParameters: function () { return [{ type: i1$1.MatDialogRef }]; } });

/**
 * @internal
 */
class RecordingDialogComponent {
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.src = data.src;
    }
    close() {
        this.dialogRef.close();
    }
}
RecordingDialogComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingDialogComponent, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
RecordingDialogComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: RecordingDialogComponent, selector: "app-recording-dialog", ngImport: i0, template: `
		<div mat-dialog-content>
			<video controls autoplay [src]="src"></video>
		</div>
		<div mat-dialog-actions *ngIf="data.showActionButtons" align="end">
			<button mat-button (click)="close()">{{ 'PANEL.CLOSE' | translate }}</button>
		</div>
	`, isInline: true, styles: ["video{max-height:64vh;max-width:100%}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }], directives: [{ type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]" }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingDialogComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'app-recording-dialog',
                    template: `
		<div mat-dialog-content>
			<video controls autoplay [src]="src"></video>
		</div>
		<div mat-dialog-actions *ngIf="data.showActionButtons" align="end">
			<button mat-button (click)="close()">{{ 'PANEL.CLOSE' | translate }}</button>
		</div>
	`,
                    styles: [
                        `
			video {
				max-height: 64vh;
				max-width: 100%;
			}
		`
                    ]
                }]
        }], ctorParameters: function () {
        return [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [MAT_DIALOG_DATA]
                    }] }];
    } });

/**
 * @internal
 */
class DialogTemplateComponent {
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
    }
    close() {
        this.dialogRef.close();
    }
}
DialogTemplateComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DialogTemplateComponent, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
DialogTemplateComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: DialogTemplateComponent, selector: "ov-dialog-template", ngImport: i0, template: `
		<h1 mat-dialog-title>{{ data.title }}</h1>
		<div mat-dialog-content>{{ data.description }}</div>
		<div mat-dialog-actions *ngIf="data.showActionButtons">
			<button mat-button (click)="close()">{{'PANEL.CLOSE' | translate}}</button>
		</div>
	`, isInline: true, components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }], directives: [{ type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]" }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DialogTemplateComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'ov-dialog-template',
                    template: `
		<h1 mat-dialog-title>{{ data.title }}</h1>
		<div mat-dialog-content>{{ data.description }}</div>
		<div mat-dialog-actions *ngIf="data.showActionButtons">
			<button mat-button (click)="close()">{{'PANEL.CLOSE' | translate}}</button>
		</div>
	`
                }]
        }], ctorParameters: function () {
        return [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                        type: Inject,
                        args: [MAT_DIALOG_DATA]
                    }] }];
    } });

/**
 * @internal
 */
class ActionService {
    constructor(snackBar, dialog) {
        this.snackBar = snackBar;
        this.dialog = dialog;
    }
    launchNotification(options, callback) {
        if (!options.config) {
            options.config = {
                duration: 3000,
                verticalPosition: 'top',
                horizontalPosition: 'end'
            };
        }
        const notification = this.snackBar.open(options.message, options.buttonActionText, options.config);
        if (callback) {
            notification.onAction().subscribe(() => {
                callback();
            });
        }
    }
    openDialog(titleMessage, descriptionMessage, allowClose = true) {
        try {
            this.closeDialog();
        }
        catch (error) {
        }
        finally {
            const config = {
                minWidth: '250px',
                data: { title: titleMessage, description: descriptionMessage, showActionButtons: allowClose },
                disableClose: !allowClose
            };
            this.dialogRef = this.dialog.open(DialogTemplateComponent, config);
            this.dialogSubscription = this.dialogRef.afterClosed().subscribe((result) => {
                this.dialogRef = null;
            });
        }
    }
    openDeleteRecordingDialog(succsessCallback) {
        try {
            this.closeDialog();
        }
        catch (error) {
        }
        finally {
            this.dialogRef = this.dialog.open(DeleteDialogComponent);
            this.dialogSubscription = this.dialogRef.afterClosed().subscribe((result) => {
                if (result) {
                    succsessCallback();
                }
            });
        }
    }
    openRecordingPlayerDialog(src, allowClose = true) {
        try {
            this.closeDialog();
        }
        catch (error) {
        }
        finally {
            const config = {
                minWidth: '250px',
                data: { src, showActionButtons: allowClose },
                disableClose: !allowClose
            };
            this.dialogRef = this.dialog.open(RecordingDialogComponent, config);
        }
    }
    closeDialog() {
        this.dialogRef.close();
        if (this.dialogSubscription)
            this.dialogSubscription.unsubscribe();
    }
}
ActionService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ActionService, deps: [{ token: i1$2.MatSnackBar }, { token: i1$1.MatDialog }], target: i0.ɵɵFactoryTarget.Injectable });
ActionService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ActionService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ActionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: i1$2.MatSnackBar }, { type: i1$1.MatDialog }]; } });

/**
 * @internal
 */
class ChatService {
    constructor(loggerSrv, openviduService, participantService, panelService, actionService) {
        this.loggerSrv = loggerSrv;
        this.openviduService = openviduService;
        this.participantService = participantService;
        this.panelService = panelService;
        this.actionService = actionService;
        this._messageList = new BehaviorSubject$1([]);
        this.messageList = [];
        this.log = this.loggerSrv.get('ChatService');
        this.messagesObs = this._messageList.asObservable();
        this.messageSound = new Audio('data:audio/wav;base64,SUQzAwAAAAAAekNPTU0AAAAmAAAAAAAAAFJlY29yZGVkIG9uIDI3LjAxLjIwMjEgaW4gRWRpc29uLkNPTU0AAAAmAAAAWFhYAFJlY29yZGVkIG9uIDI3LjAxLjIwMjEgaW4gRWRpc29uLlRYWFgAAAAQAAAAU29mdHdhcmUARWRpc29u//uQxAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAAJAAALNABMTExMTExMTExMTGxsbGxsbGxsbGxsiIiIiIiIiIiIiIijo6Ojo6Ojo6Ojo76+vr6+vr6+vr6+1NTU1NTU1NTU1NTk5OTk5OTk5OTk5PX19fX19fX19fX1//////////////8AAAA8TEFNRTMuMTAwBK8AAAAAAAAAABUgJAadQQABzAAACzQeSO05AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vAxAAABsADb7QQACOOLW3/NaBQzcKNbIACRU4IPh+H1Bhx+D7xQH4IHBIcLh+D/KOk4PwQcUOfy7/5c/IQQdrP8p1g+/////4YmoaJIwUxAFESnqIkyedtyHBoIBBD8xRVFILBVXBA8OKGuWmpLAiIAgcMHgAiQM8uBWBHlMp9xxWyoxCaksudVh8KBx50YE0aK0syZbR704cguOpoXYAqcWGp2LDxF/YFSUFkYWDpfFqiICYsMX7nYBeBwqWVu/eWkW9sxXVlRstdTUjZp2R1qWXSSnooIdGHXZlVt/VA7kSkOMsgTHdzVqrds5Sqe3Kqamq8ytRR2V2unJ5+Ua5TV8qW5jlnW3u7DOvu5Z1a1rC5hWwzy1rD8KXWeW/y3hjrPLe61NvKVWix61qlzMpXARASAAS9weVYFrKBrMWqu6jjUZ7fTbfURVYa/M7yswHEFcSLKLxqmslA6BeR7roKj6JqOin0zpcOsgrR+x0kUiko0SNUDpLOuSprSMjVJNz6/rpOpNHRUlRNVImJq6lJPd3dE1b0ldExPFbgZMgYOwaBR942K9XsCn9m9lwgoQgAACZu3yILcRAQaUpwkvPr+a6+6KdVuq9gQIb1U7y4HjTa7HGscIisVOM5lXYFkWydyDBYmjp7oKgOUYUacqINdIqIEMd0FBAWiz/UyMqbMzMchf7XOtKFoSXM8QcfQaNlmA8HQ0tbXsD56lKDIvZ3XYxS3vulF0MAQQnvwnBXQfZPwLwVAMkYoSghSkIpckFJOBBNJZmYhE4E7P58SGQAgjVRZ1ZtNmo2rHq7nz3mS2U6OiXGtkhZehWmijBt/3d1TGcQEq42sxqOUFEQVDwWBY0tRsAioZKw6WJhg69O6pJra3XaSp791mB2IASQldhZLfOAk7DIgCXxTHo0nWBshqN0Y84zMGzCMKRtYGbVvz7WAVC5NzrmykQLIlrfN2qHXQ6Z/qUmDKX/+3DE1gAPtQ9b/YaAIeAiqv2GFazATncobkc9EAAkvb9pnMjVsk3wQhM9Llh+HCIRFERd4sLROgTPOK2jHfzHpU382nQFIAgACc2fGGBODtNkTQqhIzJHrH4NFkIEcw6PKxgocFSm3CrgiDYp1tMRSzjwCVaVDj43vWr7jWiC4oaHsHa27zUKxJKDNef/jXeGuxlKTY2dTwOFKA+y6l2TnRhImDKhYQgEia822x5Zt6y5b96ngYYjIBDeuCFQwnowEHFcp3F3Q2yFFZLvS54JdWCn+lVJXjs1V1u3qntRpyU8I7Uq3/ay03bW1ndLf92/uUxpELIO44f3Kr6CBbEYW5dOlWo5LKwRnMbRHsUId8KFVgUFXg+GEpWg9Vv41YxbN1tuymfD5Cr/3HMVUhALLdtDLQpBOv1r//tgxO0ADnD3V+ekTeG+G6q9hY30qMDU1SSNOegcyOxBoQ6FNCdLvxHr23ta0sU9ysR0WbGp8xM0j1rmy6Zr61vFbVi1920wDjexZD1Z+TpXaAnGC+1gfGlRYSgYUZSeasoiXkDdS8A7z2CJdo8X3+M5NAxThdP9vO5OpACoq7KA8i6CmgsiBNQ+BkMg9yVkFKk5DiSpPVTGZJJ0XCtvGs0fKYhJ1Sb+MYfbrmtaZw+f619TVxvG5msonGaUczjGdaJoY6OcuBcGi5RYaShYxh1TNgZGJNCzgoXIN4rdR1pV0JWhFmfyldXv/JcJhgBTctuDPFGOdFAmCeC4h9ncJKcguVzY//tgxPOADhDdUeelDSHXH6o9gwrUqD7gLVJhOFnCIov6lFMYCyLz5OtEnP0OCssoUOxoKYq1NRqMpI7E75LkV8jKdIyOCknQELjSQSIuahE0OjfSySUn1W63D7/HmEXCJq83cxwh1KJ2/AANk0J/F+vsgcl1QRtTY1iDZMF0eTtOv4KncRPWe0b0xGlbTjXSib4W3AlD5TypIs2e3aqryiyIkpcxOMeN3GtGH12uYqkWhO0dqSlA9aq6uwhmNp3cAAinFeOC6lmceR2EiGUjwM14WJE5cVj0Ss0zW1vY5ZjnpSSL3Fs/V2kvm3VN90v4Zn8/mlRoVZF07uiFRV3nb+Mxz9LI//tgxPgADjytT+w8beHFFen88ZuE0l3ZwRBEJJwAAVdxwnIVhoQyXVGAWpKYIQ8VhfxuratfsU5ID7+4IOeoYj0s3vrerQYt1oo8FPA5Yi/j+ig7Cprmx3iziji76xilapmKJEQCVJQABLYVBTxyRmsXMv5AC/C2TmwTQviGYc5ILASBakpWy1I4As5Z++CQmtb3UTMNv1opus8JJzSpx8Pgv8Ul6ktLZ3Oy7QEI6CIkVHyXmE+tt69/P0V0lIuLQGmhCSAQCJEiVa9VVEiSQV+QU26Kx/Tv/EGG5PBQoapMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq//tQxP4ADRjPT+ekbSFXFqi9h5k0qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqpMQU1FMy4xMDCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7MMT8AAmom0HsMTJpKRLmPPYiUKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7MMTzgElMmTfnpNJo1AimfPSZgaqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqv/7EMTWA8AAAaQAAAAgAAA0gAAABKqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
        this.messageSound.volume = 0.6;
    }
    subscribeToChat() {
        const session = this.openviduService.getWebcamSession();
        session.on(`signal:${Signal.CHAT}`, (event) => {
            const connectionId = event.from.connectionId;
            const data = JSON.parse(event.data);
            const isMyOwnConnection = this.openviduService.isMyOwnConnection(connectionId);
            this.messageList.push({
                isLocal: isMyOwnConnection,
                nickname: data.nickname,
                message: data.message
            });
            if (!this.panelService.isChatPanelOpened()) {
                const notificationOptions = {
                    message: `${data.nickname.toUpperCase()} sent a message`,
                    cssClassName: 'messageSnackbar',
                    buttonActionText: 'READ'
                };
                this.launchNotification(notificationOptions);
                this.messageSound.play().catch(() => { });
            }
            this._messageList.next(this.messageList);
        });
    }
    sendMessage(message) {
        message = message.replace(/ +(?= )/g, '');
        if (message !== '' && message !== ' ') {
            const data = {
                message: message,
                nickname: this.participantService.getMyNickname()
            };
            this.openviduService.sendSignal(Signal.CHAT, undefined, data);
        }
    }
    launchNotification(options) {
        this.actionService.launchNotification(options, this.panelService.togglePanel.bind(this.panelService, PanelType.CHAT));
    }
}
ChatService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ChatService, deps: [{ token: LoggerService }, { token: OpenViduService }, { token: ParticipantService }, { token: PanelService }, { token: ActionService }], target: i0.ɵɵFactoryTarget.Injectable });
ChatService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ChatService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ChatService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: LoggerService }, { type: OpenViduService }, { type: ParticipantService }, { type: PanelService }, { type: ActionService }]; } });

/**
 * @internal
 */
class LayoutService {
    constructor(documentService) {
        this.documentService = documentService;
        this.layoutContainer = null;
        this.layoutWidth = new BehaviorSubject(0);
        this.subtitlesToggling = new BehaviorSubject(false);
        this.layoutWidthObs = this.layoutWidth.asObservable();
        this.subtitlesTogglingObs = this.subtitlesToggling.asObservable();
    }
    initialize(container) {
        this.layoutContainer = container;
        this.openviduLayout = new OpenViduLayout();
        this.openviduLayoutOptions = this.getOptions();
        if (this.layoutContainer) {
            this.openviduLayout.initLayoutContainer(this.layoutContainer, this.openviduLayoutOptions);
        }
        this.sendLayoutWidthEvent();
    }
    getOptions() {
        const options = {
            maxRatio: 3 / 2,
            minRatio: 9 / 16,
            fixedRatio: false /* If this is true then the aspect ratio of the video is maintained
      and minRatio and maxRatio are ignored (default false) */,
            bigClass: LayoutClass.BIG_ELEMENT,
            smallClass: LayoutClass.SMALL_ELEMENT,
            ignoredClass: LayoutClass.IGNORED_ELEMENT,
            bigPercentage: 0.8,
            minBigPercentage: 0,
            bigFixedRatio: false,
            bigMaxRatio: 9 / 16,
            bigMinRatio: 9 / 16,
            bigFirst: true,
            animate: true,
            alignItems: LayoutAlignment.CENTER,
            bigAlignItems: LayoutAlignment.CENTER,
            smallAlignItems: LayoutAlignment.CENTER,
            maxWidth: Infinity,
            maxHeight: Infinity,
            smallMaxWidth: Infinity,
            smallMaxHeight: Infinity,
            bigMaxWidth: Infinity,
            bigMaxHeight: Infinity,
            scaleLastRow: true,
            bigScaleLastRow: true
        };
        return options;
    }
    toggleSubtitles() {
        this.subtitlesToggling.next(!this.subtitlesToggling.getValue());
    }
    update(timeout = null) {
        const updateAux = () => {
            if (!!this.openviduLayout) {
                this.openviduLayout.updateLayout(this.layoutContainer, this.openviduLayoutOptions);
                this.sendLayoutWidthEvent();
            }
        };
        if (typeof timeout === 'number' && timeout >= 0) {
            setTimeout(() => updateAux(), timeout);
        }
        else {
            updateAux();
        }
    }
    getLayout() {
        return this.openviduLayout;
    }
    clear() {
        this.openviduLayout = null;
    }
    sendLayoutWidthEvent() {
        var _a;
        const sidenavLayoutElement = this.documentService.getHTMLElementByClassName((_a = this.openviduLayout) === null || _a === void 0 ? void 0 : _a.getLayoutContainer(), LayoutClass.SIDENAV_CONTAINER);
        if (sidenavLayoutElement && sidenavLayoutElement.clientWidth) {
            this.layoutWidth.next(sidenavLayoutElement.clientWidth);
        }
    }
}
LayoutService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LayoutService, deps: [{ token: DocumentService }], target: i0.ɵɵFactoryTarget.Injectable });
LayoutService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LayoutService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LayoutService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: DocumentService }]; } });

class RecordingService {
    /**
     * @internal
     * @param actionService
     * @param sanitizer
     */
    constructor(actionService, sanitizer) {
        this.actionService = actionService;
        this.sanitizer = sanitizer;
        this.currentRecording = { status: RecordingStatus.STOPPED };
        this.recordingStatus = new BehaviorSubject(null);
        this.baseUrl = '/' + (!!window.location.pathname.split('/')[1] ? window.location.pathname.split('/')[1] + '/' : '');
        this.recordingStatusObs = this.recordingStatus.asObservable();
    }
    /**
     * @internal
     * @param status
     */
    updateStatus(status) {
        this.currentRecording = {
            status: status
        };
        this.recordingStatus.next({ info: this.currentRecording });
    }
    /**
     * @internal
     * @param event
     */
    startRecording(event) {
        this.currentRecording = {
            status: RecordingStatus.STARTED,
            id: event.id,
            name: event.name,
            reason: event.reason
        };
        this.startRecordingTime();
        this.recordingStatus.next({ info: this.currentRecording, time: this.recordingTime });
    }
    /**
     * @internal
     * @param event
     */
    stopRecording(event) {
        this.currentRecording.status = RecordingStatus.STOPPED;
        this.currentRecording.reason = event.reason;
        this.recordingStatus.next({ info: this.currentRecording, time: null });
        this.stopRecordingTime();
    }
    /**
     * @internal
     * Play the recording blob received as parameter. This parameter must be obtained from backend using the OpenVidu REST API
     */
    playRecording(recording) {
        const recordingId = recording.id;
        // Only COMPOSED recording is supported. The extension will allways be 'mp4'.
        const extension = 'mp4'; //recording.url?.split('.').pop()  || 'mp4';
        this.actionService.openRecordingPlayerDialog(`${this.baseUrl}recordings/${recordingId}/${recordingId}.${extension}`);
    }
    /**
     * @internal
     * Download the the recording file received .
     * @param recording
     */
    downloadRecording(recording) {
        const recordingId = recording.id;
        // Only COMPOSED recording is supported. The extension will allways be 'mp4'.
        const extension = 'mp4'; //recording.url?.split('.').pop()  || 'mp4';
        const link = document.createElement('a');
        link.href = `/recordings/${recordingId}/${recordingId}.${extension}`;
        link.download = `${recordingId}.${extension}`;
        link.dispatchEvent(new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window
        }));
        setTimeout(() => {
            // For Firefox it is necessary to delay revoking the ObjectURL
            link.remove();
        }, 100);
    }
    startRecordingTime() {
        this.recordingTime = new Date();
        this.recordingTime.setHours(0, 0, 0, 0);
        this.recordingTimeInterval = setInterval(() => {
            this.recordingTime.setSeconds(this.recordingTime.getSeconds() + 1);
            this.recordingTime = new Date(this.recordingTime.getTime());
            this.recordingStatus.next({ info: this.currentRecording, time: this.recordingTime });
        }, 1000);
    }
    stopRecordingTime() {
        clearInterval(this.recordingTimeInterval);
        this.recordingTime = null;
    }
}
RecordingService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingService, deps: [{ token: ActionService }, { token: i2.DomSanitizer }], target: i0.ɵɵFactoryTarget.Injectable });
RecordingService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: ActionService }, { type: i2.DomSanitizer }]; } });

// * Private directives *
/**
 * Load default OpenVidu logo if custom one is not exist
 * @internal
 */
class LogoDirective {
    constructor(elementRef) {
        this.elementRef = elementRef;
        this.defaultLogo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQ0AAADtCAMAAACS/9AMAAACLlBMVEUAAAAAiqoAiKoAiKr/zAD/zAD/zAD/zAD+zAH/zAD/zAD+zAH/zAD/zAAAiKoBiKoAian/zAAAiKoAiKoAiKoAiKr/zAD/zAAAiKr/zAAAiKoAiKr/zAD/zAD/zAD/zAAAiKsAiKr/zAD/zQAAiKsAiKr/zAD/zQD/zAAAiKoAiKr/zAD/zAD/zQD/zAAAiKr+zAD/zAAAiar/zAD/zAD/zAAAian/zAAAiKr/zAD/zAD/zQAAiKv/zAAAiKr/zAAAiKr/zAD/zAAAiKoAiKoAiKr+zAD/zQAAiKr/zAAAiKr/zAAAiKr/zAAAiKr/zAAAiKoAiKoAiKoAiKoAiKoBian/zQBHwlYWymQAiKr/zAAG02IAiKr///8G0mMJ02EA02j7zAH9zAEA02UI02EG1mBl0D3+//4FxW+sziEG02MG1l/9//0ExHED02AJ1GT7/v0S1Wns/PMI02MA0FgA0VoG2F0Ag68C0l4Ah6sAha0B0lwi2HQN1GYBmJsEwXP2/vnL9t7a+egCpI8FzWhNzknk++7A9Ni789Sk78Z66KwAjqRV4pQu2nze+euE6rJh5JwEu3kX12yUzyqO67hx5qUDqopD3ok83YU13IADtIAO01880kxg0D/Hzhav8c2Z7b9o5aBN4I8DsYMFyGwU012A0DLnzQnxzQXx/ffp+/HU+OSS7Lsw0lGfzyalzyO0zh27zhvUzRHczg0Ai6cBk6Ad0lkm0lVy0De/zhkyJ1GVAAAAWnRSTlMAAvz+/AX6gAT7cQMB/qYDBAJh9p7h7BoO0beJbsyfPy1YZwjbvXtbUicU9XYg45FjMyDYxcGxsIFFKRQI8Oq7q6mJeW5COg3So5iYUujIkGRQRjszoU7vu07Vus4OAAANMUlEQVR42uzWPWsCQRDG8adYz93MTLGNEvAFTtADX1CiiEoQLGIl9vP9P0i8GIJNCvdOcBd/H+CKPzOzh5eXuzF7Imtt48lZS54ZD8TeEqJC1uMxiHDBx22/yN8mw+ZTm3TyYrHzANgy6sbEQGOR95anTCNhxt1ePgVAHrUihv86vBv9IcY5lz0154xoabzKd2Bi1MZ7DEYrKXM7IyIaBxHjjIq2Dm14X+NgFB8q4kwsHW6IMaKtSQOEWli01+VHNVZiRLsLEKM6wmamEbcoGaPjeR05CPNM427x2+MAz5Vj5LEPxpWUOahqjCLmi3FLnA6r5fDYthJYk7/pKECoYpVMDFWjpy08QhE6CcVQdboGIxCjPdMIf7j+V2VXCE11mhKjSwYjBOOY2GhUGQ6LUVJX41pjjzCMdXI1RLMtfNgN/UxtUVSdDmFxP0pwUcJXxeKc2ItSEm3twAGLgn2Cs3GxAQXUGCT3vpaMdgIOh8c0S7GG03NADUJfU6zxzX4drDQMBAEYnk08iApbqIJaBREL1kuhB/FQFNFeRDwIRdgEs9utUiM+Rp+gx1ZvrV6sUA/q2zmth4gYIQu7W0N+8gQfM8tkhh3CgoLGdhoxUOMgu0S//6oALCTX2Eypxvq8isZaCs+NscbKrIrGXKaRaWQamUamkWn8Fw0xrmG0Lw1Cyc8ozeVylACxoiEEsxNq/Hl9IYlpjQnF48dw8H5ttPs2dlFf/KWT8t7x6cYyYJSY1BD4PQx6/ZAbT0ou7/zYnP1ioVYFIMSUBi7vU6cXchl6zcBCty0nLndCslQoAaHEiIZgYvjGpRc0PStdXrX82Fx3QpKvl4ASAxqCjXpcBoFnqUgjngRB8kcUiHYNwW66XGEsTGlEHqs7QDVrCNaRocJcGNOIPPwt3BatGojBPYXBMK6BIUcFiEYNXBOpgGFHAznOqkC0aTTYqC8VMCxpIEdZnwbW5gpvhiUNzPVrQDVpCPYyBRhJNBy/qO/dEM/29ySRBg7HOdBII32jkUjD8XeBRBqpezWSzka+AkSDRoO9dkNvCkqigcPxyY6967YNQ2EAdtu96dBOXfoGfYUOHfsGLKcEEUIQomySgABZgOMhdgxfgsBG4ilxgAC5DVnzdjmKRSYGsgiIACX8/0HQ/OHw8PD8bX2rQYMGr0aURlWNPzXVxu471Pjy/wdNYE7jw90olTU+/6pF4+pymzUhlTSI419r6801aCpvxDlxGpXa6FtrUBN9aMSNUl3jZy0a9804KJU1fre2atDYa0YTrazxvfUJGl7jKzSgAQ1oQAMa0IAGNKARtIZWLI7pK6DBhM5MnOfCmlTp0DUEs8v5oD/dP1x1yUMEraHT/FzyIhHv3HVNrES4GoKpIZeJpCSSPEbHhUeoGtrOeRLxdSL6Oxi1ySNMDZ1NejziPrLwWLQNUyFqKDPjiaPwHtNVTh7habCYugbfjJQR768UeYSmEedTr7HpcXu0Qx5BaYi43Snaxqse+2NmmYLG2oOTR2yFgob3uEjJAxrOY3BCHhoapUc0PMms1tAokkguz05tpjU0So/kbGkzpaHhPA4nNlUaGuVzrrf2gIbzOO8a8oCG87grPAQ0So/r+ZMHNEqPzuxpPQaN0uNmvS6Exsa6EBp+PbbIDdPQcB79o51MQcOvgwYTq6Dh6oNfj62CRpmEy7FR0CgjeW+ZaWj46himqI3nRKeZhoYvjpFR0PAaM2i80FhAwyXiyQR945G98+pxGggC8CYxkJBYTui99957Eb33ItiYhHYCJaEJSAjlQi8CUQSiwwNdIJpE+3mM44QhIoBnbbi143m4p9Pp9Gm+bTPrxdS4dNifYX/AuHr8iE+jsrXfcv7eYX8tarLIbTl13N+nVEssJ68dPObvYavlpuNw3OOfbxil6hyUIuHo3D/7MtsYjkFZ1j8XNVugjJYOv4KwyzwPhXYfv7pUrh0YZ+X7/Mpjpc4GLPyqdLUmDTU2v0a/P1fpV8j4/Rs5o9fJ7+35scC4eNfv+6ouMIweWr8n0Cy4vrkCCwy/X7Q8kVwt383we4nNxhW4x9RAfeavkcavTV5GU1Pj3EGA2zqnt+T+vMBonPspgONCPRq5cvOwwaKR7i7BLT+4APr7BUaD3Ws7ePgOjhu1l1L2HWy8O4+GKvvrnuY04H1YSI67+xFH7sdpTkPelYaR4/D1XdWL9LuqpzmNeo/eyI4np82xw+iKNU5zGvcbC2UcJ65fOnX6zcVbTw4Yk2ojf3/DwLH30OHMiX3wE062ZPg2y4iWpJHMwGwKH+7ZhywcopEVodGKDfLmN52ye4RotOGtPUmj5NNAGvlS0aeBNG4c9ccNpHG/4LoZFsNxGreFaIzhigdpJJvOCNCIso1c9SKNVLPAuJFgYxWueo9G09lPAnNKjE2f6UEaOKUQaSR6csWDNG4XBGiwKFvGI56jgcMGjQZMKt7LDdilFHURGgk2cjhXvUYDRaHRYDE2mSseo5E8e7koRiPKBnuNRir/FFOD9EQZ5Eb/8Vzx0ts6qSZIDTKNSkTZGOdofJTg3aVUHlfl1l96rESMxSY6hGM7f5xs8cCVF/3dS3N1PpwrXnnmMZV9hp4Qxw10xZlZ9tWXFho4EMbZz5gapDkFcQziiuLIyPGwZSYV1ORsc0Gn01jKNOYYDlTlUUu+eplK5vdgZlBoTGFxpBGDVcdw4OHqF1FTqWzyqY4wKDRWmzQQx7QJXFUU25NKy4yigCKZzZaaC0UBGCE9tK4ybqAsrfqNAh4RVbWVHV///8CRAhRN+WTpTBETg0Zj1jCTBkYiwRa1Hc+BRSSiqKqoKt+sqJJyMJJAIp989rS5iMMnVZRuCANtgVX6xl6jTBBgTQRCcVAVZNGUdSLyRjQlU7tv3G7+VKiTF7QHUX/lAT8WLRw0Z/xM5d89Og4snu2xHaVS6caN+09vn2m+rB8VQ4Fvjg/F3KjlkWAQ4eljpw7u13bEoB5zuErdquzY+ZdZ8OwZ3YkoFo8WII4WdVuBK9G6QBLhBKtEGAqTEWeWHDgL3r9c0GWKkL4AadQlEktEw+Fwqyh9t6/yl192pH8rSb48C8oUQX0DwLAQxGoLbuszO38rCcyCUkVQHzDOGo0w1qxJON7tyNTJDgklKQ+h65hmBUaMMTz5IOF4n96RdoEkRma0X2MNBp6n03E8frs1k5ZdEj0U1GctsAgDROmHqUHE8erFA+CRlncmMViE9IHjrMCwW1zYDsdgjx5s3ZpJptM7D8onSQhQhPSOqzUCjOmdhAtP6jbOX94893zH1q07ks9AEvMfEIpgyDEGRgSD5h9cPL8LCwSYxYiyIUKpgekBQD68ePRw06QB7YM2/XY42i8evSDOAhYTw1bBGvNju6LyCQtZLD6sz9rl7QSjb/f2uiPpEZrVseOAxSu7LZ23fJyRE5rVxDDLTqNsHqUrCl8xJsoCMWYvhk7SHdAlpPdlXWZUN6uawYKSGr05V+2xiCzrzBJRBhHQtLhoQD6vGWBXFzwLDmhx6yRwfp1rRxS1Ikk0xmwH+N1lim1dYA6ZUTtsUkSJYtePUGJ06hdl0QRzJLSAI7rgUosYCTatNVfFWSi9qpI4xQN1EValO4szemBfragkPXvXSiKDLiF9scYCTCxmc0VYkh6tCJJQdOmGugjQCPYRoxFjnWHHJockmB6oi6Aq84RUMbvjZJHEti5YKhAdRJdwRR5JbOqCRzt4zkUSZdEKrkokSU16sL4d6bpgwZUaZje+XJLU6kLeu2CjhgiNVTwimyQ1uvQh6YIVV9jF00VpBaUD6SQR1wVxbGYafQxdqHJVQklEdUFVRpNoYI1NTkkwNEbXJaQPgJ0bVRQ2gSuSSmJLFyCHjSukHZu0kgjqgi1eVFF6cEVmScRnl5C+MoDJYb10ILUkQrpgswZxxzaTq5JLIqILNvJYC7ykIb8kZF2wp5xGoxePuEASmi6oCjQAknZs0CrpCkloumAhgVRVmuoeSei6BPUOLEAsHbhGErIuUEgg7NxiLNyVKy6ShK7LWlTFWrOXqyQh6EIsJJifeXKZJCRdoJAQt6pKrFw6cJ0kBF2gkLAeaBCavVwoSa0uA1EXC4UEcrOXKr0kVnUBGgPhdyzmxpx6NECSrtJLYkUXLCTQm71Qkpkj+rtAkjq6iBUSsNlL/VUSPmekOySxogveOqA3e6mGJFPdI4kFXfDq1u8DvzHgckkwNIa61OJYzjRCsxdKorpPkj/pgi1gFksHHpCkhsew0YYupEICluYjPy+32rpVku9DqV1CENkFMZHAT1whimhueQ7hTIKSPBiF4NkFMZFA1JAoJ+8wySS4swvhiQTE0SRsnCycwEwyZGsS7MEBzy6IiQRiZg9MQZUK7/DIJDiyC2LIh3CLQ93T3N9tuGQSBOAHZRcmYHYhZXkgDyQQBIdLJkEARljtwsQkTPR6OB4Obh7u4ZRJMLMLM2Tb54gHwOSh5Swl5aw1GhiQ8ICkktHAgGYXAUZGgdHAIAAAQBR1+dE1+L0AAAAASUVORK5CYII=';
    }
    loadDefaultLogo() {
        const element = this.elementRef.nativeElement;
        element.src = this.ovLogo || this.defaultLogo;
    }
}
LogoDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LogoDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
LogoDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: LogoDirective, selector: "img[ovLogo]", inputs: { ovLogo: "ovLogo" }, host: { listeners: { "error": "loadDefaultLogo()" } }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LogoDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'img[ovLogo]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { ovLogo: [{
                type: Input
            }], loadDefaultLogo: [{
                type: HostListener,
                args: ['error']
            }] } });

/**
 *
 * The **ToolbarComponent** is hosted inside of the {@link VideoconferenceComponent}.
 * It is in charge of displaying the participants controlls for handling the media, panels and more videoconference features.
 *
 * <div class="custom-table-container">
 * <div>
 *  <h3>API Directives</h3>
 *
 * This component allows us to show or hide certain HTML elements with the following {@link https://angular.io/guide/attribute-directives Angular attribute directives}
 * with the aim of fully customizing the ToolbarComponent.
 *
 * | **Name**                  | **Type**  | **Reference**                                   |
 * | :----------------------------: | :-------: | :---------------------------------------------: |
 * | **screenshareButton**       | `boolean` | {@link ToolbarScreenshareButtonDirective}       |
 * | **fullscreenButton**        | `boolean` | {@link ToolbarFullscreenButtonDirective}        |
 * | **backgroundEffectsButton** | `boolean` | {@link ToolbarBackgroundEffectsButtonDirective} |
 * | **leaveButton**             | `boolean` | {@link ToolbarLeaveButtonDirective}             |
 * | **chatPanelButton**         | `boolean` | {@link ToolbarChatPanelButtonDirective}         |
 * | **participantsPanelButton** | `boolean` | {@link ToolbarParticipantsPanelButtonDirective} |
 * | **displayLogo**             | `boolean` | {@link ToolbarDisplayLogoDirective}             |
 * | **displaySessionName**      | `boolean` | {@link ToolbarDisplaySessionNameDirective}      |
 *
 * <p class="component-link-text">
 * <span class="italic">See all {@link ApiDirectiveModule API Directives}</span>
 * </p>
 *
 * </div>
 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The ToolbarComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovToolbar**           |            {@link ToolbarDirective}           |
 *
 * </br>
 *
 * It is also providing us a way to **add additional buttons** to the default toolbar.
 * It will recognise the following directive in a child element.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |   ***ovToolbarAdditionalButtons**   |   {@link ToolbarAdditionalButtonsDirective}   |
 * |***ovToolbarAdditionalPanelButtons**   |   {@link ToolbarAdditionalPanelButtonsDirective}   |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
class ToolbarComponent {
    /**
     * @ignore
     */
    constructor(documentService, chatService, panelService, tokenService, participantService, openviduService, oVDevicesService, actionService, loggerSrv, layoutService, cd, libService, platformService, recordingService, translateService) {
        this.documentService = documentService;
        this.chatService = chatService;
        this.panelService = panelService;
        this.tokenService = tokenService;
        this.participantService = participantService;
        this.openviduService = openviduService;
        this.oVDevicesService = oVDevicesService;
        this.actionService = actionService;
        this.loggerSrv = loggerSrv;
        this.layoutService = layoutService;
        this.cd = cd;
        this.libService = libService;
        this.platformService = platformService;
        this.recordingService = recordingService;
        this.translateService = translateService;
        /**
         * Provides event notifications that fire when leave button has been clicked.
         */
        this.onLeaveButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when camera toolbar button has been clicked.
         */
        this.onCameraButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when microphone toolbar button has been clicked.
         */
        this.onMicrophoneButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when fullscreen toolbar button has been clicked.
         */
        this.onFullscreenButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when screenshare toolbar button has been clicked.
         */
        this.onScreenshareButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when participants panel button has been clicked.
         */
        this.onParticipantsPanelButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when chat panel button has been clicked.
         */
        this.onChatPanelButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when activities panel button has been clicked.
         */
        this.onActivitiesPanelButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when start recording button has been clicked.
         */
        this.onStartRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when stop recording button has been clicked.
         */
        this.onStopRecordingClicked = new EventEmitter();
        /**
         * @ignore
         */
        this.unreadMessages = 0;
        /**
         * @ignore
         */
        this.messageList = [];
        /**
         * @ignore
         */
        this.isFullscreenActive = false;
        /**
         * @ignore
         */
        this.isChatOpened = false;
        /**
         * @ignore
         */
        this.isParticipantsOpened = false;
        /**
         * @ignore
         */
        this.isActivitiesOpened = false;
        /**
         * @ignore
         */
        this.isMinimal = false;
        /**
         * @ignore
         */
        this.showScreenshareButton = true;
        /**
         * @ignore
         */
        this.showFullscreenButton = true;
        /**
         * @ignore
         */
        this.showBackgroundEffectsButton = true;
        /**
         * @ignore
         */
        this.showLeaveButton = true;
        /**
         * @ignore
         */
        this.showRecordingButton = true;
        /**
         * @ignore
         */
        this.showSettingsButton = true;
        /**
         * @ignore
         */
        this.showMoreOptionsButton = true;
        /**
         * @ignore
         */
        this.showParticipantsPanelButton = true;
        /**
         * @ignore
         */
        this.showActivitiesPanelButton = true;
        /**
         * @ignore
         */
        this.showChatPanelButton = true;
        /**
         * @ignore
         */
        this.showLogo = true;
        /**
         * @ignore
         */
        this.showSessionName = true;
        /**
         * @ignore
         */
        this.showSubtitlesButton = true;
        /**
         * @ignore
         */
        this.videoMuteChanging = false;
        /**
         * @ignore
         */
        this.recordingStatus = RecordingStatus.STOPPED;
        /**
         * @ignore
         */
        this._recordingStatus = RecordingStatus;
        /**
         * @ignore
         */
        this.isSessionCreator = false;
        this.currentWindowHeight = window.innerHeight;
        this.log = this.loggerSrv.get('ToolbarComponent');
    }
    /**
     * @ignore
     */
    set externalAdditionalButtons(externalAdditionalButtons) {
        // This directive will has value only when ADDITIONAL BUTTONS component tagget with '*ovToolbarAdditionalButtons' directive
        // is inside of the TOOLBAR component tagged with '*ovToolbar' directive
        if (externalAdditionalButtons) {
            this.toolbarAdditionalButtonsTemplate = externalAdditionalButtons.template;
        }
    }
    /**
     * @ignore
     */
    set externalAdditionalPanelButtons(externalAdditionalPanelButtons) {
        // This directive will has value only when ADDITIONAL PANEL BUTTONS component tagget with '*ovToolbarAdditionalPanelButtons' directive
        // is inside of the TOOLBAR component tagged with '*ovToolbar' directive
        if (externalAdditionalPanelButtons) {
            this.toolbarAdditionalPanelButtonsTemplate = externalAdditionalPanelButtons.template;
        }
    }
    /**
     * @ignore
     */
    sizeChange(event) {
        if (this.currentWindowHeight >= window.innerHeight) {
            // The user has exit the fullscreen mode
            this.isFullscreenActive = false;
            this.currentWindowHeight = window.innerHeight;
        }
    }
    /**
     * @ignore
     */
    keyDown(event) {
        if (event.key === 'F11') {
            event.preventDefault();
            this.toggleFullscreen();
            this.currentWindowHeight = window.innerHeight;
            return false;
        }
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.subscribeToToolbarDirectives();
            this.hasVideoDevices = this.oVDevicesService.hasVideoDeviceAvailable();
            this.hasAudioDevices = this.oVDevicesService.hasAudioDeviceAvailable();
            this.session = this.openviduService.getWebcamSession();
            this.subscribeToUserMediaProperties();
            this.subscribeToReconnection();
            this.subscribeToMenuToggling();
            this.subscribeToChatMessages();
            this.subscribeToRecordingStatus();
            this.subscribeToScreenSize();
            this.subscribeToSubtitlesToggling();
        });
    }
    ngAfterViewInit() {
        var _a;
        // Sometimes the connection is undefined so we have to check the role when the mat menu is opened
        (_a = this.menuTrigger) === null || _a === void 0 ? void 0 : _a.menuOpened.subscribe(() => {
            this.isSessionCreator = this.participantService.getMyRole() === OpenViduRole.MODERATOR;
        });
    }
    ngOnDestroy() {
        if (this.panelTogglingSubscription)
            this.panelTogglingSubscription.unsubscribe();
        if (this.chatMessagesSubscription)
            this.chatMessagesSubscription.unsubscribe();
        if (this.localParticipantSubscription)
            this.localParticipantSubscription.unsubscribe();
        if (this.screenshareButtonSub)
            this.screenshareButtonSub.unsubscribe();
        if (this.fullscreenButtonSub)
            this.fullscreenButtonSub.unsubscribe();
        if (this.backgroundEffectsButtonSub)
            this.backgroundEffectsButtonSub.unsubscribe();
        if (this.leaveButtonSub)
            this.leaveButtonSub.unsubscribe();
        if (this.recordingButtonSub)
            this.recordingButtonSub.unsubscribe();
        if (this.participantsPanelButtonSub)
            this.participantsPanelButtonSub.unsubscribe();
        if (this.chatPanelButtonSub)
            this.chatPanelButtonSub.unsubscribe();
        if (this.displayLogoSub)
            this.displayLogoSub.unsubscribe();
        if (this.displaySessionNameSub)
            this.displaySessionNameSub.unsubscribe();
        if (this.minimalSub)
            this.minimalSub.unsubscribe();
        if (this.activitiesPanelButtonSub)
            this.activitiesPanelButtonSub.unsubscribe();
        if (this.recordingSubscription)
            this.recordingSubscription.unsubscribe();
        if (this.screenSizeSub)
            this.screenSizeSub.unsubscribe();
        if (this.settingsButtonSub)
            this.settingsButtonSub.unsubscribe();
        if (this.subtitlesSubs)
            this.subtitlesSubs.unsubscribe();
    }
    /**
     * @ignore
     */
    toggleMicrophone() {
        return __awaiter(this, void 0, void 0, function* () {
            this.onMicrophoneButtonClicked.emit();
            try {
                yield this.openviduService.publishAudio(!this.isAudioActive);
            }
            catch (error) {
                this.log.e('There was an error toggling microphone:', error.code, error.message);
                this.actionService.openDialog(this.translateService.translate('ERRORS.TOGGLE_MICROPHONE'), (error === null || error === void 0 ? void 0 : error.error) || (error === null || error === void 0 ? void 0 : error.message) || error);
            }
        });
    }
    /**
     * @ignore
     */
    toggleCamera() {
        return __awaiter(this, void 0, void 0, function* () {
            this.videoMuteChanging = true;
            this.onCameraButtonClicked.emit();
            try {
                const publishVideo = !this.participantService.isMyVideoActive();
                if (this.panelService.isExternalPanelOpened() && !publishVideo) {
                    this.panelService.togglePanel(PanelType.BACKGROUND_EFFECTS);
                }
                yield this.openviduService.publishVideo(publishVideo);
            }
            catch (error) {
                this.log.e('There was an error toggling camera:', error.code, error.message);
                this.actionService.openDialog(this.translateService.translate('ERRORS.TOGGLE_CAMERA'), (error === null || error === void 0 ? void 0 : error.error) || (error === null || error === void 0 ? void 0 : error.message) || error);
            }
            this.videoMuteChanging = false;
        });
    }
    /**
     * @ignore
     */
    toggleScreenShare() {
        return __awaiter(this, void 0, void 0, function* () {
            this.onScreenshareButtonClicked.emit();
            try {
                yield this.openviduService.toggleScreenshare();
            }
            catch (error) {
                this.log.e('There was an error toggling screen share', error.code, error.message);
                if (error && error.name === 'SCREEN_SHARING_NOT_SUPPORTED') {
                    this.actionService.openDialog(this.translateService.translate('ERRORS.SCREEN_SHARING'), this.translateService.translate('ERRORS.SCREEN_SUPPORT'));
                }
            }
        });
    }
    /**
     * @ignore
     */
    leaveSession() {
        this.log.d('Leaving session...');
        this.openviduService.disconnect();
        this.onLeaveButtonClicked.emit();
    }
    /**
     * @ignore
     */
    toggleRecording() {
        if (this.recordingStatus === RecordingStatus.STARTED) {
            this.log.d('Stopping recording');
            this.onStopRecordingClicked.emit();
            this.recordingService.updateStatus(RecordingStatus.STOPPING);
        }
        else if (this.recordingStatus === RecordingStatus.STOPPED) {
            this.onStartRecordingClicked.emit();
            this.recordingService.updateStatus(RecordingStatus.STARTING);
            if (this.showActivitiesPanelButton && !this.isActivitiesOpened) {
                this.toggleActivitiesPanel('recording');
            }
        }
    }
    /**
     * @ignore
     */
    toggleBackgroundEffects() {
        this.panelService.togglePanel(PanelType.BACKGROUND_EFFECTS);
    }
    /**
     * @ignore
     */
    toggleSubtitles() {
        this.layoutService.toggleSubtitles();
    }
    /**
     * @ignore
     */
    toggleSettings() {
        this.panelService.togglePanel(PanelType.SETTINGS);
    }
    /**
     * @ignore
     */
    toggleParticipantsPanel() {
        this.onParticipantsPanelButtonClicked.emit();
        this.panelService.togglePanel(PanelType.PARTICIPANTS);
    }
    /**
     * @ignore
     */
    toggleChatPanel() {
        this.onChatPanelButtonClicked.emit();
        this.panelService.togglePanel(PanelType.CHAT);
    }
    /**
     * @ignore
     */
    toggleFullscreen() {
        this.isFullscreenActive = !this.isFullscreenActive;
        this.documentService.toggleFullscreen('session-container');
        this.onFullscreenButtonClicked.emit();
    }
    toggleActivitiesPanel(expandPanel) {
        this.onActivitiesPanelButtonClicked.emit();
        this.panelService.togglePanel(PanelType.ACTIVITIES, expandPanel);
    }
    subscribeToReconnection() {
        this.session.on('reconnecting', () => {
            if (this.panelService.isPanelOpened()) {
                this.panelService.closePanel();
            }
            this.isConnectionLost = true;
        });
        this.session.on('reconnected', () => {
            this.isConnectionLost = false;
        });
    }
    subscribeToMenuToggling() {
        this.panelTogglingSubscription = this.panelService.panelOpenedObs.subscribe((ev) => {
            this.isChatOpened = ev.opened && ev.type === PanelType.CHAT;
            this.isParticipantsOpened = ev.opened && ev.type === PanelType.PARTICIPANTS;
            this.isActivitiesOpened = ev.opened && ev.type === PanelType.ACTIVITIES;
            if (this.isChatOpened) {
                this.unreadMessages = 0;
            }
            this.cd.markForCheck();
        });
    }
    subscribeToChatMessages() {
        this.chatMessagesSubscription = this.chatService.messagesObs.pipe(skip(1)).subscribe((messages) => {
            if (!this.panelService.isChatPanelOpened()) {
                this.unreadMessages++;
            }
            this.messageList = messages;
            this.cd.markForCheck();
        });
    }
    subscribeToUserMediaProperties() {
        this.localParticipantSubscription = this.participantService.localParticipantObs.subscribe((p) => {
            if (p) {
                this.isWebcamVideoActive = p.isCameraVideoActive();
                this.isAudioActive = p.hasAudioActive();
                this.isScreenShareActive = p.isScreenActive();
                this.isSessionCreator = p.getRole() === OpenViduRole.MODERATOR;
                this.cd.markForCheck();
            }
        });
    }
    subscribeToRecordingStatus() {
        this.recordingSubscription = this.recordingService.recordingStatusObs
            .pipe(skip(1))
            .subscribe((ev) => {
            this.recordingStatus = ev.info.status;
            this.recordingTime = ev.time;
            this.cd.markForCheck();
        });
    }
    subscribeToToolbarDirectives() {
        this.minimalSub = this.libService.minimalObs.subscribe((value) => {
            this.isMinimal = value;
            this.cd.markForCheck();
        });
        this.screenshareButtonSub = this.libService.screenshareButtonObs.subscribe((value) => {
            this.showScreenshareButton = value && !this.platformService.isMobile();
            this.cd.markForCheck();
        });
        this.fullscreenButtonSub = this.libService.fullscreenButtonObs.subscribe((value) => {
            this.showFullscreenButton = value;
            this.checkDisplayMoreOptions();
            this.cd.markForCheck();
        });
        this.leaveButtonSub = this.libService.leaveButtonObs.subscribe((value) => {
            this.showLeaveButton = value;
            this.cd.markForCheck();
        });
        this.recordingButtonSub = this.libService.recordingButtonObs.subscribe((value) => {
            this.showRecordingButton = value;
            this.checkDisplayMoreOptions();
            this.cd.markForCheck();
        });
        this.settingsButtonSub = this.libService.toolbarSettingsButtonObs.subscribe((value) => {
            this.showSettingsButton = value;
            this.checkDisplayMoreOptions();
            this.cd.markForCheck();
        });
        this.chatPanelButtonSub = this.libService.chatPanelButtonObs.subscribe((value) => {
            this.showChatPanelButton = value;
            this.cd.markForCheck();
        });
        this.participantsPanelButtonSub = this.libService.participantsPanelButtonObs.subscribe((value) => {
            this.showParticipantsPanelButton = value;
            this.cd.markForCheck();
        });
        this.activitiesPanelButtonSub = this.libService.activitiesPanelButtonObs.subscribe((value) => {
            this.showActivitiesPanelButton = value;
            this.cd.markForCheck();
        });
        this.backgroundEffectsButtonSub = this.libService.backgroundEffectsButton.subscribe((value) => {
            this.showBackgroundEffectsButton = value;
            this.checkDisplayMoreOptions();
            this.cd.markForCheck();
        });
        this.displayLogoSub = this.libService.displayLogoObs.subscribe((value) => {
            this.showLogo = value;
            this.cd.markForCheck();
        });
        this.displaySessionNameSub = this.libService.displaySessionNameObs.subscribe((value) => {
            this.showSessionName = value;
            this.cd.markForCheck();
        });
        this.subtitlesSubs = this.libService.subtitlesButtonObs.subscribe((value) => {
            this.showSubtitlesButton = value;
            this.cd.markForCheck();
        });
    }
    subscribeToScreenSize() {
        this.screenSizeSub = this.documentService.screenSizeObs.subscribe((change) => {
            this.screenSize = change[0].mqAlias;
        });
    }
    subscribeToSubtitlesToggling() {
        this.subtitlesSubs = this.layoutService.subtitlesTogglingObs.subscribe((value) => {
            this.subtitlesEnabled = value;
            this.cd.markForCheck();
        });
    }
    checkDisplayMoreOptions() {
        this.showMoreOptionsButton =
            this.showFullscreenButton || this.showBackgroundEffectsButton || this.showRecordingButton || this.showSettingsButton;
    }
}
ToolbarComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarComponent, deps: [{ token: DocumentService }, { token: ChatService }, { token: PanelService }, { token: TokenService }, { token: ParticipantService }, { token: OpenViduService }, { token: DeviceService }, { token: ActionService }, { token: LoggerService }, { token: LayoutService }, { token: i0.ChangeDetectorRef }, { token: OpenViduAngularConfigService }, { token: PlatformService }, { token: RecordingService }, { token: TranslateService }], target: i0.ɵɵFactoryTarget.Component });
ToolbarComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarComponent, selector: "ov-toolbar", outputs: { onLeaveButtonClicked: "onLeaveButtonClicked", onCameraButtonClicked: "onCameraButtonClicked", onMicrophoneButtonClicked: "onMicrophoneButtonClicked", onFullscreenButtonClicked: "onFullscreenButtonClicked", onScreenshareButtonClicked: "onScreenshareButtonClicked", onParticipantsPanelButtonClicked: "onParticipantsPanelButtonClicked", onChatPanelButtonClicked: "onChatPanelButtonClicked", onActivitiesPanelButtonClicked: "onActivitiesPanelButtonClicked", onStartRecordingClicked: "onStartRecordingClicked", onStopRecordingClicked: "onStopRecordingClicked" }, host: { listeners: { "window:resize": "sizeChange($event)", "document:keydown": "keyDown($event)" } }, queries: [{ propertyName: "toolbarAdditionalButtonsTemplate", first: true, predicate: ["toolbarAdditionalButtons"], descendants: true, read: TemplateRef }, { propertyName: "toolbarAdditionalPanelButtonsTemplate", first: true, predicate: ["toolbarAdditionalPanelButtons"], descendants: true, read: TemplateRef }, { propertyName: "externalAdditionalButtons", first: true, predicate: ToolbarAdditionalButtonsDirective, descendants: true }, { propertyName: "externalAdditionalPanelButtons", first: true, predicate: ToolbarAdditionalPanelButtonsDirective, descendants: true }], viewQueries: [{ propertyName: "menuTrigger", first: true, predicate: MatMenuTrigger, descendants: true }], ngImport: i0, template: "<mat-toolbar id=\"toolbar\" role=\"heading\" fxLayout fxLayoutAlign=\"center\" fxLayoutGap=\"40px\">\n\t<div fxFlex=\"20%\" fxLayoutAlign=\"start center\" id=\"info-container\" *ngIf=\"screenSize !== 'xs'\">\n\t\t<div>\n\t\t\t<img *ngIf=\"!isMinimal && showLogo\" id=\"branding-logo\" src=\"assets/images/logo.png\" ovLogo />\n\t\t\t<div id=\"session-info-container\" [class.colapsed]=\"recordingStatus === _recordingStatus.STARTED\">\n\t\t\t\t<span id=\"session-name\" *ngIf=\"!isMinimal && session && session.sessionId && showSessionName\">{{ session.sessionId }}</span>\n\t\t\t\t<div *ngIf=\"recordingStatus === _recordingStatus.STARTED\" id=\"recording-tag\" class=\"recording-tag\">\n\t\t\t\t\t<mat-icon class=\"blink\">radio_button_checked</mat-icon>\n\t\t\t\t\t<span class=\"blink\">REC</span>\n\t\t\t\t\t<span> | {{ recordingTime | date: 'H:mm:ss' }}</span>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\t<div fxFlex=\"60%\" fxFlexOrder=\"2\" fxLayoutAlign=\"center center\" id=\"media-buttons-container\">\n\t\t<!-- Microphone button -->\n\t\t<button\n\t\t\tid=\"mic-btn\"\n\t\t\tmat-icon-button\n\t\t\t(click)=\"toggleMicrophone()\"\n\t\t\t[disabled]=\"isConnectionLost || !hasAudioDevices\"\n\t\t\t[class.warn-btn]=\"!isAudioActive\"\n\t\t>\n\t\t\t<mat-icon *ngIf=\"isAudioActive\" matTooltip=\"{{ 'TOOLBAR.MUTE_AUDIO' | translate }}\" id=\"mic\">mic</mat-icon>\n\t\t\t<mat-icon *ngIf=\"!isAudioActive\" matTooltip=\"{{ 'TOOLBAR.UNMUTE_AUDIO' | translate }}\" id=\"mic_off\">mic_off</mat-icon>\n\t\t</button>\n\n\t\t<!-- Camera button -->\n\t\t<button\n\t\t\tid=\"camera-btn\"\n\t\t\tmat-icon-button\n\t\t\t(click)=\"toggleCamera()\"\n\t\t\t[disabled]=\"isConnectionLost || !hasVideoDevices || videoMuteChanging\"\n\t\t\t[class.warn-btn]=\"!isWebcamVideoActive\"\n\t\t>\n\t\t\t<mat-icon *ngIf=\"isWebcamVideoActive\" matTooltip=\"{{ 'TOOLBAR.MUTE_VIDEO' | translate }}\" id=\"videocam\">videocam</mat-icon>\n\t\t\t<mat-icon *ngIf=\"!isWebcamVideoActive\" matTooltip=\"{{ 'TOOLBAR.UNMUTE_VIDEO' | translate }}\" id=\"videocam_off\"\n\t\t\t\t>videocam_off</mat-icon\n\t\t\t>\n\t\t</button>\n\n\t\t<!-- Screenshare button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\t*ngIf=\"!isMinimal && showScreenshareButton\"\n\t\t\tid=\"screenshare-btn\"\n\t\t\t(click)=\"toggleScreenShare()\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t[class.active-btn]=\"isScreenShareActive\"\n\t\t>\n\t\t\t<mat-icon *ngIf=\"!isScreenShareActive\" matTooltip=\"{{ 'TOOLBAR.ENABLE_SCREEN' | translate }}\">screen_share</mat-icon>\n\t\t\t<mat-icon *ngIf=\"isScreenShareActive\" matTooltip=\"{{ 'TOOLBAR.DISABLE_SCREEN' | translate }}\">screen_share</mat-icon>\n\t\t</button>\n\n\t\t<!-- More options button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\tid=\"more-options-btn\"\n\t\t\t*ngIf=\"!isMinimal && showMoreOptionsButton\"\n\t\t\t[matMenuTriggerFor]=\"menu\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t>\n\t\t\t<mat-icon matTooltip=\"{{ 'TOOLBAR.MORE_OPTIONS' | translate }}\">more_vert</mat-icon>\n\t\t</button>\n\t\t<mat-menu #menu=\"matMenu\" id=\"more-options-menu\">\n\t\t\t<!-- Fullscreen button -->\n\t\t\t<button *ngIf=\"showFullscreenButton\" mat-menu-item id=\"fullscreen-btn\" (click)=\"toggleFullscreen()\">\n\t\t\t\t<mat-icon *ngIf=\"!isFullscreenActive\">fullscreen</mat-icon>\n\t\t\t\t<span *ngIf=\"!isFullscreenActive\">{{ 'TOOLBAR.FULLSCREEN' | translate }}</span>\n\n\t\t\t\t<mat-icon *ngIf=\"isFullscreenActive\">fullscreen_exit</mat-icon>\n\t\t\t\t<span *ngIf=\"isFullscreenActive\">{{ 'TOOLBAR.EXIT_FULLSCREEN' | translate }}</span>\n\t\t\t</button>\n\n\t\t\t<!-- Recording button -->\n\t\t\t<button\n\t\t\t\t*ngIf=\"!isMinimal && showRecordingButton\"\n\t\t\t\tmat-menu-item\n\t\t\t\tid=\"recording-btn\"\n\t\t\t\t[disabled]=\"\n\t\t\t\t\trecordingStatus === _recordingStatus.STARTING || recordingStatus === _recordingStatus.STOPPING || !isSessionCreator\n\t\t\t\t\"\n\t\t\t\t(click)=\"toggleRecording()\"\n\t\t\t>\n\t\t\t\t<mat-icon color=\"warn\">radio_button_checked</mat-icon>\n\t\t\t\t<span *ngIf=\"recordingStatus === _recordingStatus.STOPPED || recordingStatus === _recordingStatus.STOPPING\">\n\t\t\t\t\t{{ 'TOOLBAR.START_RECORDING' | translate }}\n\t\t\t\t</span>\n\t\t\t\t<span *ngIf=\"recordingStatus === _recordingStatus.STARTED || recordingStatus === _recordingStatus.STARTING\">\n\t\t\t\t\t{{ 'TOOLBAR.STOP_RECORDING' | translate }}\n\t\t\t\t</span>\n\t\t\t</button>\n\n\t\t\t<!-- Virtual background button -->\n\t\t\t<button\n\t\t\t\t*ngIf=\"!isMinimal && showBackgroundEffectsButton\"\n\t\t\t\t[disabled]=\"!isWebcamVideoActive\"\n\t\t\t\tmat-menu-item\n\t\t\t\tid=\"virtual-bg-btn\"\n\t\t\t\t(click)=\"toggleBackgroundEffects()\"\n\t\t\t>\n\t\t\t\t<mat-icon>auto_awesome</mat-icon>\n\t\t\t\t<span>{{ 'TOOLBAR.BACKGROUND' | translate }}</span>\n\t\t\t</button>\n\n\t\t\t<!-- Subtitles button -->\n\t\t\t<button\n\t\t\t\t*ngIf=\"!isMinimal && showSubtitlesButton\"\n\t\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t\tmat-menu-item\n\t\t\t\tid=\"subtitles-btn\"\n\t\t\t\t(click)=\"toggleSubtitles()\"\n\t\t\t>\n\t\t\t\t<mat-icon>closed_caption</mat-icon>\n\t\t\t\t<span *ngIf=\"subtitlesEnabled\">{{ 'TOOLBAR.DISABLE_SUBTITLES' | translate }}</span>\n\t\t\t\t<span *ngIf=\"!subtitlesEnabled\">{{ 'TOOLBAR.ENABLE_SUBTITLES' | translate }}</span>\n\t\t\t</button>\n\n\t\t\t<mat-divider class=\"divider\" *ngIf=\"!isMinimal && showSettingsButton\"></mat-divider>\n\n\t\t\t<!-- Settings button -->\n\t\t\t<button *ngIf=\"!isMinimal && showSettingsButton\" mat-menu-item id=\"toolbar-settings-btn\" (click)=\"toggleSettings()\">\n\t\t\t\t<mat-icon>settings</mat-icon>\n\t\t\t\t<span>{{ 'TOOLBAR.SETTINGS' | translate }}</span>\n\t\t\t</button>\n\t\t</mat-menu>\n\n\t\t<!-- External additional buttons  -->\n\t\t<ng-container *ngIf=\"toolbarAdditionalButtonsTemplate\">\n\t\t\t<ng-container *ngTemplateOutlet=\"toolbarAdditionalButtonsTemplate\"></ng-container>\n\t\t</ng-container>\n\n\t\t<!-- Leave session button -->\n\t\t<button mat-icon-button *ngIf=\"showLeaveButton\" (click)=\"leaveSession()\" id=\"leave-btn\">\n\t\t\t<mat-icon matTooltip=\"{{ 'TOOLBAR.LEAVE' | translate }}\">call_end</mat-icon>\n\t\t</button>\n\t</div>\n\t<div fxFlex=\"20%\" fxFlexOrder=\"3\" fxLayoutAlign=\"end center\" id=\"menu-buttons-container\">\n\t\t<!-- Default activities button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\tid=\"activities-panel-btn\"\n\t\t\t*ngIf=\"!isMinimal && showActivitiesPanelButton\"\n\t\t\tmatTooltip=\"{{ 'TOOLBAR.ACTIVITIES' | translate }}\"\n\t\t\t(click)=\"toggleActivitiesPanel()\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t[class.active-btn]=\"isActivitiesOpened\"\n\t\t>\n\t\t\t<mat-icon>category</mat-icon>\n\t\t</button>\n\n\t\t<!-- Default participants button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\tid=\"participants-panel-btn\"\n\t\t\t*ngIf=\"!isMinimal && showParticipantsPanelButton\"\n\t\t\tmatTooltip=\"{{ 'TOOLBAR.PARTICIPANTS' | translate }}\"\n\t\t\t(click)=\"toggleParticipantsPanel()\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t[class.active-btn]=\"isParticipantsOpened\"\n\t\t>\n\t\t\t<mat-icon>people</mat-icon>\n\t\t</button>\n\n\t\t<!-- Default chat button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\tid=\"chat-panel-btn\"\n\t\t\t*ngIf=\"!isMinimal && showChatPanelButton\"\n\t\t\tmatTooltip=\"{{ 'TOOLBAR.CHAT' | translate }}\"\n\t\t\t(click)=\"toggleChatPanel()\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t[class.active-btn]=\"isChatOpened\"\n\t\t>\n\t\t\t<mat-icon\n\t\t\t\tmatBadge=\"{{ unreadMessages }}\"\n\t\t\t\t[matBadgeHidden]=\"unreadMessages === 0\"\n\t\t\t\tmatBadgePosition=\"above before\"\n\t\t\t\tmatBadgeSize=\"small\"\n\t\t\t\tmatBadgeColor=\"accent\"\n\t\t\t>\n\t\t\t\tchat\n\t\t\t</mat-icon>\n\t\t</button>\n\n\t\t<!-- External additional panel buttons  -->\n\t\t<ng-container *ngIf=\"toolbarAdditionalPanelButtonsTemplate\">\n\t\t\t<ng-container *ngTemplateOutlet=\"toolbarAdditionalPanelButtonsTemplate\"></ng-container>\n\t\t</ng-container>\n\t</div>\n</mat-toolbar>\n", styles: ["#toolbar{height:100%;background-color:transparent;color:var(--ov-text-color)}.buttonsContainer{position:absolute;left:0;right:0}#info-container>div{display:flex;align-items:center}#media-buttons-container{max-height:100%!important}#media-buttons-container>button,::ng-deep #media-buttons-container>button,#media-buttons-container:not(#media-buttons-container > button) button,::ng-deep #media-buttons-container:not(#media-buttons-container > button) button{width:40px;height:40px;background-color:var(--ov-secondary-color);margin:6px}.warn-btn{background-color:var(--ov-warn-color)!important}.active-btn,::ng-deep .active-btn{background-color:var(--ov-tertiary-color)!important}#media-buttons-container mat-icon{font-size:24px}#media-buttons-container button,#menu-buttons-container button{border-radius:var(--ov-buttons-radius)}#branding-logo{background-color:var(--ov-logo-background-color);border-radius:var(--ov-panel-radius);max-width:35px;max-height:35px;padding:10px}#session-name{font-family:Ubuntu,sans-serif;font-weight:700;font-size:15px;height:fit-content;padding:0 15px}#session-info-container{display:flex}.colapsed{flex-direction:column}.recording-tag{padding:0 10px;background-color:var(--ov-warn-color);border-radius:var(--ov-panel-radius);width:fit-content;font-size:12px;text-align:center;line-height:20px;margin:auto}.recording-tag mat-icon{font-size:16px;display:inline;vertical-align:sub;margin-right:5px}.blink{animation:blinker 1.5s linear infinite}#point{width:10px;height:10px;position:absolute;top:12px;right:33px;border-radius:var(--ov-buttons-radius);background-color:#ffa600;border:1px solid #000;z-index:99999}#leave-btn{background-color:var(--ov-warn-color)!important;border-radius:var(--ov-leave-button-radius)!important;width:60px!important}.tooltipList{white-space:pre}#navChatButton .mat-badge-medium.mat-badge-overlap.mat-badge-before .mat-badge-content{left:-17px}#navChatButton .mat-badge-medium.mat-badge-above .mat-badge-content{top:-6px}.mat-icon-button[disabled]{color:#fff}.divider{margin:8px 0}::ng-deep .mat-menu-item{height:40px;line-height:40px}@media (max-width: 750px){#session-name{display:none}}@media (max-width: 850px){#branding-logo{display:none}}@media (max-width: 550px){#toolbar{padding:0;place-content:space-evenly}}@keyframes blinker{50%{opacity:.3}}\n"], components: [{ type: i15.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i18.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { type: i18.MatMenuItem, selector: "[mat-menu-item]", inputs: ["disabled", "disableRipple", "role"], exportAs: ["matMenuItem"] }, { type: i19.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }], directives: [{ type: i5.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { type: i5.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }, { type: i5.DefaultLayoutGapDirective, selector: "  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]", inputs: ["fxLayoutGap", "fxLayoutGap.xs", "fxLayoutGap.sm", "fxLayoutGap.md", "fxLayoutGap.lg", "fxLayoutGap.xl", "fxLayoutGap.lt-sm", "fxLayoutGap.lt-md", "fxLayoutGap.lt-lg", "fxLayoutGap.lt-xl", "fxLayoutGap.gt-xs", "fxLayoutGap.gt-sm", "fxLayoutGap.gt-md", "fxLayoutGap.gt-lg"] }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i5.DefaultFlexDirective, selector: "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", inputs: ["fxFlex", "fxFlex.xs", "fxFlex.sm", "fxFlex.md", "fxFlex.lg", "fxFlex.xl", "fxFlex.lt-sm", "fxFlex.lt-md", "fxFlex.lt-lg", "fxFlex.lt-xl", "fxFlex.gt-xs", "fxFlex.gt-sm", "fxFlex.gt-md", "fxFlex.gt-lg"] }, { type: LogoDirective, selector: "img[ovLogo]", inputs: ["ovLogo"] }, { type: i5.DefaultFlexOrderDirective, selector: "  [fxFlexOrder], [fxFlexOrder.xs], [fxFlexOrder.sm], [fxFlexOrder.md],  [fxFlexOrder.lg], [fxFlexOrder.xl], [fxFlexOrder.lt-sm], [fxFlexOrder.lt-md],  [fxFlexOrder.lt-lg], [fxFlexOrder.lt-xl], [fxFlexOrder.gt-xs], [fxFlexOrder.gt-sm],  [fxFlexOrder.gt-md], [fxFlexOrder.gt-lg]", inputs: ["fxFlexOrder", "fxFlexOrder.xs", "fxFlexOrder.sm", "fxFlexOrder.md", "fxFlexOrder.lg", "fxFlexOrder.xl", "fxFlexOrder.lt-sm", "fxFlexOrder.lt-md", "fxFlexOrder.lt-lg", "fxFlexOrder.lt-xl", "fxFlexOrder.gt-xs", "fxFlexOrder.gt-sm", "fxFlexOrder.gt-md", "fxFlexOrder.gt-lg"] }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: i18.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { type: i10.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }, { type: i24.MatBadge, selector: "[matBadge]", inputs: ["matBadgeDisabled", "matBadgeColor", "matBadgeOverlap", "matBadgePosition", "matBadge", "matBadgeDescription", "matBadgeSize", "matBadgeHidden"] }], pipes: { "date": i10.DatePipe, "translate": TranslatePipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-toolbar', changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-toolbar id=\"toolbar\" role=\"heading\" fxLayout fxLayoutAlign=\"center\" fxLayoutGap=\"40px\">\n\t<div fxFlex=\"20%\" fxLayoutAlign=\"start center\" id=\"info-container\" *ngIf=\"screenSize !== 'xs'\">\n\t\t<div>\n\t\t\t<img *ngIf=\"!isMinimal && showLogo\" id=\"branding-logo\" src=\"assets/images/logo.png\" ovLogo />\n\t\t\t<div id=\"session-info-container\" [class.colapsed]=\"recordingStatus === _recordingStatus.STARTED\">\n\t\t\t\t<span id=\"session-name\" *ngIf=\"!isMinimal && session && session.sessionId && showSessionName\">{{ session.sessionId }}</span>\n\t\t\t\t<div *ngIf=\"recordingStatus === _recordingStatus.STARTED\" id=\"recording-tag\" class=\"recording-tag\">\n\t\t\t\t\t<mat-icon class=\"blink\">radio_button_checked</mat-icon>\n\t\t\t\t\t<span class=\"blink\">REC</span>\n\t\t\t\t\t<span> | {{ recordingTime | date: 'H:mm:ss' }}</span>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\t<div fxFlex=\"60%\" fxFlexOrder=\"2\" fxLayoutAlign=\"center center\" id=\"media-buttons-container\">\n\t\t<!-- Microphone button -->\n\t\t<button\n\t\t\tid=\"mic-btn\"\n\t\t\tmat-icon-button\n\t\t\t(click)=\"toggleMicrophone()\"\n\t\t\t[disabled]=\"isConnectionLost || !hasAudioDevices\"\n\t\t\t[class.warn-btn]=\"!isAudioActive\"\n\t\t>\n\t\t\t<mat-icon *ngIf=\"isAudioActive\" matTooltip=\"{{ 'TOOLBAR.MUTE_AUDIO' | translate }}\" id=\"mic\">mic</mat-icon>\n\t\t\t<mat-icon *ngIf=\"!isAudioActive\" matTooltip=\"{{ 'TOOLBAR.UNMUTE_AUDIO' | translate }}\" id=\"mic_off\">mic_off</mat-icon>\n\t\t</button>\n\n\t\t<!-- Camera button -->\n\t\t<button\n\t\t\tid=\"camera-btn\"\n\t\t\tmat-icon-button\n\t\t\t(click)=\"toggleCamera()\"\n\t\t\t[disabled]=\"isConnectionLost || !hasVideoDevices || videoMuteChanging\"\n\t\t\t[class.warn-btn]=\"!isWebcamVideoActive\"\n\t\t>\n\t\t\t<mat-icon *ngIf=\"isWebcamVideoActive\" matTooltip=\"{{ 'TOOLBAR.MUTE_VIDEO' | translate }}\" id=\"videocam\">videocam</mat-icon>\n\t\t\t<mat-icon *ngIf=\"!isWebcamVideoActive\" matTooltip=\"{{ 'TOOLBAR.UNMUTE_VIDEO' | translate }}\" id=\"videocam_off\"\n\t\t\t\t>videocam_off</mat-icon\n\t\t\t>\n\t\t</button>\n\n\t\t<!-- Screenshare button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\t*ngIf=\"!isMinimal && showScreenshareButton\"\n\t\t\tid=\"screenshare-btn\"\n\t\t\t(click)=\"toggleScreenShare()\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t[class.active-btn]=\"isScreenShareActive\"\n\t\t>\n\t\t\t<mat-icon *ngIf=\"!isScreenShareActive\" matTooltip=\"{{ 'TOOLBAR.ENABLE_SCREEN' | translate }}\">screen_share</mat-icon>\n\t\t\t<mat-icon *ngIf=\"isScreenShareActive\" matTooltip=\"{{ 'TOOLBAR.DISABLE_SCREEN' | translate }}\">screen_share</mat-icon>\n\t\t</button>\n\n\t\t<!-- More options button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\tid=\"more-options-btn\"\n\t\t\t*ngIf=\"!isMinimal && showMoreOptionsButton\"\n\t\t\t[matMenuTriggerFor]=\"menu\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t>\n\t\t\t<mat-icon matTooltip=\"{{ 'TOOLBAR.MORE_OPTIONS' | translate }}\">more_vert</mat-icon>\n\t\t</button>\n\t\t<mat-menu #menu=\"matMenu\" id=\"more-options-menu\">\n\t\t\t<!-- Fullscreen button -->\n\t\t\t<button *ngIf=\"showFullscreenButton\" mat-menu-item id=\"fullscreen-btn\" (click)=\"toggleFullscreen()\">\n\t\t\t\t<mat-icon *ngIf=\"!isFullscreenActive\">fullscreen</mat-icon>\n\t\t\t\t<span *ngIf=\"!isFullscreenActive\">{{ 'TOOLBAR.FULLSCREEN' | translate }}</span>\n\n\t\t\t\t<mat-icon *ngIf=\"isFullscreenActive\">fullscreen_exit</mat-icon>\n\t\t\t\t<span *ngIf=\"isFullscreenActive\">{{ 'TOOLBAR.EXIT_FULLSCREEN' | translate }}</span>\n\t\t\t</button>\n\n\t\t\t<!-- Recording button -->\n\t\t\t<button\n\t\t\t\t*ngIf=\"!isMinimal && showRecordingButton\"\n\t\t\t\tmat-menu-item\n\t\t\t\tid=\"recording-btn\"\n\t\t\t\t[disabled]=\"\n\t\t\t\t\trecordingStatus === _recordingStatus.STARTING || recordingStatus === _recordingStatus.STOPPING || !isSessionCreator\n\t\t\t\t\"\n\t\t\t\t(click)=\"toggleRecording()\"\n\t\t\t>\n\t\t\t\t<mat-icon color=\"warn\">radio_button_checked</mat-icon>\n\t\t\t\t<span *ngIf=\"recordingStatus === _recordingStatus.STOPPED || recordingStatus === _recordingStatus.STOPPING\">\n\t\t\t\t\t{{ 'TOOLBAR.START_RECORDING' | translate }}\n\t\t\t\t</span>\n\t\t\t\t<span *ngIf=\"recordingStatus === _recordingStatus.STARTED || recordingStatus === _recordingStatus.STARTING\">\n\t\t\t\t\t{{ 'TOOLBAR.STOP_RECORDING' | translate }}\n\t\t\t\t</span>\n\t\t\t</button>\n\n\t\t\t<!-- Virtual background button -->\n\t\t\t<button\n\t\t\t\t*ngIf=\"!isMinimal && showBackgroundEffectsButton\"\n\t\t\t\t[disabled]=\"!isWebcamVideoActive\"\n\t\t\t\tmat-menu-item\n\t\t\t\tid=\"virtual-bg-btn\"\n\t\t\t\t(click)=\"toggleBackgroundEffects()\"\n\t\t\t>\n\t\t\t\t<mat-icon>auto_awesome</mat-icon>\n\t\t\t\t<span>{{ 'TOOLBAR.BACKGROUND' | translate }}</span>\n\t\t\t</button>\n\n\t\t\t<!-- Subtitles button -->\n\t\t\t<button\n\t\t\t\t*ngIf=\"!isMinimal && showSubtitlesButton\"\n\t\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t\tmat-menu-item\n\t\t\t\tid=\"subtitles-btn\"\n\t\t\t\t(click)=\"toggleSubtitles()\"\n\t\t\t>\n\t\t\t\t<mat-icon>closed_caption</mat-icon>\n\t\t\t\t<span *ngIf=\"subtitlesEnabled\">{{ 'TOOLBAR.DISABLE_SUBTITLES' | translate }}</span>\n\t\t\t\t<span *ngIf=\"!subtitlesEnabled\">{{ 'TOOLBAR.ENABLE_SUBTITLES' | translate }}</span>\n\t\t\t</button>\n\n\t\t\t<mat-divider class=\"divider\" *ngIf=\"!isMinimal && showSettingsButton\"></mat-divider>\n\n\t\t\t<!-- Settings button -->\n\t\t\t<button *ngIf=\"!isMinimal && showSettingsButton\" mat-menu-item id=\"toolbar-settings-btn\" (click)=\"toggleSettings()\">\n\t\t\t\t<mat-icon>settings</mat-icon>\n\t\t\t\t<span>{{ 'TOOLBAR.SETTINGS' | translate }}</span>\n\t\t\t</button>\n\t\t</mat-menu>\n\n\t\t<!-- External additional buttons  -->\n\t\t<ng-container *ngIf=\"toolbarAdditionalButtonsTemplate\">\n\t\t\t<ng-container *ngTemplateOutlet=\"toolbarAdditionalButtonsTemplate\"></ng-container>\n\t\t</ng-container>\n\n\t\t<!-- Leave session button -->\n\t\t<button mat-icon-button *ngIf=\"showLeaveButton\" (click)=\"leaveSession()\" id=\"leave-btn\">\n\t\t\t<mat-icon matTooltip=\"{{ 'TOOLBAR.LEAVE' | translate }}\">call_end</mat-icon>\n\t\t</button>\n\t</div>\n\t<div fxFlex=\"20%\" fxFlexOrder=\"3\" fxLayoutAlign=\"end center\" id=\"menu-buttons-container\">\n\t\t<!-- Default activities button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\tid=\"activities-panel-btn\"\n\t\t\t*ngIf=\"!isMinimal && showActivitiesPanelButton\"\n\t\t\tmatTooltip=\"{{ 'TOOLBAR.ACTIVITIES' | translate }}\"\n\t\t\t(click)=\"toggleActivitiesPanel()\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t[class.active-btn]=\"isActivitiesOpened\"\n\t\t>\n\t\t\t<mat-icon>category</mat-icon>\n\t\t</button>\n\n\t\t<!-- Default participants button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\tid=\"participants-panel-btn\"\n\t\t\t*ngIf=\"!isMinimal && showParticipantsPanelButton\"\n\t\t\tmatTooltip=\"{{ 'TOOLBAR.PARTICIPANTS' | translate }}\"\n\t\t\t(click)=\"toggleParticipantsPanel()\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t[class.active-btn]=\"isParticipantsOpened\"\n\t\t>\n\t\t\t<mat-icon>people</mat-icon>\n\t\t</button>\n\n\t\t<!-- Default chat button -->\n\t\t<button\n\t\t\tmat-icon-button\n\t\t\tid=\"chat-panel-btn\"\n\t\t\t*ngIf=\"!isMinimal && showChatPanelButton\"\n\t\t\tmatTooltip=\"{{ 'TOOLBAR.CHAT' | translate }}\"\n\t\t\t(click)=\"toggleChatPanel()\"\n\t\t\t[disabled]=\"isConnectionLost\"\n\t\t\t[class.active-btn]=\"isChatOpened\"\n\t\t>\n\t\t\t<mat-icon\n\t\t\t\tmatBadge=\"{{ unreadMessages }}\"\n\t\t\t\t[matBadgeHidden]=\"unreadMessages === 0\"\n\t\t\t\tmatBadgePosition=\"above before\"\n\t\t\t\tmatBadgeSize=\"small\"\n\t\t\t\tmatBadgeColor=\"accent\"\n\t\t\t>\n\t\t\t\tchat\n\t\t\t</mat-icon>\n\t\t</button>\n\n\t\t<!-- External additional panel buttons  -->\n\t\t<ng-container *ngIf=\"toolbarAdditionalPanelButtonsTemplate\">\n\t\t\t<ng-container *ngTemplateOutlet=\"toolbarAdditionalPanelButtonsTemplate\"></ng-container>\n\t\t</ng-container>\n\t</div>\n</mat-toolbar>\n", styles: ["#toolbar{height:100%;background-color:transparent;color:var(--ov-text-color)}.buttonsContainer{position:absolute;left:0;right:0}#info-container>div{display:flex;align-items:center}#media-buttons-container{max-height:100%!important}#media-buttons-container>button,::ng-deep #media-buttons-container>button,#media-buttons-container:not(#media-buttons-container > button) button,::ng-deep #media-buttons-container:not(#media-buttons-container > button) button{width:40px;height:40px;background-color:var(--ov-secondary-color);margin:6px}.warn-btn{background-color:var(--ov-warn-color)!important}.active-btn,::ng-deep .active-btn{background-color:var(--ov-tertiary-color)!important}#media-buttons-container mat-icon{font-size:24px}#media-buttons-container button,#menu-buttons-container button{border-radius:var(--ov-buttons-radius)}#branding-logo{background-color:var(--ov-logo-background-color);border-radius:var(--ov-panel-radius);max-width:35px;max-height:35px;padding:10px}#session-name{font-family:Ubuntu,sans-serif;font-weight:700;font-size:15px;height:fit-content;padding:0 15px}#session-info-container{display:flex}.colapsed{flex-direction:column}.recording-tag{padding:0 10px;background-color:var(--ov-warn-color);border-radius:var(--ov-panel-radius);width:fit-content;font-size:12px;text-align:center;line-height:20px;margin:auto}.recording-tag mat-icon{font-size:16px;display:inline;vertical-align:sub;margin-right:5px}.blink{animation:blinker 1.5s linear infinite}#point{width:10px;height:10px;position:absolute;top:12px;right:33px;border-radius:var(--ov-buttons-radius);background-color:#ffa600;border:1px solid #000;z-index:99999}#leave-btn{background-color:var(--ov-warn-color)!important;border-radius:var(--ov-leave-button-radius)!important;width:60px!important}.tooltipList{white-space:pre}#navChatButton .mat-badge-medium.mat-badge-overlap.mat-badge-before .mat-badge-content{left:-17px}#navChatButton .mat-badge-medium.mat-badge-above .mat-badge-content{top:-6px}.mat-icon-button[disabled]{color:#fff}.divider{margin:8px 0}::ng-deep .mat-menu-item{height:40px;line-height:40px}@media (max-width: 750px){#session-name{display:none}}@media (max-width: 850px){#branding-logo{display:none}}@media (max-width: 550px){#toolbar{padding:0;place-content:space-evenly}}@keyframes blinker{50%{opacity:.3}}\n"] }]
        }], ctorParameters: function () { return [{ type: DocumentService }, { type: ChatService }, { type: PanelService }, { type: TokenService }, { type: ParticipantService }, { type: OpenViduService }, { type: DeviceService }, { type: ActionService }, { type: LoggerService }, { type: LayoutService }, { type: i0.ChangeDetectorRef }, { type: OpenViduAngularConfigService }, { type: PlatformService }, { type: RecordingService }, { type: TranslateService }]; }, propDecorators: { toolbarAdditionalButtonsTemplate: [{
                type: ContentChild,
                args: ['toolbarAdditionalButtons', { read: TemplateRef }]
            }], toolbarAdditionalPanelButtonsTemplate: [{
                type: ContentChild,
                args: ['toolbarAdditionalPanelButtons', { read: TemplateRef }]
            }], externalAdditionalButtons: [{
                type: ContentChild,
                args: [ToolbarAdditionalButtonsDirective]
            }], externalAdditionalPanelButtons: [{
                type: ContentChild,
                args: [ToolbarAdditionalPanelButtonsDirective]
            }], onLeaveButtonClicked: [{
                type: Output
            }], onCameraButtonClicked: [{
                type: Output
            }], onMicrophoneButtonClicked: [{
                type: Output
            }], onFullscreenButtonClicked: [{
                type: Output
            }], onScreenshareButtonClicked: [{
                type: Output
            }], onParticipantsPanelButtonClicked: [{
                type: Output
            }], onChatPanelButtonClicked: [{
                type: Output
            }], onActivitiesPanelButtonClicked: [{
                type: Output
            }], onStartRecordingClicked: [{
                type: Output
            }], onStopRecordingClicked: [{
                type: Output
            }], menuTrigger: [{
                type: ViewChild,
                args: [MatMenuTrigger]
            }], sizeChange: [{
                type: HostListener,
                args: ['window:resize', ['$event']]
            }], keyDown: [{
                type: HostListener,
                args: ['document:keydown', ['$event']]
            }] } });

/**
 * @internal
 */
class VideoComponent {
    constructor() {
        this.type = VideoType.CAMERA;
    }
    ngAfterViewInit() {
        setTimeout(() => {
            if (this._streamManager && this._videoElement) {
                this.updateVideoStyles();
                this._streamManager.addVideoElement(this._videoElement.nativeElement);
            }
        });
    }
    set videoElement(element) {
        this._videoElement = element;
    }
    set streamManager(streamManager) {
        if (streamManager) {
            this._streamManager = streamManager;
            if (!!this._videoElement && this._streamManager) {
                this.updateVideoStyles();
                this._streamManager.addVideoElement(this._videoElement.nativeElement);
            }
        }
    }
    updateVideoStyles() {
        var _a, _b;
        this.type = (_b = (_a = this._streamManager) === null || _a === void 0 ? void 0 : _a.stream) === null || _b === void 0 ? void 0 : _b.typeOfVideo;
        if (this.type === VideoType.SCREEN) {
            this._videoElement.nativeElement.style.objectFit = 'contain';
            this._videoElement.nativeElement.classList.add('screen-type');
        }
        else {
            this._videoElement.nativeElement.style.objectFit = 'cover';
            this._videoElement.nativeElement.classList.add('camera-type');
        }
    }
}
VideoComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VideoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
VideoComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: VideoComponent, selector: "ov-video", inputs: { mutedSound: "mutedSound", streamManager: "streamManager" }, viewQueries: [{ propertyName: "videoElement", first: true, predicate: ["videoElement"], descendants: true }], ngImport: i0, template: `
		<video
			class="OT_video-element"
			#videoElement
			[attr.id]="streamManager && _streamManager.stream ? 'video-' + _streamManager.stream.streamId : 'video-undefined'"
			[muted]="mutedSound"
		></video>
	`, isInline: true, styles: ["video{object-fit:cover;width:100%;height:100%;color:#fff;margin:0;padding:0;border:0;font-size:100%;border-radius:var(--ov-video-radius);background-color:#000}\n"] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VideoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-video', template: `
		<video
			class="OT_video-element"
			#videoElement
			[attr.id]="streamManager && _streamManager.stream ? 'video-' + _streamManager.stream.streamId : 'video-undefined'"
			[muted]="mutedSound"
		></video>
	`, styles: ["video{object-fit:cover;width:100%;height:100%;color:#fff;margin:0;padding:0;border:0;font-size:100%;border-radius:var(--ov-video-radius);background-color:#000}\n"] }]
        }], propDecorators: { mutedSound: [{
                type: Input
            }], videoElement: [{
                type: ViewChild,
                args: ['videoElement', { static: false }]
            }], streamManager: [{
                type: Input
            }] } });

/**
 * @internal
 */
const AUTOLINKER_CFGS = {
    urls: {
        schemeMatches: true,
        wwwMatches: true,
        tldMatches: true
    },
    email: true,
    phone: true,
    mention: 'twitter',
    hashtag: 'twitter',
    stripPrefix: false,
    stripTrailingSlash: false,
    newWindow: true,
    truncate: {
        length: 0,
        location: 'end'
    },
    decodePercentEncoding: true
};
/**
 * @internal
 */
class Linkifier {
    constructor() {
        this.autolinker = new Autolinker(AUTOLINKER_CFGS);
    }
    link(textOrHtml) {
        return this.autolinker.link(textOrHtml);
    }
}

/**
 * @internal
 */
class LinkifyPipe {
    constructor() {
        this.linkifer = new Linkifier();
    }
    transform(str) {
        return str ? this.linkifer.link(str) : str;
    }
}
LinkifyPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LinkifyPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
LinkifyPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LinkifyPipe, name: "linkify" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LinkifyPipe, decorators: [{
            type: Pipe,
            args: [{ name: 'linkify' }]
        }], ctorParameters: function () { return []; } });

/**
 *
 * The **ChatPanelComponent** is hosted inside of the {@link PanelComponent}.
 * It is in charge of displaying the session chat.
 *
 * <div class="custom-table-container">

 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The ChatPanelComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovChatPanel**          |           {@link ChatPanelDirective}          |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
class ChatPanelComponent {
    /**
     * @ignore
     */
    constructor(chatService, panelService, cd) {
        this.chatService = chatService;
        this.panelService = panelService;
        this.cd = cd;
        this.messageList = [];
    }
    ngOnInit() {
        this.subscribeToMessages();
    }
    ngAfterViewInit() {
        setTimeout(() => {
            this.scrollToBottom();
            this.chatInput.nativeElement.focus();
        }, 100);
    }
    ngOnDestroy() {
        if (this.chatMessageSubscription)
            this.chatMessageSubscription.unsubscribe();
    }
    /**
     * @ignore
     */
    eventKeyPress(event) {
        // Pressed 'Enter' key
        if (event && event.keyCode === 13) {
            event.preventDefault();
            this.sendMessage();
        }
    }
    sendMessage() {
        if (!!this.message) {
            this.chatService.sendMessage(this.message);
            this.message = '';
        }
    }
    scrollToBottom() {
        setTimeout(() => {
            try {
                this.chatScroll.nativeElement.scrollTop = this.chatScroll.nativeElement.scrollHeight;
            }
            catch (err) { }
        }, 20);
    }
    close() {
        this.panelService.togglePanel(PanelType.CHAT);
    }
    subscribeToMessages() {
        this.chatMessageSubscription = this.chatService.messagesObs.subscribe((messages) => {
            this.messageList = messages;
            if (this.panelService.isChatPanelOpened()) {
                this.scrollToBottom();
                this.cd.markForCheck();
            }
        });
    }
}
ChatPanelComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ChatPanelComponent, deps: [{ token: ChatService }, { token: PanelService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
ChatPanelComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: ChatPanelComponent, selector: "ov-chat-panel", viewQueries: [{ propertyName: "chatScroll", first: true, predicate: ["chatScroll"], descendants: true }, { propertyName: "chatInput", first: true, predicate: ["chatInput"], descendants: true }], ngImport: i0, template: "<div class=\"panel-container\" id=\"chat-container\" fxLayout=\"column\" fxLayoutAlign=\"space-evenly none\" >\n\t<div class=\"panel-header-container\" fxFlex=\"55px\" fxLayoutAlign=\"start center\">\n\t\t<h3 class=\"panel-title\">{{ 'PANEL.CHAT.TITLE' | translate }}</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"text-container\" fxFlex=\"20px\">\n\t\t<p class=\"text-info\">{{ 'PANEL.CHAT.SUBTITLE' | translate }}</p>\n\t</div>\n\n\t<div class=\"messages-container\" fxFlex=\"75%\" fxLayoutAlign=\"space-evenly none\" #chatScroll>\n\t\t<div *ngFor=\"let data of messageList\" class=\"message\" [ngClass]=\"data.isLocal ? 'right' : 'left'\">\n\t\t\t<div class=\"msg-detail\">\n\t\t\t\t<div class=\"nickname-container\">\n\t\t\t\t\t<p *ngIf=\"data.isLocal\">{{ 'PANEL.CHAT.YOU' | translate }}</p>\n\t\t\t\t\t<p *ngIf=\"!data.isLocal\">{{ data.nickname }}</p>\n\t\t\t\t</div>\n\t\t\t\t<div class=\"msg-content\">\n\t\t\t\t\t<p [innerHTML]=\"data.message | linkify\"></p>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n\t<div class=\"input-container\" fxFlex=\"55px\" fxFlexOrder=\"3\" fxLayoutAlign=\"space-evenly none\">\n\t\t<textarea\n\t\t\t#chatInput\n\t\t\tmaxlength=\"500\"\n\t\t\trows=\"4\"\n\t\t\tplaceholder=\"{{ 'PANEL.CHAT.PLACEHOLDER' | translate }}\"\n\t\t\tautocomplete=\"off\"\n\t\t\t(keypress)=\"eventKeyPress($event)\"\n\t\t\t[(ngModel)]=\"message\"\n\t\t\tid=\"chat-input\"\n\t\t></textarea>\n\t\t<button mat-icon-button id=\"send-btn\" (click)=\"sendMessage()\">\n\t\t\t<mat-icon matTooltip=\"{{ 'PANEL.CHAT.SEND' | translate }}\">send</mat-icon>\n\t\t</button>\n\t</div>\n</div>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".text-container{background-color:var(--ov-light-color);color:var(--ov-panel-text-color);text-align:center;font-size:12px}.text-info{margin:3px}.messages-container{display:block!important;overflow-y:auto;overflow-x:hidden;padding:10px}.input-container{height:25px;display:flex;background-color:var(--ov-light-color);padding:10px;margin:10px;border-radius:var(--ov-panel-radius)}.input-container textarea{width:100%;height:16px;margin:auto;background-color:transparent;display:block;border:none;padding:0;word-wrap:break-word;white-space:pre-wrap;resize:none;outline:none;box-shadow:none;font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif}.message{position:relative;padding:3px 0}.msg-detail{width:95%;display:inline-block}.msg-detail p{margin:0;font-size:14px}.nickname-container p{font-size:13px;font-weight:700;color:var(--ov-panel-text-color)}.msg-content{position:relative;border-radius:var(--ov-panel-radius);padding:8px;color:#000;width:auto;max-width:95%;font-size:13px;word-break:break-all}#send-btn{border-radius:var(--ov-buttons-radius)}.message.left .msg-detail .nickname-container{text-align:left}.message.left .msg-detail .msg-content{float:left}.message.right .msg-detail .nickname-container{text-align:right}.message.right .msg-detail .msg-content{float:right}::ng-deep a:-webkit-any-link{color:#1a73e8}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], directives: [{ type: i5.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { type: i5.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }, { type: i5.DefaultFlexDirective, selector: "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", inputs: ["fxFlex", "fxFlex.xs", "fxFlex.sm", "fxFlex.md", "fxFlex.lg", "fxFlex.xl", "fxFlex.lt-sm", "fxFlex.lt-md", "fxFlex.lt-lg", "fxFlex.lt-xl", "fxFlex.gt-xs", "fxFlex.gt-sm", "fxFlex.gt-md", "fxFlex.gt-lg"] }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i10.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i2$1.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i5.DefaultFlexOrderDirective, selector: "  [fxFlexOrder], [fxFlexOrder.xs], [fxFlexOrder.sm], [fxFlexOrder.md],  [fxFlexOrder.lg], [fxFlexOrder.xl], [fxFlexOrder.lt-sm], [fxFlexOrder.lt-md],  [fxFlexOrder.lt-lg], [fxFlexOrder.lt-xl], [fxFlexOrder.gt-xs], [fxFlexOrder.gt-sm],  [fxFlexOrder.gt-md], [fxFlexOrder.gt-lg]", inputs: ["fxFlexOrder", "fxFlexOrder.xs", "fxFlexOrder.sm", "fxFlexOrder.md", "fxFlexOrder.lg", "fxFlexOrder.xl", "fxFlexOrder.lt-sm", "fxFlexOrder.lt-md", "fxFlexOrder.lt-lg", "fxFlexOrder.lt-xl", "fxFlexOrder.gt-xs", "fxFlexOrder.gt-sm", "fxFlexOrder.gt-md", "fxFlexOrder.gt-lg"] }, { type: i9.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { type: i9.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { type: i9.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i9.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], pipes: { "translate": TranslatePipe, "linkify": LinkifyPipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ChatPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-chat-panel', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"panel-container\" id=\"chat-container\" fxLayout=\"column\" fxLayoutAlign=\"space-evenly none\" >\n\t<div class=\"panel-header-container\" fxFlex=\"55px\" fxLayoutAlign=\"start center\">\n\t\t<h3 class=\"panel-title\">{{ 'PANEL.CHAT.TITLE' | translate }}</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"text-container\" fxFlex=\"20px\">\n\t\t<p class=\"text-info\">{{ 'PANEL.CHAT.SUBTITLE' | translate }}</p>\n\t</div>\n\n\t<div class=\"messages-container\" fxFlex=\"75%\" fxLayoutAlign=\"space-evenly none\" #chatScroll>\n\t\t<div *ngFor=\"let data of messageList\" class=\"message\" [ngClass]=\"data.isLocal ? 'right' : 'left'\">\n\t\t\t<div class=\"msg-detail\">\n\t\t\t\t<div class=\"nickname-container\">\n\t\t\t\t\t<p *ngIf=\"data.isLocal\">{{ 'PANEL.CHAT.YOU' | translate }}</p>\n\t\t\t\t\t<p *ngIf=\"!data.isLocal\">{{ data.nickname }}</p>\n\t\t\t\t</div>\n\t\t\t\t<div class=\"msg-content\">\n\t\t\t\t\t<p [innerHTML]=\"data.message | linkify\"></p>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n\t<div class=\"input-container\" fxFlex=\"55px\" fxFlexOrder=\"3\" fxLayoutAlign=\"space-evenly none\">\n\t\t<textarea\n\t\t\t#chatInput\n\t\t\tmaxlength=\"500\"\n\t\t\trows=\"4\"\n\t\t\tplaceholder=\"{{ 'PANEL.CHAT.PLACEHOLDER' | translate }}\"\n\t\t\tautocomplete=\"off\"\n\t\t\t(keypress)=\"eventKeyPress($event)\"\n\t\t\t[(ngModel)]=\"message\"\n\t\t\tid=\"chat-input\"\n\t\t></textarea>\n\t\t<button mat-icon-button id=\"send-btn\" (click)=\"sendMessage()\">\n\t\t\t<mat-icon matTooltip=\"{{ 'PANEL.CHAT.SEND' | translate }}\">send</mat-icon>\n\t\t</button>\n\t</div>\n</div>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".text-container{background-color:var(--ov-light-color);color:var(--ov-panel-text-color);text-align:center;font-size:12px}.text-info{margin:3px}.messages-container{display:block!important;overflow-y:auto;overflow-x:hidden;padding:10px}.input-container{height:25px;display:flex;background-color:var(--ov-light-color);padding:10px;margin:10px;border-radius:var(--ov-panel-radius)}.input-container textarea{width:100%;height:16px;margin:auto;background-color:transparent;display:block;border:none;padding:0;word-wrap:break-word;white-space:pre-wrap;resize:none;outline:none;box-shadow:none;font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif}.message{position:relative;padding:3px 0}.msg-detail{width:95%;display:inline-block}.msg-detail p{margin:0;font-size:14px}.nickname-container p{font-size:13px;font-weight:700;color:var(--ov-panel-text-color)}.msg-content{position:relative;border-radius:var(--ov-panel-radius);padding:8px;color:#000;width:auto;max-width:95%;font-size:13px;word-break:break-all}#send-btn{border-radius:var(--ov-buttons-radius)}.message.left .msg-detail .nickname-container{text-align:left}.message.left .msg-detail .msg-content{float:left}.message.right .msg-detail .nickname-container{text-align:right}.message.right .msg-detail .msg-content{float:right}::ng-deep a:-webkit-any-link{color:#1a73e8}\n"] }]
        }], ctorParameters: function () { return [{ type: ChatService }, { type: PanelService }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { chatScroll: [{
                type: ViewChild,
                args: ['chatScroll']
            }], chatInput: [{
                type: ViewChild,
                args: ['chatInput']
            }] } });

/**
 * @internal
 */
class SessionComponent {
    constructor(actionService, openviduService, participantService, loggerSrv, chatService, tokenService, libService, layoutService, panelService, recordingService, translateService, platformService) {
        this.actionService = actionService;
        this.openviduService = openviduService;
        this.participantService = participantService;
        this.loggerSrv = loggerSrv;
        this.chatService = chatService;
        this.tokenService = tokenService;
        this.libService = libService;
        this.layoutService = layoutService;
        this.panelService = panelService;
        this.recordingService = recordingService;
        this.translateService = translateService;
        this.platformService = platformService;
        this.usedInPrejoinPage = false;
        this.onSessionCreated = new EventEmitter();
        this.sidenavMode = SidenavMode.SIDE;
        this.SIDENAV_WIDTH_LIMIT_MODE = 790;
        this.log = this.loggerSrv.get('SessionComponent');
    }
    beforeunloadHandler() {
        this.leaveSession();
    }
    sizeChange() {
        this.layoutService.update();
    }
    set sidenavMenu(menu) {
        setTimeout(() => {
            if (menu) {
                this.sideMenu = menu;
                this.subscribeToTogglingMenu();
            }
        }, 0);
    }
    set videoContainer(container) {
        setTimeout(() => {
            if (container && !this.toolbarTemplate) {
                container.nativeElement.style.height = '100%';
                container.nativeElement.style.minHeight = '100%';
                this.layoutService.update();
            }
        }, 0);
    }
    set container(container) {
        setTimeout(() => {
            if (container) {
                this.drawer = container;
                this.drawer._contentMarginChanges.subscribe(() => {
                    setTimeout(() => {
                        this.stopUpdateLayoutInterval();
                        this.layoutService.update();
                        this.drawer.autosize = false;
                    }, 250);
                });
            }
        }, 0);
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.usedInPrejoinPage) {
                if (!this.tokenService.getScreenToken()) {
                    // Hide screenshare button if screen token does not exist
                    this.libService.screenshareButton.next(false);
                }
                this.session = this.openviduService.getWebcamSession();
                this.sessionScreen = this.openviduService.getScreenSession();
                this.subscribeToConnectionCreatedAndDestroyed();
                this.subscribeToStreamCreated();
                this.subscribeToStreamDestroyed();
                this.subscribeToStreamPropertyChange();
                this.subscribeToNicknameChanged();
                this.chatService.subscribeToChat();
                this.subscribeToReconnection();
                const recordingEnabled = this.libService.recordingButton.getValue() && this.libService.recordingActivity.getValue();
                if (recordingEnabled) {
                    this.subscribeToRecordingEvents();
                }
                this.onSessionCreated.emit(this.session);
                yield this.connectToSession();
                // ios devices appear with blank video. Muting and unmuting it fix this problem
                if (this.platformService.isIos() && this.participantService.isMyCameraActive()) {
                    yield this.openviduService.publishVideo(false);
                    yield this.openviduService.publishVideo(true);
                }
            }
        });
    }
    ngOnDestroy() {
        var _a;
        // Reconnecting session is received in Firefox
        // To avoid 'Connection lost' message uses session.off()
        (_a = this.session) === null || _a === void 0 ? void 0 : _a.off('reconnecting');
        this.participantService.clear();
        this.session = null;
        this.sessionScreen = null;
        if (this.menuSubscription)
            this.menuSubscription.unsubscribe();
        if (this.layoutWidthSubscription)
            this.layoutWidthSubscription.unsubscribe();
    }
    leaveSession() {
        this.log.d('Leaving session...');
        this.openviduService.disconnect();
    }
    subscribeToTogglingMenu() {
        this.sideMenu.openedChange.subscribe(() => {
            this.stopUpdateLayoutInterval();
            this.layoutService.update();
        });
        this.sideMenu.openedStart.subscribe(() => {
            this.startUpdateLayoutInterval();
        });
        this.sideMenu.closedStart.subscribe(() => {
            this.startUpdateLayoutInterval();
        });
        this.menuSubscription = this.panelService.panelOpenedObs.pipe(skip(1)).subscribe((ev) => {
            if (this.sideMenu) {
                this.settingsPanelOpened = ev.opened && ev.type === PanelType.SETTINGS;
                if (this.sideMenu.opened && ev.opened) {
                    if (ev.type === PanelType.SETTINGS || ev.oldType === PanelType.SETTINGS) {
                        // Switch from SETTINGS to another panel and vice versa.
                        // As the SETTINGS panel will be bigger than others, the sidenav container must be updated.
                        // Setting autosize to 'true' allows update it.
                        this.drawer.autosize = true;
                        this.startUpdateLayoutInterval();
                    }
                }
                ev.opened ? this.sideMenu.open() : this.sideMenu.close();
            }
        });
    }
    subscribeToLayoutWidth() {
        this.layoutWidthSubscription = this.layoutService.layoutWidthObs.subscribe((width) => {
            this.sidenavMode = width <= this.SIDENAV_WIDTH_LIMIT_MODE ? SidenavMode.OVER : SidenavMode.SIDE;
        });
    }
    connectToSession() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                if (this.participantService.haveICameraAndScreenActive()) {
                    yield this.openviduService.connectSession(this.openviduService.getWebcamSession(), this.tokenService.getWebcamToken());
                    yield this.openviduService.connectSession(this.openviduService.getScreenSession(), this.tokenService.getScreenToken());
                    yield this.openviduService.publish(this.participantService.getMyCameraPublisher());
                    yield this.openviduService.publish(this.participantService.getMyScreenPublisher());
                }
                else if (this.participantService.isOnlyMyScreenActive()) {
                    yield this.openviduService.connectSession(this.openviduService.getScreenSession(), this.tokenService.getScreenToken());
                    yield this.openviduService.publish(this.participantService.getMyScreenPublisher());
                }
                else {
                    yield this.openviduService.connectSession(this.openviduService.getWebcamSession(), this.tokenService.getWebcamToken());
                    yield this.openviduService.publish(this.participantService.getMyCameraPublisher());
                }
            }
            catch (error) {
                // this._error.emit({ error: error.error, messgae: error.message, code: error.code, status: error.status });
                this.log.e('There was an error connecting to the session:', error.code, error.message);
                this.actionService.openDialog(this.translateService.translate('ERRORS.SESSION'), (error === null || error === void 0 ? void 0 : error.error) || (error === null || error === void 0 ? void 0 : error.message) || error);
            }
        });
    }
    subscribeToConnectionCreatedAndDestroyed() {
        this.session.on('connectionCreated', (event) => {
            var _a, _b;
            const connectionId = (_a = event.connection) === null || _a === void 0 ? void 0 : _a.connectionId;
            const nickname = this.participantService.getNicknameFromConnectionData(event.connection.data);
            const isRemoteConnection = !this.openviduService.isMyOwnConnection(connectionId);
            const isCameraConnection = !(nickname === null || nickname === void 0 ? void 0 : nickname.includes(`_${VideoType.SCREEN}`));
            const data = (_b = event.connection) === null || _b === void 0 ? void 0 : _b.data;
            if (isRemoteConnection && isCameraConnection) {
                // Adding participant when connection is created and it's not screen
                this.participantService.addRemoteConnection(connectionId, data, null);
                //Sending nicnkanme signal to new participants
                if (this.openviduService.needSendNicknameSignal()) {
                    const data = { clientData: this.participantService.getMyNickname() };
                    this.openviduService.sendSignal(Signal.NICKNAME_CHANGED, [event.connection], data);
                }
            }
        });
        this.session.on('connectionDestroyed', (event) => {
            const nickname = this.participantService.getNicknameFromConnectionData(event.connection.data);
            const isRemoteConnection = !this.openviduService.isMyOwnConnection(event.connection.connectionId);
            const isCameraConnection = !(nickname === null || nickname === void 0 ? void 0 : nickname.includes(`_${VideoType.SCREEN}`));
            // Deleting participant when connection is destroyed
            if (isRemoteConnection && isCameraConnection) {
                this.participantService.removeConnectionByConnectionId(event.connection.connectionId);
            }
        });
    }
    subscribeToStreamCreated() {
        this.session.on('streamCreated', (event) => {
            var _a, _b, _c, _d;
            const connectionId = (_b = (_a = event.stream) === null || _a === void 0 ? void 0 : _a.connection) === null || _b === void 0 ? void 0 : _b.connectionId;
            const data = (_d = (_c = event.stream) === null || _c === void 0 ? void 0 : _c.connection) === null || _d === void 0 ? void 0 : _d.data;
            const isRemoteConnection = !this.openviduService.isMyOwnConnection(connectionId);
            if (isRemoteConnection) {
                const subscriber = this.session.subscribe(event.stream, undefined);
                this.participantService.addRemoteConnection(connectionId, data, subscriber);
                // this.oVSessionService.sendNicknameSignal(event.stream.connection);
            }
        });
    }
    subscribeToStreamDestroyed() {
        this.session.on('streamDestroyed', (event) => {
            const connectionId = event.stream.connection.connectionId;
            this.participantService.removeConnectionByConnectionId(connectionId);
        });
    }
    subscribeToStreamPropertyChange() {
        this.session.on('streamPropertyChanged', (event) => {
            const connectionId = event.stream.connection.connectionId;
            const isRemoteConnection = !this.openviduService.isMyOwnConnection(connectionId);
            if (isRemoteConnection) {
                this.participantService.updateRemoteParticipants();
            }
        });
    }
    subscribeToNicknameChanged() {
        this.session.on(`signal:${Signal.NICKNAME_CHANGED}`, (event) => {
            const connectionId = event.from.connectionId;
            const isRemoteConnection = !this.openviduService.isMyOwnConnection(connectionId);
            if (isRemoteConnection) {
                const nickname = this.participantService.getNicknameFromConnectionData(event.data);
                this.participantService.setRemoteNickname(connectionId, nickname);
            }
        });
    }
    subscribeToReconnection() {
        this.session.on('reconnecting', () => {
            this.log.w('Connection lost: Reconnecting');
            this.actionService.openDialog(this.translateService.translate('ERRORS.CONNECTION'), this.translateService.translate('ERRORS.RECONNECT'), false);
        });
        this.session.on('reconnected', () => {
            this.log.w('Connection lost: Reconnected');
            this.actionService.closeDialog();
        });
        this.session.on('sessionDisconnected', (event) => {
            if (event.reason === 'networkDisconnect') {
                this.actionService.closeDialog();
                this.leaveSession();
            }
        });
    }
    subscribeToRecordingEvents() {
        this.session.on('recordingStarted', (event) => {
            this.recordingService.startRecording(event);
        });
        this.session.on('recordingStopped', (event) => {
            this.recordingService.stopRecording(event);
        });
    }
    startUpdateLayoutInterval() {
        this.updateLayoutInterval = setInterval(() => {
            this.layoutService.update();
        }, 50);
    }
    stopUpdateLayoutInterval() {
        if (this.updateLayoutInterval) {
            clearInterval(this.updateLayoutInterval);
        }
    }
}
SessionComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: SessionComponent, deps: [{ token: ActionService }, { token: OpenViduService }, { token: ParticipantService }, { token: LoggerService }, { token: ChatService }, { token: TokenService }, { token: OpenViduAngularConfigService }, { token: LayoutService }, { token: PanelService }, { token: RecordingService }, { token: TranslateService }, { token: PlatformService }], target: i0.ɵɵFactoryTarget.Component });
SessionComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: SessionComponent, selector: "ov-session", inputs: { usedInPrejoinPage: "usedInPrejoinPage" }, outputs: { onSessionCreated: "onSessionCreated" }, host: { listeners: { "window:beforeunload": "beforeunloadHandler()", "window:resize": "sizeChange()" } }, queries: [{ propertyName: "toolbarTemplate", first: true, predicate: ["toolbar"], descendants: true, read: TemplateRef }, { propertyName: "panelTemplate", first: true, predicate: ["panel"], descendants: true, read: TemplateRef }, { propertyName: "layoutTemplate", first: true, predicate: ["layout"], descendants: true, read: TemplateRef }], viewQueries: [{ propertyName: "sidenavMenu", first: true, predicate: ["sidenav"], descendants: true }, { propertyName: "videoContainer", first: true, predicate: ["videoContainer"], descendants: true, read: ElementRef }, { propertyName: "container", first: true, predicate: ["container"], descendants: true }], ngImport: i0, template: "<div id=\"session-container\">\n\t<mat-sidenav-container #container #videoContainer class=\"sidenav-container\">\n\t\t<mat-sidenav\n\t\t\t#sidenav\n\t\t\tmode=\"{{ sidenavMode }}\"\n\t\t\tposition=\"end\"\n\t\t\tclass=\"sidenav-menu\"\n\t\t\t[ngClass]=\"{big: settingsPanelOpened}\"\n\t\t\tfixedInViewport=\"true\"\n\t\t\tfixedTopGap=\"0\"\n\t\t\tfixedBottomGap=\"0\"\n\t\t>\n\t\t\t<ng-container *ngTemplateOutlet=\"panelTemplate\"></ng-container>\n\t\t</mat-sidenav>\n\n\t\t<mat-sidenav-content class=\"sidenav-main\">\n\t\t\t<div id=\"layout-container\">\n\t\t\t\t<ng-container *ngTemplateOutlet=\"layoutTemplate\"></ng-container>\n\t\t\t</div>\n\t\t</mat-sidenav-content>\n\t</mat-sidenav-container>\n\n\t<div id=\"footer-container\" *ngIf=\"toolbarTemplate\">\n\t\t<ng-container *ngTemplateOutlet=\"toolbarTemplate\"></ng-container>\n\t</div>\n</div>\n", styles: ["#session-container{background-color:var(--ov-primary-color);height:100%}.sidenav-container{position:relative;height:calc(100% - 70px);min-height:calc(100% - 70px);padding-top:0;width:100%;overflow:hidden}.sidenav-menu{display:flex;align-items:center;justify-content:center;width:380px;background-color:var(--ov-primary-color);border-left:none;position:absolute;z-index:1}.big{width:650px;max-width:100%}.mat-drawer.mat-drawer-side{z-index:0!important}.sidenav-main{height:100%;overflow:hidden;min-height:-webkit-fill-available;min-height:-moz-available}#layout-container{height:inherit;width:inherit}.mat-drawer-container{background-color:var(--ov-primary-color)}#toolbar-container,#footer-container{background-color:var(--ov-primary-color);width:100%;height:70px}#footer{color:#fff;height:25px;background-color:#333;padding:0 14px 0 0;position:absolute;bottom:0;left:0;z-index:999999}.reconnecting-container{width:100%;height:100%;z-index:1000;background-color:#000;opacity:80%;position:absolute}@media only screen and (max-width: 600px){#session-container{width:100%}}::ng-deep .mat-button-toggle-appearance-standard .mat-button-toggle-label-content{padding:1px!important}::ng-deep .mat-input-element{caret-color:#000}::ng-deep .mat-primary .mat-option.mat-selected:not(.mat-option-disabled){color:#000}::ng-deep .mat-form-field-label{color:var(--ov-panel-text-color)!important}::ng-deep .mat-form-field.mat-focused .mat-form-field-ripple{background-color:var(--ov-panel-text-color)!important}::ng-deep .mat-drawer{background-color:transparent!important}\n"], components: [{ type: i13.MatSidenavContainer, selector: "mat-sidenav-container", exportAs: ["matSidenavContainer"] }, { type: i13.MatSidenav, selector: "mat-sidenav", inputs: ["fixedInViewport", "fixedTopGap", "fixedBottomGap"], exportAs: ["matSidenav"] }, { type: i13.MatSidenavContent, selector: "mat-sidenav-content" }], directives: [{ type: i10.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i2$1.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }, { type: i10.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: SessionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-session', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div id=\"session-container\">\n\t<mat-sidenav-container #container #videoContainer class=\"sidenav-container\">\n\t\t<mat-sidenav\n\t\t\t#sidenav\n\t\t\tmode=\"{{ sidenavMode }}\"\n\t\t\tposition=\"end\"\n\t\t\tclass=\"sidenav-menu\"\n\t\t\t[ngClass]=\"{big: settingsPanelOpened}\"\n\t\t\tfixedInViewport=\"true\"\n\t\t\tfixedTopGap=\"0\"\n\t\t\tfixedBottomGap=\"0\"\n\t\t>\n\t\t\t<ng-container *ngTemplateOutlet=\"panelTemplate\"></ng-container>\n\t\t</mat-sidenav>\n\n\t\t<mat-sidenav-content class=\"sidenav-main\">\n\t\t\t<div id=\"layout-container\">\n\t\t\t\t<ng-container *ngTemplateOutlet=\"layoutTemplate\"></ng-container>\n\t\t\t</div>\n\t\t</mat-sidenav-content>\n\t</mat-sidenav-container>\n\n\t<div id=\"footer-container\" *ngIf=\"toolbarTemplate\">\n\t\t<ng-container *ngTemplateOutlet=\"toolbarTemplate\"></ng-container>\n\t</div>\n</div>\n", styles: ["#session-container{background-color:var(--ov-primary-color);height:100%}.sidenav-container{position:relative;height:calc(100% - 70px);min-height:calc(100% - 70px);padding-top:0;width:100%;overflow:hidden}.sidenav-menu{display:flex;align-items:center;justify-content:center;width:380px;background-color:var(--ov-primary-color);border-left:none;position:absolute;z-index:1}.big{width:650px;max-width:100%}.mat-drawer.mat-drawer-side{z-index:0!important}.sidenav-main{height:100%;overflow:hidden;min-height:-webkit-fill-available;min-height:-moz-available}#layout-container{height:inherit;width:inherit}.mat-drawer-container{background-color:var(--ov-primary-color)}#toolbar-container,#footer-container{background-color:var(--ov-primary-color);width:100%;height:70px}#footer{color:#fff;height:25px;background-color:#333;padding:0 14px 0 0;position:absolute;bottom:0;left:0;z-index:999999}.reconnecting-container{width:100%;height:100%;z-index:1000;background-color:#000;opacity:80%;position:absolute}@media only screen and (max-width: 600px){#session-container{width:100%}}::ng-deep .mat-button-toggle-appearance-standard .mat-button-toggle-label-content{padding:1px!important}::ng-deep .mat-input-element{caret-color:#000}::ng-deep .mat-primary .mat-option.mat-selected:not(.mat-option-disabled){color:#000}::ng-deep .mat-form-field-label{color:var(--ov-panel-text-color)!important}::ng-deep .mat-form-field.mat-focused .mat-form-field-ripple{background-color:var(--ov-panel-text-color)!important}::ng-deep .mat-drawer{background-color:transparent!important}\n"] }]
        }], ctorParameters: function () { return [{ type: ActionService }, { type: OpenViduService }, { type: ParticipantService }, { type: LoggerService }, { type: ChatService }, { type: TokenService }, { type: OpenViduAngularConfigService }, { type: LayoutService }, { type: PanelService }, { type: RecordingService }, { type: TranslateService }, { type: PlatformService }]; }, propDecorators: { toolbarTemplate: [{
                type: ContentChild,
                args: ['toolbar', { read: TemplateRef }]
            }], panelTemplate: [{
                type: ContentChild,
                args: ['panel', { read: TemplateRef }]
            }], layoutTemplate: [{
                type: ContentChild,
                args: ['layout', { read: TemplateRef }]
            }], usedInPrejoinPage: [{
                type: Input
            }], onSessionCreated: [{
                type: Output
            }], beforeunloadHandler: [{
                type: HostListener,
                args: ['window:beforeunload']
            }], sizeChange: [{
                type: HostListener,
                args: ['window:resize']
            }], sidenavMenu: [{
                type: ViewChild,
                args: ['sidenav']
            }], videoContainer: [{
                type: ViewChild,
                args: ['videoContainer', { static: false, read: ElementRef }]
            }], container: [{
                type: ViewChild,
                args: ['container']
            }] } });

/**
 * @internal
 */
class CaptionsComponent {
    constructor(documentService, panelService, cd) {
        this.documentService = documentService;
        this.panelService = panelService;
        this.cd = cd;
        this.captionElements = [];
        //TODO: Delete
        this.sample = [
            { connectionId: '1', partial: 'frente' },
            { connectionId: '1', partial: 'friends' },
            { connectionId: '1', partial: 'friends' },
            { connectionId: '1', partial: 'friends estilizado' },
            { connectionId: '1', partial: 'friends estilizado' },
            { connectionId: '1', partial: 'friends estilizado' },
            { connectionId: '1', partial: 'friends estilizado' },
            { connectionId: '1', partial: 'friends estilizado efe' },
            { connectionId: '1', partial: 'friends estilizado efe' },
            { connectionId: '1', partial: 'friends estilizado efe erre' },
            { connectionId: '1', partial: 'friends estilizado efe erre' },
            { connectionId: '1', partial: 'friends estilizado efe erre' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y he' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y he' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y he' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y he' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en de' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en de' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en de' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en de' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida como' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida como' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida como' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa' },
            { connectionId: '1', partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa' },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense crear productos'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense crear productos'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense crear productos'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por mayor'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por mayor'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por mayor'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por mark'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por mark'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y la'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y la'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y la'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y la'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y la'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz cree'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz cree'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz cree'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz cree'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz cree'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz creen se'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz creen se'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz creen se'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz creen se'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz creen se'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz creen se'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz creen se'
            },
            {
                connectionId: '1',
                partial: 'friends estilizado efe el rey y en ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense creado y producida por marta kaufman y lápiz creen se'
            },
            {
                connectionId: '1',
                text: 'friends estilizado efe erre y ene de ese también conocida en hispanoamérica como amigos y en españa como colegas durante la temporada uno es una serie de televisión estadounidense y producida por marta kaufman y la creen se emitió'
            },
            { connectionId: '2', partial: 'la' },
            { connectionId: '2', partial: 'primera vez en' },
            { connectionId: '2', partial: 'primera vez en' },
            { connectionId: '2', partial: 'a veces vendidos' },
            { connectionId: '2', partial: 'a veces vendidos' },
            { connectionId: '2', partial: 'a veces vendidos' },
            { connectionId: '2', partial: 'a veces vendidos' },
            { connectionId: '2', partial: 'a veces vendidos' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la academia' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la academia' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la academia' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena de' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena de' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en eventos' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en eventos' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena de veces y' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena de veces y' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena de veces y' },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena de veces y términos y'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena de veces y términos y'
            },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de' },
            { connectionId: '2', partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de' },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatrocientos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatrocientos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatrocientos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro las'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro las'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que recibieron'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que recibieron'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que recibieron'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que recibieron matarnos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que recibieron matarnos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york sucede en'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york sucede en'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto unos como'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto unos como'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto unos como'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la actualidad y'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la actualidad y'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la actualidad y'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo considerable'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo considerable'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo considerable'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo considerable'
            },
            {
                connectionId: '2',
                partial: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena en términos de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que residen en oaxaca nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo considerable'
            },
            {
                connectionId: '2',
                text: 'a veces vendidos de septiembre de mil novecientos noventa y cuatro por la cadena de veces y terminó en seis de mayo de dos mil cuatro la serie trata sobre la vida de un grupo de amigos que en baja tan nueva york suceden tanto buenos como malos momentos pero con una crítica cómica los hechos más trascendentales de la autoridad inmediatamente después del éxito de su país el programa comenzó su difusión por todo el mundo considerable resultados'
            }
        ];
        this.captionsHeight = 0;
    }
    ngOnInit() {
        this.subscribeToScreenSize();
        this.subscribeToPanelToggling();
        this.subscribeToTranscription();
    }
    ngOnDestroy() {
        if (this.screenSizeSub)
            this.screenSizeSub.unsubscribe();
        if (this.panelTogglingSubscription)
            this.panelTogglingSubscription.unsubscribe();
        //TODO: Unsubscribe to openvidu-browser subtitle event
        clearInterval(this.interval);
    }
    onSettingsCliked() {
        this.panelService.togglePanel(PanelType.SETTINGS, PanelSettingsOptions.SUBTITLES);
    }
    subscribeToTranscription() {
        //TODO: Subscribe to openvidu-browser subtitle event
        this.startFakeEventWithSample();
        this.fakeEvent.subscribe((event) => {
            const text = !!event.text ? event.text : event.partial;
            this.updateCaption(event.connectionId, text);
            this.cd.markForCheck();
            this.scrollToBottom();
        });
    }
    updateCaption(connectionId, text) {
        //TODO: Delete
        const nicknames = new Map();
        nicknames.set('1', 'Pepe');
        nicknames.set('2', 'Mario');
        nicknames.set('3', 'Luis');
        nicknames.set('4', 'Juan');
        nicknames.set('5', 'INTERUPCION');
        // TODO End delete
        let newCaptionElements = [...this.captionElements];
        const newItem = { connectionId, author: nicknames.get(connectionId), text };
        if ((newCaptionElements === null || newCaptionElements === void 0 ? void 0 : newCaptionElements.length) > 0) {
            let lastItem = newCaptionElements[newCaptionElements.length - 1];
            if (lastItem.connectionId === connectionId) {
                //Last author and new author are the same. Updating the caption
                lastItem.text = text;
            }
            else {
                // const lastIntervention = newCaptionElements.find((item) => item.connectionId === connectionId);
                // if (!!lastIntervention) {
                // 	// The author is in the captionElements array
                // 	// adding only the new words after its intervention.
                // 	const splittedText = newItem.text.split(lastIntervention?.text)[1];
                // 	newItem.text = !!splittedText ? splittedText : newItem.text;
                // }
                newCaptionElements.push(newItem);
            }
        }
        else {
            newCaptionElements.push(newItem);
        }
        this.adjustCaptionsToContainer(newCaptionElements);
    }
    adjustCaptionsToContainer(newCaptionElements) {
        var _a;
        this.captionsHeight = 0;
        // TODO: the height is being calculated for old data
        // it should be calculated with the new caption elements
        (_a = this.captionElementsRef) === null || _a === void 0 ? void 0 : _a.forEach((item) => {
            this.captionsHeight += item.nativeElement.offsetHeight;
        });
        if ((newCaptionElements === null || newCaptionElements === void 0 ? void 0 : newCaptionElements.length) > 3) {
            // Maximum elements exceeded. Delete first element.
            newCaptionElements.shift();
        }
        else if (this.captionsHeight > 240) {
            if ((newCaptionElements === null || newCaptionElements === void 0 ? void 0 : newCaptionElements.length) === 3) {
                // Maximum height exceeded. Delete first element.
                newCaptionElements.shift();
            }
            else if ((newCaptionElements === null || newCaptionElements === void 0 ? void 0 : newCaptionElements.length) === 2 || (newCaptionElements === null || newCaptionElements === void 0 ? void 0 : newCaptionElements.length) === 1) {
                newCaptionElements[0].text = newCaptionElements[0].text.slice(100);
                if (newCaptionElements[0].text.length < 100) {
                    newCaptionElements.shift();
                }
            }
        }
        this.captionElements = [...newCaptionElements];
    }
    // TODO Delete when feature is enabled
    startFakeEventWithSample() {
        let index = 0;
        let event = this.sample[index];
        const fakeEventBS = new BehaviorSubject(event);
        this.fakeEvent = fakeEventBS.asObservable();
        const eventLoop = () => {
            return setInterval(() => {
                event = this.sample[index];
                index++;
                fakeEventBS.next(event);
                if (!this.sample[index]) {
                    clearInterval(this.interval);
                    index = 0;
                }
            }, 180);
        };
        this.interval = eventLoop();
        setInterval(() => {
            clearInterval(this.interval);
            const lorem = new LoremIpsum();
            let times = 5;
            let partial = 'BLA BLA BLA ';
            const interval2 = setInterval(() => {
                fakeEventBS.next({ connectionId: '5', partial });
                partial += lorem.generateWords(2);
                if (times <= 0) {
                    fakeEventBS.next({ connectionId: '5', partial, text: partial });
                    clearInterval(interval2);
                    this.interval = eventLoop();
                }
                times--;
            }, 400);
        }, 6000);
    }
    subscribeToPanelToggling() {
        this.panelTogglingSubscription = this.panelService.panelOpenedObs.subscribe((ev) => {
            this.settingsPanelOpened = ev.opened;
            this.cd.markForCheck();
        });
    }
    subscribeToScreenSize() {
        this.screenSizeSub = this.documentService.screenSizeObs.subscribe((change) => {
            this.screenSize = change[0].mqAlias;
            console.log(this.screenSize);
            this.cd.markForCheck();
        });
    }
    scrollToBottom() {
        // setTimeout(() => {
        try {
            this.textContainer.nativeElement.scrollTop = this.textContainer.nativeElement.scrollHeight;
        }
        catch (err) { }
        // }, 20);
    }
}
CaptionsComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CaptionsComponent, deps: [{ token: DocumentService }, { token: PanelService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
CaptionsComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: CaptionsComponent, selector: "ov-captions", viewQueries: [{ propertyName: "textContainer", first: true, predicate: ["textContainer"], descendants: true }, { propertyName: "captionElementsRef", predicate: ["captionElement"], descendants: true }], ngImport: i0, template: "<div class=\"subtitles-container\" #captionsContainer>\n\t<div *ngIf=\"screenSize !== 'sm' && screenSize !== 'xs' && !settingsPanelOpened\" class=\"subtitles-offset\">\n\t\t<button (click)=\"onSettingsCliked()\" id=\"subtitle-settings-btn\" mat-flat-button>\n\t\t\t<mat-icon id=\"subtitle-settings-icon\">settings</mat-icon>\n\t\t\t<span>English</span>\n\t\t</button>\n\t</div>\n\t<div class=\"subtitles-main-container\" #textContainer>\n\t\t<div class=\"element\" *ngFor=\"let item of captionElements\" #captionElement>\n\t\t\t<p\n\t\t\t\tid=\"author\"\n\t\t\t\t[ngClass]=\"{\n\t\t\t\t\t'big-author': captionsContainer.offsetWidth >= 1000 || screenSize === 'lg' || screenSize === 'xl',\n\t\t\t\t\t'medium-author': (captionsContainer.offsetWidth >= 960 && captionsContainer.offsetWidth < 1000) || screenSize === 'md',\n\t\t\t\t\t'small-author': captionsContainer.offsetWidth < 600 || screenSize === 'xs' || screenSize === 'sm'\n\t\t\t\t}\"\n\t\t\t>\n\t\t\t\t{{ item.author }} ({{item.text.length}})\n\t\t\t</p>\n\t\t\t<span\n\t\t\t\tid=\"subtitle-text\"\n\t\t\t\t[ngClass]=\"{\n\t\t\t\t\t'big-text': captionsContainer.offsetWidth >= 1000 || screenSize === 'lg' || screenSize === 'xl',\n\t\t\t\t\t'medium-text': (captionsContainer.offsetWidth >= 960 && captionsContainer.offsetWidth < 1000) || screenSize === 'md',\n\t\t\t\t\t'small-text': (captionsContainer.offsetWidth >= 600 && captionsContainer.offsetWidth < 960) || screenSize === 'sm',\n\t\t\t\t\t'extra-small-text': captionsContainer.offsetWidth < 600 || screenSize === 'xs'\n\t\t\t\t}\"\n\t\t\t>\n\t\t\t\t{{ item.text }}</span\n\t\t\t>\n\t\t</div>\n\t</div>\n\n\t<div *ngIf=\"screenSize !== 'sm' && screenSize !== 'xs' && !settingsPanelOpened\" class=\"subtitles-offset\">\n\t</div>\n</div>\n", styles: [".subtitles-container{display:flex;height:var(--ov-captions-height, 200px);margin:0 10px}.subtitles-offset{height:var(--ov-captions-height, 200px);width:15%;text-align:center}.subtitles-main-container{flex-grow:1;align-self:center;margin-left:15px;max-height:var(--ov-captions-height, 200px);width:70%;overflow:hidden}#subtitle-settings-btn{color:var(--ov-text-color);background-color:var(--ov-secondary-color)}#subtitle-settings-icon{font-size:15px;height:15px;width:15px;padding-right:5px}#author{margin-bottom:3px;font-weight:700}#subtitle-text,#author{color:var(--ov-text-color);font-family:Roboto,arial,sans-serif}.subtitles-main-container .element{margin:5px}#subtitle-text{background-color:var(--ov-logo-background-color);padding:4.5px;line-height:1.6;word-break:break-word}.big-text{font-size:22px}.medium-text{font-size:20px}.small-text{font-size:18px}.extra-small-text,.big-author{font-size:16px}.medium-author{font-size:14px}.small-author{font-size:12px}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], directives: [{ type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i10.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i2$1.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CaptionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-captions', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"subtitles-container\" #captionsContainer>\n\t<div *ngIf=\"screenSize !== 'sm' && screenSize !== 'xs' && !settingsPanelOpened\" class=\"subtitles-offset\">\n\t\t<button (click)=\"onSettingsCliked()\" id=\"subtitle-settings-btn\" mat-flat-button>\n\t\t\t<mat-icon id=\"subtitle-settings-icon\">settings</mat-icon>\n\t\t\t<span>English</span>\n\t\t</button>\n\t</div>\n\t<div class=\"subtitles-main-container\" #textContainer>\n\t\t<div class=\"element\" *ngFor=\"let item of captionElements\" #captionElement>\n\t\t\t<p\n\t\t\t\tid=\"author\"\n\t\t\t\t[ngClass]=\"{\n\t\t\t\t\t'big-author': captionsContainer.offsetWidth >= 1000 || screenSize === 'lg' || screenSize === 'xl',\n\t\t\t\t\t'medium-author': (captionsContainer.offsetWidth >= 960 && captionsContainer.offsetWidth < 1000) || screenSize === 'md',\n\t\t\t\t\t'small-author': captionsContainer.offsetWidth < 600 || screenSize === 'xs' || screenSize === 'sm'\n\t\t\t\t}\"\n\t\t\t>\n\t\t\t\t{{ item.author }} ({{item.text.length}})\n\t\t\t</p>\n\t\t\t<span\n\t\t\t\tid=\"subtitle-text\"\n\t\t\t\t[ngClass]=\"{\n\t\t\t\t\t'big-text': captionsContainer.offsetWidth >= 1000 || screenSize === 'lg' || screenSize === 'xl',\n\t\t\t\t\t'medium-text': (captionsContainer.offsetWidth >= 960 && captionsContainer.offsetWidth < 1000) || screenSize === 'md',\n\t\t\t\t\t'small-text': (captionsContainer.offsetWidth >= 600 && captionsContainer.offsetWidth < 960) || screenSize === 'sm',\n\t\t\t\t\t'extra-small-text': captionsContainer.offsetWidth < 600 || screenSize === 'xs'\n\t\t\t\t}\"\n\t\t\t>\n\t\t\t\t{{ item.text }}</span\n\t\t\t>\n\t\t</div>\n\t</div>\n\n\t<div *ngIf=\"screenSize !== 'sm' && screenSize !== 'xs' && !settingsPanelOpened\" class=\"subtitles-offset\">\n\t</div>\n</div>\n", styles: [".subtitles-container{display:flex;height:var(--ov-captions-height, 200px);margin:0 10px}.subtitles-offset{height:var(--ov-captions-height, 200px);width:15%;text-align:center}.subtitles-main-container{flex-grow:1;align-self:center;margin-left:15px;max-height:var(--ov-captions-height, 200px);width:70%;overflow:hidden}#subtitle-settings-btn{color:var(--ov-text-color);background-color:var(--ov-secondary-color)}#subtitle-settings-icon{font-size:15px;height:15px;width:15px;padding-right:5px}#author{margin-bottom:3px;font-weight:700}#subtitle-text,#author{color:var(--ov-text-color);font-family:Roboto,arial,sans-serif}.subtitles-main-container .element{margin:5px}#subtitle-text{background-color:var(--ov-logo-background-color);padding:4.5px;line-height:1.6;word-break:break-word}.big-text{font-size:22px}.medium-text{font-size:20px}.small-text{font-size:18px}.extra-small-text,.big-author{font-size:16px}.medium-author{font-size:14px}.small-author{font-size:12px}\n"] }]
        }], ctorParameters: function () { return [{ type: DocumentService }, { type: PanelService }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { textContainer: [{
                type: ViewChild,
                args: ['textContainer']
            }], captionElementsRef: [{
                type: ViewChildren,
                args: ['captionElement']
            }] } });

class ParticipantStreamsPipe {
    constructor() { }
    transform(participants) {
        let streams = [];
        if (participants && Object.keys(participants).length > 0) {
            if (Array.isArray(participants)) {
                participants.forEach((p) => {
                    streams = streams.concat(p.getAvailableConnections());
                });
            }
            else {
                streams = participants.getAvailableConnections();
            }
        }
        return streams;
    }
}
ParticipantStreamsPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantStreamsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
ParticipantStreamsPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantStreamsPipe, name: "streams" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantStreamsPipe, decorators: [{
            type: Pipe,
            args: [{ name: 'streams' }]
        }], ctorParameters: function () { return []; } });
/**
 * @internal
 */
class StreamTypesEnabledPipe {
    constructor(translateService) {
        this.translateService = translateService;
    }
    transform(participant) {
        let result = '';
        let activeStreams = participant === null || participant === void 0 ? void 0 : participant.getConnectionTypesActive().toString();
        const activeStreamsArr = activeStreams.split(',');
        activeStreamsArr.forEach((type, index) => {
            result += this.translateService.translate(`PANEL.PARTICIPANTS.${type}`);
            if (activeStreamsArr.length > 0 && index < activeStreamsArr.length - 1) {
                result += ', ';
            }
        });
        return `(${result})`;
    }
}
StreamTypesEnabledPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamTypesEnabledPipe, deps: [{ token: TranslateService }], target: i0.ɵɵFactoryTarget.Pipe });
StreamTypesEnabledPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamTypesEnabledPipe, name: "streamTypesEnabled" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamTypesEnabledPipe, decorators: [{
            type: Pipe,
            args: [{ name: 'streamTypesEnabled' }]
        }], ctorParameters: function () { return [{ type: TranslateService }]; } });

/**
 *
 * The **LayoutComponent** is hosted inside of the {@link VideoconferenceComponent}.
 * It is in charge of displaying the participants streams layout.
 *
 * <div class="custom-table-container">
 *
 * <div>
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The LayoutComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |            ***ovLayout**            |            {@link LayoutDirective}            |
 *
 * </br>
 *
 * It is also providing us a way to **replace the {@link StreamComponent Stream Component}** (<span class="italic">which is hosted inside of it</span>) with a custom one.
 * It will recognise the following directive in a child element.
 *
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |            ***ovStream**            |            {@link StreamDirective}            |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
class LayoutComponent {
    /**
     * @ignore
     */
    constructor(layoutService, participantService, cd) {
        this.layoutService = layoutService;
        this.participantService = participantService;
        this.cd = cd;
        this.remoteParticipants = [];
        /**
         * @ignore
         */
        this.subtitlesEnabled = true;
    }
    /**
     * @ignore
     */
    set externalStream(externalStream) {
        // This directive will has value only when STREAM component tagget with '*ovStream' directive
        // is inside of the layout component tagged with '*ovLayout' directive
        if (externalStream) {
            this.streamTemplate = externalStream.template;
        }
    }
    ngOnInit() {
        this.subscribeToParticipants();
        this.subscribeToSubtitles();
    }
    ngAfterViewInit() {
        this.layoutService.initialize(this.layoutContainer.element.nativeElement);
    }
    ngOnDestroy() {
        this.localParticipant = null;
        this.remoteParticipants = [];
        if (this.localParticipantSubs)
            this.localParticipantSubs.unsubscribe();
        if (this.remoteParticipantsSubs)
            this.remoteParticipantsSubs.unsubscribe();
        if (this.subtitlesSubs)
            this.subtitlesSubs.unsubscribe();
        this.layoutService.clear();
    }
    subscribeToSubtitles() {
        this.subtitlesSubs = this.layoutService.subtitlesTogglingObs.subscribe((value) => {
            this.subtitlesEnabled = value;
            this.cd.markForCheck();
            this.layoutService.update();
        });
    }
    subscribeToParticipants() {
        this.localParticipantSubs = this.participantService.localParticipantObs.subscribe((p) => {
            this.localParticipant = p;
            this.layoutService.update();
            this.cd.markForCheck();
        });
        this.remoteParticipantsSubs = this.participantService.remoteParticipantsObs.subscribe((participants) => {
            this.remoteParticipants = participants;
            this.layoutService.update();
            this.cd.markForCheck();
        });
    }
}
LayoutComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LayoutComponent, deps: [{ token: LayoutService }, { token: ParticipantService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
LayoutComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: LayoutComponent, selector: "ov-layout", queries: [{ propertyName: "streamTemplate", first: true, predicate: ["stream"], descendants: true, read: TemplateRef }, { propertyName: "externalStream", first: true, predicate: StreamDirective, descendants: true }], viewQueries: [{ propertyName: "layoutContainer", first: true, predicate: ["layout"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "<div class=\"container\" [class.withSubtitles]=\"subtitlesEnabled\">\n\t<div id=\"layout\" class=\"layout\" #layout>\n\t\t<div *ngFor=\"let stream of localParticipant | streams\"  [ngClass]=\"{ OV_big: stream.videoEnlarged }\" class=\"OT_root OT_publisher\">\n\t\t\t<ng-container *ngTemplateOutlet=\"streamTemplate; context: { $implicit: stream }\"></ng-container>\n\t\t</div>\n\n\t\t<div\n\t\t\t*ngFor=\"let stream of remoteParticipants | streams\"\n\t\t\tclass=\"OT_root OT_publisher\"\n\t\t\tid=\"remote-participant\"\n\t\t\t[ngClass]=\"{ OV_big: stream.videoEnlarged }\"\n\t\t>\n\t\t\t<ng-container *ngTemplateOutlet=\"streamTemplate; context: { $implicit: stream }\"></ng-container>\n\t\t</div>\n\t</div>\n\n\t<ov-captions *ngIf=\"subtitlesEnabled\" class=\"OV_ignored\"></ov-captions>\n</div>\n", styles: ["#remote-participant,.container{height:100%}.withSubtitles{height:calc(100% - var(--ov-captions-height, 200px))!important}.layout{position:relative;inset:0;min-width:350px!important;min-height:100%;width:inherit;height:-webkit-fill-available;height:-moz-available}/*!\n   * Copyright (c) 2017 TokBox, Inc.\n   * Released under the MIT license\n   * http://opensource.org/licenses/MIT\n   */.OT_root,.OT_root *{color:#fff;margin:0;padding:0;border:0;font-size:100%;vertical-align:baseline}.OT_dialog-centering{display:table;width:100%;height:100%}.OT_dialog-centering-child{display:table-cell;vertical-align:middle}.OT_dialog{position:relative;box-sizing:border-box;margin-right:auto;margin-left:auto;color:#fff;font-family:Ubuntu,sans-serif;font-size:13px;line-height:1.4}.OT_dialog *{font-family:inherit;box-sizing:inherit}.OT_closeButton{color:#999;cursor:pointer;font-size:32px;line-height:36px;position:absolute;right:18px;top:0}.OT_dialog-messages{text-align:center}.OT_dialog-messages-main{margin-bottom:36px;line-height:36px;font-weight:300;font-size:24px}.OT_dialog-messages-minor{margin-bottom:18px;font-size:13px;line-height:18px;color:#a4a4a4}.OT_dialog-messages-minor strong{color:#fff}.OT_dialog-actions-card{display:inline-block}.OT_dialog-button-title{margin-bottom:18px;line-height:18px;font-weight:300;text-align:center;font-size:14px;color:#999}.OT_dialog-button-title label{color:#999}.OT_dialog-button-title a,.OT_dialog-button-title a:link,.OT_dialog-button-title a:active{color:#02a1de}.OT_dialog-button-title strong{color:#fff;font-weight:100;display:block}.OT_dialog-button{display:inline-block;margin-bottom:18px;padding:0 1em;background-color:#1ca3dc;text-align:center;cursor:pointer}.OT_dialog-button:disabled{cursor:not-allowed;opacity:.5}.OT_dialog-button-large{line-height:36px;padding-top:9px;padding-bottom:9px;font-weight:100;font-size:24px}.OT_dialog-button-small{line-height:18px;padding-top:9px;padding-bottom:9px;background-color:#444;color:#999;font-size:16px}.OT_dialog-progress-bar{display:inline-block;width:100%;margin-top:5px;margin-bottom:41px;border:1px solid #4e4e4e;height:8px}.OT_dialog-progress-bar-fill{height:100%;background-color:#29a4da}.OT_dialog-plugin-upgrading .OT_dialog-plugin-upgrade-percentage{line-height:54px;font-size:48px;font-weight:100}.OT_centered{position:fixed;left:50%;top:50%;margin:0}.OT_dialog-hidden{display:none}.OT_dialog-button-block{display:block}.OT_dialog-no-natural-margin{margin-bottom:0}.OT_publisher,.OT_subscriber{position:relative;min-width:0px;min-height:0px;padding:3px;transition-duration:.1s;transition-timing-function:ease-in-out}.OT_publisher .OT_video-element,.OT_subscriber .OT_video-element{display:block;position:absolute;width:100%;height:100%;transform-origin:0 0}.OT_subscriber_error{background-color:#000;color:#fff;text-align:center}.OT_subscriber_error>p{padding:20px}.OT_publisher .OT_bar,.OT_subscriber .OT_bar,.OT_publisher .OT_name,.OT_subscriber .OT_name,.OT_publisher .OT_archiving,.OT_subscriber .OT_archiving,.OT_publisher .OT_archiving-status,.OT_subscriber .OT_archiving-status,.OT_publisher .OT_archiving-light-box,.OT_subscriber .OT_archiving-light-box{-ms-box-sizing:border-box;box-sizing:border-box;top:0;left:0;right:0;display:block;height:34px;position:absolute}.OT_publisher .OT_bar,.OT_subscriber .OT_bar{background:rgba(0,0,0,.4)}.OT_publisher .OT_edge-bar-item,.OT_subscriber .OT_edge-bar-item{z-index:1}.OT_publisher .OT_name,.OT_subscriber .OT_name{background-color:transparent;color:#fff;font-size:15px;line-height:34px;font-weight:400;padding:0 4px 0 36px}.OT_publisher .OT_archiving-status,.OT_subscriber .OT_archiving-status{background:rgba(0,0,0,.4);top:auto;bottom:0;left:34px;padding:0 4px;color:#fffc;font-size:15px;line-height:34px;font-weight:400}.OT_micro .OT_archiving-status,.OT_micro:hover .OT_archiving-status,.OT_mini .OT_archiving-status,.OT_mini:hover .OT_archiving-status{display:none}.OT_publisher .OT_archiving-light-box,.OT_subscriber .OT_archiving-light-box{background:rgba(0,0,0,.4);top:auto;bottom:0;right:auto;width:34px;height:34px}.OT_archiving-light{width:7px;height:7px;border-radius:30px;position:absolute;top:14px;left:14px;background-color:#575757;box-shadow:0 0 5px 1px #575757}.OT_archiving-light.OT_active{background-color:#970d13;animation:OT_pulse 1.3s ease-in;-webkit-animation:OT_pulse 1.3s ease-in;-moz-animation:OT_pulse 1.3s ease-in;-webkit-animation:OT_pulse 1.3s ease-in;animation-iteration-count:infinite;-moz-animation-iteration-count:infinite;-webkit-animation-iteration-count:infinite}.OT_mini .OT_bar,.OT_bar.OT_mode-mini,.OT_bar.OT_mode-mini-auto{bottom:0;height:auto}.OT_mini .OT_name.OT_mode-off,.OT_mini .OT_name.OT_mode-on,.OT_mini .OT_name.OT_mode-auto,.OT_mini:hover .OT_name.OT_mode-auto{display:none}.OT_publisher .OT_name,.OT_subscriber .OT_name{left:10px;right:37px;height:34px;padding-left:0}.OT_publisher .OT_mute,.OT_subscriber .OT_mute{border:none;cursor:pointer;display:block;position:absolute;text-align:center;text-indent:-9999em;background-color:transparent;background-repeat:no-repeat}.OT_publisher .OT_mute,.OT_subscriber .OT_mute{right:0;top:0;border-left:1px solid rgba(255,255,255,.2);height:36px;width:37px}.OT_mini .OT_mute,.OT_publisher.OT_mini .OT_mute.OT_mode-auto.OT_mode-on-hold,.OT_subscriber.OT_mini .OT_mute.OT_mode-auto.OT_mode-on-hold{top:50%;left:50%;right:auto;margin-top:-18px;margin-left:-18.5px;border-left:none}.OT_publisher .OT_mute{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAcCAMAAAC02HQrAAAA1VBMVEUAAAD3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pn3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pn3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj39/j3+Pj3+Pn4+Pk/JRMlAAAAQ3RSTlMABAUHCQoLDhAQERwdHiAjLjAxOD9ASFBRVl1mbnZ6fH2LjI+QkaWqrrC1uLzAwcXJycrL1NXj5Ofo6u3w9fr7/P3+d4M3+QAAAQBJREFUGBlVwYdCglAABdCLlr5Unijm3hMUtBzlBLSr//9JgUToOQgVJgceJgU8aHgMeA38K50ZOpcQmTPwcyXn+JM8M3JJIqQypiIkeXelTyIkGZPwKS1NMia1lgKTVkaE3oQQGYsmHNqSMWnTgUFbMiZtGlD2dpaxrL1XgM0i4ZK8MeAmFhsAs29MGZniawagS63oMOQUNXYB5D0D1RMDpyoMLw/fiE2og/V+PVDR5AiBl0/2Uwik+vx4xV3a5G5Ye68Nd1czjUjZckm6VhmPciRzeCZICjwTJAViQq+3e+St167rAoHK8sLYZVkBYPCZAZ/eGa+2R5LH7Wrc0YFf/O9J3yBDFaoAAAAASUVORK5CYII=);background-position:9px 5px}.OT_publisher .OT_mute.OT_active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAdCAYAAABFRCf7AAADcElEQVRIiaWVXWhcRRTHf7NNd2aDtUKMIjTpg4ufFIuiUOmDEWm0Vi3VYhXRqIggQh4sWJFSig9+oOhTKSpIRUWMIBIr2kptoTbgU6ooxCiIjR+14kcJmf9sNceHnd3ebnc3Uv9wuXfOzPzmnDMz5zozGwdWAbc65w5RUJQ8cC2wDJgFJioh/MJCMrNxq2vOzK4HmIvRRemxKP0RJWt53o7S+d2Yzsx6gQ+AIUDAnUqpBLzXZd4RYFUlhB/bdZacc3PAOmAcCMC7wfvFwLNdoAPAyx09bXyYWRl4E7gDmAdGlNKFwLYu8GolhO9O87RJd64GbMrgEvB68P4osMWdXLtVV7czlooNpVRWSs8DO7NpR/B+3rBHsvetCgtCMTxwQCm9BbyQrc8F7/uBex3uRCeXO0PrUZ4NfKyUPgWeyj3bg/crDNsIRGwBaJQGorQ3Svdn2wHgc2BUKb0DPJHtjwfvbwRucc7tz+N+i9LFUdoXpfVN36I0CVwBTFI/q9e1LPxT8P4qYEdu70q12mYzWw1MYQzjeJF6zq+shHC4B7jklOBPP/TzSunh4P0DwKvAfb5c9krpe+CcwsEoZdbhEvBM9wxRAl5RShcA9wAngE3B+8tLpdLuwrhp4MNmK0pfRWkySr7NXS8+L5nZbWZWy/Vin1IaitJnUTqvwevJ71lgSSWEFKUfHG7Q2m/xqFJaGry/GXgfGPLl8mJgrXPur2JoUC8Qy3OpG+sAbGhEKT0ErAWOA6uBPWbW1wr9BOgFbgKezot0kAPYqJQA1gC/A9cA+82svzksSn1R+jNKX0SpnM/e1x3yqig92JhrZivM7FjO8bSZLSuCR/Ok16K0KMNHojQWpYko7Y7S1igN5PE3ROl4lNaZ2UVmNpPBU01orvZvZPCeKFXbBR+lEKVtUapFaSZKg9njqpl9aWYTrmXCImA7sCWb9lK/jj9TrwkrgA1AH3AQuKsSwkzbrLfxpgpsBtYDxf/R3xm2ExirhNCuHHZXTsmRwiat+S/zSt06eysVA/4pmGr/G3qm6ik28v29FKgCg8BS6pvS0KNRGgZ+Bb4FpsxsOkfUlMuwDcBWYOUZOHYM2AU8WQmhBifDv70O7PjX7KZ+4G7g3FM8zd6uBIaBy4AqxnIcZwFLCovPAhE4Sj38b4BDwEeVEFKD9S94Khjn486v3QAAAABJRU5ErkJggg==);background-position:9px 4px}.OT_subscriber .OT_mute{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAATCAYAAAB7u5a2AAABx0lEQVQ4jaWUv48NURiGn3ONmCs32ZBd28ht1gqyZAkF21ylQkEiSp2ehpDlD1BoFGqqVdJohYKI7MaPxMoVNghCWMF+7ybLUewnOXfcMWO9yeQ857zne8+XmZOBGjJpr0kvTIomvTZpS526UCO4DUwD64FjwCFgqZnnR+oc8LfgzKQ73vGsr42ZtGjSQFV9o8KfBCacZwCaef4YmAf2rzjcpN3A2WSpm/AssKcqPDNpDBjs410CViXzTwk/A7b1C4wxDgOngAsZcAXY2buDfp/6S4F3lDS8DjgBzDWAjX/Y/e/QgYS/AhsKHa+OMQ6GEJ4Cj4BOAxgq6aCowyZtdf4OtAr+FHDO+R4wWnVbihr3cQnICt4boO38GWj9a/icjwOACt4m4K3zEPA+AxaAtTWCnwN3lzHkEL8V/OPAGud9wK2GF9XR1Wae/1zG2AI+pGYI4VUIoRtjHAc2A9cz4LRPevYCZ+i9/4sJt4GXJU10gaPAzdI2TTro/5Tfz8XEe2LSZGmxq/SDNvP8BnA5WRrx4BwYBe6vONx1EnjovGvBLAAd4Adwuyq8UiaNmDTvr+a8SQ9MuvbfwckBHZPe+QEfTdpep+4XZmPBHiHgz74AAAAASUVORK5CYII=);background-position:8px 7px}.OT_subscriber .OT_mute.OT_active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAUCAYAAACXtf2DAAACtklEQVQ4jZ2VSYiURxTHf+/T9Nc9iRrBuYySmIsXUU9iFMEFERRBvAjJLUQi5ioiHvSScfTmgqC4XAT1ZIgLuJHkICaaQAgKI2hAUBT30bjUq7bbv4eukXK029F3+eqtv/fqK6qQdEnSNUmT6CDB/bvgfjO4N9zj2RD8007xg1IABkwEzkma0qb4PGAPMBZYLtSD8eNwAEjqTlNI0gNJM4YU7w7ut4O7gvuhZFsR3C8NC5BBLiTIY0mzM8AvqbiC++pk+zLpE95XuwAws3vAQuBPYDRwWtL84P4tsDSLv5oaug4EYOawAMF9jMdoLxqNZcDvQA04UVYqL4G/svj7AF21mhJscrvCksYBFO7xc2AAGGg2mrdjvf4rcAyomNn+slLZmUEGBgsYdh945xZJmgvckDSrEJpK6ySBgV6q12O8ABwGPjGzfWWlsjdN9rpjoSfA+DYDXARGAksK4Is3XC1Ub4z1f4CDQGFmu6tleQSYk0U+p7WVeefLJc00s4fAeWB6Qeunvj0m2ugx9gO7kmlrtSxvBfcy6fXUZS6rgG/S+jLQUwCVNmMC9HqM14EtSe+rluWazN8YEv8IqKZ1E1qnaIDO0ucx3gX6kv6TpM3AM+D/IbGjgP60/gq4WQA33gMA2OQxPgHWJX1ttSwL4FAeZGYLgB2SasBs4A8L7qOBf9M0uXQB3a+TMYSmVctyDrA9mfcBK82smSdKWgCcAaa1bTm4fxbc/8uuCQX3RanAD5Ka6Wo5IGnE0HxJPZ03pQX5Org3MsD3AO5xXLPZXJ9BjkrqdFg6QjZkgG3Jtsw93pG0VFI9QU5K6voYQBHcTydAfwheBI9HgvvPAJIWS3qeIL9JGvUxkO7gfi1BrqTvwkG/pPmSnibIqTzXPgAyEVgBjAEu1qrVPbk/PVTHgb/NbPGg/RVIzOQqzSTBaQAAAABJRU5ErkJggg==);background-position:7px 7px}.OT_publisher .OT_edge-bar-item,.OT_subscriber .OT_edge-bar-item{transition-property:top,bottom,opacity;transition-duration:.5s;transition-timing-function:ease-in}.OT_publisher .OT_edge-bar-item.OT_mode-off,.OT_subscriber .OT_edge-bar-item.OT_mode-off,.OT_publisher .OT_edge-bar-item.OT_mode-auto,.OT_subscriber .OT_edge-bar-item.OT_mode-auto,.OT_publisher .OT_edge-bar-item.OT_mode-mini-auto,.OT_subscriber .OT_edge-bar-item.OT_mode-mini-auto{top:-25px;opacity:0}.OT_publisher .OT_edge-bar-item.OT_mode-off,.OT_subscriber .OT_edge-bar-item.OT_mode-off{display:none}.OT_mini .OT_mute.OT_mode-auto,.OT_publisher .OT_mute.OT_mode-mini-auto,.OT_subscriber .OT_mute.OT_mode-mini-auto{top:50%}.OT_publisher .OT_edge-bar-item.OT_edge-bottom.OT_mode-off,.OT_subscriber .OT_edge-bar-item.OT_edge-bottom.OT_mode-off,.OT_publisher .OT_edge-bar-item.OT_edge-bottom.OT_mode-auto,.OT_subscriber .OT_edge-bar-item.OT_edge-bottom.OT_mode-auto,.OT_publisher .OT_edge-bar-item.OT_edge-bottom.OT_mode-mini-auto,.OT_subscriber .OT_edge-bar-item.OT_edge-bottom.OT_mode-mini-auto{top:auto;bottom:-25px}.OT_publisher .OT_edge-bar-item.OT_mode-on,.OT_subscriber .OT_edge-bar-item.OT_mode-on,.OT_publisher .OT_edge-bar-item.OT_mode-auto.OT_mode-on-hold,.OT_subscriber .OT_edge-bar-item.OT_mode-auto.OT_mode-on-hold,.OT_publisher:hover .OT_edge-bar-item.OT_mode-auto,.OT_subscriber:hover .OT_edge-bar-item.OT_mode-auto,.OT_publisher:hover .OT_edge-bar-item.OT_mode-mini-auto,.OT_subscriber:hover .OT_edge-bar-item.OT_mode-mini-auto{top:0;opacity:1}.OT_mini .OT_mute.OT_mode-on,.OT_mini:hover .OT_mute.OT_mode-auto,.OT_mute.OT_mode-mini,.OT_root:hover .OT_mute.OT_mode-mini-auto{top:50%}.OT_publisher .OT_edge-bar-item.OT_edge-bottom.OT_mode-on,.OT_subscriber .OT_edge-bar-item.OT_edge-bottom.OT_mode-on,.OT_publisher:hover .OT_edge-bar-item.OT_edge-bottom.OT_mode-auto,.OT_subscriber:hover .OT_edge-bar-item.OT_edge-bottom.OT_mode-auto{top:auto;bottom:0;opacity:1}.OT_root .OT_video-loading{position:absolute;z-index:1;width:100%;height:100%;display:none;background-color:#000000bf}.OT_root .OT_video-loading .OT_video-loading-spinner{background:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9Ii0yMCAtMjAgMjQwIDI0MCI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJhIiB4Mj0iMCIgeTI9IjEiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIwIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9IjAiLz48L2xpbmVhckdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0iYiIgeDE9IjEiIHgyPSIwIiB5Mj0iMSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9IjAiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNmZmYiIHN0b3Atb3BhY2l0eT0iLjA4Ii8+PC9saW5lYXJHcmFkaWVudD48bGluZWFyR3JhZGllbnQgaWQ9ImMiIHgxPSIxIiB4Mj0iMCIgeTE9IjEiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuMDgiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNmZmYiIHN0b3Atb3BhY2l0eT0iLjE2Ii8+PC9saW5lYXJHcmFkaWVudD48bGluZWFyR3JhZGllbnQgaWQ9ImQiIHgyPSIwIiB5MT0iMSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9Ii4xNiIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuMzMiLz48L2xpbmVhckdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0iZSIgeDI9IjEiIHkxPSIxIj48c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiNmZmYiIHN0b3Atb3BhY2l0eT0iLjMzIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9Ii42NiIvPjwvbGluZWFyR3JhZGllbnQ+PGxpbmVhckdyYWRpZW50IGlkPSJmIiB4Mj0iMSIgeTI9IjEiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuNjYiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNmZmYiLz48L2xpbmVhckdyYWRpZW50PjxtYXNrIGlkPSJnIj48ZyBmaWxsPSJub25lIiBzdHJva2Utd2lkdGg9IjQwIj48cGF0aCBzdHJva2U9InVybCgjYSkiIGQ9Ik04Ni42LTUwYTEwMCAxMDAgMCAwIDEgMCAxMDAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEwMCAxMDApIi8+PHBhdGggc3Ryb2tlPSJ1cmwoI2IpIiBkPSJNODYuNiA1MEExMDAgMTAwIDAgMCAxIDAgMTAwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDAgMTAwKSIvPjxwYXRoIHN0cm9rZT0idXJsKCNjKSIgZD0iTTAgMTAwYTEwMCAxMDAgMCAwIDEtODYuNi01MCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTAwIDEwMCkiLz48cGF0aCBzdHJva2U9InVybCgjZCkiIGQ9Ik0tODYuNiA1MGExMDAgMTAwIDAgMCAxIDAtMTAwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDAgMTAwKSIvPjxwYXRoIHN0cm9rZT0idXJsKCNlKSIgZD0iTS04Ni42LTUwQTEwMCAxMDAgMCAwIDEgMC0xMDAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEwMCAxMDApIi8+PHBhdGggc3Ryb2tlPSJ1cmwoI2YpIiBkPSJNMC0xMDBhMTAwIDEwMCAwIDAgMSA4Ni42IDUwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDAgMTAwKSIvPjwvZz48L21hc2s+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIHg9Ii0yMCIgeT0iLTIwIiBtYXNrPSJ1cmwoI2cpIiBmaWxsPSIjZmZmIi8+PC9zdmc+) no-repeat;position:absolute;width:32px;height:32px;left:50%;top:50%;margin-left:-16px;margin-top:-16px;animation:OT_spin 2s linear infinite}@keyframes OT_spin{to{transform:rotate(360deg)}}.OT_publisher.OT_loading .OT_video-loading,.OT_subscriber.OT_loading .OT_video-loading{display:block}.OT_video-centering{display:table;width:100%;height:100%}.OT_video-container{display:table-cell;vertical-align:middle}.OT_video-poster{position:absolute;z-index:1;width:100%;height:100%;display:none;opacity:.25;background-repeat:no-repeat;background-image:url(data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgNDcxIDQ2NCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48bGluZWFyR3JhZGllbnQgaWQ9ImEiIHgyPSIwIiB5Mj0iMSI+PHN0b3Agb2Zmc2V0PSI2Ni42NiUiIHN0b3AtY29sb3I9IiNmZmYiLz48c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNmZmYiIHN0b3Atb3BhY2l0eT0iMCIvPjwvbGluZWFyR3JhZGllbnQ+PHBhdGggZmlsbD0idXJsKCNhKSIgZD0iTTc5IDMwOGMxNC4yNS02LjUgNTQuMjUtMTkuNzUgNzEtMjkgOS0zLjI1IDI1LTIxIDI1LTIxczMuNzUtMTMgMy0yMmMtMS43NS02Ljc1LTE1LTQzLTE1LTQzLTIuNSAzLTQuNzQxIDMuMjU5LTcgMS0zLjI1LTcuNS0yMC41LTQ0LjUtMTYtNTcgMS4yNS03LjUgMTAtNiAxMC02LTExLjI1LTMzLjc1LTgtNjctOC02N3MuMDczLTcuMzQ2IDYtMTVjLTMuNDguNjM3LTkgNC05IDQgMi41NjMtMTEuNzI3IDE1LTIxIDE1LTIxIC4xNDgtLjMxMi0xLjMyMS0xLjQ1NC0xMCAxIDEuNS0yLjc4IDE2LjY3NS04LjY1NCAzMC0xMSAzLjc4Ny05LjM2MSAxMi43ODItMTcuMzk4IDIyLTIyLTIuMzY1IDMuMTMzLTMgNi0zIDZzMTUuNjQ3LTguMDg4IDQxLTZjLTE5Ljc1IDItMjQgNi0yNCA2czc0LjUtMTAuNzUgMTA0IDM3YzcuNSA5LjUgMjQuNzUgNTUuNzUgMTAgODkgMy43NS0xLjUgNC41LTQuNSA5IDEgLjI1IDE0Ljc1LTExLjUgNjMtMTkgNjItMi43NSAxLTQtMy00LTMtMTAuNzUgMjkuNS0xNCAzOC0xNCAzOC0yIDQuMjUtMy43NSAxOC41LTEgMjIgMS4yNSA0LjUgMjMgMjMgMjMgMjNsMTI3IDUzYzM3IDM1IDIzIDEzNSAyMyAxMzVMMCA0NjRzLTMtOTYuNzUgMTQtMTIwYzUuMjUtNi4yNSAyMS43NS0xOS43NSA2NS0zNnoiLz48L3N2Zz4=);background-size:auto 76%}.OT_fit-mode-cover .OT_video-element{object-fit:cover}@media only screen and (orientation: portrait){.OT_subscriber.OT_ForceContain.OT_fit-mode-cover .OT_video-element{object-fit:contain!important}}.OT_fit-mode-contain .OT_video-element{object-fit:contain}.OT_fit-mode-cover .OT_video-poster{background-position:center bottom}.OT_fit-mode-contain .OT_video-poster{background-position:center}.OT_audio-level-meter{position:absolute;width:25%;max-width:224px;min-width:21px;top:0;right:0;overflow:hidden}.OT_audio-level-meter:before{content:\"\";display:block;padding-top:100%}.OT_audio-level-meter__bar{position:absolute;width:192%;height:192%;top:-96%;right:-96%;border-radius:50%;background-color:#000c}.OT_audio-level-meter__audio-only-img{position:absolute;top:22%;right:15%;width:40%;opacity:.7;background:url(data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgNzkgODYiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgZmlsbD0iI2ZmZiI+PHBhdGggZD0iTTkuNzU3IDQwLjkyNGMzLjczOC01LjE5MSAxMi43MTEtNC4zMDggMTIuNzExLTQuMzA4IDIuMjIzIDMuMDE0IDUuMTI2IDI0LjU4NiAzLjYyNCAyOC43MTgtMS40MDEgMS4zMDEtMTEuNjExIDEuNjI5LTEzLjM4LTEuNDM2LTEuMjI2LTguODA0LTIuOTU1LTIyLjk3NS0yLjk1NS0yMi45NzV6bTU4Ljc4NSAwYy0zLjczNy01LjE5MS0xMi43MTEtNC4zMDgtMTIuNzExLTQuMzA4LTIuMjIzIDMuMDE0LTUuMTI2IDI0LjU4Ni0zLjYyNCAyOC43MTggMS40MDEgMS4zMDEgMTEuNjExIDEuNjI5IDEzLjM4LTEuNDM2IDEuMjI2LTguODA0IDIuOTU1LTIyLjk3NSAyLjk1NS0yMi45NzV6Ii8+PHBhdGggZD0iTTY4LjY0NyA1OC42Yy43MjktNC43NTMgMi4zOC05LjU2MSAyLjM4LTE0LjgwNCAwLTIxLjQxMi0xNC4xMTUtMzguNzctMzEuNTI4LTM4Ljc3LTE3LjQxMiAwLTMxLjUyNyAxNy4zNTgtMzEuNTI3IDM4Ljc3IDAgNC41NDEuNTE1IDguOTM2IDEuODAyIDEyLjk1IDEuNjk4IDUuMjk1LTUuNTQyIDYuOTkxLTYuNjE2IDIuMDczQzIuNDEgNTUuMzk0IDAgNTEuNzg3IDAgNDguMTAzIDAgMjEuNTM2IDE3LjY4NSAwIDM5LjUgMCA2MS4zMTYgMCA3OSAyMS41MzYgNzkgNDguMTAzYzAgLjcxOC0yLjg5OSA5LjY5My0zLjI5MiAxMS40MDgtLjc1NCAzLjI5My03Ljc1MSAzLjU4OS03LjA2MS0uOTEyeiIvPjxwYXRoIGQ9Ik01LjA4NCA1MS4zODVjLS44MDQtMy43ODIuNTY5LTcuMzM1IDMuMTM0LTcuOTIxIDIuNjM2LS42MDMgNS40ODUgMi4xNSA2LjI4OSA2LjEzMi43OTcgMy45NDgtLjc1MiA3LjQ1Ny0zLjM4OCA3Ljg1OS0yLjU2Ni4zOTEtNS4yMzctMi4zMTgtNi4wMzQtNi4wN3ptNjguODM0IDBjLjgwNC0zLjc4Mi0uNTY4LTcuMzM1LTMuMTMzLTcuOTIxLTIuNjM2LS42MDMtNS40ODUgMi4xNS02LjI4OSA2LjEzMi0uNzk3IDMuOTQ4Ljc1MiA3LjQ1NyAzLjM4OSA3Ljg1OSAyLjU2NS4zOTEgNS4yMzctMi4zMTggNi4wMzQtNi4wN3ptLTIuMDM4IDguMjg4Yy0uOTI2IDE5LjY1OS0xNS4xMTIgMjQuNzU5LTI1Ljg1OSAyMC40NzUtNS40MDUtLjYwNi0zLjAzNCAxLjI2Mi0zLjAzNCAxLjI2MiAxMy42NjEgMy41NjIgMjYuMTY4IDMuNDk3IDMxLjI3My0yMC41NDktLjU4NS00LjUxMS0yLjM3OS0xLjE4Ny0yLjM3OS0xLjE4N3oiLz48cGF0aCBkPSJNNDEuNjYyIDc4LjQyMmw3LjU1My41NWMxLjE5Mi4xMDcgMi4xMiAxLjE1MyAyLjA3MiAyLjMzNWwtLjEwOSAyLjczOGMtLjA0NyAxLjE4Mi0xLjA1MSAyLjA1NC0yLjI0MyAxLjk0NmwtNy41NTMtLjU1Yy0xLjE5MS0uMTA3LTIuMTE5LTEuMTUzLTIuMDcyLTIuMzM1bC4xMDktMi43MzdjLjA0Ny0xLjE4MiAxLjA1Mi0yLjA1NCAyLjI0My0xLjk0N3oiLz48L2c+PC9zdmc+) no-repeat center}.OT_audio-level-meter__audio-only-img:before{content:\"\";display:block;padding-top:100%}.OT_audio-level-meter__value{position:absolute;border-radius:50%;background-image:radial-gradient(circle,rgba(151,206,0,1) 0%,rgba(151,206,0,0) 100%)}.OT_audio-level-meter.OT_mode-off{display:none}.OT_audio-level-meter.OT_mode-on,.OT_audio-only .OT_audio-level-meter.OT_mode-auto{display:block}.OT_audio-only.OT_publisher .OT_video-element,.OT_audio-only.OT_subscriber .OT_video-element{display:none}.OT_video-disabled-indicator{opacity:1;border:none;display:none;position:absolute;background-color:transparent;background-repeat:no-repeat;background-position:bottom right;pointer-events:none;inset:0 3px 3px 0}.OT_video-disabled{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAoCAYAAABtla08AAAINUlEQVR42u2aaUxUVxTHcRBmAAEBRVTK4sKwDIsg+wCK7CqIw1CN1YobbbS2qYlJ06Qx1UpdqMbYWq2pSzWmH6ytNbXWJY1Lq7VuqBERtW64V0XFLYae0/xvcp3MMAMzDz6IyT/ge2ce5/7ucpY3Ts3NzZ1ygF57AJ0gO0G2jyZPmdbFyclJSAV1EeoEaUUSLGdSV5KLLFxzFmA7QVqGqDqjixhWkxCVeyRVl38wM6bwj6yYItYK47BAuu9B0gCqs6Ng2r494KQtkj/Dz2jHraw6qw2fdSE4rNmcCPCvZONP8iF1I6kdBdMaQJWZLeJqRWa2kPJAxXY+GxE+zxLI03GRh8lGSwoi9WCY8FWlCEh+8JOnT7MfPGjMuXX7Tt61hoaCi/9cKmKdv3BxeEtim/UbNpnbQiqF4MmT7kqrbr4lkMcTo46TTSpJB5g+8NHuVWnWuaampvhmO/7duHmrGluoO4C6OsJZGRrkDIld43ZqUOTnlkDSmXmabAoBU0vqBf+6KgFSxQ9++uzZ8rZApM81TJ8xM5me0Z/UF7PuBmdVdkGEb5gYDeQmyZNW3SJLIP9Kj64lGyMpmxRN6sOfIbkoAhKOdnv2/PmB1kB88eLFo+olyyrps3rSINIAzLonnqlqK8R9w+L86vtrt5L2nhug3Vc3ULu/Liz8AOuXESlZZONH6kmr7gtLIA9lRNeRzVukAvj3BslLnJNKgfScO69K+/Lly0ZbQW7e8tNK+pwBjqaSIjDrXgJkW1ciAZvbQjQ+RDahpBBKd5ZZsqN758hmImk4KQHnpDd8UwSkCyJarx07d4+3BeKJmlMHyX4qaRxpBCmNFE4KENvHDpAutVERn1kCVBMfeRRgYvZnx62wZPdnZkw92VQA5GClQXYRBze2S+iJmpPVVoJLA9l9QKokjcWKTCT1R5rhLg70NuSsziT16diIKkuAjibrTpJNDkn/e17CahtAjlAWJAYkb29Sb1LE9Rs391kILk8mVkyuIpuZcLKUlEmKkra1WuSTNuesEPzwoEploSVAh9Oiz+BIyd9dOHhtx4OEpFpVg6gbNK3yXX1j48N6U5Dz5i/gc/FDrMY3sTLiSMEkXxGxzUEUAGnbxlPaksMlHUXWAlHS8URCPseSohZbCSLjSSU7ixLXdzhIWVKq4Y7t2a/2bN0qGeKly1fYsVmk6RgIDz4J0bonyUOcjeYqm/8hRoYbWkigV2NH9CHAS60EkUkkw47hSRs6FqT1LR5AVcsrueXlK1d5AO+RpmBrZZEiefByytPCanRGNLZY0uF52gNDYr9sCRB8MHY0SJu2OJWKS2WQV65e4y31DmkCImEi0hBfufRime0RIhpbKen0/Ny9OYNW2ghyYytABjNIaxNuKttAWk6HPLn0k0FevdZwFinPWFIuKZbUV16NVko6jbWSDoPO3pOf8K0jQWLSQ0S9bdpkYck+m7vfWpAiHfKgBsZiGSSt0FqcTeU8WETqAHE2CgcAVd3Gkm4MD3xXYeI6B4NMItvKbcUpQ9gP+KMWnSsW+TaYJtoo+avBWLoKoK0CCSDud+7eXWQGZAXqV3YoQjQCfixJ8+fzj9ta3JHhlUeJ8wJOY2ws6eRKpPS3oqTvHAESEz9ya0naXL5WH6pt3FqSOhTHkTcKEXc6k1POh4Q9YJu/03TT4a8PoGMFI4i2EqSbOZAYaBkpCyD92RkG6KCSbjI/H0HEISBnlOZPFdcEzI2GTO4KBZICGKyAKLTEmJOB2txf5MbgohBINCl4FTqmpJMB2W+HiRn1Q2l6lXyPmiEP6VVE2TfGoaMYrHyPdtAnyI0jEOn9RLWmNEhvBBE7SjpFQZaShtLK+1S+T12lRwxUvrZlVPp8jE1PikeO7C/nyEqBDCB1t7+kUx4kKUWclea0yZC5BIGpiJSNSD9QgFR0RQKkL6KxHSWdsiARHJNYewoGrzG1/bk4dTPSunL2EyDjcbb7MQ+lQfZmkKiN7SjpFAM5CWAyGcwyY84YsZ1lUcbRNNtQMAdtQWGvQ0DyVjzYAKQfQFodeAeC1C8vzymXIZqD+ZEh/2OyLSalS/3VbnJZ+VqDXGjMrTCFuK4s66vVZUNfqaDolcbjOcb899sLpEE+I20GifywXe2QR3KElu99PzqjGufhREqB1pjCnG3IL3fY1v733r2FMsiGhutn0LAoJWWIGbPxjKwgjUbF0m52mPhigrpdXOecEq9pR6MkHbu2LOtrcZ9y3d0ODTb15y9MePz48aF79+8fvXnr9sljx2u2I7KNxDuaMPGVECoRs7mC4eT7SIruFNfNHK15MKuM2evwNq+4qjxvGnd5CHwNNynawW4cOlUZdG8b55IIJHmkItwrZHH6QxB3OSL9kTtAGpIvZiQB3Z4SKBfXQtEE9sashWAW87Bt3sYZNR6zn4uzJwWDKUKXfaKCdqUoBpLxSjYe9nqGiwWRBGipuGZ3Qm76itYLbbJI/PEhUApfw73uOIy9xfse3M9F9BuFJHcYrseSouGkHtCVtkuGTTikI8XgZzhg9SeF4VqcvSWiaSvNHQ8JwkNjIfEHemCmNLD1RaEfLs18mlgNuN6PFALHo7CyU5W2g00gFAQF4ozvibH04muwDbWraSFAyt/AAMzewgGR8uCeWn77xzBxPxgzPRCDDMZ14bQ/3jqGKGoHf2Hjgx3kw5LbaJDYWb52t9FMgw4AuWNWukNeuOYqOsmQi2jgws4PA/DD/z0B2x0/veCs4naw0cgybezid7X9jV3rX2RSs0wfLkll4pBGcgifg+NYxe1kJ2ycTaRq66uG/wBOl0vjcw70xwAAAABJRU5ErkJggg==);background-size:33px auto}.OT_video-disabled-warning{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAoCAYAAABtla08AAAGMElEQVR4Ae2aA7D0yBaAc7oH12vbRmlLaxYWb23btm3btm2899a2bWuYtPZ01cmtU9lJrib315yqr9I3Oem/5/s7acwEnehEJzoxCcX2O+wEeIgRBDDaGjAZOgQ6ihRpLklHZDJIXK1WWymMIhGGkVBKCWMM+Iv/f/b5t7faYtM/sGgIS7j8RNLjceUVl41GvGN1BFiHy9sgtRWaYbhvuVQ6o1VOvV5/tLe3dyssKoZuh8xClkDEi2MMS6ZjR0cScxdK/+HgnJsmLccYOx0e/PUGUqfTJDEHkV5go9lcMQoj4R8RpSIRRUr4a9baTJFCCNfqESKJ7RYJibK0xoi05EhFRTxMi1Rit6xHAuLaKRLwEVi6q1x+EhlVpd3d3Wfh4VQkQhRhxthYLg7SRGqdLlIp7UVOHf+JhEhEMscUolVje3p63saeeOFoKsT7fjj++BNuw2I/0ouUENmGaQcQEilQvUU6xuWC0kqmVWCt8df6kG7WLoFA20VSCOyNh0RKPT+SyrTWtQsvuvTYCy84z3+oAdbgAiLGIvHjTz6bFuu/B3lKKfVkFKknwih6EnnipZdfXQZzepAupXSGSCfwUGZtkrx3t/0dSQGnnXbmdocdetArQoj+4VR23wMP3bj/vnv9Sv/rBmkish09ca655thHSrlWq4TFF1vkNDxsgjiUnPqZnHPABIq47jx7pPMcecShfz7x1DO7D6eit99576X1113nVd8rqLGAuDaNitJonTGIqHgQGQjDsJglMrUH5iDSEQbRa6y2yrNvv/PuWVmV/PTzLz8steTit1B9FtGJeZrJksmWdBzBMcami4xUkaY1A1Qe94WIaPGBApJhaERrLrXkElf8+NPPz6YMLs1DDjn0Wn9PnI/UiQadM4jNEkhzVsEGE8nIHESM1j5/KqRX+/IEiOQ/yifNBlEkpnb00cccesbpp13T3983H88/48xzrrvm6it/8U5JXgX5G6nSvSq1R5LATR7aYGkwMG1RSwkWABH+4jUb3vT/uJ1Z0xpjraTBRltrxUQhksIRmgTJyy69+Pv99tv3qYX6FxgU+fU33352xGEHf5wisU7nNWJpZRMkAjZ6aIN1mwV7h29Jo2wCHlveu/GV169z65E+T6koexCh6c+EEiky3lnxQKFjUeVyOeI5AOBzIiayRhJryd7YYnkIHgvB0qk9Tdql6N3XH4bRUIOIIIKJSiRb0hkSEpZKRd1CpEq8GxtIyCVmDSgFl94GacTgaJw1rUlYhYng0c4ewaUsmKRIJjpiqMSOCh9QeI+UYECmtQIsxEu6OorEcv6Rl0gu0woh8MhFkmSCTXVI4pC704WCFRJvSRNJSzrMMEZO2iKZTCHAZYnmvXCny7ed5vfZK3viHSBdIFCKEFj2+nt+73nw8m2uedcLJlktA++VNMEPaR45aYukcKnnCfY3/DFbZS8t7eHxNgsPM0N1hXhJJwwM1QbpoQFlog2R13a/zBxEYHAQEUYUM6qiVwEyBYoM6JFNF2kFLelI5KQf+fVI4dJFCguDS7oAyx2R6SFQJKRedSDj/cMg/RXQ6ZE05GSIDAaXdCi1I3L021SQWNJ1RLY5OiIdL4/yvuw8ADfWPFrSciaMyH8tEQPwf1uGG54g5+KlJGTmsrxsQdl5PKidnPFe2QS///7Hu+VS6WX/HYnf0sevGL7lXydwod2/9DykZq0s5yff0sgSWCigNOH7TPHL7ufj+/TH8P/+qYpL4HkBDiRYpEXeM8/89/9zzjn7EtY64dfd1nqccM7Bs8+9MKy8555/8TnKS+5MufH6EZVASkgPzf+mJXroet17JirU0ALST3nT0y5ONyLpeo1y64ih+vuQfsoTOeRFSJXa+SvyB90TUmdw49EjLaKpMQ0mzEeTzkWsd/oI6fzfiKM8gWg6X6OjpXstu5ZHnmIb0GFiu29MIUfUewkmVrEN3RqVQ/bY8FzNcquMBv/pCNUZ5pHHem01KdN/I/DG66/lLhKSvTO5M84kav5C5z2ZfyAivi9i9VGd45RH7UWJbjwGG/7NYsRECt7jiOToHedKAui8SW4CsxyRc54mKH/8f7ELhCCACyNcIl/wI+FaAJyc8yzRtinQPzWzuFZrFHq/AAAAAElFTkSuQmCC);background-size:33px auto}.OT_video-disabled-indicator.OT_active{display:block}.OT_audio-blocked-indicator{opacity:1;border:none;display:none;position:absolute;background-color:transparent;background-repeat:no-repeat;background-position:center;pointer-events:none;inset:0}.OT_audio-blocked{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMTUwIiBoZWlnaHQ9IjkwIj48ZGVmcz48cGF0aCBkPSJNNjcgMTJMNi40NDggNzIuNTUyIDAgMzFWMThMMjYgMGw0MSAxMnptMyA3bDYgNDctMjkgMTgtMzUuNTAyLTYuNDk4TDcwIDE5eiIgaWQ9ImEiLz48L2RlZnM+PHJlY3Qgd2lkdGg9IjE1MCIgaGVpZ2h0PSI5MCIgcng9IjM1IiByeT0iNDUiIG9wYWNpdHk9Ii41Ii8+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzNikiPjxtYXNrIGlkPSJiIiBmaWxsPSIjZmZmIj48dXNlIHhsaW5rOmhyZWY9IiNhIi8+PC9tYXNrPjxwYXRoIGQ9Ik0zOS4yNDkgNTEuMzEyYy42OTcgMTAuMzcgMi43ODUgMTcuODk3IDUuMjUxIDE3Ljg5NyAzLjAzOCAwIDUuNS0xMS40MTcgNS41LTI1LjVzLTIuNDYyLTI1LjUtNS41LTI1LjVjLTIuNTEgMC00LjYyOCA3Ljc5Ny01LjI4NyAxOC40NTNBOC45ODkgOC45ODkgMCAwIDEgNDMgNDRhOC45ODggOC45ODggMCAwIDEtMy43NTEgNy4zMTJ6TTIwLjk4NSAzMi4yMjRsMTUuNzQ2LTE2Ljg3N2E3LjM4NSA3LjM4NSAwIDAgMSAxMC4zNzQtLjQyQzUxLjcwMiAxOS4xMTQgNTQgMjkuMjA4IDU0IDQ1LjIwOGMwIDE0LjUyNy0yLjM0MyAyMy44OC03LjAzIDI4LjA1OGE3LjI4IDcuMjggMCAwIDEtMTAuMTY4LS40NjhMMjAuNDA1IDU1LjIyNEgxMmE1IDUgMCAwIDEtNS01di0xM2E1IDUgMCAwIDEgNS01aDguOTg1eiIgZmlsbD0iI0ZGRiIgbWFzaz0idXJsKCNiKSIvPjwvZz48cGF0aCBkPSJNMTA2LjUgMTMuNUw0NC45OTggNzUuMDAyIiBzdHJva2U9IiNGRkYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PC9nPjwvc3ZnPg==);background-size:90px auto}.OT_container-audio-blocked{cursor:pointer}.OT_container-audio-blocked.OT_mini .OT_edge-bar-item,.OT_container-audio-blocked .OT_mute{display:none}.OT_audio-blocked-indicator.OT_active{display:block}.OT_video-unsupported{opacity:1;border:none;display:none;position:absolute;background-color:transparent;background-repeat:no-repeat;background-position:center;background-image:url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOTciIGhlaWdodD0iOTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxkZWZzPjxwYXRoIGQ9Ik03MCAxMkw5LjQ0OCA3Mi41NTIgMCA2MmwzLTQ0TDI5IDBsNDEgMTJ6bTggMmwxIDUyLTI5IDE4LTM1LjUwMi02LjQ5OEw3OCAxNHoiIGlkPSJhIi8+PC9kZWZzPjxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoOCAzKSI+PG1hc2sgaWQ9ImIiIGZpbGw9IiNmZmYiPjx1c2UgeGxpbms6aHJlZj0iI2EiLz48L21hc2s+PHBhdGggZD0iTTkuMTEgMjAuOTY4SDQ4LjFhNSA1IDAgMCAxIDUgNVY1OC4xOGE1IDUgMCAwIDEtNSA1SDkuMTFhNSA1IDAgMCAxLTUtNVYyNS45N2E1IDUgMCAwIDEgNS01em00Ny4wOCAxMy4zOTRjMC0uMzQ1IDUuNDcyLTMuMTU5IDE2LjQxNS04LjQ0M2EzIDMgMCAwIDEgNC4zMDQgMi43MDJ2MjYuODM1YTMgMyAwIDAgMS00LjMwNSAyLjcwMWMtMTAuOTQyLTUuMjg2LTE2LjQxMy04LjEtMTYuNDEzLTguNDQ2VjM0LjM2MnoiIGZpbGw9IiNGRkYiIG1hc2s9InVybCgjYikiLz48L2c+PHBhdGggZD0iTTgxLjUgMTYuNUwxOS45OTggNzguMDAyIiBzdHJva2U9IiNGRkYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PC9nPjwvc3ZnPg==);background-size:58px auto;pointer-events:none;inset:0;margin-top:-30px}.OT_video-unsupported-bar{display:none;position:absolute;width:192%;height:192%;top:-96%;left:-96%;border-radius:50%;background-color:#000c}.OT_video-unsupported-img{display:none;position:absolute;top:11%;left:15%;width:70%;opacity:.7;background-image:url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOTciIGhlaWdodD0iOTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxkZWZzPjxwYXRoIGQ9Ik03MCAxMkw5LjQ0OCA3Mi41NTIgMCA2MmwzLTQ0TDI5IDBsNDEgMTJ6bTggMmwxIDUyLTI5IDE4LTM1LjUwMi02LjQ5OEw3OCAxNHoiIGlkPSJhIi8+PC9kZWZzPjxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoOCAzKSI+PG1hc2sgaWQ9ImIiIGZpbGw9IiNmZmYiPjx1c2UgeGxpbms6aHJlZj0iI2EiLz48L21hc2s+PHBhdGggZD0iTTkuMTEgMjAuOTY4SDQ4LjFhNSA1IDAgMCAxIDUgNVY1OC4xOGE1IDUgMCAwIDEtNSA1SDkuMTFhNSA1IDAgMCAxLTUtNVYyNS45N2E1IDUgMCAwIDEgNS01em00Ny4wOCAxMy4zOTRjMC0uMzQ1IDUuNDcyLTMuMTU5IDE2LjQxNS04LjQ0M2EzIDMgMCAwIDEgNC4zMDQgMi43MDJ2MjYuODM1YTMgMyAwIDAgMS00LjMwNSAyLjcwMWMtMTAuOTQyLTUuMjg2LTE2LjQxMy04LjEtMTYuNDEzLTguNDQ2VjM0LjM2MnoiIGZpbGw9IiNGRkYiIG1hc2s9InVybCgjYikiLz48L2c+PHBhdGggZD0iTTgxLjUgMTYuNUwxOS45OTggNzguMDAyIiBzdHJva2U9IiNGRkYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PC9nPjwvc3ZnPg==);background-repeat:no-repeat;background-position:center;background-size:100% auto}.OT_video-unsupported-img:before{content:\"\";display:block;padding-top:93%}.OT_video-unsupported-text{display:flex;justify-content:center;align-items:center;text-align:center;height:100%;margin-top:40px}\n"], components: [{ type: CaptionsComponent, selector: "ov-captions" }], directives: [{ type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i10.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i2$1.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }, { type: i10.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "streams": ParticipantStreamsPipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LayoutComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-layout', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"container\" [class.withSubtitles]=\"subtitlesEnabled\">\n\t<div id=\"layout\" class=\"layout\" #layout>\n\t\t<div *ngFor=\"let stream of localParticipant | streams\"  [ngClass]=\"{ OV_big: stream.videoEnlarged }\" class=\"OT_root OT_publisher\">\n\t\t\t<ng-container *ngTemplateOutlet=\"streamTemplate; context: { $implicit: stream }\"></ng-container>\n\t\t</div>\n\n\t\t<div\n\t\t\t*ngFor=\"let stream of remoteParticipants | streams\"\n\t\t\tclass=\"OT_root OT_publisher\"\n\t\t\tid=\"remote-participant\"\n\t\t\t[ngClass]=\"{ OV_big: stream.videoEnlarged }\"\n\t\t>\n\t\t\t<ng-container *ngTemplateOutlet=\"streamTemplate; context: { $implicit: stream }\"></ng-container>\n\t\t</div>\n\t</div>\n\n\t<ov-captions *ngIf=\"subtitlesEnabled\" class=\"OV_ignored\"></ov-captions>\n</div>\n", styles: ["#remote-participant,.container{height:100%}.withSubtitles{height:calc(100% - var(--ov-captions-height, 200px))!important}.layout{position:relative;inset:0;min-width:350px!important;min-height:100%;width:inherit;height:-webkit-fill-available;height:-moz-available}/*!\n   * Copyright (c) 2017 TokBox, Inc.\n   * Released under the MIT license\n   * http://opensource.org/licenses/MIT\n   */.OT_root,.OT_root *{color:#fff;margin:0;padding:0;border:0;font-size:100%;vertical-align:baseline}.OT_dialog-centering{display:table;width:100%;height:100%}.OT_dialog-centering-child{display:table-cell;vertical-align:middle}.OT_dialog{position:relative;box-sizing:border-box;margin-right:auto;margin-left:auto;color:#fff;font-family:Ubuntu,sans-serif;font-size:13px;line-height:1.4}.OT_dialog *{font-family:inherit;box-sizing:inherit}.OT_closeButton{color:#999;cursor:pointer;font-size:32px;line-height:36px;position:absolute;right:18px;top:0}.OT_dialog-messages{text-align:center}.OT_dialog-messages-main{margin-bottom:36px;line-height:36px;font-weight:300;font-size:24px}.OT_dialog-messages-minor{margin-bottom:18px;font-size:13px;line-height:18px;color:#a4a4a4}.OT_dialog-messages-minor strong{color:#fff}.OT_dialog-actions-card{display:inline-block}.OT_dialog-button-title{margin-bottom:18px;line-height:18px;font-weight:300;text-align:center;font-size:14px;color:#999}.OT_dialog-button-title label{color:#999}.OT_dialog-button-title a,.OT_dialog-button-title a:link,.OT_dialog-button-title a:active{color:#02a1de}.OT_dialog-button-title strong{color:#fff;font-weight:100;display:block}.OT_dialog-button{display:inline-block;margin-bottom:18px;padding:0 1em;background-color:#1ca3dc;text-align:center;cursor:pointer}.OT_dialog-button:disabled{cursor:not-allowed;opacity:.5}.OT_dialog-button-large{line-height:36px;padding-top:9px;padding-bottom:9px;font-weight:100;font-size:24px}.OT_dialog-button-small{line-height:18px;padding-top:9px;padding-bottom:9px;background-color:#444;color:#999;font-size:16px}.OT_dialog-progress-bar{display:inline-block;width:100%;margin-top:5px;margin-bottom:41px;border:1px solid #4e4e4e;height:8px}.OT_dialog-progress-bar-fill{height:100%;background-color:#29a4da}.OT_dialog-plugin-upgrading .OT_dialog-plugin-upgrade-percentage{line-height:54px;font-size:48px;font-weight:100}.OT_centered{position:fixed;left:50%;top:50%;margin:0}.OT_dialog-hidden{display:none}.OT_dialog-button-block{display:block}.OT_dialog-no-natural-margin{margin-bottom:0}.OT_publisher,.OT_subscriber{position:relative;min-width:0px;min-height:0px;padding:3px;transition-duration:.1s;transition-timing-function:ease-in-out}.OT_publisher .OT_video-element,.OT_subscriber .OT_video-element{display:block;position:absolute;width:100%;height:100%;transform-origin:0 0}.OT_subscriber_error{background-color:#000;color:#fff;text-align:center}.OT_subscriber_error>p{padding:20px}.OT_publisher .OT_bar,.OT_subscriber .OT_bar,.OT_publisher .OT_name,.OT_subscriber .OT_name,.OT_publisher .OT_archiving,.OT_subscriber .OT_archiving,.OT_publisher .OT_archiving-status,.OT_subscriber .OT_archiving-status,.OT_publisher .OT_archiving-light-box,.OT_subscriber .OT_archiving-light-box{-ms-box-sizing:border-box;box-sizing:border-box;top:0;left:0;right:0;display:block;height:34px;position:absolute}.OT_publisher .OT_bar,.OT_subscriber .OT_bar{background:rgba(0,0,0,.4)}.OT_publisher .OT_edge-bar-item,.OT_subscriber .OT_edge-bar-item{z-index:1}.OT_publisher .OT_name,.OT_subscriber .OT_name{background-color:transparent;color:#fff;font-size:15px;line-height:34px;font-weight:400;padding:0 4px 0 36px}.OT_publisher .OT_archiving-status,.OT_subscriber .OT_archiving-status{background:rgba(0,0,0,.4);top:auto;bottom:0;left:34px;padding:0 4px;color:#fffc;font-size:15px;line-height:34px;font-weight:400}.OT_micro .OT_archiving-status,.OT_micro:hover .OT_archiving-status,.OT_mini .OT_archiving-status,.OT_mini:hover .OT_archiving-status{display:none}.OT_publisher .OT_archiving-light-box,.OT_subscriber .OT_archiving-light-box{background:rgba(0,0,0,.4);top:auto;bottom:0;right:auto;width:34px;height:34px}.OT_archiving-light{width:7px;height:7px;border-radius:30px;position:absolute;top:14px;left:14px;background-color:#575757;box-shadow:0 0 5px 1px #575757}.OT_archiving-light.OT_active{background-color:#970d13;animation:OT_pulse 1.3s ease-in;-webkit-animation:OT_pulse 1.3s ease-in;-moz-animation:OT_pulse 1.3s ease-in;-webkit-animation:OT_pulse 1.3s ease-in;animation-iteration-count:infinite;-moz-animation-iteration-count:infinite;-webkit-animation-iteration-count:infinite}.OT_mini .OT_bar,.OT_bar.OT_mode-mini,.OT_bar.OT_mode-mini-auto{bottom:0;height:auto}.OT_mini .OT_name.OT_mode-off,.OT_mini .OT_name.OT_mode-on,.OT_mini .OT_name.OT_mode-auto,.OT_mini:hover .OT_name.OT_mode-auto{display:none}.OT_publisher .OT_name,.OT_subscriber .OT_name{left:10px;right:37px;height:34px;padding-left:0}.OT_publisher .OT_mute,.OT_subscriber .OT_mute{border:none;cursor:pointer;display:block;position:absolute;text-align:center;text-indent:-9999em;background-color:transparent;background-repeat:no-repeat}.OT_publisher .OT_mute,.OT_subscriber .OT_mute{right:0;top:0;border-left:1px solid rgba(255,255,255,.2);height:36px;width:37px}.OT_mini .OT_mute,.OT_publisher.OT_mini .OT_mute.OT_mode-auto.OT_mode-on-hold,.OT_subscriber.OT_mini .OT_mute.OT_mode-auto.OT_mode-on-hold{top:50%;left:50%;right:auto;margin-top:-18px;margin-left:-18.5px;border-left:none}.OT_publisher .OT_mute{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAAcCAMAAAC02HQrAAAA1VBMVEUAAAD3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pn3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pn3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj3+Pj39/j3+Pj3+Pn4+Pk/JRMlAAAAQ3RSTlMABAUHCQoLDhAQERwdHiAjLjAxOD9ASFBRVl1mbnZ6fH2LjI+QkaWqrrC1uLzAwcXJycrL1NXj5Ofo6u3w9fr7/P3+d4M3+QAAAQBJREFUGBlVwYdCglAABdCLlr5Unijm3hMUtBzlBLSr//9JgUToOQgVJgceJgU8aHgMeA38K50ZOpcQmTPwcyXn+JM8M3JJIqQypiIkeXelTyIkGZPwKS1NMia1lgKTVkaE3oQQGYsmHNqSMWnTgUFbMiZtGlD2dpaxrL1XgM0i4ZK8MeAmFhsAs29MGZniawagS63oMOQUNXYB5D0D1RMDpyoMLw/fiE2og/V+PVDR5AiBl0/2Uwik+vx4xV3a5G5Ye68Nd1czjUjZckm6VhmPciRzeCZICjwTJAViQq+3e+St167rAoHK8sLYZVkBYPCZAZ/eGa+2R5LH7Wrc0YFf/O9J3yBDFaoAAAAASUVORK5CYII=);background-position:9px 5px}.OT_publisher .OT_mute.OT_active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAdCAYAAABFRCf7AAADcElEQVRIiaWVXWhcRRTHf7NNd2aDtUKMIjTpg4ufFIuiUOmDEWm0Vi3VYhXRqIggQh4sWJFSig9+oOhTKSpIRUWMIBIr2kptoTbgU6ooxCiIjR+14kcJmf9sNceHnd3ebnc3Uv9wuXfOzPzmnDMz5zozGwdWAbc65w5RUJQ8cC2wDJgFJioh/MJCMrNxq2vOzK4HmIvRRemxKP0RJWt53o7S+d2Yzsx6gQ+AIUDAnUqpBLzXZd4RYFUlhB/bdZacc3PAOmAcCMC7wfvFwLNdoAPAyx09bXyYWRl4E7gDmAdGlNKFwLYu8GolhO9O87RJd64GbMrgEvB68P4osMWdXLtVV7czlooNpVRWSs8DO7NpR/B+3rBHsvetCgtCMTxwQCm9BbyQrc8F7/uBex3uRCeXO0PrUZ4NfKyUPgWeyj3bg/crDNsIRGwBaJQGorQ3Svdn2wHgc2BUKb0DPJHtjwfvbwRucc7tz+N+i9LFUdoXpfVN36I0CVwBTFI/q9e1LPxT8P4qYEdu70q12mYzWw1MYQzjeJF6zq+shHC4B7jklOBPP/TzSunh4P0DwKvAfb5c9krpe+CcwsEoZdbhEvBM9wxRAl5RShcA9wAngE3B+8tLpdLuwrhp4MNmK0pfRWkySr7NXS8+L5nZbWZWy/Vin1IaitJnUTqvwevJ71lgSSWEFKUfHG7Q2m/xqFJaGry/GXgfGPLl8mJgrXPur2JoUC8Qy3OpG+sAbGhEKT0ErAWOA6uBPWbW1wr9BOgFbgKezot0kAPYqJQA1gC/A9cA+82svzksSn1R+jNKX0SpnM/e1x3yqig92JhrZivM7FjO8bSZLSuCR/Ok16K0KMNHojQWpYko7Y7S1igN5PE3ROl4lNaZ2UVmNpPBU01orvZvZPCeKFXbBR+lEKVtUapFaSZKg9njqpl9aWYTrmXCImA7sCWb9lK/jj9TrwkrgA1AH3AQuKsSwkzbrLfxpgpsBtYDxf/R3xm2ExirhNCuHHZXTsmRwiat+S/zSt06eysVA/4pmGr/G3qm6ik28v29FKgCg8BS6pvS0KNRGgZ+Bb4FpsxsOkfUlMuwDcBWYOUZOHYM2AU8WQmhBifDv70O7PjX7KZ+4G7g3FM8zd6uBIaBy4AqxnIcZwFLCovPAhE4Sj38b4BDwEeVEFKD9S94Khjn486v3QAAAABJRU5ErkJggg==);background-position:9px 4px}.OT_subscriber .OT_mute{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAAATCAYAAAB7u5a2AAABx0lEQVQ4jaWUv48NURiGn3ONmCs32ZBd28ht1gqyZAkF21ylQkEiSp2ehpDlD1BoFGqqVdJohYKI7MaPxMoVNghCWMF+7ybLUewnOXfcMWO9yeQ857zne8+XmZOBGjJpr0kvTIomvTZpS526UCO4DUwD64FjwCFgqZnnR+oc8LfgzKQ73vGsr42ZtGjSQFV9o8KfBCacZwCaef4YmAf2rzjcpN3A2WSpm/AssKcqPDNpDBjs410CViXzTwk/A7b1C4wxDgOngAsZcAXY2buDfp/6S4F3lDS8DjgBzDWAjX/Y/e/QgYS/AhsKHa+OMQ6GEJ4Cj4BOAxgq6aCowyZtdf4OtAr+FHDO+R4wWnVbihr3cQnICt4boO38GWj9a/icjwOACt4m4K3zEPA+AxaAtTWCnwN3lzHkEL8V/OPAGud9wK2GF9XR1Wae/1zG2AI+pGYI4VUIoRtjHAc2A9cz4LRPevYCZ+i9/4sJt4GXJU10gaPAzdI2TTro/5Tfz8XEe2LSZGmxq/SDNvP8BnA5WRrx4BwYBe6vONx1EnjovGvBLAAd4Adwuyq8UiaNmDTvr+a8SQ9MuvbfwckBHZPe+QEfTdpep+4XZmPBHiHgz74AAAAASUVORK5CYII=);background-position:8px 7px}.OT_subscriber .OT_mute.OT_active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAUCAYAAACXtf2DAAACtklEQVQ4jZ2VSYiURxTHf+/T9Nc9iRrBuYySmIsXUU9iFMEFERRBvAjJLUQi5ioiHvSScfTmgqC4XAT1ZIgLuJHkICaaQAgKI2hAUBT30bjUq7bbv4eukXK029F3+eqtv/fqK6qQdEnSNUmT6CDB/bvgfjO4N9zj2RD8007xg1IABkwEzkma0qb4PGAPMBZYLtSD8eNwAEjqTlNI0gNJM4YU7w7ut4O7gvuhZFsR3C8NC5BBLiTIY0mzM8AvqbiC++pk+zLpE95XuwAws3vAQuBPYDRwWtL84P4tsDSLv5oaug4EYOawAMF9jMdoLxqNZcDvQA04UVYqL4G/svj7AF21mhJscrvCksYBFO7xc2AAGGg2mrdjvf4rcAyomNn+slLZmUEGBgsYdh945xZJmgvckDSrEJpK6ySBgV6q12O8ABwGPjGzfWWlsjdN9rpjoSfA+DYDXARGAksK4Is3XC1Ub4z1f4CDQGFmu6tleQSYk0U+p7WVeefLJc00s4fAeWB6Qeunvj0m2ugx9gO7kmlrtSxvBfcy6fXUZS6rgG/S+jLQUwCVNmMC9HqM14EtSe+rluWazN8YEv8IqKZ1E1qnaIDO0ucx3gX6kv6TpM3AM+D/IbGjgP60/gq4WQA33gMA2OQxPgHWJX1ttSwL4FAeZGYLgB2SasBs4A8L7qOBf9M0uXQB3a+TMYSmVctyDrA9mfcBK82smSdKWgCcAaa1bTm4fxbc/8uuCQX3RanAD5Ka6Wo5IGnE0HxJPZ03pQX5Org3MsD3AO5xXLPZXJ9BjkrqdFg6QjZkgG3Jtsw93pG0VFI9QU5K6voYQBHcTydAfwheBI9HgvvPAJIWS3qeIL9JGvUxkO7gfi1BrqTvwkG/pPmSnibIqTzXPgAyEVgBjAEu1qrVPbk/PVTHgb/NbPGg/RVIzOQqzSTBaQAAAABJRU5ErkJggg==);background-position:7px 7px}.OT_publisher .OT_edge-bar-item,.OT_subscriber .OT_edge-bar-item{transition-property:top,bottom,opacity;transition-duration:.5s;transition-timing-function:ease-in}.OT_publisher .OT_edge-bar-item.OT_mode-off,.OT_subscriber .OT_edge-bar-item.OT_mode-off,.OT_publisher .OT_edge-bar-item.OT_mode-auto,.OT_subscriber .OT_edge-bar-item.OT_mode-auto,.OT_publisher .OT_edge-bar-item.OT_mode-mini-auto,.OT_subscriber .OT_edge-bar-item.OT_mode-mini-auto{top:-25px;opacity:0}.OT_publisher .OT_edge-bar-item.OT_mode-off,.OT_subscriber .OT_edge-bar-item.OT_mode-off{display:none}.OT_mini .OT_mute.OT_mode-auto,.OT_publisher .OT_mute.OT_mode-mini-auto,.OT_subscriber .OT_mute.OT_mode-mini-auto{top:50%}.OT_publisher .OT_edge-bar-item.OT_edge-bottom.OT_mode-off,.OT_subscriber .OT_edge-bar-item.OT_edge-bottom.OT_mode-off,.OT_publisher .OT_edge-bar-item.OT_edge-bottom.OT_mode-auto,.OT_subscriber .OT_edge-bar-item.OT_edge-bottom.OT_mode-auto,.OT_publisher .OT_edge-bar-item.OT_edge-bottom.OT_mode-mini-auto,.OT_subscriber .OT_edge-bar-item.OT_edge-bottom.OT_mode-mini-auto{top:auto;bottom:-25px}.OT_publisher .OT_edge-bar-item.OT_mode-on,.OT_subscriber .OT_edge-bar-item.OT_mode-on,.OT_publisher .OT_edge-bar-item.OT_mode-auto.OT_mode-on-hold,.OT_subscriber .OT_edge-bar-item.OT_mode-auto.OT_mode-on-hold,.OT_publisher:hover .OT_edge-bar-item.OT_mode-auto,.OT_subscriber:hover .OT_edge-bar-item.OT_mode-auto,.OT_publisher:hover .OT_edge-bar-item.OT_mode-mini-auto,.OT_subscriber:hover .OT_edge-bar-item.OT_mode-mini-auto{top:0;opacity:1}.OT_mini .OT_mute.OT_mode-on,.OT_mini:hover .OT_mute.OT_mode-auto,.OT_mute.OT_mode-mini,.OT_root:hover .OT_mute.OT_mode-mini-auto{top:50%}.OT_publisher .OT_edge-bar-item.OT_edge-bottom.OT_mode-on,.OT_subscriber .OT_edge-bar-item.OT_edge-bottom.OT_mode-on,.OT_publisher:hover .OT_edge-bar-item.OT_edge-bottom.OT_mode-auto,.OT_subscriber:hover .OT_edge-bar-item.OT_edge-bottom.OT_mode-auto{top:auto;bottom:0;opacity:1}.OT_root .OT_video-loading{position:absolute;z-index:1;width:100%;height:100%;display:none;background-color:#000000bf}.OT_root .OT_video-loading .OT_video-loading-spinner{background:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9Ii0yMCAtMjAgMjQwIDI0MCI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJhIiB4Mj0iMCIgeTI9IjEiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIwIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9IjAiLz48L2xpbmVhckdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0iYiIgeDE9IjEiIHgyPSIwIiB5Mj0iMSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9IjAiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNmZmYiIHN0b3Atb3BhY2l0eT0iLjA4Ii8+PC9saW5lYXJHcmFkaWVudD48bGluZWFyR3JhZGllbnQgaWQ9ImMiIHgxPSIxIiB4Mj0iMCIgeTE9IjEiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuMDgiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNmZmYiIHN0b3Atb3BhY2l0eT0iLjE2Ii8+PC9saW5lYXJHcmFkaWVudD48bGluZWFyR3JhZGllbnQgaWQ9ImQiIHgyPSIwIiB5MT0iMSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9Ii4xNiIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuMzMiLz48L2xpbmVhckdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0iZSIgeDI9IjEiIHkxPSIxIj48c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiNmZmYiIHN0b3Atb3BhY2l0eT0iLjMzIi8+PHN0b3Agb2Zmc2V0PSIxIiBzdG9wLWNvbG9yPSIjZmZmIiBzdG9wLW9wYWNpdHk9Ii42NiIvPjwvbGluZWFyR3JhZGllbnQ+PGxpbmVhckdyYWRpZW50IGlkPSJmIiB4Mj0iMSIgeTI9IjEiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iI2ZmZiIgc3RvcC1vcGFjaXR5PSIuNjYiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNmZmYiLz48L2xpbmVhckdyYWRpZW50PjxtYXNrIGlkPSJnIj48ZyBmaWxsPSJub25lIiBzdHJva2Utd2lkdGg9IjQwIj48cGF0aCBzdHJva2U9InVybCgjYSkiIGQ9Ik04Ni42LTUwYTEwMCAxMDAgMCAwIDEgMCAxMDAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEwMCAxMDApIi8+PHBhdGggc3Ryb2tlPSJ1cmwoI2IpIiBkPSJNODYuNiA1MEExMDAgMTAwIDAgMCAxIDAgMTAwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDAgMTAwKSIvPjxwYXRoIHN0cm9rZT0idXJsKCNjKSIgZD0iTTAgMTAwYTEwMCAxMDAgMCAwIDEtODYuNi01MCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMTAwIDEwMCkiLz48cGF0aCBzdHJva2U9InVybCgjZCkiIGQ9Ik0tODYuNiA1MGExMDAgMTAwIDAgMCAxIDAtMTAwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDAgMTAwKSIvPjxwYXRoIHN0cm9rZT0idXJsKCNlKSIgZD0iTS04Ni42LTUwQTEwMCAxMDAgMCAwIDEgMC0xMDAiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEwMCAxMDApIi8+PHBhdGggc3Ryb2tlPSJ1cmwoI2YpIiBkPSJNMC0xMDBhMTAwIDEwMCAwIDAgMSA4Ni42IDUwIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDAgMTAwKSIvPjwvZz48L21hc2s+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIHg9Ii0yMCIgeT0iLTIwIiBtYXNrPSJ1cmwoI2cpIiBmaWxsPSIjZmZmIi8+PC9zdmc+) no-repeat;position:absolute;width:32px;height:32px;left:50%;top:50%;margin-left:-16px;margin-top:-16px;animation:OT_spin 2s linear infinite}@keyframes OT_spin{to{transform:rotate(360deg)}}.OT_publisher.OT_loading .OT_video-loading,.OT_subscriber.OT_loading .OT_video-loading{display:block}.OT_video-centering{display:table;width:100%;height:100%}.OT_video-container{display:table-cell;vertical-align:middle}.OT_video-poster{position:absolute;z-index:1;width:100%;height:100%;display:none;opacity:.25;background-repeat:no-repeat;background-image:url(data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgNDcxIDQ2NCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48bGluZWFyR3JhZGllbnQgaWQ9ImEiIHgyPSIwIiB5Mj0iMSI+PHN0b3Agb2Zmc2V0PSI2Ni42NiUiIHN0b3AtY29sb3I9IiNmZmYiLz48c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNmZmYiIHN0b3Atb3BhY2l0eT0iMCIvPjwvbGluZWFyR3JhZGllbnQ+PHBhdGggZmlsbD0idXJsKCNhKSIgZD0iTTc5IDMwOGMxNC4yNS02LjUgNTQuMjUtMTkuNzUgNzEtMjkgOS0zLjI1IDI1LTIxIDI1LTIxczMuNzUtMTMgMy0yMmMtMS43NS02Ljc1LTE1LTQzLTE1LTQzLTIuNSAzLTQuNzQxIDMuMjU5LTcgMS0zLjI1LTcuNS0yMC41LTQ0LjUtMTYtNTcgMS4yNS03LjUgMTAtNiAxMC02LTExLjI1LTMzLjc1LTgtNjctOC02N3MuMDczLTcuMzQ2IDYtMTVjLTMuNDguNjM3LTkgNC05IDQgMi41NjMtMTEuNzI3IDE1LTIxIDE1LTIxIC4xNDgtLjMxMi0xLjMyMS0xLjQ1NC0xMCAxIDEuNS0yLjc4IDE2LjY3NS04LjY1NCAzMC0xMSAzLjc4Ny05LjM2MSAxMi43ODItMTcuMzk4IDIyLTIyLTIuMzY1IDMuMTMzLTMgNi0zIDZzMTUuNjQ3LTguMDg4IDQxLTZjLTE5Ljc1IDItMjQgNi0yNCA2czc0LjUtMTAuNzUgMTA0IDM3YzcuNSA5LjUgMjQuNzUgNTUuNzUgMTAgODkgMy43NS0xLjUgNC41LTQuNSA5IDEgLjI1IDE0Ljc1LTExLjUgNjMtMTkgNjItMi43NSAxLTQtMy00LTMtMTAuNzUgMjkuNS0xNCAzOC0xNCAzOC0yIDQuMjUtMy43NSAxOC41LTEgMjIgMS4yNSA0LjUgMjMgMjMgMjMgMjNsMTI3IDUzYzM3IDM1IDIzIDEzNSAyMyAxMzVMMCA0NjRzLTMtOTYuNzUgMTQtMTIwYzUuMjUtNi4yNSAyMS43NS0xOS43NSA2NS0zNnoiLz48L3N2Zz4=);background-size:auto 76%}.OT_fit-mode-cover .OT_video-element{object-fit:cover}@media only screen and (orientation: portrait){.OT_subscriber.OT_ForceContain.OT_fit-mode-cover .OT_video-element{object-fit:contain!important}}.OT_fit-mode-contain .OT_video-element{object-fit:contain}.OT_fit-mode-cover .OT_video-poster{background-position:center bottom}.OT_fit-mode-contain .OT_video-poster{background-position:center}.OT_audio-level-meter{position:absolute;width:25%;max-width:224px;min-width:21px;top:0;right:0;overflow:hidden}.OT_audio-level-meter:before{content:\"\";display:block;padding-top:100%}.OT_audio-level-meter__bar{position:absolute;width:192%;height:192%;top:-96%;right:-96%;border-radius:50%;background-color:#000c}.OT_audio-level-meter__audio-only-img{position:absolute;top:22%;right:15%;width:40%;opacity:.7;background:url(data:image/svg+xml;base64,PHN2ZyB2aWV3Qm94PSIwIDAgNzkgODYiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgZmlsbD0iI2ZmZiI+PHBhdGggZD0iTTkuNzU3IDQwLjkyNGMzLjczOC01LjE5MSAxMi43MTEtNC4zMDggMTIuNzExLTQuMzA4IDIuMjIzIDMuMDE0IDUuMTI2IDI0LjU4NiAzLjYyNCAyOC43MTgtMS40MDEgMS4zMDEtMTEuNjExIDEuNjI5LTEzLjM4LTEuNDM2LTEuMjI2LTguODA0LTIuOTU1LTIyLjk3NS0yLjk1NS0yMi45NzV6bTU4Ljc4NSAwYy0zLjczNy01LjE5MS0xMi43MTEtNC4zMDgtMTIuNzExLTQuMzA4LTIuMjIzIDMuMDE0LTUuMTI2IDI0LjU4Ni0zLjYyNCAyOC43MTggMS40MDEgMS4zMDEgMTEuNjExIDEuNjI5IDEzLjM4LTEuNDM2IDEuMjI2LTguODA0IDIuOTU1LTIyLjk3NSAyLjk1NS0yMi45NzV6Ii8+PHBhdGggZD0iTTY4LjY0NyA1OC42Yy43MjktNC43NTMgMi4zOC05LjU2MSAyLjM4LTE0LjgwNCAwLTIxLjQxMi0xNC4xMTUtMzguNzctMzEuNTI4LTM4Ljc3LTE3LjQxMiAwLTMxLjUyNyAxNy4zNTgtMzEuNTI3IDM4Ljc3IDAgNC41NDEuNTE1IDguOTM2IDEuODAyIDEyLjk1IDEuNjk4IDUuMjk1LTUuNTQyIDYuOTkxLTYuNjE2IDIuMDczQzIuNDEgNTUuMzk0IDAgNTEuNzg3IDAgNDguMTAzIDAgMjEuNTM2IDE3LjY4NSAwIDM5LjUgMCA2MS4zMTYgMCA3OSAyMS41MzYgNzkgNDguMTAzYzAgLjcxOC0yLjg5OSA5LjY5My0zLjI5MiAxMS40MDgtLjc1NCAzLjI5My03Ljc1MSAzLjU4OS03LjA2MS0uOTEyeiIvPjxwYXRoIGQ9Ik01LjA4NCA1MS4zODVjLS44MDQtMy43ODIuNTY5LTcuMzM1IDMuMTM0LTcuOTIxIDIuNjM2LS42MDMgNS40ODUgMi4xNSA2LjI4OSA2LjEzMi43OTcgMy45NDgtLjc1MiA3LjQ1Ny0zLjM4OCA3Ljg1OS0yLjU2Ni4zOTEtNS4yMzctMi4zMTgtNi4wMzQtNi4wN3ptNjguODM0IDBjLjgwNC0zLjc4Mi0uNTY4LTcuMzM1LTMuMTMzLTcuOTIxLTIuNjM2LS42MDMtNS40ODUgMi4xNS02LjI4OSA2LjEzMi0uNzk3IDMuOTQ4Ljc1MiA3LjQ1NyAzLjM4OSA3Ljg1OSAyLjU2NS4zOTEgNS4yMzctMi4zMTggNi4wMzQtNi4wN3ptLTIuMDM4IDguMjg4Yy0uOTI2IDE5LjY1OS0xNS4xMTIgMjQuNzU5LTI1Ljg1OSAyMC40NzUtNS40MDUtLjYwNi0zLjAzNCAxLjI2Mi0zLjAzNCAxLjI2MiAxMy42NjEgMy41NjIgMjYuMTY4IDMuNDk3IDMxLjI3My0yMC41NDktLjU4NS00LjUxMS0yLjM3OS0xLjE4Ny0yLjM3OS0xLjE4N3oiLz48cGF0aCBkPSJNNDEuNjYyIDc4LjQyMmw3LjU1My41NWMxLjE5Mi4xMDcgMi4xMiAxLjE1MyAyLjA3MiAyLjMzNWwtLjEwOSAyLjczOGMtLjA0NyAxLjE4Mi0xLjA1MSAyLjA1NC0yLjI0MyAxLjk0NmwtNy41NTMtLjU1Yy0xLjE5MS0uMTA3LTIuMTE5LTEuMTUzLTIuMDcyLTIuMzM1bC4xMDktMi43MzdjLjA0Ny0xLjE4MiAxLjA1Mi0yLjA1NCAyLjI0My0xLjk0N3oiLz48L2c+PC9zdmc+) no-repeat center}.OT_audio-level-meter__audio-only-img:before{content:\"\";display:block;padding-top:100%}.OT_audio-level-meter__value{position:absolute;border-radius:50%;background-image:radial-gradient(circle,rgba(151,206,0,1) 0%,rgba(151,206,0,0) 100%)}.OT_audio-level-meter.OT_mode-off{display:none}.OT_audio-level-meter.OT_mode-on,.OT_audio-only .OT_audio-level-meter.OT_mode-auto{display:block}.OT_audio-only.OT_publisher .OT_video-element,.OT_audio-only.OT_subscriber .OT_video-element{display:none}.OT_video-disabled-indicator{opacity:1;border:none;display:none;position:absolute;background-color:transparent;background-repeat:no-repeat;background-position:bottom right;pointer-events:none;inset:0 3px 3px 0}.OT_video-disabled{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAoCAYAAABtla08AAAINUlEQVR42u2aaUxUVxTHcRBmAAEBRVTK4sKwDIsg+wCK7CqIw1CN1YobbbS2qYlJ06Qx1UpdqMbYWq2pSzWmH6ytNbXWJY1Lq7VuqBERtW64V0XFLYae0/xvcp3MMAMzDz6IyT/ge2ce5/7ucpY3Ts3NzZ1ygF57AJ0gO0G2jyZPmdbFyclJSAV1EeoEaUUSLGdSV5KLLFxzFmA7QVqGqDqjixhWkxCVeyRVl38wM6bwj6yYItYK47BAuu9B0gCqs6Ng2r494KQtkj/Dz2jHraw6qw2fdSE4rNmcCPCvZONP8iF1I6kdBdMaQJWZLeJqRWa2kPJAxXY+GxE+zxLI03GRh8lGSwoi9WCY8FWlCEh+8JOnT7MfPGjMuXX7Tt61hoaCi/9cKmKdv3BxeEtim/UbNpnbQiqF4MmT7kqrbr4lkMcTo46TTSpJB5g+8NHuVWnWuaampvhmO/7duHmrGluoO4C6OsJZGRrkDIld43ZqUOTnlkDSmXmabAoBU0vqBf+6KgFSxQ9++uzZ8rZApM81TJ8xM5me0Z/UF7PuBmdVdkGEb5gYDeQmyZNW3SJLIP9Kj64lGyMpmxRN6sOfIbkoAhKOdnv2/PmB1kB88eLFo+olyyrps3rSINIAzLonnqlqK8R9w+L86vtrt5L2nhug3Vc3ULu/Liz8AOuXESlZZONH6kmr7gtLIA9lRNeRzVukAvj3BslLnJNKgfScO69K+/Lly0ZbQW7e8tNK+pwBjqaSIjDrXgJkW1ciAZvbQjQ+RDahpBBKd5ZZsqN758hmImk4KQHnpDd8UwSkCyJarx07d4+3BeKJmlMHyX4qaRxpBCmNFE4KENvHDpAutVERn1kCVBMfeRRgYvZnx62wZPdnZkw92VQA5GClQXYRBze2S+iJmpPVVoJLA9l9QKokjcWKTCT1R5rhLg70NuSsziT16diIKkuAjibrTpJNDkn/e17CahtAjlAWJAYkb29Sb1LE9Rs391kILk8mVkyuIpuZcLKUlEmKkra1WuSTNuesEPzwoEploSVAh9Oiz+BIyd9dOHhtx4OEpFpVg6gbNK3yXX1j48N6U5Dz5i/gc/FDrMY3sTLiSMEkXxGxzUEUAGnbxlPaksMlHUXWAlHS8URCPseSohZbCSLjSSU7ixLXdzhIWVKq4Y7t2a/2bN0qGeKly1fYsVmk6RgIDz4J0bonyUOcjeYqm/8hRoYbWkigV2NH9CHAS60EkUkkw47hSRs6FqT1LR5AVcsrueXlK1d5AO+RpmBrZZEiefByytPCanRGNLZY0uF52gNDYr9sCRB8MHY0SJu2OJWKS2WQV65e4y31DmkCImEi0hBfufRime0RIhpbKen0/Ny9OYNW2ghyYytABjNIaxNuKttAWk6HPLn0k0FevdZwFinPWFIuKZbUV16NVko6jbWSDoPO3pOf8K0jQWLSQ0S9bdpkYck+m7vfWpAiHfKgBsZiGSSt0FqcTeU8WETqAHE2CgcAVd3Gkm4MD3xXYeI6B4NMItvKbcUpQ9gP+KMWnSsW+TaYJtoo+avBWLoKoK0CCSDud+7eXWQGZAXqV3YoQjQCfixJ8+fzj9ta3JHhlUeJ8wJOY2ws6eRKpPS3oqTvHAESEz9ya0naXL5WH6pt3FqSOhTHkTcKEXc6k1POh4Q9YJu/03TT4a8PoGMFI4i2EqSbOZAYaBkpCyD92RkG6KCSbjI/H0HEISBnlOZPFdcEzI2GTO4KBZICGKyAKLTEmJOB2txf5MbgohBINCl4FTqmpJMB2W+HiRn1Q2l6lXyPmiEP6VVE2TfGoaMYrHyPdtAnyI0jEOn9RLWmNEhvBBE7SjpFQZaShtLK+1S+T12lRwxUvrZlVPp8jE1PikeO7C/nyEqBDCB1t7+kUx4kKUWclea0yZC5BIGpiJSNSD9QgFR0RQKkL6KxHSWdsiARHJNYewoGrzG1/bk4dTPSunL2EyDjcbb7MQ+lQfZmkKiN7SjpFAM5CWAyGcwyY84YsZ1lUcbRNNtQMAdtQWGvQ0DyVjzYAKQfQFodeAeC1C8vzymXIZqD+ZEh/2OyLSalS/3VbnJZ+VqDXGjMrTCFuK4s66vVZUNfqaDolcbjOcb899sLpEE+I20GifywXe2QR3KElu99PzqjGufhREqB1pjCnG3IL3fY1v733r2FMsiGhutn0LAoJWWIGbPxjKwgjUbF0m52mPhigrpdXOecEq9pR6MkHbu2LOtrcZ9y3d0ODTb15y9MePz48aF79+8fvXnr9sljx2u2I7KNxDuaMPGVECoRs7mC4eT7SIruFNfNHK15MKuM2evwNq+4qjxvGnd5CHwNNynawW4cOlUZdG8b55IIJHmkItwrZHH6QxB3OSL9kTtAGpIvZiQB3Z4SKBfXQtEE9sashWAW87Bt3sYZNR6zn4uzJwWDKUKXfaKCdqUoBpLxSjYe9nqGiwWRBGipuGZ3Qm76itYLbbJI/PEhUApfw73uOIy9xfse3M9F9BuFJHcYrseSouGkHtCVtkuGTTikI8XgZzhg9SeF4VqcvSWiaSvNHQ8JwkNjIfEHemCmNLD1RaEfLs18mlgNuN6PFALHo7CyU5W2g00gFAQF4ozvibH04muwDbWraSFAyt/AAMzewgGR8uCeWn77xzBxPxgzPRCDDMZ14bQ/3jqGKGoHf2Hjgx3kw5LbaJDYWb52t9FMgw4AuWNWukNeuOYqOsmQi2jgws4PA/DD/z0B2x0/veCs4naw0cgybezid7X9jV3rX2RSs0wfLkll4pBGcgifg+NYxe1kJ2ycTaRq66uG/wBOl0vjcw70xwAAAABJRU5ErkJggg==);background-size:33px auto}.OT_video-disabled-warning{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFIAAAAoCAYAAABtla08AAAGMElEQVR4Ae2aA7D0yBaAc7oH12vbRmlLaxYWb23btm3btm2899a2bWuYtPZ01cmtU9lJrib315yqr9I3Oem/5/s7acwEnehEJzoxCcX2O+wEeIgRBDDaGjAZOgQ6ihRpLklHZDJIXK1WWymMIhGGkVBKCWMM+Iv/f/b5t7faYtM/sGgIS7j8RNLjceUVl41GvGN1BFiHy9sgtRWaYbhvuVQ6o1VOvV5/tLe3dyssKoZuh8xClkDEi2MMS6ZjR0cScxdK/+HgnJsmLccYOx0e/PUGUqfTJDEHkV5go9lcMQoj4R8RpSIRRUr4a9baTJFCCNfqESKJ7RYJibK0xoi05EhFRTxMi1Rit6xHAuLaKRLwEVi6q1x+EhlVpd3d3Wfh4VQkQhRhxthYLg7SRGqdLlIp7UVOHf+JhEhEMscUolVje3p63saeeOFoKsT7fjj++BNuw2I/0ouUENmGaQcQEilQvUU6xuWC0kqmVWCt8df6kG7WLoFA20VSCOyNh0RKPT+SyrTWtQsvuvTYCy84z3+oAdbgAiLGIvHjTz6bFuu/B3lKKfVkFKknwih6EnnipZdfXQZzepAupXSGSCfwUGZtkrx3t/0dSQGnnXbmdocdetArQoj+4VR23wMP3bj/vnv9Sv/rBmkish09ca655thHSrlWq4TFF1vkNDxsgjiUnPqZnHPABIq47jx7pPMcecShfz7x1DO7D6eit99576X1113nVd8rqLGAuDaNitJonTGIqHgQGQjDsJglMrUH5iDSEQbRa6y2yrNvv/PuWVmV/PTzLz8steTit1B9FtGJeZrJksmWdBzBMcami4xUkaY1A1Qe94WIaPGBApJhaERrLrXkElf8+NPPz6YMLs1DDjn0Wn9PnI/UiQadM4jNEkhzVsEGE8nIHESM1j5/KqRX+/IEiOQ/yifNBlEkpnb00cccesbpp13T3983H88/48xzrrvm6it/8U5JXgX5G6nSvSq1R5LATR7aYGkwMG1RSwkWABH+4jUb3vT/uJ1Z0xpjraTBRltrxUQhksIRmgTJyy69+Pv99tv3qYX6FxgU+fU33352xGEHf5wisU7nNWJpZRMkAjZ6aIN1mwV7h29Jo2wCHlveu/GV169z65E+T6koexCh6c+EEiky3lnxQKFjUeVyOeI5AOBzIiayRhJryd7YYnkIHgvB0qk9Tdql6N3XH4bRUIOIIIKJSiRb0hkSEpZKRd1CpEq8GxtIyCVmDSgFl94GacTgaJw1rUlYhYng0c4ewaUsmKRIJjpiqMSOCh9QeI+UYECmtQIsxEu6OorEcv6Rl0gu0woh8MhFkmSCTXVI4pC704WCFRJvSRNJSzrMMEZO2iKZTCHAZYnmvXCny7ed5vfZK3viHSBdIFCKEFj2+nt+73nw8m2uedcLJlktA++VNMEPaR45aYukcKnnCfY3/DFbZS8t7eHxNgsPM0N1hXhJJwwM1QbpoQFlog2R13a/zBxEYHAQEUYUM6qiVwEyBYoM6JFNF2kFLelI5KQf+fVI4dJFCguDS7oAyx2R6SFQJKRedSDj/cMg/RXQ6ZE05GSIDAaXdCi1I3L021SQWNJ1RLY5OiIdL4/yvuw8ADfWPFrSciaMyH8tEQPwf1uGG54g5+KlJGTmsrxsQdl5PKidnPFe2QS///7Hu+VS6WX/HYnf0sevGL7lXydwod2/9DykZq0s5yff0sgSWCigNOH7TPHL7ufj+/TH8P/+qYpL4HkBDiRYpEXeM8/89/9zzjn7EtY64dfd1nqccM7Bs8+9MKy8555/8TnKS+5MufH6EZVASkgPzf+mJXroet17JirU0ALST3nT0y5ONyLpeo1y64ih+vuQfsoTOeRFSJXa+SvyB90TUmdw49EjLaKpMQ0mzEeTzkWsd/oI6fzfiKM8gWg6X6OjpXstu5ZHnmIb0GFiu29MIUfUewkmVrEN3RqVQ/bY8FzNcquMBv/pCNUZ5pHHem01KdN/I/DG66/lLhKSvTO5M84kav5C5z2ZfyAivi9i9VGd45RH7UWJbjwGG/7NYsRECt7jiOToHedKAui8SW4CsxyRc54mKH/8f7ELhCCACyNcIl/wI+FaAJyc8yzRtinQPzWzuFZrFHq/AAAAAElFTkSuQmCC);background-size:33px auto}.OT_video-disabled-indicator.OT_active{display:block}.OT_audio-blocked-indicator{opacity:1;border:none;display:none;position:absolute;background-color:transparent;background-repeat:no-repeat;background-position:center;pointer-events:none;inset:0}.OT_audio-blocked{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB3aWR0aD0iMTUwIiBoZWlnaHQ9IjkwIj48ZGVmcz48cGF0aCBkPSJNNjcgMTJMNi40NDggNzIuNTUyIDAgMzFWMThMMjYgMGw0MSAxMnptMyA3bDYgNDctMjkgMTgtMzUuNTAyLTYuNDk4TDcwIDE5eiIgaWQ9ImEiLz48L2RlZnM+PHJlY3Qgd2lkdGg9IjE1MCIgaGVpZ2h0PSI5MCIgcng9IjM1IiByeT0iNDUiIG9wYWNpdHk9Ii41Ii8+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzNikiPjxtYXNrIGlkPSJiIiBmaWxsPSIjZmZmIj48dXNlIHhsaW5rOmhyZWY9IiNhIi8+PC9tYXNrPjxwYXRoIGQ9Ik0zOS4yNDkgNTEuMzEyYy42OTcgMTAuMzcgMi43ODUgMTcuODk3IDUuMjUxIDE3Ljg5NyAzLjAzOCAwIDUuNS0xMS40MTcgNS41LTI1LjVzLTIuNDYyLTI1LjUtNS41LTI1LjVjLTIuNTEgMC00LjYyOCA3Ljc5Ny01LjI4NyAxOC40NTNBOC45ODkgOC45ODkgMCAwIDEgNDMgNDRhOC45ODggOC45ODggMCAwIDEtMy43NTEgNy4zMTJ6TTIwLjk4NSAzMi4yMjRsMTUuNzQ2LTE2Ljg3N2E3LjM4NSA3LjM4NSAwIDAgMSAxMC4zNzQtLjQyQzUxLjcwMiAxOS4xMTQgNTQgMjkuMjA4IDU0IDQ1LjIwOGMwIDE0LjUyNy0yLjM0MyAyMy44OC03LjAzIDI4LjA1OGE3LjI4IDcuMjggMCAwIDEtMTAuMTY4LS40NjhMMjAuNDA1IDU1LjIyNEgxMmE1IDUgMCAwIDEtNS01di0xM2E1IDUgMCAwIDEgNS01aDguOTg1eiIgZmlsbD0iI0ZGRiIgbWFzaz0idXJsKCNiKSIvPjwvZz48cGF0aCBkPSJNMTA2LjUgMTMuNUw0NC45OTggNzUuMDAyIiBzdHJva2U9IiNGRkYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PC9nPjwvc3ZnPg==);background-size:90px auto}.OT_container-audio-blocked{cursor:pointer}.OT_container-audio-blocked.OT_mini .OT_edge-bar-item,.OT_container-audio-blocked .OT_mute{display:none}.OT_audio-blocked-indicator.OT_active{display:block}.OT_video-unsupported{opacity:1;border:none;display:none;position:absolute;background-color:transparent;background-repeat:no-repeat;background-position:center;background-image:url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOTciIGhlaWdodD0iOTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxkZWZzPjxwYXRoIGQ9Ik03MCAxMkw5LjQ0OCA3Mi41NTIgMCA2MmwzLTQ0TDI5IDBsNDEgMTJ6bTggMmwxIDUyLTI5IDE4LTM1LjUwMi02LjQ5OEw3OCAxNHoiIGlkPSJhIi8+PC9kZWZzPjxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoOCAzKSI+PG1hc2sgaWQ9ImIiIGZpbGw9IiNmZmYiPjx1c2UgeGxpbms6aHJlZj0iI2EiLz48L21hc2s+PHBhdGggZD0iTTkuMTEgMjAuOTY4SDQ4LjFhNSA1IDAgMCAxIDUgNVY1OC4xOGE1IDUgMCAwIDEtNSA1SDkuMTFhNSA1IDAgMCAxLTUtNVYyNS45N2E1IDUgMCAwIDEgNS01em00Ny4wOCAxMy4zOTRjMC0uMzQ1IDUuNDcyLTMuMTU5IDE2LjQxNS04LjQ0M2EzIDMgMCAwIDEgNC4zMDQgMi43MDJ2MjYuODM1YTMgMyAwIDAgMS00LjMwNSAyLjcwMWMtMTAuOTQyLTUuMjg2LTE2LjQxMy04LjEtMTYuNDEzLTguNDQ2VjM0LjM2MnoiIGZpbGw9IiNGRkYiIG1hc2s9InVybCgjYikiLz48L2c+PHBhdGggZD0iTTgxLjUgMTYuNUwxOS45OTggNzguMDAyIiBzdHJva2U9IiNGRkYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PC9nPjwvc3ZnPg==);background-size:58px auto;pointer-events:none;inset:0;margin-top:-30px}.OT_video-unsupported-bar{display:none;position:absolute;width:192%;height:192%;top:-96%;left:-96%;border-radius:50%;background-color:#000c}.OT_video-unsupported-img{display:none;position:absolute;top:11%;left:15%;width:70%;opacity:.7;background-image:url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOTciIGhlaWdodD0iOTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxkZWZzPjxwYXRoIGQ9Ik03MCAxMkw5LjQ0OCA3Mi41NTIgMCA2MmwzLTQ0TDI5IDBsNDEgMTJ6bTggMmwxIDUyLTI5IDE4LTM1LjUwMi02LjQ5OEw3OCAxNHoiIGlkPSJhIi8+PC9kZWZzPjxnIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoOCAzKSI+PG1hc2sgaWQ9ImIiIGZpbGw9IiNmZmYiPjx1c2UgeGxpbms6aHJlZj0iI2EiLz48L21hc2s+PHBhdGggZD0iTTkuMTEgMjAuOTY4SDQ4LjFhNSA1IDAgMCAxIDUgNVY1OC4xOGE1IDUgMCAwIDEtNSA1SDkuMTFhNSA1IDAgMCAxLTUtNVYyNS45N2E1IDUgMCAwIDEgNS01em00Ny4wOCAxMy4zOTRjMC0uMzQ1IDUuNDcyLTMuMTU5IDE2LjQxNS04LjQ0M2EzIDMgMCAwIDEgNC4zMDQgMi43MDJ2MjYuODM1YTMgMyAwIDAgMS00LjMwNSAyLjcwMWMtMTAuOTQyLTUuMjg2LTE2LjQxMy04LjEtMTYuNDEzLTguNDQ2VjM0LjM2MnoiIGZpbGw9IiNGRkYiIG1hc2s9InVybCgjYikiLz48L2c+PHBhdGggZD0iTTgxLjUgMTYuNUwxOS45OTggNzguMDAyIiBzdHJva2U9IiNGRkYiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIi8+PC9nPjwvc3ZnPg==);background-repeat:no-repeat;background-position:center;background-size:100% auto}.OT_video-unsupported-img:before{content:\"\";display:block;padding-top:93%}.OT_video-unsupported-text{display:flex;justify-content:center;align-items:center;text-align:center;height:100%;margin-top:40px}\n"] }]
        }], ctorParameters: function () { return [{ type: LayoutService }, { type: ParticipantService }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { streamTemplate: [{
                type: ContentChild,
                args: ['stream', { read: TemplateRef }]
            }], layoutContainer: [{
                type: ViewChild,
                args: ['layout', { static: false, read: ViewContainerRef }]
            }], externalStream: [{
                type: ContentChild,
                args: [StreamDirective]
            }] } });

/**
 * @internal
 */
var VideoSizeIcon;
(function (VideoSizeIcon) {
    VideoSizeIcon["BIG"] = "zoom_in";
    VideoSizeIcon["NORMAL"] = "zoom_out";
})(VideoSizeIcon || (VideoSizeIcon = {}));

class CdkOverlayContainer extends OverlayContainer {
    constructor() {
        super(...arguments);
        this.containerSelector = '.sidenav-main';
        this.customClass = 'cdk-overlay-container';
    }
    _createContainer() {
        const container = document.createElement('div');
        container.classList.add(this.customClass);
        let element = this.getElement(this.containerSelector);
        if (!element) {
            element = this.getElement('body');
        }
        this._containerElement = element.appendChild(container);
    }
    setSelector(selector) {
        const overlayElement = this.getElement('.' + this.customClass);
        if (overlayElement && this.containerSelector !== selector) {
            const newContainerOverlayContainer = this.getElement(selector);
            this.containerSelector = selector;
            newContainerOverlayContainer === null || newContainerOverlayContainer === void 0 ? void 0 : newContainerOverlayContainer.appendChild(overlayElement);
        }
    }
    getElement(selector) {
        return document.querySelector(selector);
    }
}
CdkOverlayContainer.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CdkOverlayContainer, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
CdkOverlayContainer.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CdkOverlayContainer });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CdkOverlayContainer, decorators: [{
            type: Injectable
        }] });

/**
 * @internal
 */
class CdkOverlayService {
    constructor(cdkOverlayModel) {
        this.cdkOverlayModel = cdkOverlayModel;
    }
    setSelector(selector) {
        this.cdkOverlayModel.setSelector(selector);
    }
}
CdkOverlayService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CdkOverlayService, deps: [{ token: CdkOverlayContainer }], target: i0.ɵɵFactoryTarget.Injectable });
CdkOverlayService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CdkOverlayService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CdkOverlayService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: CdkOverlayContainer }]; } });

/**
 * @internal
 */
class AudioWaveComponent {
    constructor() {
        this.isSpeaking = false;
    }
    ngOnInit() {
        this.subscribeSpeakingEvents();
    }
    ngOnDestroy() {
        this.unsubscribeSpeakingEvents();
    }
    subscribeSpeakingEvents() {
        if (this.streamManager) {
            this.streamManager.on('publisherStartSpeaking', (event) => (this.isSpeaking = true));
            this.streamManager.on('publisherStopSpeaking', (event) => (this.isSpeaking = false));
        }
    }
    unsubscribeSpeakingEvents() {
        if (this.streamManager) {
            this.streamManager.off('publisherStartSpeaking');
            this.streamManager.off('publisherStopSpeaking');
        }
    }
}
AudioWaveComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AudioWaveComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
AudioWaveComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: AudioWaveComponent, selector: "ov-audio-wave", inputs: { streamManager: "streamManager" }, ngImport: i0, template: "<div class=\"audio-container\">\n\t<div class=\"stick normal\" [ngClass]=\"isSpeaking ? 'play' : 'pause'\"></div>\n\t<div class=\"stick loud\" [ngClass]=\"isSpeaking ? 'play' : 'pause'\"></div>\n\t<div class=\"stick normal\" [ngClass]=\"isSpeaking ? 'play' : 'pause'\"></div>\n</div>\n", styles: ["@keyframes normal{0%{height:20%}50%{height:40%}to{height:20%}}@keyframes loud{0%{height:30%}50%{height:80%}to{height:30%}}.audio-container{background-color:var(--ov-tertiary-color);padding:5px;max-width:15px;max-height:15px;height:15px;width:15px;border-radius:var(--ov-buttons-radius);display:flex;justify-content:space-between}.stick{margin:auto;height:80%;width:3px;background:var(--ov-text-color);border-radius:8px}.pause{animation-play-state:paused;height:1px}.play{animation-duration:1.2s;animation-timing-function:ease-in-out;animation-iteration-count:infinite;animation-play-state:running}.normal{animation-name:normal}.loud{animation-name:loud}\n"], directives: [{ type: i10.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i2$1.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AudioWaveComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-audio-wave', template: "<div class=\"audio-container\">\n\t<div class=\"stick normal\" [ngClass]=\"isSpeaking ? 'play' : 'pause'\"></div>\n\t<div class=\"stick loud\" [ngClass]=\"isSpeaking ? 'play' : 'pause'\"></div>\n\t<div class=\"stick normal\" [ngClass]=\"isSpeaking ? 'play' : 'pause'\"></div>\n</div>\n", styles: ["@keyframes normal{0%{height:20%}50%{height:40%}to{height:20%}}@keyframes loud{0%{height:30%}50%{height:80%}to{height:30%}}.audio-container{background-color:var(--ov-tertiary-color);padding:5px;max-width:15px;max-height:15px;height:15px;width:15px;border-radius:var(--ov-buttons-radius);display:flex;justify-content:space-between}.stick{margin:auto;height:80%;width:3px;background:var(--ov-text-color);border-radius:8px}.pause{animation-play-state:paused;height:1px}.play{animation-duration:1.2s;animation-timing-function:ease-in-out;animation-iteration-count:infinite;animation-play-state:running}.normal{animation-name:normal}.loud{animation-name:loud}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { streamManager: [{
                type: Input
            }] } });

/**
 * @internal
 */
class AvatarProfileComponent {
    constructor() { }
    set name(nickname) {
        this.letter = nickname[0];
    }
}
AvatarProfileComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AvatarProfileComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
AvatarProfileComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: AvatarProfileComponent, selector: "ov-avatar-profile", inputs: { name: "name", color: "color" }, ngImport: i0, template: `
		<div class="poster" @posterAnimation>
			<div class="initial" [ngStyle]="{ 'background-color': color }">
				<span id="poster-text">{{ letter }}</span>
			</div>
		</div>
	`, isInline: true, styles: [".poster{height:100%;width:100%;background-color:#000;position:absolute;z-index:1}.initial{position:absolute;display:inline-grid;z-index:1;margin:auto;inset:0;height:70px;width:70px;border-radius:var(--ov-video-radius);border:2px solid var(--ov-text-color);color:#000}#poster-text{padding:0!important;font-weight:700;font-size:40px;margin:auto}\n"], directives: [{ type: i10.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { type: i2$1.DefaultStyleDirective, selector: "  [ngStyle],  [ngStyle.xs], [ngStyle.sm], [ngStyle.md], [ngStyle.lg], [ngStyle.xl],  [ngStyle.lt-sm], [ngStyle.lt-md], [ngStyle.lt-lg], [ngStyle.lt-xl],  [ngStyle.gt-xs], [ngStyle.gt-sm], [ngStyle.gt-md], [ngStyle.gt-lg]", inputs: ["ngStyle", "ngStyle.xs", "ngStyle.sm", "ngStyle.md", "ngStyle.lg", "ngStyle.xl", "ngStyle.lt-sm", "ngStyle.lt-md", "ngStyle.lt-lg", "ngStyle.lt-xl", "ngStyle.gt-xs", "ngStyle.gt-sm", "ngStyle.gt-md", "ngStyle.gt-lg"] }], animations: [
        trigger('posterAnimation', [
            transition(':enter', [style({ opacity: 0 }), animate('600ms', style({ opacity: 1 }))])
            // transition(':leave', [animate(600, style({ backgroundColor: 'yellow' }))]),
        ])
    ] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AvatarProfileComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-avatar-profile', template: `
		<div class="poster" @posterAnimation>
			<div class="initial" [ngStyle]="{ 'background-color': color }">
				<span id="poster-text">{{ letter }}</span>
			</div>
		</div>
	`, animations: [
                        trigger('posterAnimation', [
                            transition(':enter', [style({ opacity: 0 }), animate('600ms', style({ opacity: 1 }))])
                            // transition(':leave', [animate(600, style({ backgroundColor: 'yellow' }))]),
                        ])
                    ], styles: [".poster{height:100%;width:100%;background-color:#000;position:absolute;z-index:1}.initial{position:absolute;display:inline-grid;z-index:1;margin:auto;inset:0;height:70px;width:70px;border-radius:var(--ov-video-radius);border:2px solid var(--ov-text-color);color:#000}#poster-text{padding:0!important;font-weight:700;font-size:40px;margin:auto}\n"] }]
        }], ctorParameters: function () { return []; }, propDecorators: { name: [{
                type: Input
            }], color: [{
                type: Input
            }] } });

/**
 * The **StreamComponent** is hosted inside of the {@link LayoutComponent}.
 * It is in charge of displaying the participant video stream in the videoconference layout.
 *
 * <div class="custom-table-container">
 * <div>
 *  <h3>API Directives</h3>
 *
 * This component allows us to show or hide certain HTML elements with the following {@link https://angular.io/guide/attribute-directives Angular attribute directives}
 * with the aim of fully customizing the StreamComponent.
 *
 * | **Parameter**                  | **Type**  | **Reference**                                   |
 * | :----------------------------: | :-------: | :---------------------------------------------: |
 * | **displayParticipantName**   | `boolean` | {@link StreamDisplayParticipantNameDirective}   |
 * | **displayAudioDetection**    | `boolean` | {@link StreamDisplayAudioDetectionDirective}    |
 * | **settingsButton**          | `boolean` | {@link StreamSettingsButtonDirective}           |
 *
 * <p class="component-link-text">
 * <span class="italic">See all {@link ApiDirectiveModule API Directives}</span>
 * </p>
 * </div>
 *
 * <div>
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The StreamComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovStream**           |            {@link StreamDirective}           |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 *
 * </div>
 */
class StreamComponent {
    /**
     * @ignore
     */
    constructor(openviduService, layoutService, participantService, storageService, cdkSrv, libService) {
        this.openviduService = openviduService;
        this.layoutService = layoutService;
        this.participantService = participantService;
        this.storageService = storageService;
        this.cdkSrv = cdkSrv;
        this.libService = libService;
        /**
         * @ignore
         */
        this.videoSizeIconEnum = VideoSizeIcon;
        /**
         * @ignore
         */
        this.videoTypeEnum = VideoType;
        /**
         * @ignore
         */
        this.videoSizeIcon = VideoSizeIcon.BIG;
        /**
         * @ignore
         */
        this.isMinimal = false;
        /**
         * @ignore
         */
        this.showNickname = true;
        /**
         * @ignore
         */
        this.showAudioDetection = true;
        /**
         * @ignore
         */
        this.showSettingsButton = true;
    }
    /**
     * @ignore
     */
    set streamContainer(streamContainer) {
        setTimeout(() => {
            if (streamContainer) {
                this._streamContainer = streamContainer;
                // This is a workaround for fixing a layout bug which provide a bad UX with each new elements created.
                setTimeout(() => {
                    this.showVideo = true;
                }, 100);
            }
        }, 0);
    }
    set stream(stream) {
        this._stream = stream;
        this.checkVideoEnlarged();
        if (this._stream.participant) {
            this.nickname = this._stream.participant.nickname;
        }
    }
    /**
     * @ignore
     */
    set nicknameInputElement(element) {
        setTimeout(() => {
            element === null || element === void 0 ? void 0 : element.nativeElement.focus();
        });
    }
    ngOnInit() {
        this.subscribeToStreamDirectives();
    }
    ngOnDestroy() {
        this.cdkSrv.setSelector('body');
        if (this.settingsButtonSub)
            this.settingsButtonSub.unsubscribe();
        if (this.displayAudioDetectionSub)
            this.displayAudioDetectionSub.unsubscribe();
        if (this.displayParticipantNameSub)
            this.displayParticipantNameSub.unsubscribe();
        if (this.minimalSub)
            this.minimalSub.unsubscribe();
    }
    /**
     * @ignore
     */
    toggleVideoEnlarged() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
        if (!!((_c = (_b = (_a = this._stream.streamManager) === null || _a === void 0 ? void 0 : _a.stream) === null || _b === void 0 ? void 0 : _b.connection) === null || _c === void 0 ? void 0 : _c.connectionId)) {
            if (this.openviduService.isMyOwnConnection((_f = (_e = (_d = this._stream.streamManager) === null || _d === void 0 ? void 0 : _d.stream) === null || _e === void 0 ? void 0 : _e.connection) === null || _f === void 0 ? void 0 : _f.connectionId)) {
                this.participantService.toggleMyVideoEnlarged((_j = (_h = (_g = this._stream.streamManager) === null || _g === void 0 ? void 0 : _g.stream) === null || _h === void 0 ? void 0 : _h.connection) === null || _j === void 0 ? void 0 : _j.connectionId);
            }
            else {
                this.participantService.toggleRemoteVideoEnlarged((_m = (_l = (_k = this._stream.streamManager) === null || _k === void 0 ? void 0 : _k.stream) === null || _l === void 0 ? void 0 : _l.connection) === null || _m === void 0 ? void 0 : _m.connectionId);
            }
        }
        this.layoutService.update();
    }
    /**
     * @ignore
     */
    toggleVideoMenu(event) {
        var _a, _b;
        if (this.menuTrigger.menuOpen) {
            this.menuTrigger.closeMenu();
            return;
        }
        this.cdkSrv.setSelector('#container-' + ((_b = (_a = this._stream.streamManager) === null || _a === void 0 ? void 0 : _a.stream) === null || _b === void 0 ? void 0 : _b.streamId));
        this.menuTrigger.openMenu();
    }
    /**
     * @ignore
     */
    toggleMuteForcibly() {
        this.participantService.setRemoteMutedForcibly(this._stream.participant.id, !this._stream.participant.isMutedForcibly);
    }
    /**
     * @ignore
     */
    toggleNicknameForm() {
        var _a, _b;
        if ((_b = (_a = this._stream) === null || _a === void 0 ? void 0 : _a.participant) === null || _b === void 0 ? void 0 : _b.local) {
            this.toggleNickname = !this.toggleNickname;
        }
    }
    /**
     * @ignore
     */
    updateNickname(event) {
        if ((event === null || event === void 0 ? void 0 : event.keyCode) === 13 || (event === null || event === void 0 ? void 0 : event.type) === 'focusout') {
            if (!!this.nickname) {
                this.participantService.setMyNickname(this.nickname);
                this.storageService.setNickname(this.nickname);
                this.openviduService.sendSignal(Signal.NICKNAME_CHANGED, undefined, { clientData: this.nickname });
            }
            this.toggleNicknameForm();
        }
    }
    /**
     * @ignore
     */
    replaceScreenTrack() {
        return __awaiter(this, void 0, void 0, function* () {
            const properties = {
                videoSource: ScreenType.SCREEN,
                publishVideo: true,
                publishAudio: !this.participantService.isMyCameraActive(),
                mirror: false
            };
            yield this.openviduService.replaceTrack(VideoType.SCREEN, properties);
        });
    }
    checkVideoEnlarged() {
        this.videoSizeIcon = this._stream.videoEnlarged ? VideoSizeIcon.NORMAL : VideoSizeIcon.BIG;
    }
    subscribeToStreamDirectives() {
        this.minimalSub = this.libService.minimalObs.subscribe((value) => {
            this.isMinimal = value;
        });
        this.displayParticipantNameSub = this.libService.displayParticipantNameObs.subscribe((value) => {
            this.showNickname = value;
            // this.cd.markForCheck();
        });
        this.displayAudioDetectionSub = this.libService.displayAudioDetectionObs.subscribe((value) => {
            this.showAudioDetection = value;
            // this.cd.markForCheck();
        });
        this.settingsButtonSub = this.libService.streamSettingsButtonObs.subscribe((value) => {
            this.showSettingsButton = value;
            // this.cd.markForCheck();
        });
    }
}
StreamComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamComponent, deps: [{ token: OpenViduService }, { token: LayoutService }, { token: ParticipantService }, { token: StorageService }, { token: CdkOverlayService }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Component });
StreamComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: StreamComponent, selector: "ov-stream", inputs: { stream: "stream" }, viewQueries: [{ propertyName: "menuTrigger", first: true, predicate: MatMenuTrigger, descendants: true }, { propertyName: "menu", first: true, predicate: ["menu"], descendants: true }, { propertyName: "streamContainer", first: true, predicate: ["streamContainer"], descendants: true, read: ElementRef }, { propertyName: "nicknameInputElement", first: true, predicate: ["nicknameInput"], descendants: true }], ngImport: i0, template: "<div\n\t*ngIf=\"this._stream\"\n\tclass=\"OV_stream\"\n\t[ngClass]=\"{'no-size': !showVideo}\"\n\t[id]=\"'container-' + this._stream.streamManager?.stream?.streamId\"\n\t#streamContainer\n>\n\t<div *ngIf=\"!isMinimal && showNickname\" id=\"nickname-container\" class=\"nickname\" [class.fullscreen]=\"isFullscreen\">\n\t\t<div (click)=\"toggleNicknameForm()\" class=\"nicknameContainer\" selected *ngIf=\"!toggleNickname\">\n\t\t\t<span id=\"nickname\" *ngIf=\"this._stream.type === 'CAMERA'\">{{ this._stream.participant.nickname }}</span>\n\t\t\t<span id=\"nickname\" *ngIf=\"this._stream.type === 'SCREEN'\">{{ this._stream.participant.nickname }}_SCREEN</span>\n\t\t</div>\n\t\t<div *ngIf=\"toggleNickname && !this._stream.streamManager?.remote\" [class.fullscreen]=\"isFullscreen\" id=\"nickname-input-container\">\n\t\t\t<input\n\t\t\t\tmatInput\n\t\t\t\t#nicknameInput\n\t\t\t\tautocomplete=\"off\"\n\t\t\t\tmaxlength=\"20\"\n\t\t\t\t[(ngModel)]=\"this.nickname\"\n\t\t\t\t(keypress)=\"updateNickname($event)\"\n\t\t\t\t(focusout)=\"updateNickname($event)\"\n\t\t\t/>\n\t\t</div>\n\t</div>\n\n\t<div\n\t\t*ngIf=\"!isMinimal && showAudioDetection && _stream.type === 'CAMERA' && _stream.streamManager?.stream?.audioActive\"\n\t\tid=\"audio-wave-container\"\n\t>\n\t\t<ov-audio-wave [streamManager]=\"_stream.streamManager\"></ov-audio-wave>\n\t</div>\n\n\t<ov-avatar-profile\n\t\t*ngIf=\"!_stream.streamManager?.stream?.videoActive && _stream.type === 'CAMERA'\"\n\t\t[name]=\"_stream.participant.nickname\"\n\t\t[color]=\"_stream.participant.colorProfile\"\n\t></ov-avatar-profile>\n\n\t<ov-video\n\t\t(dblclick)=\"toggleVideoEnlarged()\"\n\t\t[streamManager]=\"_stream.streamManager\"\n\t\t[mutedSound]=\"_stream?.participant?.isMutedForcibly\"\n\t></ov-video>\n\n\t<div class=\"status-icons\">\n\t\t<button mat-icon-button id=\"statusMic\" *ngIf=\"!this._stream.streamManager?.stream?.audioActive\" disabled>\n\t\t\t<mat-icon>mic_off</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div *ngIf=\"!isMinimal && showSettingsButton\" id=\"settings-container\" class=\"videoButtons\">\n\t\t<button mat-icon-button (click)=\"toggleVideoMenu($event)\" matTooltip=\"{{ 'STREAM.SETTINGS' | translate }}\" matTooltipPosition=\"above\" aria-label=\"Video settings menu\">\n\t\t\t<mat-icon>more_vert</mat-icon>\n\t\t</button>\n\t\t<span [matMenuTriggerFor]=\"menu\"></span>\n\t\t<mat-menu #menu=\"matMenu\" yPosition=\"above\" xPosition=\"before\">\n\t\t\t<button mat-menu-item id=\"videoZoomButton\" (click)=\"toggleVideoEnlarged()\">\n\t\t\t\t<mat-icon>{{ this.videoSizeIcon }}</mat-icon>\n\t\t\t\t<span *ngIf=\"videoSizeIcon === videoSizeIconEnum.NORMAL\">{{ 'STREAM.ZOOM_OUT' | translate }}</span>\n\t\t\t\t<span *ngIf=\"videoSizeIcon === videoSizeIconEnum.BIG\">{{ 'STREAM.ZOOM_IN' | translate }}</span>\n\t\t\t</button>\n\t\t\t<button mat-menu-item id=\"volumeButton\" *ngIf=\"!this._stream.local\" (click)=\"toggleMuteForcibly()\">\n\t\t\t\t<mat-icon *ngIf=\"!_stream.participant.isMutedForcibly\">volume_up</mat-icon>\n\t\t\t\t<span *ngIf=\"!_stream.participant.isMutedForcibly\">{{ 'STREAM.MUTE_SOUND' | translate }}</span>\n\n\t\t\t\t<mat-icon *ngIf=\"_stream.participant.isMutedForcibly\">volume_off</mat-icon>\n\t\t\t\t<span *ngIf=\"_stream.participant.isMutedForcibly\">{{ 'STREAM.UNMUTE_SOUND' | translate }}</span>\n\t\t\t</button>\n\t\t\t<button\n\t\t\t\tmat-menu-item\n\t\t\t\t(click)=\"replaceScreenTrack()\"\n\t\t\t\tid=\"changeScreenButton\"\n\t\t\t\t*ngIf=\"!this._stream.streamManager?.remote && this._stream.streamManager?.stream?.typeOfVideo === videoTypeEnum.SCREEN\"\n\t\t\t>\n\t\t\t\t<mat-icon>picture_in_picture</mat-icon>\n\t\t\t\t<span>{{ 'STREAM.REPLACE_SCREEN' | translate }}</span>\n\t\t\t</button>\n\t\t</mat-menu>\n\t</div>\n</div>\n", styles: [".no-size{height:0px!important;width:0px!important}.nickname{padding:0;position:absolute;z-index:999;border-radius:var(--ov-video-radius);color:var(--ov-text-color);font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif}.nicknameContainer{background-color:var(--ov-secondary-color);padding:5px;color:var(--ov-text-color);font-weight:700;border-radius:var(--ov-video-radius)}#nickname-input-container{background-color:var(--ov-secondary-color);border-radius:var(--ov-video-radius)}#closeButton{position:absolute;top:-3px;right:0;z-index:999}#nicknameForm{padding:10px}#audio-wave-container{position:absolute;right:0;z-index:2;padding:5px}.fullscreen{top:40px}video{object-fit:cover;width:100%;height:100%;color:#fff;margin:0;padding:0;border:0;font-size:100%}.status-icons,#settings-container{position:absolute;bottom:0;z-index:10;text-align:center}.status-icons{left:0}.status-icons button,#settings-container button{color:var(--ov-text-color);width:26px;height:26px;margin:5px;border-radius:var(--ov-buttons-radius)}.status-icons button{background-color:var(--ov-warn-color)}.status-icons .mat-icon-button,#settings-container .mat-icon-button{line-height:0px}.status-icons mat-icon,#settings-container mat-icon{font-size:18px}#settings-container{right:0}#settings-container button{background-color:var(--ov-secondary-color)}.OV_stream{width:100%;height:100%;position:relative;overflow:hidden;background-color:transparent;border-radius:var(--ov-video-radius)}input{caret-color:#fff!important}\n"], components: [{ type: AudioWaveComponent, selector: "ov-audio-wave", inputs: ["streamManager"] }, { type: AvatarProfileComponent, selector: "ov-avatar-profile", inputs: ["name", "color"] }, { type: VideoComponent, selector: "ov-video", inputs: ["mutedSound", "streamManager"] }, { type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i18.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { type: i18.MatMenuItem, selector: "[mat-menu-item]", inputs: ["disabled", "disableRipple", "role"], exportAs: ["matMenuItem"] }], directives: [{ type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i10.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i2$1.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }, { type: i15$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { type: i9.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { type: i9.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { type: i9.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i9.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: i18.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-stream', template: "<div\n\t*ngIf=\"this._stream\"\n\tclass=\"OV_stream\"\n\t[ngClass]=\"{'no-size': !showVideo}\"\n\t[id]=\"'container-' + this._stream.streamManager?.stream?.streamId\"\n\t#streamContainer\n>\n\t<div *ngIf=\"!isMinimal && showNickname\" id=\"nickname-container\" class=\"nickname\" [class.fullscreen]=\"isFullscreen\">\n\t\t<div (click)=\"toggleNicknameForm()\" class=\"nicknameContainer\" selected *ngIf=\"!toggleNickname\">\n\t\t\t<span id=\"nickname\" *ngIf=\"this._stream.type === 'CAMERA'\">{{ this._stream.participant.nickname }}</span>\n\t\t\t<span id=\"nickname\" *ngIf=\"this._stream.type === 'SCREEN'\">{{ this._stream.participant.nickname }}_SCREEN</span>\n\t\t</div>\n\t\t<div *ngIf=\"toggleNickname && !this._stream.streamManager?.remote\" [class.fullscreen]=\"isFullscreen\" id=\"nickname-input-container\">\n\t\t\t<input\n\t\t\t\tmatInput\n\t\t\t\t#nicknameInput\n\t\t\t\tautocomplete=\"off\"\n\t\t\t\tmaxlength=\"20\"\n\t\t\t\t[(ngModel)]=\"this.nickname\"\n\t\t\t\t(keypress)=\"updateNickname($event)\"\n\t\t\t\t(focusout)=\"updateNickname($event)\"\n\t\t\t/>\n\t\t</div>\n\t</div>\n\n\t<div\n\t\t*ngIf=\"!isMinimal && showAudioDetection && _stream.type === 'CAMERA' && _stream.streamManager?.stream?.audioActive\"\n\t\tid=\"audio-wave-container\"\n\t>\n\t\t<ov-audio-wave [streamManager]=\"_stream.streamManager\"></ov-audio-wave>\n\t</div>\n\n\t<ov-avatar-profile\n\t\t*ngIf=\"!_stream.streamManager?.stream?.videoActive && _stream.type === 'CAMERA'\"\n\t\t[name]=\"_stream.participant.nickname\"\n\t\t[color]=\"_stream.participant.colorProfile\"\n\t></ov-avatar-profile>\n\n\t<ov-video\n\t\t(dblclick)=\"toggleVideoEnlarged()\"\n\t\t[streamManager]=\"_stream.streamManager\"\n\t\t[mutedSound]=\"_stream?.participant?.isMutedForcibly\"\n\t></ov-video>\n\n\t<div class=\"status-icons\">\n\t\t<button mat-icon-button id=\"statusMic\" *ngIf=\"!this._stream.streamManager?.stream?.audioActive\" disabled>\n\t\t\t<mat-icon>mic_off</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div *ngIf=\"!isMinimal && showSettingsButton\" id=\"settings-container\" class=\"videoButtons\">\n\t\t<button mat-icon-button (click)=\"toggleVideoMenu($event)\" matTooltip=\"{{ 'STREAM.SETTINGS' | translate }}\" matTooltipPosition=\"above\" aria-label=\"Video settings menu\">\n\t\t\t<mat-icon>more_vert</mat-icon>\n\t\t</button>\n\t\t<span [matMenuTriggerFor]=\"menu\"></span>\n\t\t<mat-menu #menu=\"matMenu\" yPosition=\"above\" xPosition=\"before\">\n\t\t\t<button mat-menu-item id=\"videoZoomButton\" (click)=\"toggleVideoEnlarged()\">\n\t\t\t\t<mat-icon>{{ this.videoSizeIcon }}</mat-icon>\n\t\t\t\t<span *ngIf=\"videoSizeIcon === videoSizeIconEnum.NORMAL\">{{ 'STREAM.ZOOM_OUT' | translate }}</span>\n\t\t\t\t<span *ngIf=\"videoSizeIcon === videoSizeIconEnum.BIG\">{{ 'STREAM.ZOOM_IN' | translate }}</span>\n\t\t\t</button>\n\t\t\t<button mat-menu-item id=\"volumeButton\" *ngIf=\"!this._stream.local\" (click)=\"toggleMuteForcibly()\">\n\t\t\t\t<mat-icon *ngIf=\"!_stream.participant.isMutedForcibly\">volume_up</mat-icon>\n\t\t\t\t<span *ngIf=\"!_stream.participant.isMutedForcibly\">{{ 'STREAM.MUTE_SOUND' | translate }}</span>\n\n\t\t\t\t<mat-icon *ngIf=\"_stream.participant.isMutedForcibly\">volume_off</mat-icon>\n\t\t\t\t<span *ngIf=\"_stream.participant.isMutedForcibly\">{{ 'STREAM.UNMUTE_SOUND' | translate }}</span>\n\t\t\t</button>\n\t\t\t<button\n\t\t\t\tmat-menu-item\n\t\t\t\t(click)=\"replaceScreenTrack()\"\n\t\t\t\tid=\"changeScreenButton\"\n\t\t\t\t*ngIf=\"!this._stream.streamManager?.remote && this._stream.streamManager?.stream?.typeOfVideo === videoTypeEnum.SCREEN\"\n\t\t\t>\n\t\t\t\t<mat-icon>picture_in_picture</mat-icon>\n\t\t\t\t<span>{{ 'STREAM.REPLACE_SCREEN' | translate }}</span>\n\t\t\t</button>\n\t\t</mat-menu>\n\t</div>\n</div>\n", styles: [".no-size{height:0px!important;width:0px!important}.nickname{padding:0;position:absolute;z-index:999;border-radius:var(--ov-video-radius);color:var(--ov-text-color);font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif}.nicknameContainer{background-color:var(--ov-secondary-color);padding:5px;color:var(--ov-text-color);font-weight:700;border-radius:var(--ov-video-radius)}#nickname-input-container{background-color:var(--ov-secondary-color);border-radius:var(--ov-video-radius)}#closeButton{position:absolute;top:-3px;right:0;z-index:999}#nicknameForm{padding:10px}#audio-wave-container{position:absolute;right:0;z-index:2;padding:5px}.fullscreen{top:40px}video{object-fit:cover;width:100%;height:100%;color:#fff;margin:0;padding:0;border:0;font-size:100%}.status-icons,#settings-container{position:absolute;bottom:0;z-index:10;text-align:center}.status-icons{left:0}.status-icons button,#settings-container button{color:var(--ov-text-color);width:26px;height:26px;margin:5px;border-radius:var(--ov-buttons-radius)}.status-icons button{background-color:var(--ov-warn-color)}.status-icons .mat-icon-button,#settings-container .mat-icon-button{line-height:0px}.status-icons mat-icon,#settings-container mat-icon{font-size:18px}#settings-container{right:0}#settings-container button{background-color:var(--ov-secondary-color)}.OV_stream{width:100%;height:100%;position:relative;overflow:hidden;background-color:transparent;border-radius:var(--ov-video-radius)}input{caret-color:#fff!important}\n"] }]
        }], ctorParameters: function () { return [{ type: OpenViduService }, { type: LayoutService }, { type: ParticipantService }, { type: StorageService }, { type: CdkOverlayService }, { type: OpenViduAngularConfigService }]; }, propDecorators: { menuTrigger: [{
                type: ViewChild,
                args: [MatMenuTrigger]
            }], menu: [{
                type: ViewChild,
                args: ['menu']
            }], streamContainer: [{
                type: ViewChild,
                args: ['streamContainer', { static: false, read: ElementRef }]
            }], stream: [{
                type: Input
            }], nicknameInputElement: [{
                type: ViewChild,
                args: ['nicknameInput']
            }] } });

/**
 * @internal
 */
class DurationFromSecondsPipe {
    transform(durationInSeconds) {
        if (durationInSeconds < 60) {
            return Math.floor(durationInSeconds) + 's';
        }
        else if (durationInSeconds < 3600) {
            return Math.floor(durationInSeconds / 60) + 'm ' + Math.floor(durationInSeconds % 60) + 's';
        }
        else {
            const hours = Math.floor(durationInSeconds / 3600);
            const minutes = Math.floor((durationInSeconds - hours * 3600) / 60);
            return hours + 'h ' + minutes + 'm';
        }
    }
}
DurationFromSecondsPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DurationFromSecondsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
DurationFromSecondsPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DurationFromSecondsPipe, name: "duration" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: DurationFromSecondsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'duration'
                }]
        }] });
/**
 * @internal
 */
class SearchByStringPropertyPipe {
    transform(items, props) {
        if (!items || !props || props.properties.length === 0 || !props.filter) {
            return items;
        }
        return items.filter(item => {
            return props.properties.some(prop => {
                const multipleProps = prop.split('.');
                let recursiveProp = item;
                try {
                    multipleProps.forEach(p => {
                        recursiveProp = recursiveProp[p];
                        if (recursiveProp === null || recursiveProp === undefined) {
                            throw new Error('Property not found');
                        }
                    });
                }
                catch (error) {
                    return false;
                }
                return recursiveProp.indexOf(props.filter) !== -1;
            });
        });
    }
}
SearchByStringPropertyPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: SearchByStringPropertyPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
SearchByStringPropertyPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: SearchByStringPropertyPipe, name: "searchByStringProperty" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: SearchByStringPropertyPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'searchByStringProperty'
                }]
        }] });
/**
 * @internal
 */
class ThumbnailFromUrlPipe {
    transform(url) {
        if (url.includes('.mp4')) {
            const lastPart = url.split('/').pop();
            let thumbnailUrl = lastPart === null || lastPart === void 0 ? void 0 : lastPart.replace('mp4', 'jpg');
            thumbnailUrl = `recordings/${thumbnailUrl === null || thumbnailUrl === void 0 ? void 0 : thumbnailUrl.split('.')[0]}/${thumbnailUrl}`;
            return thumbnailUrl;
        }
        return '';
    }
}
ThumbnailFromUrlPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ThumbnailFromUrlPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
ThumbnailFromUrlPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ThumbnailFromUrlPipe, name: "thumbnailUrl" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ThumbnailFromUrlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'thumbnailUrl'
                }]
        }] });

/**
 *
 * The **ParticipantPanelItemComponent** is hosted inside of the {@link ParticipantsPanelComponent}.
 * It is in charge of displaying the participants information inside of the ParticipansPanelComponent.
 *
 * <div class="custom-table-container">
 * <div>
 *  <h3>API Directives</h3>
 *
 * This component allows us to show or hide certain HTML elements with the following {@link https://angular.io/guide/attribute-directives Angular attribute directives}
 * with the aim of fully customizing the ToolbarComponent.
 *
 * | **Name**                  | **Type**  | **Reference**                                   |
 * | :----------------------------: | :-------: | :---------------------------------------------: |
 * | **muteButton** | `boolean` | {@link ParticipantPanelItemMuteButtonDirective} |
 *
 * <p class="component-link-text">
 * <span class="italic">See all {@link ApiDirectiveModule API Directives}</span>
 * </p>
 *
 * </div>
 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The ParticipantPanelItemComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |     ***ovParticipantPanelItem**     |     {@link ParticipantPanelItemDirective}     |
 *
 * </br>
 *
 * It is also providing us a way to **add additional buttons** to the default participant panel item.
 * It will recognise the following directive in a child element.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * | ***ovParticipantPanelItemElements** | {@link ParticipantPanelItemElementsDirective} |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
class ParticipantPanelItemComponent {
    /**
     * @ignore
     */
    constructor(libService, participantService, cd) {
        this.libService = libService;
        this.participantService = participantService;
        this.cd = cd;
        /**
         * @ignore
         */
        this.showMuteButton = true;
    }
    /**
     * @ignore
     */
    set externalItemElements(externalItemElements) {
        // This directive will has value only when ITEM ELEMENTS component tagget with '*ovParticipantPanelItemElements' directive
        // is inside of the P PANEL ITEM component tagged with '*ovParticipantPanelItem' directive
        if (externalItemElements) {
            this.participantPanelItemElementsTemplate = externalItemElements.template;
        }
    }
    set participant(participant) {
        this._participant = participant;
    }
    ngOnInit() {
        this.subscribeToParticipantPanelItemDirectives();
    }
    ngOnDestroy() {
        if (this.muteButtonSub)
            this.muteButtonSub.unsubscribe();
    }
    /**
     * @ignore
     */
    toggleMuteForcibly() {
        this.participantService.setRemoteMutedForcibly(this._participant.id, !this._participant.isMutedForcibly);
    }
    subscribeToParticipantPanelItemDirectives() {
        this.muteButtonSub = this.libService.participantItemMuteButton.subscribe((value) => {
            this.showMuteButton = value;
            this.cd.markForCheck();
        });
    }
}
ParticipantPanelItemComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantPanelItemComponent, deps: [{ token: OpenViduAngularConfigService }, { token: ParticipantService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
ParticipantPanelItemComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: ParticipantPanelItemComponent, selector: "ov-participant-panel-item", inputs: { participant: "participant" }, queries: [{ propertyName: "participantPanelItemElementsTemplate", first: true, predicate: ["participantPanelItemElements"], descendants: true, read: TemplateRef }, { propertyName: "externalItemElements", first: true, predicate: ParticipantPanelItemElementsDirective, descendants: true }], ngImport: i0, template: "<mat-list>\n\t<mat-list-item>\n\t\t<mat-icon matListAvatar class=\"participant-avatar\">person</mat-icon>\n\t\t<h3 matLine class=\"participant-nickname\">{{ _participant.nickname }}</h3>\n\t\t<p matLine class=\"participant-subtitle\">{{ _participant | streamTypesEnabled }}</p>\n\t\t<!-- <p matLine>\n\t\t\t<span class=\"participant-subtitle\"></span>\n\t\t</p> -->\n\n\t\t<div class=\"participant-action-buttons\">\n\t\t\t<button\n\t\t\t\tmat-icon-button\n\t\t\t\tid=\"mute-btn\"\n\t\t\t\t*ngIf=\"!_participant.local && showMuteButton\"\n\t\t\t\t[class.warn-btn]=\"_participant.isMutedForcibly\"\n\t\t\t\t(click)=\"toggleMuteForcibly()\"\n\t\t\t>\n\t\t\t\t<mat-icon *ngIf=\"!_participant.isMutedForcibly\">volume_up</mat-icon>\n\t\t\t\t<mat-icon *ngIf=\"_participant.isMutedForcibly\">volume_off</mat-icon>\n\t\t\t</button>\n\n\t\t\t<!-- External item elements  -->\n\t\t\t<ng-container *ngIf=\"participantPanelItemElementsTemplate\">\n\t\t\t\t<ng-container *ngTemplateOutlet=\"participantPanelItemElementsTemplate\"></ng-container>\n\t\t\t</ng-container>\n\t\t</div>\n\t</mat-list-item>\n</mat-list>\n", styles: [".participant-subtitle{font-style:italic;font-size:11px!important}.participant-nickname{font-weight:700!important}.participant-action-buttons{display:flex}::ng-deep .participant-action-buttons>*:not(#mute-btn){display:contents}::ng-deep .participant-action-buttons>*:not(#mute-btn)>*{margin:auto}mat-list-item{height:max-content!important;padding-bottom:10px!important}mat-list{padding:3px}.participant-avatar{display:contents}#mute-btn{border-radius:var(--ov-buttons-radius)}.warn-btn{color:var(--ov-warn-color)}\n"], components: [{ type: i5$1.MatList, selector: "mat-list, mat-action-list", inputs: ["disableRipple", "disabled"], exportAs: ["matList"] }, { type: i5$1.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["disableRipple", "disabled"], exportAs: ["matListItem"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }], directives: [{ type: i5$1.MatListAvatarCssMatStyler, selector: "[mat-list-avatar], [matListAvatar]" }, { type: i6$1.MatLine, selector: "[mat-line], [matLine]" }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i10.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }], pipes: { "streamTypesEnabled": StreamTypesEnabledPipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantPanelItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-participant-panel-item', changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-list>\n\t<mat-list-item>\n\t\t<mat-icon matListAvatar class=\"participant-avatar\">person</mat-icon>\n\t\t<h3 matLine class=\"participant-nickname\">{{ _participant.nickname }}</h3>\n\t\t<p matLine class=\"participant-subtitle\">{{ _participant | streamTypesEnabled }}</p>\n\t\t<!-- <p matLine>\n\t\t\t<span class=\"participant-subtitle\"></span>\n\t\t</p> -->\n\n\t\t<div class=\"participant-action-buttons\">\n\t\t\t<button\n\t\t\t\tmat-icon-button\n\t\t\t\tid=\"mute-btn\"\n\t\t\t\t*ngIf=\"!_participant.local && showMuteButton\"\n\t\t\t\t[class.warn-btn]=\"_participant.isMutedForcibly\"\n\t\t\t\t(click)=\"toggleMuteForcibly()\"\n\t\t\t>\n\t\t\t\t<mat-icon *ngIf=\"!_participant.isMutedForcibly\">volume_up</mat-icon>\n\t\t\t\t<mat-icon *ngIf=\"_participant.isMutedForcibly\">volume_off</mat-icon>\n\t\t\t</button>\n\n\t\t\t<!-- External item elements  -->\n\t\t\t<ng-container *ngIf=\"participantPanelItemElementsTemplate\">\n\t\t\t\t<ng-container *ngTemplateOutlet=\"participantPanelItemElementsTemplate\"></ng-container>\n\t\t\t</ng-container>\n\t\t</div>\n\t</mat-list-item>\n</mat-list>\n", styles: [".participant-subtitle{font-style:italic;font-size:11px!important}.participant-nickname{font-weight:700!important}.participant-action-buttons{display:flex}::ng-deep .participant-action-buttons>*:not(#mute-btn){display:contents}::ng-deep .participant-action-buttons>*:not(#mute-btn)>*{margin:auto}mat-list-item{height:max-content!important;padding-bottom:10px!important}mat-list{padding:3px}.participant-avatar{display:contents}#mute-btn{border-radius:var(--ov-buttons-radius)}.warn-btn{color:var(--ov-warn-color)}\n"] }]
        }], ctorParameters: function () { return [{ type: OpenViduAngularConfigService }, { type: ParticipantService }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { participantPanelItemElementsTemplate: [{
                type: ContentChild,
                args: ['participantPanelItemElements', { read: TemplateRef }]
            }], externalItemElements: [{
                type: ContentChild,
                args: [ParticipantPanelItemElementsDirective]
            }], participant: [{
                type: Input
            }] } });

/**
 *
 * The **ParticipantsPanelComponent** is hosted inside of the {@link PanelComponent}.
 * It is in charge of displaying the participants connected to the session.
 * This component is composed by the {@link ParticipantPanelItemComponent}.
 *
 * <div class="custom-table-container">
 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The ParticipantsPanelComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |       ***ovParticipantsPanel**      |       {@link ParticipantsPanelDirective}      |
 *
 * </br>
 *
 * As the ParticipantsPanelComponent is composed by ParticipantPanelItemComponent, it is also providing us a way to **replace the participant item** with a custom one.
 * It will recognise the following directive in a child element.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |     ***ovParticipantPanelItem**     |     {@link ParticipantPanelItemDirective}     |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
class ParticipantsPanelComponent {
    /**
     * @ignore
     */
    constructor(participantService, panelService, cd) {
        this.participantService = participantService;
        this.panelService = panelService;
        this.cd = cd;
        this.remoteParticipants = [];
    }
    set externalParticipantPanelItem(externalParticipantPanelItem) {
        // This directive will has value only when PARTICIPANT PANEL ITEM component tagged with '*ovParticipantPanelItem'
        // is inside of the PARTICIPANTS PANEL component tagged with '*ovParticipantsPanel'
        if (externalParticipantPanelItem) {
            this.participantPanelItemTemplate = externalParticipantPanelItem.template;
        }
    }
    ngOnInit() {
        this.localParticipantSubs = this.participantService.localParticipantObs.subscribe((p) => {
            this.localParticipant = p;
            // Mark for re-rendering using an impure pipe 'streamsTypesEnabled'
            this.cd.markForCheck();
        });
        this.remoteParticipantsSubs = this.participantService.remoteParticipantsObs.subscribe((p) => {
            // Workaround which forc the objects references update
            // After one entirely day trying to make it works, this is the only way
            const remoteParticipantsAux = [];
            p.forEach((par) => {
                remoteParticipantsAux.push(Object.create(par));
            });
            this.remoteParticipants = remoteParticipantsAux;
            // Mark for re-rendering using an impure pipe 'streamsTypesEnabled'
            this.cd.markForCheck();
        });
    }
    ngOnDestroy() {
        if (this.localParticipantSubs)
            this.localParticipantSubs.unsubscribe();
        if (this.remoteParticipantsSubs)
            this.remoteParticipantsSubs.unsubscribe;
    }
    ngAfterViewInit() {
        if (!this.participantPanelItemTemplate) {
            // the user has override the default participants panel but not the 'participant-panel-item'
            // so the default component must be injected
            this.participantPanelItemTemplate = this.defaultParticipantPanelItemTemplate;
            this.cd.detectChanges();
        }
    }
    close() {
        this.panelService.closePanel();
    }
}
ParticipantsPanelComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantsPanelComponent, deps: [{ token: ParticipantService }, { token: PanelService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
ParticipantsPanelComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: ParticipantsPanelComponent, selector: "ov-participants-panel", queries: [{ propertyName: "participantPanelItemTemplate", first: true, predicate: ["participantPanelItem"], descendants: true, read: TemplateRef }, { propertyName: "externalParticipantPanelItem", first: true, predicate: ParticipantPanelItemDirective, descendants: true }], viewQueries: [{ propertyName: "defaultParticipantPanelItemTemplate", first: true, predicate: ["defaultParticipantPanelItem"], descendants: true, read: TemplateRef }], ngImport: i0, template: "<div class=\"panel-container\" id=\"participants-container\">\n\t<div class=\"panel-header-container\">\n\t\t<h3 class=\"panel-title\">{{ 'PANEL.PARTICIPANTS.TITLE' | translate }}</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"scrollable\">\n\n\t\t<div class=\"local-participant-container\" *ngIf=\"localParticipant\">\n\t\t\t<ng-container *ngTemplateOutlet=\"participantPanelItemTemplate; context: { $implicit: localParticipant }\"></ng-container>\n\t\t\t<mat-divider *ngIf=\"true\"></mat-divider>\n\t\t</div>\n\n\t\t<div class=\"remote-participants-container\" id=\"remote-participants-container\" *ngIf=\"remoteParticipants.length > 0\">\n\n\t\t\t<div *ngFor=\"let participant of this.remoteParticipants\" id=\"remote-participant-item\">\n\t\t\t\t<ng-container *ngTemplateOutlet=\"participantPanelItemTemplate; context: { $implicit: participant }\"></ng-container>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n\n<ng-template #defaultParticipantPanelItem let-participant>\n\t<ov-participant-panel-item [participant]=\"participant\" id=\"default-participant-panel-item\"></ov-participant-panel-item>\n</ng-template>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".local-participant-container,.remote-participants-container{margin:5px 10px}.scrollable{height:calc(100% - 60px);max-height:calc(100% - 60px);overflow:auto}.message-container{padding:5px;background-color:var(--ov-light-color);color:var(--ov-panel-text-color);text-align:center;margin:5px;font-size:12px}.message-container p{margin:0}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i19.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { type: ParticipantPanelItemComponent, selector: "ov-participant-panel-item", inputs: ["participant"] }], directives: [{ type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i10.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }], pipes: { "translate": TranslatePipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantsPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-participants-panel', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"panel-container\" id=\"participants-container\">\n\t<div class=\"panel-header-container\">\n\t\t<h3 class=\"panel-title\">{{ 'PANEL.PARTICIPANTS.TITLE' | translate }}</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"scrollable\">\n\n\t\t<div class=\"local-participant-container\" *ngIf=\"localParticipant\">\n\t\t\t<ng-container *ngTemplateOutlet=\"participantPanelItemTemplate; context: { $implicit: localParticipant }\"></ng-container>\n\t\t\t<mat-divider *ngIf=\"true\"></mat-divider>\n\t\t</div>\n\n\t\t<div class=\"remote-participants-container\" id=\"remote-participants-container\" *ngIf=\"remoteParticipants.length > 0\">\n\n\t\t\t<div *ngFor=\"let participant of this.remoteParticipants\" id=\"remote-participant-item\">\n\t\t\t\t<ng-container *ngTemplateOutlet=\"participantPanelItemTemplate; context: { $implicit: participant }\"></ng-container>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n\n<ng-template #defaultParticipantPanelItem let-participant>\n\t<ov-participant-panel-item [participant]=\"participant\" id=\"default-participant-panel-item\"></ov-participant-panel-item>\n</ng-template>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".local-participant-container,.remote-participants-container{margin:5px 10px}.scrollable{height:calc(100% - 60px);max-height:calc(100% - 60px);overflow:auto}.message-container{padding:5px;background-color:var(--ov-light-color);color:var(--ov-panel-text-color);text-align:center;margin:5px;font-size:12px}.message-container p{margin:0}\n"] }]
        }], ctorParameters: function () { return [{ type: ParticipantService }, { type: PanelService }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { defaultParticipantPanelItemTemplate: [{
                type: ViewChild,
                args: ['defaultParticipantPanelItem', { static: false, read: TemplateRef }]
            }], participantPanelItemTemplate: [{
                type: ContentChild,
                args: ['participantPanelItem', { read: TemplateRef }]
            }], externalParticipantPanelItem: [{
                type: ContentChild,
                args: [ParticipantPanelItemDirective]
            }] } });

/**
 * @internal
 */
class LangSelectorComponent {
    constructor(translateService, storageSrv) {
        this.translateService = translateService;
        this.storageSrv = storageSrv;
        this.onLangSelectorClicked = new EventEmitter();
        this.languages = [];
    }
    ngOnInit() {
        this.languages = this.translateService.getLanguagesInfo();
        this.langSelected = this.translateService.getLangSelected();
    }
    ngAfterViewInit() {
        var _a, _b;
        (_a = this.menuTrigger) === null || _a === void 0 ? void 0 : _a.menuOpened.subscribe(() => {
            this.onLangSelectorClicked.emit();
        });
        (_b = this.matSelect) === null || _b === void 0 ? void 0 : _b.openedChange.subscribe(() => {
            this.onLangSelectorClicked.emit();
        });
    }
    onLangSelected(lang) {
        this.translateService.setLanguage(lang);
        this.storageSrv.setLang(lang);
        this.langSelected = this.translateService.getLangSelected();
    }
}
LangSelectorComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LangSelectorComponent, deps: [{ token: TranslateService }, { token: StorageService }], target: i0.ɵɵFactoryTarget.Component });
LangSelectorComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: LangSelectorComponent, selector: "ov-lang-selector", outputs: { onLangSelectorClicked: "onLangSelectorClicked" }, viewQueries: [{ propertyName: "menuTrigger", first: true, predicate: MatMenuTrigger, descendants: true }, { propertyName: "matSelect", first: true, predicate: MatSelect, descendants: true }], ngImport: i0, template: "<button mat-flat-button [matMenuTriggerFor]=\"menu\" class=\"lang-button\">\n\t<span>{{langSelected?.name}}</span>\n\t<mat-icon>expand_more</mat-icon>\n</button>\n<mat-menu #menu=\"matMenu\">\n\t<button mat-menu-item *ngFor=\"let lang of languages\" (click)=\"onLangSelected(lang.ISO)\">\n\t\t<span>{{lang.name}}</span>\n\t</button>\n</mat-menu>", styles: [".lang-button{background-color:var(--ov-logo-background-color);color:var(--ov-text-color)}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i18.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { type: i18.MatMenuItem, selector: "[mat-menu-item]", inputs: ["disabled", "disableRipple", "role"], exportAs: ["matMenuItem"] }], directives: [{ type: i18.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LangSelectorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-lang-selector', template: "<button mat-flat-button [matMenuTriggerFor]=\"menu\" class=\"lang-button\">\n\t<span>{{langSelected?.name}}</span>\n\t<mat-icon>expand_more</mat-icon>\n</button>\n<mat-menu #menu=\"matMenu\">\n\t<button mat-menu-item *ngFor=\"let lang of languages\" (click)=\"onLangSelected(lang.ISO)\">\n\t\t<span>{{lang.name}}</span>\n\t</button>\n</mat-menu>", styles: [".lang-button{background-color:var(--ov-logo-background-color);color:var(--ov-text-color)}\n"] }]
        }], ctorParameters: function () { return [{ type: TranslateService }, { type: StorageService }]; }, propDecorators: { onLangSelectorClicked: [{
                type: Output
            }], menuTrigger: [{
                type: ViewChild,
                args: [MatMenuTrigger]
            }], matSelect: [{
                type: ViewChild,
                args: [MatSelect]
            }] } });

/**
 *
 * The **PanelComponent** is hosted inside of the {@link VideoconferenceComponent}.
 * It is in charge of displaying the videoconference panels providing functionalities to the videoconference app
 * such as the chat ({@link ChatPanelComponent}) and list of participants ({@link ParticipantsPanelComponent}) .
 *
 * <div class="custom-table-container">

 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 * The PanelComponent can be replaced with a custom component. It provides us the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * for doing this.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovPanel**           |            {@link PanelDirective}           |
 *
 * </br>
 *
 * It is also providing us a way to **replace the children panels** to the default panel.
 * It will recognise the following directive in a child element.
 *
 * |            **Directive**           |                 **Reference**                 |
 * |:----------------------------------:|:---------------------------------------------:|
 * |           ***ovChatPanel**          |           {@link ChatPanelDirective}          |
 * |       ***ovParticipantsPanel**      |       {@link ParticipantsPanelDirective}      |
 * |        ***ovAdditionalPanels**      |       {@link AdditionalPanelsDirective}       |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
class PanelComponent {
    /**
     * @ignore
     */
    constructor(panelService, cd) {
        this.panelService = panelService;
        this.cd = cd;
    }
    set externalParticipantPanel(externalParticipantsPanel) {
        // This directive will has value only when PARTICIPANTS PANEL component tagged with '*ovParticipantsPanel'
        // is inside of the PANEL component tagged with '*ovPanel'
        if (externalParticipantsPanel) {
            this.participantsPanelTemplate = externalParticipantsPanel.template;
        }
    }
    // TODO: backgroundEffectsPanel does not provides customization
    // @ContentChild(BackgroundEffectsPanelDirective)
    // set externalBackgroundEffectsPanel(externalBackgroundEffectsPanel: BackgroundEffectsPanelDirective) {
    // This directive will has value only when BACKGROUND EFFECTS PANEL component tagged with '*ovBackgroundEffectsPanel'
    // is inside of the PANEL component tagged with '*ovPanel'
    // if (externalBackgroundEffectsPanel) {
    // 	this.backgroundEffectsPanelTemplate = externalBackgroundEffectsPanel.template;
    // }
    // }
    // TODO: settingsPanel does not provides customization
    // @ContentChild(SettingsPanelDirective)
    // set externalSettingsPanel(externalSettingsPanel: SettingsPanelDirective) {
    // This directive will has value only when SETTINGS PANEL component tagged with '*ovSettingsPanel'
    // is inside of the PANEL component tagged with '*ovPanel'
    // if (externalSettingsPanel) {
    // 	this.settingsPanelTemplate = externalSettingsPanel.template;
    // }
    // }
    set externalActivitiesPanel(externalActivitiesPanel) {
        // This directive will has value only when ACTIVITIES PANEL component tagged with '*ovActivitiesPanel'
        // is inside of the PANEL component tagged with '*ovPanel'
        if (externalActivitiesPanel) {
            this.activitiesPanelTemplate = externalActivitiesPanel.template;
        }
    }
    set externalChatPanel(externalChatPanel) {
        // This directive will has value only when CHAT PANEL component tagged with '*ovChatPanel'
        // is inside of the PANEL component tagged with '*ovPanel'
        if (externalChatPanel) {
            this.chatPanelTemplate = externalChatPanel.template;
        }
    }
    set externalAdditionalPanels(externalAdditionalPanels) {
        // This directive will has value only when ADDITIONAL PANELS component tagged with '*ovPanelAdditionalPanels'
        // is inside of the PANEL component tagged with '*ovPanel'
        if (externalAdditionalPanels) {
            this.additionalPanelsTemplate = externalAdditionalPanels.template;
        }
    }
    ngOnInit() {
        this.subscribeToPanelToggling();
    }
    ngOnDestroy() {
        this.isChatPanelOpened = false;
        this.isParticipantsPanelOpened = false;
        if (this.panelSubscription)
            this.panelSubscription.unsubscribe();
    }
    subscribeToPanelToggling() {
        this.panelSubscription = this.panelService.panelOpenedObs.pipe(skip(1)).subscribe((ev) => {
            this.isChatPanelOpened = ev.opened && ev.type === PanelType.CHAT;
            this.isParticipantsPanelOpened = ev.opened && ev.type === PanelType.PARTICIPANTS;
            this.isBackgroundEffectsPanelOpened = ev.opened && ev.type === PanelType.BACKGROUND_EFFECTS;
            this.isSettingsPanelOpened = ev.opened && ev.type === PanelType.SETTINGS;
            this.isActivitiesPanelOpened = ev.opened && ev.type === PanelType.ACTIVITIES;
            this.isExternalPanelOpened = ev.opened && ev.type !== PanelType.PARTICIPANTS && ev.type !== PanelType.CHAT;
            this.cd.markForCheck();
        });
    }
}
PanelComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PanelComponent, deps: [{ token: PanelService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
PanelComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: PanelComponent, selector: "ov-panel", queries: [{ propertyName: "participantsPanelTemplate", first: true, predicate: ["participantsPanel"], descendants: true, read: TemplateRef }, { propertyName: "backgroundEffectsPanelTemplate", first: true, predicate: ["backgroundEffectsPanel"], descendants: true, read: TemplateRef }, { propertyName: "settingsPanelTemplate", first: true, predicate: ["settingsPanel"], descendants: true, read: TemplateRef }, { propertyName: "activitiesPanelTemplate", first: true, predicate: ["activitiesPanel"], descendants: true, read: TemplateRef }, { propertyName: "chatPanelTemplate", first: true, predicate: ["chatPanel"], descendants: true, read: TemplateRef }, { propertyName: "additionalPanelsTemplate", first: true, predicate: ["additionalPanels"], descendants: true, read: TemplateRef }, { propertyName: "externalParticipantPanel", first: true, predicate: ParticipantsPanelDirective, descendants: true }, { propertyName: "externalActivitiesPanel", first: true, predicate: ActivitiesPanelDirective, descendants: true }, { propertyName: "externalChatPanel", first: true, predicate: ChatPanelDirective, descendants: true }, { propertyName: "externalAdditionalPanels", first: true, predicate: AdditionalPanelsDirective, descendants: true }], ngImport: i0, template: "<!-- CHAT panel -->\n<ng-container *ngIf=\"isChatPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"chatPanelTemplate\"></ng-container>\n</ng-container>\n\n\n<!-- PARTICIPANTS panel -->\n<ng-container *ngIf=\"isParticipantsPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"participantsPanelTemplate\"></ng-container>\n</ng-container>\n\n<!-- Background effects panel -->\n<ng-container *ngIf=\"isBackgroundEffectsPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"backgroundEffectsPanelTemplate\"></ng-container>\n</ng-container>\n\n<!-- Settings panel -->\n<ng-container *ngIf=\"isSettingsPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"settingsPanelTemplate\"></ng-container>\n</ng-container>\n\n<!-- Activities panel -->\n<ng-container *ngIf=\"isActivitiesPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"activitiesPanelTemplate\"></ng-container>\n</ng-container>\n\n<!-- External additional panels  -->\n<ng-container *ngIf=\"additionalPanelsTemplate && isExternalPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"additionalPanelsTemplate\"></ng-container>\n</ng-container>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n"], directives: [{ type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i10.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-panel', changeDetection: ChangeDetectionStrategy.OnPush, template: "<!-- CHAT panel -->\n<ng-container *ngIf=\"isChatPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"chatPanelTemplate\"></ng-container>\n</ng-container>\n\n\n<!-- PARTICIPANTS panel -->\n<ng-container *ngIf=\"isParticipantsPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"participantsPanelTemplate\"></ng-container>\n</ng-container>\n\n<!-- Background effects panel -->\n<ng-container *ngIf=\"isBackgroundEffectsPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"backgroundEffectsPanelTemplate\"></ng-container>\n</ng-container>\n\n<!-- Settings panel -->\n<ng-container *ngIf=\"isSettingsPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"settingsPanelTemplate\"></ng-container>\n</ng-container>\n\n<!-- Activities panel -->\n<ng-container *ngIf=\"isActivitiesPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"activitiesPanelTemplate\"></ng-container>\n</ng-container>\n\n<!-- External additional panels  -->\n<ng-container *ngIf=\"additionalPanelsTemplate && isExternalPanelOpened\">\n\t<ng-container *ngTemplateOutlet=\"additionalPanelsTemplate\"></ng-container>\n</ng-container>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n"] }]
        }], ctorParameters: function () { return [{ type: PanelService }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { participantsPanelTemplate: [{
                type: ContentChild,
                args: ['participantsPanel', { read: TemplateRef }]
            }], backgroundEffectsPanelTemplate: [{
                type: ContentChild,
                args: ['backgroundEffectsPanel', { read: TemplateRef }]
            }], settingsPanelTemplate: [{
                type: ContentChild,
                args: ['settingsPanel', { read: TemplateRef }]
            }], activitiesPanelTemplate: [{
                type: ContentChild,
                args: ['activitiesPanel', { read: TemplateRef }]
            }], chatPanelTemplate: [{
                type: ContentChild,
                args: ['chatPanel', { read: TemplateRef }]
            }], additionalPanelsTemplate: [{
                type: ContentChild,
                args: ['additionalPanels', { read: TemplateRef }]
            }], externalParticipantPanel: [{
                type: ContentChild,
                args: [ParticipantsPanelDirective]
            }], externalActivitiesPanel: [{
                type: ContentChild,
                args: [ActivitiesPanelDirective]
            }], externalChatPanel: [{
                type: ContentChild,
                args: [ChatPanelDirective]
            }], externalAdditionalPanels: [{
                type: ContentChild,
                args: [AdditionalPanelsDirective]
            }] } });

/**
 * @internal
 */
var EffectType;
(function (EffectType) {
    EffectType["NONE"] = "NONE";
    EffectType["BLUR"] = "BLUR";
    EffectType["IMAGE"] = "IMAGE";
})(EffectType || (EffectType = {}));

/**
 * @internal
 */
class VirtualBackgroundService {
    constructor(participantService, translateService, tokenService) {
        this.participantService = participantService;
        this.translateService = translateService;
        this.tokenService = tokenService;
        this.backgroundSelected = new BehaviorSubject('');
        this.backgrounds = [
            { id: 'no_effect', type: EffectType.NONE, thumbnail: 'block' },
            { id: 'soft_blur', type: EffectType.BLUR, thumbnail: 'blur_on' },
            { id: '1', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-1.jpg', src: 'assets/backgrounds/bg-1.jpg' },
            { id: '2', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-2.jpg', src: 'assets/backgrounds/bg-2.jpg' },
            { id: '3', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-3.jpg', src: 'assets/backgrounds/bg-3.jpg' },
            { id: '4', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-4.jpg', src: 'assets/backgrounds/bg-4.jpg' },
            { id: '19', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-19.jpg', src: 'assets/backgrounds/bg-19.jpg' },
            { id: '5', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-5.jpg', src: 'assets/backgrounds/bg-5.jpg' },
            { id: '6', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-6.jpg', src: 'assets/backgrounds/bg-6.jpg' },
            { id: '7', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-7.jpg', src: 'assets/backgrounds/bg-7.jpg' },
            { id: '8', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-8.jpg', src: 'assets/backgrounds/bg-8.jpg' },
            { id: '9', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-9.jpg', src: 'assets/backgrounds/bg-9.jpg' },
            { id: '10', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-10.jpg', src: 'assets/backgrounds/bg-10.jpg' },
            { id: '11', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-11.jpg', src: 'assets/backgrounds/bg-11.jpg' },
            { id: '12', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-12.jpg', src: 'assets/backgrounds/bg-12.jpg' },
            { id: '13', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-13.jpg', src: 'assets/backgrounds/bg-13.jpg' },
            { id: '14', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-14.jpg', src: 'assets/backgrounds/bg-14.jpg' },
            { id: '15', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-15.jpg', src: 'assets/backgrounds/bg-15.jpg' },
            { id: '16', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-16.jpg', src: 'assets/backgrounds/bg-16.jpg' },
            { id: '17', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-17.jpg', src: 'assets/backgrounds/bg-17.jpg' },
            { id: '18', type: EffectType.IMAGE, thumbnail: 'assets/backgrounds/thumbnails/bg-18.jpg', src: 'assets/backgrounds/bg-18.jpg' }
        ];
        this.backgroundSelectedObs = this.backgroundSelected.asObservable();
    }
    getBackgrounds() {
        return this.backgrounds;
    }
    isBackgroundApplied() {
        const bgSelected = this.backgroundSelected.getValue();
        return !!bgSelected && bgSelected !== 'no_effect';
    }
    applyBackground(effect) {
        return __awaiter(this, void 0, void 0, function* () {
            if (effect.id !== this.backgroundSelected.getValue()) {
                const filter = this.participantService.getMyCameraPublisher().stream.filter;
                const isBackgroundSelected = !!filter && filter.type.startsWith('VB:');
                let options = { token: this.tokenService.getWebcamToken(), url: '' };
                if (effect.type === EffectType.IMAGE) {
                    options.url = effect.src;
                }
                if (isBackgroundSelected && this.hasSameTypeAsAbove(effect.type)) {
                    this.replaceBackground(effect);
                }
                else {
                    yield this.removeBackground();
                    yield this.participantService.getMyCameraPublisher().stream.applyFilter(`VB:${effect.type.toLowerCase()}`, options);
                }
                this.backgroundSelected.next(effect.id);
            }
        });
    }
    removeBackground() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!!this.isBackgroundApplied()) {
                this.backgroundSelected.next('no_effect');
                yield this.participantService.getMyCameraPublisher().stream.removeFilter();
            }
        });
    }
    replaceBackground(effect) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.participantService.getMyCameraPublisher().stream.filter.execMethod('update', { url: effect.src });
        });
    }
    hasSameTypeAsAbove(type) {
        const oldEffect = this.backgrounds.find((bg) => bg.id === this.backgroundSelected.getValue());
        return (oldEffect === null || oldEffect === void 0 ? void 0 : oldEffect.type) === type;
    }
}
VirtualBackgroundService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VirtualBackgroundService, deps: [{ token: ParticipantService }, { token: TranslateService }, { token: TokenService }], target: i0.ɵɵFactoryTarget.Injectable });
VirtualBackgroundService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VirtualBackgroundService, providedIn: 'root' });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VirtualBackgroundService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: function () { return [{ type: ParticipantService }, { type: TranslateService }, { type: TokenService }]; } });

/**
 * @internal
 */
class BackgroundEffectsPanelComponent {
    /**
     * @internal
     * @param panelService
     * @param backgroundService
     * @param cd
     */
    constructor(panelService, backgroundService, cd) {
        this.panelService = panelService;
        this.backgroundService = backgroundService;
        this.cd = cd;
        this.effectType = EffectType;
        this.backgroundImages = [];
        this.noEffectAndBlurredBackground = [];
    }
    ngOnInit() {
        this.subscribeToBackgroundSelected();
        this.backgrounds = this.backgroundService.getBackgrounds();
        this.noEffectAndBlurredBackground = this.backgrounds.filter(f => f.type === EffectType.BLUR || f.type === EffectType.NONE);
        this.backgroundImages = this.backgrounds.filter(f => f.type === EffectType.IMAGE);
    }
    ngOnDestroy() {
        if (this.backgroundSubs)
            this.backgroundSubs.unsubscribe();
    }
    subscribeToBackgroundSelected() {
        this.backgroundSubs = this.backgroundService.backgroundSelectedObs.subscribe((id) => {
            this.backgroundSelectedId = id;
            this.cd.markForCheck();
        });
    }
    close() {
        this.panelService.togglePanel(PanelType.BACKGROUND_EFFECTS);
    }
    applyBackground(effect) {
        return __awaiter(this, void 0, void 0, function* () {
            if (effect.type === EffectType.NONE) {
                yield this.removeBackground();
            }
            else {
                yield this.backgroundService.applyBackground(effect);
            }
        });
    }
    removeBackground() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.backgroundService.removeBackground();
        });
    }
}
BackgroundEffectsPanelComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: BackgroundEffectsPanelComponent, deps: [{ token: PanelService }, { token: VirtualBackgroundService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
BackgroundEffectsPanelComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: BackgroundEffectsPanelComponent, selector: "ov-background-effects-panel", ngImport: i0, template: "<div class=\"panel-container\" id=\"background-effects-container\" fxLayout=\"column\" fxLayoutAlign=\"space-evenly none\">\n\t<div class=\"panel-header-container\" fxFlex=\"55px\" fxLayoutAlign=\"start center\">\n\t\t<h3 class=\"panel-title\">{{ 'PANEL.BACKGROUND.TITLE' | translate }}</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"effects-container\" fxFlex=\"100%\" fxLayoutAlign=\"space-evenly none\">\n\t\t<div>\n\t\t\t<h4>{{ 'PANEL.BACKGROUND.BLURRED_SECTION' | translate }}</h4>\n\t\t\t<div>\n\t\t\t\t<button\n\t\t\t\t\t*ngFor=\"let effect of noEffectAndBlurredBackground\"\n\t\t\t\t\tmat-icon-button\n\t\t\t\t\tclass=\"effect-button\"\n\t\t\t\t\t[class.active-effect-btn]=\"backgroundSelectedId === effect.id\"\n\t\t\t\t\t(click)=\"applyBackground(effect)\"\n\t\t\t\t>\n\t\t\t\t\t<mat-icon\n\t\t\t\t\t\t[matTooltip]=\"\n\t\t\t\t\t\t\teffect.type === effectType.NONE\n\t\t\t\t\t\t\t\t? ('PANEL.BACKGROUND.NO_EFFECTS' | translate)\n\t\t\t\t\t\t\t\t: ('PANEL.BACKGROUND.BLURRED_EFFECT' | translate)\n\t\t\t\t\t\t\"\n\t\t\t\t\t\t>{{ effect.thumbnail }}</mat-icon\n\t\t\t\t\t>\n\t\t\t\t</button>\n\t\t\t\t<!-- <button\n\t\t\t\t\tmat-icon-button\n\t\t\t\t\tclass=\"effect-button\"\n\t\t\t\t\tid=\"hard-blur-btn\"\n\t\t\t\t\t[class.active-effect-btn]=\"backgroundSelectedId === 'hard_blur'\"\n\t\t\t\t\t(click)=\"applyBackground('hard_blur')\"\n\t\t\t\t>\n\t\t\t\t\t<mat-icon matTooltip=\"Hard blur effect\">blur_on</mat-icon>\n\t\t\t\t</button> -->\n\t\t\t</div>\n\t\t</div>\n\t\t<hr />\n\t\t<div>\n\t\t\t<h4>{{ 'PANEL.BACKGROUND.IMAGES_SECTION' | translate }}</h4>\n\n\t\t\t<div class=\"grid\">\n\t\t\t\t<div\n\t\t\t\t\t*ngFor=\"let effect of backgroundImages\"\n\t\t\t\t\tclass=\"effect-button\"\n\t\t\t\t\t[class.active-effect-btn]=\"backgroundSelectedId === effect.id\"\n\t\t\t\t\t(click)=\"applyBackground(effect)\"\n\t\t\t\t>\n\t\t\t\t\t<img [src]=\"effect.thumbnail\" />\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".effects-container{display:block!important;overflow-y:auto;overflow-x:hidden;padding:10px}.effect-button{margin:5px;border-radius:var(--ov-panel-radius);background-color:var(--ov-light-color);width:60px;height:60px}.effect-button:hover{cursor:pointer}.active-effect-btn{border:2px solid var(--ov-tertiary-color)}#hard-blur-btn .mat-icon{font-weight:700!important}.grid{display:grid;grid-template-columns:repeat(auto-fit,70px)}.grid img{max-width:100%;max-height:100%;border-radius:var(--ov-panel-radius)}::ng-deep .mat-slider-thumb{visibility:hidden}::ng-deep .mat-slider-vertical .mat-slider-track-fill,::ng-deep .mat-slider-vertical .mat-slider-track-background,::ng-deep .mat-slider-vertical .mat-slider-track-wrapper{width:10px!important}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], directives: [{ type: i5.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { type: i5.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }, { type: i5.DefaultFlexDirective, selector: "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", inputs: ["fxFlex", "fxFlex.xs", "fxFlex.sm", "fxFlex.md", "fxFlex.lg", "fxFlex.xl", "fxFlex.lt-sm", "fxFlex.lt-md", "fxFlex.lt-lg", "fxFlex.lt-xl", "fxFlex.gt-xs", "fxFlex.gt-sm", "fxFlex.gt-md", "fxFlex.gt-lg"] }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }], pipes: { "translate": TranslatePipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: BackgroundEffectsPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-background-effects-panel', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"panel-container\" id=\"background-effects-container\" fxLayout=\"column\" fxLayoutAlign=\"space-evenly none\">\n\t<div class=\"panel-header-container\" fxFlex=\"55px\" fxLayoutAlign=\"start center\">\n\t\t<h3 class=\"panel-title\">{{ 'PANEL.BACKGROUND.TITLE' | translate }}</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"effects-container\" fxFlex=\"100%\" fxLayoutAlign=\"space-evenly none\">\n\t\t<div>\n\t\t\t<h4>{{ 'PANEL.BACKGROUND.BLURRED_SECTION' | translate }}</h4>\n\t\t\t<div>\n\t\t\t\t<button\n\t\t\t\t\t*ngFor=\"let effect of noEffectAndBlurredBackground\"\n\t\t\t\t\tmat-icon-button\n\t\t\t\t\tclass=\"effect-button\"\n\t\t\t\t\t[class.active-effect-btn]=\"backgroundSelectedId === effect.id\"\n\t\t\t\t\t(click)=\"applyBackground(effect)\"\n\t\t\t\t>\n\t\t\t\t\t<mat-icon\n\t\t\t\t\t\t[matTooltip]=\"\n\t\t\t\t\t\t\teffect.type === effectType.NONE\n\t\t\t\t\t\t\t\t? ('PANEL.BACKGROUND.NO_EFFECTS' | translate)\n\t\t\t\t\t\t\t\t: ('PANEL.BACKGROUND.BLURRED_EFFECT' | translate)\n\t\t\t\t\t\t\"\n\t\t\t\t\t\t>{{ effect.thumbnail }}</mat-icon\n\t\t\t\t\t>\n\t\t\t\t</button>\n\t\t\t\t<!-- <button\n\t\t\t\t\tmat-icon-button\n\t\t\t\t\tclass=\"effect-button\"\n\t\t\t\t\tid=\"hard-blur-btn\"\n\t\t\t\t\t[class.active-effect-btn]=\"backgroundSelectedId === 'hard_blur'\"\n\t\t\t\t\t(click)=\"applyBackground('hard_blur')\"\n\t\t\t\t>\n\t\t\t\t\t<mat-icon matTooltip=\"Hard blur effect\">blur_on</mat-icon>\n\t\t\t\t</button> -->\n\t\t\t</div>\n\t\t</div>\n\t\t<hr />\n\t\t<div>\n\t\t\t<h4>{{ 'PANEL.BACKGROUND.IMAGES_SECTION' | translate }}</h4>\n\n\t\t\t<div class=\"grid\">\n\t\t\t\t<div\n\t\t\t\t\t*ngFor=\"let effect of backgroundImages\"\n\t\t\t\t\tclass=\"effect-button\"\n\t\t\t\t\t[class.active-effect-btn]=\"backgroundSelectedId === effect.id\"\n\t\t\t\t\t(click)=\"applyBackground(effect)\"\n\t\t\t\t>\n\t\t\t\t\t<img [src]=\"effect.thumbnail\" />\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".effects-container{display:block!important;overflow-y:auto;overflow-x:hidden;padding:10px}.effect-button{margin:5px;border-radius:var(--ov-panel-radius);background-color:var(--ov-light-color);width:60px;height:60px}.effect-button:hover{cursor:pointer}.active-effect-btn{border:2px solid var(--ov-tertiary-color)}#hard-blur-btn .mat-icon{font-weight:700!important}.grid{display:grid;grid-template-columns:repeat(auto-fit,70px)}.grid img{max-width:100%;max-height:100%;border-radius:var(--ov-panel-radius)}::ng-deep .mat-slider-thumb{visibility:hidden}::ng-deep .mat-slider-vertical .mat-slider-track-fill,::ng-deep .mat-slider-vertical .mat-slider-track-background,::ng-deep .mat-slider-vertical .mat-slider-track-wrapper{width:10px!important}\n"] }]
        }], ctorParameters: function () { return [{ type: PanelService }, { type: VirtualBackgroundService }, { type: i0.ChangeDetectorRef }]; } });

/**
 * @internal
 */
class NicknameInputComponent {
    constructor(participantService, storageSrv) {
        this.participantService = participantService;
        this.storageSrv = storageSrv;
    }
    ngOnInit() {
        this.subscribeToParticipantProperties();
        this.nickname = this.participantService.getMyNickname();
    }
    updateNickname() {
        this.nickname = this.nickname === '' ? this.participantService.getMyNickname() : this.nickname;
        this.participantService.setMyNickname(this.nickname);
        this.storageSrv.setNickname(this.nickname);
    }
    subscribeToParticipantProperties() {
        this.localParticipantSubscription = this.participantService.localParticipantObs.subscribe((p) => {
            if (p) {
                this.nickname = p.getNickname();
            }
        });
    }
}
NicknameInputComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: NicknameInputComponent, deps: [{ token: ParticipantService }, { token: StorageService }], target: i0.ɵɵFactoryTarget.Component });
NicknameInputComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: NicknameInputComponent, selector: "ov-nickname-input", ngImport: i0, template: "<div id=\"nickname-input-container\">\n\t<button mat-icon-button disabled>\n\t\t<mat-icon>person</mat-icon>\n\t</button>\n\t<mat-form-field appearance=\"standard\">\n\t\t<mat-label>{{ 'PREJOIN.NICKNAME' | translate }}</mat-label>\n\t\t<input\n\t\t\tmatInput\n\t\t\ttype=\"text\"\n\t\t\tmaxlength=\"20\"\n\t\t\t[(ngModel)]=\"nickname\"\n\t\t\t(change)=\"updateNickname()\"\n\t\t\tautocomplete=\"off\"\n\t\t/>\n\t</mat-form-field>\n</div>", styles: ["#nickname-input-container{display:flex}#nickname-input-container button{margin:auto 10px auto auto}#nickname-input-container button.mat-button-disabled{color:#000!important}#nickname-input-container mat-form-field{width:100%;margin-top:10px;color:#000}#nickname-input-container mat-form-field{color:#000}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i9$1.MatFormField, selector: "mat-form-field", inputs: ["color", "appearance", "hideRequiredMarker", "hintLabel", "floatLabel"], exportAs: ["matFormField"] }], directives: [{ type: i9$1.MatLabel, selector: "mat-label" }, { type: i15$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { type: i9.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { type: i9.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { type: i9.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i9.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: NicknameInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-nickname-input', template: "<div id=\"nickname-input-container\">\n\t<button mat-icon-button disabled>\n\t\t<mat-icon>person</mat-icon>\n\t</button>\n\t<mat-form-field appearance=\"standard\">\n\t\t<mat-label>{{ 'PREJOIN.NICKNAME' | translate }}</mat-label>\n\t\t<input\n\t\t\tmatInput\n\t\t\ttype=\"text\"\n\t\t\tmaxlength=\"20\"\n\t\t\t[(ngModel)]=\"nickname\"\n\t\t\t(change)=\"updateNickname()\"\n\t\t\tautocomplete=\"off\"\n\t\t/>\n\t</mat-form-field>\n</div>", styles: ["#nickname-input-container{display:flex}#nickname-input-container button{margin:auto 10px auto auto}#nickname-input-container button.mat-button-disabled{color:#000!important}#nickname-input-container mat-form-field{width:100%;margin-top:10px;color:#000}#nickname-input-container mat-form-field{color:#000}\n"] }]
        }], ctorParameters: function () { return [{ type: ParticipantService }, { type: StorageService }]; } });

/**
 * @internal
 */
class VideoDevicesComponent {
    constructor(openviduService, panelService, storageSrv, deviceSrv, participantService, backgroundService) {
        this.openviduService = openviduService;
        this.panelService = panelService;
        this.storageSrv = storageSrv;
        this.deviceSrv = deviceSrv;
        this.participantService = participantService;
        this.backgroundService = backgroundService;
        this.onDeviceSelectorClicked = new EventEmitter();
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.subscribeToParticipantMediaProperties();
            if (this.openviduService.isSessionConnected()) {
                // Updating devices only with session connected
                yield this.deviceSrv.initializeDevices();
            }
            this.hasVideoDevices = this.deviceSrv.hasVideoDeviceAvailable();
            this.cameras = this.deviceSrv.getCameras();
            this.cameraSelected = this.deviceSrv.getCameraSelected();
            if (this.openviduService.isSessionConnected()) {
                this.isVideoMuted = !this.participantService.getLocalParticipant().isCameraVideoActive();
            }
            else {
                this.isVideoMuted = this.deviceSrv.isVideoMuted();
            }
        });
    }
    ngOnDestroy() {
        return __awaiter(this, void 0, void 0, function* () {
            this.cameras = [];
            if (this.localParticipantSubscription)
                this.localParticipantSubscription.unsubscribe();
        });
    }
    toggleCam() {
        return __awaiter(this, void 0, void 0, function* () {
            this.videoMuteChanging = true;
            const publish = this.isVideoMuted;
            yield this.openviduService.publishVideo(publish);
            this.storageSrv.setVideoMuted(this.isVideoMuted);
            if (this.isVideoMuted && this.panelService.isExternalPanelOpened()) {
                this.panelService.togglePanel(PanelType.BACKGROUND_EFFECTS);
            }
            this.videoMuteChanging = false;
        });
    }
    onCameraSelected(event) {
        return __awaiter(this, void 0, void 0, function* () {
            const videoSource = event === null || event === void 0 ? void 0 : event.value;
            // Is New deviceId different from the old one?
            if (this.deviceSrv.needUpdateVideoTrack(videoSource)) {
                const mirror = this.deviceSrv.cameraNeedsMirror(videoSource);
                // Reapply Virtual Background to new Publisher if necessary
                const backgroundSelected = this.backgroundService.backgroundSelected.getValue();
                if (this.backgroundService.isBackgroundApplied()) {
                    yield this.backgroundService.removeBackground();
                }
                const pp = { videoSource, audioSource: false, mirror };
                yield this.openviduService.replaceTrack(VideoType.CAMERA, pp);
                if (this.backgroundService.isBackgroundApplied()) {
                    const bgSelected = this.backgroundService.backgrounds.find((b) => b.id === backgroundSelected);
                    if (bgSelected) {
                        yield this.backgroundService.applyBackground(bgSelected);
                    }
                }
                this.deviceSrv.setCameraSelected(videoSource);
                this.cameraSelected = this.deviceSrv.getCameraSelected();
            }
        });
    }
    subscribeToParticipantMediaProperties() {
        this.localParticipantSubscription = this.participantService.localParticipantObs.subscribe((p) => {
            if (p) {
                this.isVideoMuted = !p.isCameraVideoActive();
            }
        });
    }
}
VideoDevicesComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VideoDevicesComponent, deps: [{ token: OpenViduService }, { token: PanelService }, { token: StorageService }, { token: DeviceService }, { token: ParticipantService }, { token: VirtualBackgroundService }], target: i0.ɵɵFactoryTarget.Component });
VideoDevicesComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: VideoDevicesComponent, selector: "ov-video-devices-select", outputs: { onDeviceSelectorClicked: "onDeviceSelectorClicked" }, ngImport: i0, template: "<div class=\"device-container-element\">\n\t<button\n\t\tmat-icon-button\n\t\tid=\"camera-button\"\n\t\t[disabled]=\"!hasVideoDevices || videoMuteChanging\"\n\t\t[class.warn-btn]=\"isVideoMuted\"\n\t\t(click)=\"toggleCam()\"\n\t>\n\t\t<mat-icon *ngIf=\"!isVideoMuted\" matTooltip=\"{{ 'TOOLBAR.MUTE_VIDEO' | translate }}\" id=\"videocam\">videocam</mat-icon>\n\t\t<mat-icon *ngIf=\"isVideoMuted\" matTooltip=\"{{ 'TOOLBAR.UNMUTE_VIDEO' | translate }}\" id=\"videocam_off\">videocam_off</mat-icon>\n\t</button>\n\t<mat-form-field>\n\t\t<mat-label>{{ 'PREJOIN.VIDEO_DEVICE' | translate }}</mat-label>\n\t\t<mat-select\n\t\t\t[disabled]=\"isVideoMuted || !hasVideoDevices\"\n\t\t\t[value]=\"cameraSelected?.device\"\n\t\t\t(click)=\"onDeviceSelectorClicked.emit()\"\n\t\t\t(selectionChange)=\"onCameraSelected($event)\"\n\t\t>\n\t\t\t<mat-option *ngFor=\"let camera of cameras\" [value]=\"camera.device\">\n\t\t\t\t{{ camera.label }}\n\t\t\t</mat-option>\n\t\t</mat-select>\n\t</mat-form-field>\n</div>\n", styles: ["#camera-button{border-radius:var(--ov-buttons-radius)}.device-container-element mat-form-field{width:100%;margin-top:10px;color:#000}.device-container-element button{margin:auto 10px auto auto}.device-container-element{display:flex}.warn-btn{color:var(--ov-text-color);background-color:var(--ov-warn-color)!important}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i9$1.MatFormField, selector: "mat-form-field", inputs: ["color", "appearance", "hideRequiredMarker", "hintLabel", "floatLabel"], exportAs: ["matFormField"] }, { type: i10$1.MatSelect, selector: "mat-select", inputs: ["disabled", "disableRipple", "tabIndex"], exportAs: ["matSelect"] }, { type: i6$1.MatOption, selector: "mat-option", exportAs: ["matOption"] }], directives: [{ type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: i9$1.MatLabel, selector: "mat-label" }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VideoDevicesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-video-devices-select', template: "<div class=\"device-container-element\">\n\t<button\n\t\tmat-icon-button\n\t\tid=\"camera-button\"\n\t\t[disabled]=\"!hasVideoDevices || videoMuteChanging\"\n\t\t[class.warn-btn]=\"isVideoMuted\"\n\t\t(click)=\"toggleCam()\"\n\t>\n\t\t<mat-icon *ngIf=\"!isVideoMuted\" matTooltip=\"{{ 'TOOLBAR.MUTE_VIDEO' | translate }}\" id=\"videocam\">videocam</mat-icon>\n\t\t<mat-icon *ngIf=\"isVideoMuted\" matTooltip=\"{{ 'TOOLBAR.UNMUTE_VIDEO' | translate }}\" id=\"videocam_off\">videocam_off</mat-icon>\n\t</button>\n\t<mat-form-field>\n\t\t<mat-label>{{ 'PREJOIN.VIDEO_DEVICE' | translate }}</mat-label>\n\t\t<mat-select\n\t\t\t[disabled]=\"isVideoMuted || !hasVideoDevices\"\n\t\t\t[value]=\"cameraSelected?.device\"\n\t\t\t(click)=\"onDeviceSelectorClicked.emit()\"\n\t\t\t(selectionChange)=\"onCameraSelected($event)\"\n\t\t>\n\t\t\t<mat-option *ngFor=\"let camera of cameras\" [value]=\"camera.device\">\n\t\t\t\t{{ camera.label }}\n\t\t\t</mat-option>\n\t\t</mat-select>\n\t</mat-form-field>\n</div>\n", styles: ["#camera-button{border-radius:var(--ov-buttons-radius)}.device-container-element mat-form-field{width:100%;margin-top:10px;color:#000}.device-container-element button{margin:auto 10px auto auto}.device-container-element{display:flex}.warn-btn{color:var(--ov-text-color);background-color:var(--ov-warn-color)!important}\n"] }]
        }], ctorParameters: function () { return [{ type: OpenViduService }, { type: PanelService }, { type: StorageService }, { type: DeviceService }, { type: ParticipantService }, { type: VirtualBackgroundService }]; }, propDecorators: { onDeviceSelectorClicked: [{
                type: Output
            }] } });

/**
 * @internal
 */
class AudioDevicesComponent {
    constructor(openviduService, deviceSrv, storageSrv, participantService) {
        this.openviduService = openviduService;
        this.deviceSrv = deviceSrv;
        this.storageSrv = storageSrv;
        this.participantService = participantService;
        this.onDeviceSelectorClicked = new EventEmitter();
        this.microphones = [];
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.subscribeToParticipantMediaProperties();
            if (this.openviduService.isSessionConnected()) {
                // Updating devices only with session connected
                yield this.deviceSrv.initializeDevices();
            }
            this.hasAudioDevices = this.deviceSrv.hasAudioDeviceAvailable();
            this.microphones = this.deviceSrv.getMicrophones();
            this.microphoneSelected = this.deviceSrv.getMicrophoneSelected();
            this.isAudioMuted = this.deviceSrv.isAudioMuted();
            if (this.openviduService.isSessionConnected()) {
                this.isAudioMuted = !this.participantService.isMyAudioActive();
            }
            else {
                this.isAudioMuted = this.deviceSrv.isAudioMuted();
            }
        });
    }
    ngOnDestroy() {
        if (this.localParticipantSubscription)
            this.localParticipantSubscription.unsubscribe();
    }
    toggleMic() {
        const publish = this.isAudioMuted;
        this.openviduService.publishAudio(publish);
    }
    onMicrophoneSelected(event) {
        return __awaiter(this, void 0, void 0, function* () {
            const audioSource = event === null || event === void 0 ? void 0 : event.value;
            if (this.deviceSrv.needUpdateAudioTrack(audioSource)) {
                const pp = { audioSource, videoSource: false };
                yield this.openviduService.replaceTrack(VideoType.CAMERA, pp);
                this.deviceSrv.setMicSelected(audioSource);
                this.microphoneSelected = this.deviceSrv.getMicrophoneSelected();
            }
        });
    }
    subscribeToParticipantMediaProperties() {
        this.localParticipantSubscription = this.participantService.localParticipantObs.subscribe((p) => {
            if (p) {
                this.isAudioMuted = !p.hasAudioActive();
                this.storageSrv.setAudioMuted(this.isAudioMuted);
            }
        });
    }
}
AudioDevicesComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AudioDevicesComponent, deps: [{ token: OpenViduService }, { token: DeviceService }, { token: StorageService }, { token: ParticipantService }], target: i0.ɵɵFactoryTarget.Component });
AudioDevicesComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: AudioDevicesComponent, selector: "ov-audio-devices-select", outputs: { onDeviceSelectorClicked: "onDeviceSelectorClicked" }, ngImport: i0, template: "<div class=\"device-container-element\">\n\t<button\n\t\tmat-icon-button\n\t\tid=\"microhpone-button\"\n\t\t[disabled]=\"!hasAudioDevices\"\n\t\t[class.warn-btn]=\"isAudioMuted\"\n\t\t(click)=\"toggleMic()\"\n\t>\n\t\t<mat-icon *ngIf=\"!isAudioMuted\" matTooltip=\"{{ 'TOOLBAR.MUTE_AUDIO' | translate }}\" id=\"mic\">mic</mat-icon>\n\t\t<mat-icon *ngIf=\"isAudioMuted\" matTooltip=\"{{ 'TOOLBAR.UNMUTE_AUDIO' | translate }}\" id=\"mic_off\"\n\t\t\t>mic_off</mat-icon\n\t\t>\n\t</button>\n\t<mat-form-field>\n\t\t<mat-label>{{ 'PREJOIN.AUDIO_DEVICE' | translate }}</mat-label>\n\t\t<mat-select\n\t\t\t[disabled]=\"isAudioMuted || !hasAudioDevices\"\n\t\t\t[value]=\"microphoneSelected?.device\"\n\t\t\t(click)=\"onDeviceSelectorClicked.emit()\"\n\t\t\t(selectionChange)=\"onMicrophoneSelected($event)\"\n\t\t>\n\t\t\t<mat-option *ngFor=\"let microphone of microphones\" [value]=\"microphone.device\">\n\t\t\t\t{{ microphone.label }}\n\t\t\t</mat-option>\n\t\t</mat-select>\n\t</mat-form-field>\n</div>\n", styles: [".device-container-element mat-form-field{width:100%;margin-top:10px;color:#000}.device-container-element button{margin:auto 10px auto auto}.device-container-element{display:flex}.warn-btn{color:var(--ov-text-color);background-color:var(--ov-warn-color)!important}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i9$1.MatFormField, selector: "mat-form-field", inputs: ["color", "appearance", "hideRequiredMarker", "hintLabel", "floatLabel"], exportAs: ["matFormField"] }, { type: i10$1.MatSelect, selector: "mat-select", inputs: ["disabled", "disableRipple", "tabIndex"], exportAs: ["matSelect"] }, { type: i6$1.MatOption, selector: "mat-option", exportAs: ["matOption"] }], directives: [{ type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: i9$1.MatLabel, selector: "mat-label" }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AudioDevicesComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-audio-devices-select', template: "<div class=\"device-container-element\">\n\t<button\n\t\tmat-icon-button\n\t\tid=\"microhpone-button\"\n\t\t[disabled]=\"!hasAudioDevices\"\n\t\t[class.warn-btn]=\"isAudioMuted\"\n\t\t(click)=\"toggleMic()\"\n\t>\n\t\t<mat-icon *ngIf=\"!isAudioMuted\" matTooltip=\"{{ 'TOOLBAR.MUTE_AUDIO' | translate }}\" id=\"mic\">mic</mat-icon>\n\t\t<mat-icon *ngIf=\"isAudioMuted\" matTooltip=\"{{ 'TOOLBAR.UNMUTE_AUDIO' | translate }}\" id=\"mic_off\"\n\t\t\t>mic_off</mat-icon\n\t\t>\n\t</button>\n\t<mat-form-field>\n\t\t<mat-label>{{ 'PREJOIN.AUDIO_DEVICE' | translate }}</mat-label>\n\t\t<mat-select\n\t\t\t[disabled]=\"isAudioMuted || !hasAudioDevices\"\n\t\t\t[value]=\"microphoneSelected?.device\"\n\t\t\t(click)=\"onDeviceSelectorClicked.emit()\"\n\t\t\t(selectionChange)=\"onMicrophoneSelected($event)\"\n\t\t>\n\t\t\t<mat-option *ngFor=\"let microphone of microphones\" [value]=\"microphone.device\">\n\t\t\t\t{{ microphone.label }}\n\t\t\t</mat-option>\n\t\t</mat-select>\n\t</mat-form-field>\n</div>\n", styles: [".device-container-element mat-form-field{width:100%;margin-top:10px;color:#000}.device-container-element button{margin:auto 10px auto auto}.device-container-element{display:flex}.warn-btn{color:var(--ov-text-color);background-color:var(--ov-warn-color)!important}\n"] }]
        }], ctorParameters: function () { return [{ type: OpenViduService }, { type: DeviceService }, { type: StorageService }, { type: ParticipantService }]; }, propDecorators: { onDeviceSelectorClicked: [{
                type: Output
            }] } });

const LANDSCAPE_BREAKPOINTS = [
    {
        alias: 'landscape',
        suffix: 'Landscape',
        mediaQuery: 'screen and (orientation: landscape)',
        overlapping: false,
        priority: 2001
    }
];
const CustomBreakPointsProvider = {
    provide: BREAKPOINT,
    useValue: LANDSCAPE_BREAKPOINTS,
    multi: true
};
const selector = `[fxLayout.landscape]`;
const inputs = ['fxLayout.landscape'];
class CustomLayoutExtensionDirective extends LayoutDirective$1 {
    constructor() {
        super(...arguments);
        this.inputs = inputs;
    }
}
CustomLayoutExtensionDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CustomLayoutExtensionDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
CustomLayoutExtensionDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: CustomLayoutExtensionDirective, selector: "[fxLayout.landscape]", inputs: { "fxLayout.landscape": "fxLayout.landscape" }, usesInheritance: true, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: CustomLayoutExtensionDirective, decorators: [{
            type: Directive,
            args: [{ selector, inputs }]
        }] });

/**
 * The **displayParticipantName** directive allows show/hide the participants name in stream component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `stream` component:
 *
 * @example
 * <ov-videoconference [streamDisplayParticipantName]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link StreamComponent}.
 * @example
 * <ov-stream [displayParticipantName]="false"></ov-stream>
 */
class StreamDisplayParticipantNameDirective {
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
    }
    set streamDisplayParticipantName(value) {
        this.displayParticipantNameValue = value;
        this.update(this.displayParticipantNameValue);
    }
    set displayParticipantName(value) {
        this.displayParticipantNameValue = value;
        this.update(this.displayParticipantNameValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    ngAfterViewInit() {
        this.update(this.displayParticipantNameValue);
    }
    update(value) {
        if (this.libService.displayParticipantName.getValue() !== value) {
            this.libService.displayParticipantName.next(value);
        }
    }
    clear() {
        this.update(true);
    }
}
StreamDisplayParticipantNameDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamDisplayParticipantNameDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
StreamDisplayParticipantNameDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: StreamDisplayParticipantNameDirective, selector: "ov-videoconference[streamDisplayParticipantName], ov-stream[displayParticipantName]", inputs: { streamDisplayParticipantName: "streamDisplayParticipantName", displayParticipantName: "displayParticipantName" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamDisplayParticipantNameDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[streamDisplayParticipantName], ov-stream[displayParticipantName]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { streamDisplayParticipantName: [{
                type: Input
            }], displayParticipantName: [{
                type: Input
            }] } });
/**
 * The **displayAudioDetection** directive allows show/hide the participants audio detection in stream component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `stream` component:
 *
 * @example
 * <ov-videoconference [streamDisplayAudioDetection]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link StreamComponent}.
 * @example
 * <ov-stream [displayAudioDetection]="false"></ov-stream>
 */
class StreamDisplayAudioDetectionDirective {
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
    }
    set streamDisplayAudioDetection(value) {
        this.displayAudioDetectionValue = value;
        this.update(this.displayAudioDetectionValue);
    }
    set displayAudioDetection(value) {
        this.displayAudioDetectionValue = value;
        this.update(this.displayAudioDetectionValue);
    }
    ngAfterViewInit() {
        this.update(this.displayAudioDetectionValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    update(value) {
        if (this.libService.displayAudioDetection.getValue() !== value) {
            this.libService.displayAudioDetection.next(value);
        }
    }
    clear() {
        this.update(true);
    }
}
StreamDisplayAudioDetectionDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamDisplayAudioDetectionDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
StreamDisplayAudioDetectionDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: StreamDisplayAudioDetectionDirective, selector: "ov-videoconference[streamDisplayAudioDetection], ov-stream[displayAudioDetection]", inputs: { streamDisplayAudioDetection: "streamDisplayAudioDetection", displayAudioDetection: "displayAudioDetection" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamDisplayAudioDetectionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[streamDisplayAudioDetection], ov-stream[displayAudioDetection]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { streamDisplayAudioDetection: [{
                type: Input
            }], displayAudioDetection: [{
                type: Input
            }] } });
/**
 * The **settingsButton** directive allows show/hide the participants settings button in stream component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `stream` component:
 *
 * @example
 * <ov-videoconference [streamSettingsButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link StreamComponent}.
 * @example
 * <ov-stream [settingsButton]="false"></ov-stream>
 */
class StreamSettingsButtonDirective {
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
    }
    set streamSettingsButton(value) {
        this.settingsValue = value;
        this.update(this.settingsValue);
    }
    set settingsButton(value) {
        this.settingsValue = value;
        this.update(this.settingsValue);
    }
    ngAfterViewInit() {
        this.update(this.settingsValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    update(value) {
        if (this.libService.streamSettingsButton.getValue() !== value) {
            this.libService.streamSettingsButton.next(value);
        }
    }
    clear() {
        this.update(true);
    }
}
StreamSettingsButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamSettingsButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
StreamSettingsButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: StreamSettingsButtonDirective, selector: "ov-videoconference[streamSettingsButton], ov-stream[settingsButton]", inputs: { streamSettingsButton: "streamSettingsButton", settingsButton: "settingsButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: StreamSettingsButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[streamSettingsButton], ov-stream[settingsButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { streamSettingsButton: [{
                type: Input
            }], settingsButton: [{
                type: Input
            }] } });

/**
 * @internal
 */
class PreJoinComponent {
    constructor(layoutService, loggerSrv, participantService, panelService, libService, cdkSrv) {
        this.layoutService = layoutService;
        this.loggerSrv = loggerSrv;
        this.participantService = participantService;
        this.panelService = panelService;
        this.libService = libService;
        this.cdkSrv = cdkSrv;
        this.onJoinButtonClicked = new EventEmitter();
        this.isLoading = true;
        /**
         * @ignore
         */
        this.showBackgroundEffectsButton = true;
        /**
         * @ignore
         */
        this.isMinimal = false;
        this.showLogo = true;
        this.log = this.loggerSrv.get('PreJoinComponent');
    }
    sizeChange() {
        this.windowSize = window.innerWidth;
        this.layoutService.update();
    }
    ngOnInit() {
        this.subscribeToPrejoinDirectives();
        this.subscribeToLocalParticipantEvents();
        this.windowSize = window.innerWidth;
        this.isLoading = false;
    }
    ngOnDestroy() {
        return __awaiter(this, void 0, void 0, function* () {
            this.cdkSrv.setSelector('body');
            if (this.localParticipantSubscription)
                this.localParticipantSubscription.unsubscribe();
            if (this.screenShareStateSubscription)
                this.screenShareStateSubscription.unsubscribe();
            if (this.backgroundEffectsButtonSub)
                this.backgroundEffectsButtonSub.unsubscribe();
            if (this.minimalSub)
                this.minimalSub.unsubscribe();
            this.panelService.closePanel();
        });
    }
    onDeviceSelectorClicked() {
        // Some devices as iPhone do not show the menu panels correctly
        // Updating the container where the panel is added fix the problem.
        this.cdkSrv.setSelector('#prejoin-container');
    }
    joinSession() {
        this.onJoinButtonClicked.emit();
        this.panelService.closePanel();
    }
    toggleBackgroundEffects() {
        this.panelService.togglePanel(PanelType.BACKGROUND_EFFECTS);
    }
    subscribeToLocalParticipantEvents() {
        this.localParticipantSubscription = this.participantService.localParticipantObs.subscribe((p) => {
            this.localParticipant = p;
            this.nickname = this.localParticipant.getNickname();
        });
    }
    subscribeToPrejoinDirectives() {
        this.minimalSub = this.libService.minimalObs.subscribe((value) => {
            this.isMinimal = value;
            // this.cd.markForCheck();
        });
        this.displayLogoSub = this.libService.displayLogoObs.subscribe((value) => {
            this.showLogo = value;
            // this.cd.markForCheck();
        });
        this.backgroundEffectsButtonSub = this.libService.backgroundEffectsButton.subscribe((value) => {
            this.showBackgroundEffectsButton = value;
            // this.cd.markForCheck();
        });
    }
}
PreJoinComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PreJoinComponent, deps: [{ token: LayoutService }, { token: LoggerService }, { token: ParticipantService }, { token: PanelService }, { token: OpenViduAngularConfigService }, { token: CdkOverlayService }], target: i0.ɵɵFactoryTarget.Component });
PreJoinComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: PreJoinComponent, selector: "ov-pre-join", outputs: { onJoinButtonClicked: "onJoinButtonClicked" }, host: { listeners: { "window:resize": "sizeChange()" } }, ngImport: i0, template: "<div class=\"prejoin-toolbar\">\n\t<mat-toolbar id=\"toolbar\">\n\t\t<img *ngIf=\"!isMinimal && showLogo\" id=\"branding-logo\" src=\"assets/images/logo.png\" ovLogo />\n\t\t<!-- <span>OpenVidu Call</span> -->\n\t\t<span class=\"spacer\"></span>\n\n\t\t<ov-lang-selector *ngIf=\"!isMinimal\" (onLangSelectorClicked)=\"onDeviceSelectorClicked()\"></ov-lang-selector>\n\t</mat-toolbar>\n</div>\n\n<div class=\"container\" id=\"prejoin-container\" fxLayout.landscape=\"row\" fxLayout.lt-md=\"column\" fxLayout.md=\"row\" fxLayout.gt-md=\"row\">\n\t<div fxFlex.lt-sm=\"50%\" fxFlex.lt-md=\"50%\" fxFlex.md=\"45%\" fxFlex.gt-md=\"45%\" fxLayoutAlign=\"center center\" id=\"layout-container\">\n\t\t<ov-session [usedInPrejoinPage]=\"true\" class=\"ov-session\">\n\t\t\t<ng-template #panel *ngIf=\"!isMinimal && showBackgroundEffectsButton\">\n\t\t\t\t<ov-panel>\n\t\t\t\t\t<ng-template #backgroundEffectsPanel>\n\t\t\t\t\t\t<ov-background-effects-panel></ov-background-effects-panel>\n\t\t\t\t\t</ng-template>\n\t\t\t\t</ov-panel>\n\t\t\t</ng-template>\n\n\t\t\t<ng-template #layout>\n\t\t\t\t<ov-layout>\n\t\t\t\t\t<ng-template #stream let-stream>\n\t\t\t\t\t\t<button\n\t\t\t\t\t\t\t*ngIf=\"!isMinimal && showBackgroundEffectsButton\"\n\t\t\t\t\t\t\t[disabled]=\"isVideoMuted\"\n\t\t\t\t\t\t\tmatTooltip=\"{{ 'TOOLBAR.BACKGROUND' | translate }}\"\n\t\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t\tid=\"background-effects-btn\"\n\t\t\t\t\t\t\t(click)=\"toggleBackgroundEffects()\"\n\t\t\t\t\t\t>\n\t\t\t\t\t\t\t<mat-icon>auto_awesome</mat-icon>\n\t\t\t\t\t\t</button>\n\t\t\t\t\t\t<ov-stream [stream]=\"stream\" [displayParticipantName]=\"false\" [settingsButton]=\"false\"></ov-stream>\n\t\t\t\t\t</ng-template>\n\t\t\t\t</ov-layout>\n\t\t\t</ng-template>\n\t\t</ov-session>\n\t</div>\n\t<div fxFlex.lt-md=\"50%\" fxFlex.md=\"55%\" fxFlex.gt-md=\"55%\" fxLayoutAlign=\"center center\" class=\"media-panel\" *ngIf=\"localParticipant\">\n\t\t<div fxLayout=\"column\" fxLayoutGap=\"10px\" class=\"media-panel-container\">\n\t\t\t<div fxLayout.gt-sm=\"column\" fxLayout.lt-md=\"column\" fxLayoutGap=\"10px\" fxFlex=\"33%\">\n\t\t\t\t<div fxFlex.gt-sm=\"100%\" fxFlex.lt-md=\"33%\" fxLayoutAlign=\"center center\" fxFlexFill class=\"nickname-container\">\n\t\t\t\t\t<h4 *ngIf=\"windowSize >= 960\">{{ 'PREJOIN.NICKNAME_SECTION' | translate }}</h4>\n\t\t\t\t\t<hr *ngIf=\"windowSize >= 960\" />\n\t\t\t\t\t<ov-nickname-input></ov-nickname-input>\n\t\t\t\t</div>\n\n\t\t\t\t<div fxFlex.gt-sm=\"100%\" fxFlex.lt-md=\"33%\" fxLayoutAlign=\"center center\" fxFlexFill class=\"buttons-container\">\n\t\t\t\t\t<h4 *ngIf=\"windowSize >= 960\">{{ 'PREJOIN.DEVICE_SECTION' | translate }}</h4>\n\t\t\t\t\t<hr *ngIf=\"windowSize >= 960\" />\n\n\t\t\t\t\t<!-- Camera -->\n\t\t\t\t\t<ov-video-devices-select (onDeviceSelectorClicked)=\"onDeviceSelectorClicked()\"></ov-video-devices-select>\n\n\t\t\t\t\t<!-- Microphone -->\n\t\t\t\t\t<ov-audio-devices-select (onDeviceSelectorClicked)=\"onDeviceSelectorClicked()\"></ov-audio-devices-select>\n\t\t\t\t</div>\n\n\t\t\t\t<div fxFlex.gt-sm=\"60%\" fxLayout.lt-md=\"column\" fxLayoutAlign=\"center center\" fxFlexFill class=\"join-btn-container\">\n\t\t\t\t\t<button mat-flat-button (click)=\"joinSession()\" form=\"nicknameForm\" id=\"join-button\">\n\t\t\t\t\t\t{{ 'PREJOIN.JOIN' | translate }}\n\t\t\t\t\t</button>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n", styles: [".container{height:calc(100% - 64px);padding:30px 60px;background-color:var(--ov-light-color)}.prejoin-toolbar{max-height:40px;height:40px}#toolbar{background-color:var(--ov-light-color);height:100%}#toolbar ::ng-deep .lang-button{height:25px!important;font-size:14px!important;line-height:0px;align-items:unset!important}.spacer{flex:1 1 auto}#branding-logo{border-radius:var(--ov-panel-radius);max-width:35px;max-height:35px;height:-webkit-fill-available;height:-moz-available;padding:10px;margin-right:10px}#layout-container{display:block!important}h4{margin-bottom:1px;font-weight:700}hr{margin:0}#prejoin-container{height:calc(100% - 40px)}#prejoin-container ::ng-deep .sidenav-container{padding-top:0!important}#prejoin-container ::ng-deep #background-effects-container{margin:0!important;max-height:100%!important;height:100%!important}#prejoin-container ::ng-deep .mat-drawer-container,#prejoin-container ::ng-deep .sidenav-menu,#prejoin-container ::ng-deep #session-container{background-color:transparent!important}#prejoin-container ::ng-deep .sidenav-menu{width:320px}#prejoin-container ::ng-deep .layout{min-width:0px!important}#prejoin-container ::ng-deep .OT_root{padding:0!important}#background-effects-btn{position:absolute;z-index:1;background-color:var(--ov-secondary-color);bottom:5px;right:5px}.media-panel{background-color:var(--ov-light-color)}.media-panel-container{width:100%;padding:20px 0 20px 20px}.nickname-container{display:block!important;margin-bottom:0!important}.mat-form-field-appearance-fill .mat-form-field-flex{border-radius:var(--ov-video-radius)}.buttons-container{border-radius:5px;padding:10px 0;height:100px;display:block!important}.join-btn-container{width:inherit;text-align:center}#join-button{width:100%;font-weight:700;color:var(--ov-text-color);background-color:var(--ov-tertiary-color);border-radius:var(--ov-video-radius)}@media only screen and (max-width: 480px){.container,.media-panel-container,.buttons-container{padding:0}.nickname-container,.buttons-container,.join-btn-container{width:90%!important;margin:auto}.join-btn-container{padding:0 10px}.media-panel{align-items:flex-start!important}}@media only screen and (min-width: 480px) and (max-width: 959px){.media-panel-container,.buttons-container{padding:0}.nickname-container,.buttons-container,.join-btn-container{width:80%!important;min-width:80%!important;margin:auto}.buttons-container,.media-panel-container{padding-top:0;max-width:600px}}\n"], components: [{ type: i15.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { type: LangSelectorComponent, selector: "ov-lang-selector", outputs: ["onLangSelectorClicked"] }, { type: SessionComponent, selector: "ov-session", inputs: ["usedInPrejoinPage"], outputs: ["onSessionCreated"] }, { type: PanelComponent, selector: "ov-panel" }, { type: BackgroundEffectsPanelComponent, selector: "ov-background-effects-panel" }, { type: LayoutComponent, selector: "ov-layout" }, { type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: StreamComponent, selector: "ov-stream", inputs: ["stream"] }, { type: NicknameInputComponent, selector: "ov-nickname-input" }, { type: VideoDevicesComponent, selector: "ov-video-devices-select", outputs: ["onDeviceSelectorClicked"] }, { type: AudioDevicesComponent, selector: "ov-audio-devices-select", outputs: ["onDeviceSelectorClicked"] }], directives: [{ type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: LogoDirective, selector: "img[ovLogo]", inputs: ["ovLogo"] }, { type: CustomLayoutExtensionDirective, selector: "[fxLayout.landscape]", inputs: ["fxLayout.landscape"] }, { type: i5.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { type: i5.DefaultFlexDirective, selector: "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", inputs: ["fxFlex", "fxFlex.xs", "fxFlex.sm", "fxFlex.md", "fxFlex.lg", "fxFlex.xl", "fxFlex.lt-sm", "fxFlex.lt-md", "fxFlex.lt-lg", "fxFlex.lt-xl", "fxFlex.gt-xs", "fxFlex.gt-sm", "fxFlex.gt-md", "fxFlex.gt-lg"] }, { type: i5.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: StreamDisplayParticipantNameDirective, selector: "ov-videoconference[streamDisplayParticipantName], ov-stream[displayParticipantName]", inputs: ["streamDisplayParticipantName", "displayParticipantName"] }, { type: StreamSettingsButtonDirective, selector: "ov-videoconference[streamSettingsButton], ov-stream[settingsButton]", inputs: ["streamSettingsButton", "settingsButton"] }, { type: i5.DefaultLayoutGapDirective, selector: "  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]", inputs: ["fxLayoutGap", "fxLayoutGap.xs", "fxLayoutGap.sm", "fxLayoutGap.md", "fxLayoutGap.lg", "fxLayoutGap.xl", "fxLayoutGap.lt-sm", "fxLayoutGap.lt-md", "fxLayoutGap.lt-lg", "fxLayoutGap.lt-xl", "fxLayoutGap.gt-xs", "fxLayoutGap.gt-sm", "fxLayoutGap.gt-md", "fxLayoutGap.gt-lg"] }, { type: i5.FlexFillDirective, selector: "[fxFill], [fxFlexFill]" }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PreJoinComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-pre-join', template: "<div class=\"prejoin-toolbar\">\n\t<mat-toolbar id=\"toolbar\">\n\t\t<img *ngIf=\"!isMinimal && showLogo\" id=\"branding-logo\" src=\"assets/images/logo.png\" ovLogo />\n\t\t<!-- <span>OpenVidu Call</span> -->\n\t\t<span class=\"spacer\"></span>\n\n\t\t<ov-lang-selector *ngIf=\"!isMinimal\" (onLangSelectorClicked)=\"onDeviceSelectorClicked()\"></ov-lang-selector>\n\t</mat-toolbar>\n</div>\n\n<div class=\"container\" id=\"prejoin-container\" fxLayout.landscape=\"row\" fxLayout.lt-md=\"column\" fxLayout.md=\"row\" fxLayout.gt-md=\"row\">\n\t<div fxFlex.lt-sm=\"50%\" fxFlex.lt-md=\"50%\" fxFlex.md=\"45%\" fxFlex.gt-md=\"45%\" fxLayoutAlign=\"center center\" id=\"layout-container\">\n\t\t<ov-session [usedInPrejoinPage]=\"true\" class=\"ov-session\">\n\t\t\t<ng-template #panel *ngIf=\"!isMinimal && showBackgroundEffectsButton\">\n\t\t\t\t<ov-panel>\n\t\t\t\t\t<ng-template #backgroundEffectsPanel>\n\t\t\t\t\t\t<ov-background-effects-panel></ov-background-effects-panel>\n\t\t\t\t\t</ng-template>\n\t\t\t\t</ov-panel>\n\t\t\t</ng-template>\n\n\t\t\t<ng-template #layout>\n\t\t\t\t<ov-layout>\n\t\t\t\t\t<ng-template #stream let-stream>\n\t\t\t\t\t\t<button\n\t\t\t\t\t\t\t*ngIf=\"!isMinimal && showBackgroundEffectsButton\"\n\t\t\t\t\t\t\t[disabled]=\"isVideoMuted\"\n\t\t\t\t\t\t\tmatTooltip=\"{{ 'TOOLBAR.BACKGROUND' | translate }}\"\n\t\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t\tid=\"background-effects-btn\"\n\t\t\t\t\t\t\t(click)=\"toggleBackgroundEffects()\"\n\t\t\t\t\t\t>\n\t\t\t\t\t\t\t<mat-icon>auto_awesome</mat-icon>\n\t\t\t\t\t\t</button>\n\t\t\t\t\t\t<ov-stream [stream]=\"stream\" [displayParticipantName]=\"false\" [settingsButton]=\"false\"></ov-stream>\n\t\t\t\t\t</ng-template>\n\t\t\t\t</ov-layout>\n\t\t\t</ng-template>\n\t\t</ov-session>\n\t</div>\n\t<div fxFlex.lt-md=\"50%\" fxFlex.md=\"55%\" fxFlex.gt-md=\"55%\" fxLayoutAlign=\"center center\" class=\"media-panel\" *ngIf=\"localParticipant\">\n\t\t<div fxLayout=\"column\" fxLayoutGap=\"10px\" class=\"media-panel-container\">\n\t\t\t<div fxLayout.gt-sm=\"column\" fxLayout.lt-md=\"column\" fxLayoutGap=\"10px\" fxFlex=\"33%\">\n\t\t\t\t<div fxFlex.gt-sm=\"100%\" fxFlex.lt-md=\"33%\" fxLayoutAlign=\"center center\" fxFlexFill class=\"nickname-container\">\n\t\t\t\t\t<h4 *ngIf=\"windowSize >= 960\">{{ 'PREJOIN.NICKNAME_SECTION' | translate }}</h4>\n\t\t\t\t\t<hr *ngIf=\"windowSize >= 960\" />\n\t\t\t\t\t<ov-nickname-input></ov-nickname-input>\n\t\t\t\t</div>\n\n\t\t\t\t<div fxFlex.gt-sm=\"100%\" fxFlex.lt-md=\"33%\" fxLayoutAlign=\"center center\" fxFlexFill class=\"buttons-container\">\n\t\t\t\t\t<h4 *ngIf=\"windowSize >= 960\">{{ 'PREJOIN.DEVICE_SECTION' | translate }}</h4>\n\t\t\t\t\t<hr *ngIf=\"windowSize >= 960\" />\n\n\t\t\t\t\t<!-- Camera -->\n\t\t\t\t\t<ov-video-devices-select (onDeviceSelectorClicked)=\"onDeviceSelectorClicked()\"></ov-video-devices-select>\n\n\t\t\t\t\t<!-- Microphone -->\n\t\t\t\t\t<ov-audio-devices-select (onDeviceSelectorClicked)=\"onDeviceSelectorClicked()\"></ov-audio-devices-select>\n\t\t\t\t</div>\n\n\t\t\t\t<div fxFlex.gt-sm=\"60%\" fxLayout.lt-md=\"column\" fxLayoutAlign=\"center center\" fxFlexFill class=\"join-btn-container\">\n\t\t\t\t\t<button mat-flat-button (click)=\"joinSession()\" form=\"nicknameForm\" id=\"join-button\">\n\t\t\t\t\t\t{{ 'PREJOIN.JOIN' | translate }}\n\t\t\t\t\t</button>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n", styles: [".container{height:calc(100% - 64px);padding:30px 60px;background-color:var(--ov-light-color)}.prejoin-toolbar{max-height:40px;height:40px}#toolbar{background-color:var(--ov-light-color);height:100%}#toolbar ::ng-deep .lang-button{height:25px!important;font-size:14px!important;line-height:0px;align-items:unset!important}.spacer{flex:1 1 auto}#branding-logo{border-radius:var(--ov-panel-radius);max-width:35px;max-height:35px;height:-webkit-fill-available;height:-moz-available;padding:10px;margin-right:10px}#layout-container{display:block!important}h4{margin-bottom:1px;font-weight:700}hr{margin:0}#prejoin-container{height:calc(100% - 40px)}#prejoin-container ::ng-deep .sidenav-container{padding-top:0!important}#prejoin-container ::ng-deep #background-effects-container{margin:0!important;max-height:100%!important;height:100%!important}#prejoin-container ::ng-deep .mat-drawer-container,#prejoin-container ::ng-deep .sidenav-menu,#prejoin-container ::ng-deep #session-container{background-color:transparent!important}#prejoin-container ::ng-deep .sidenav-menu{width:320px}#prejoin-container ::ng-deep .layout{min-width:0px!important}#prejoin-container ::ng-deep .OT_root{padding:0!important}#background-effects-btn{position:absolute;z-index:1;background-color:var(--ov-secondary-color);bottom:5px;right:5px}.media-panel{background-color:var(--ov-light-color)}.media-panel-container{width:100%;padding:20px 0 20px 20px}.nickname-container{display:block!important;margin-bottom:0!important}.mat-form-field-appearance-fill .mat-form-field-flex{border-radius:var(--ov-video-radius)}.buttons-container{border-radius:5px;padding:10px 0;height:100px;display:block!important}.join-btn-container{width:inherit;text-align:center}#join-button{width:100%;font-weight:700;color:var(--ov-text-color);background-color:var(--ov-tertiary-color);border-radius:var(--ov-video-radius)}@media only screen and (max-width: 480px){.container,.media-panel-container,.buttons-container{padding:0}.nickname-container,.buttons-container,.join-btn-container{width:90%!important;margin:auto}.join-btn-container{padding:0 10px}.media-panel{align-items:flex-start!important}}@media only screen and (min-width: 480px) and (max-width: 959px){.media-panel-container,.buttons-container{padding:0}.nickname-container,.buttons-container,.join-btn-container{width:80%!important;min-width:80%!important;margin:auto}.buttons-container,.media-panel-container{padding-top:0;max-width:600px}}\n"] }]
        }], ctorParameters: function () { return [{ type: LayoutService }, { type: LoggerService }, { type: ParticipantService }, { type: PanelService }, { type: OpenViduAngularConfigService }, { type: CdkOverlayService }]; }, propDecorators: { onJoinButtonClicked: [{
                type: Output
            }], sizeChange: [{
                type: HostListener,
                args: ['window:resize']
            }] } });

/**
 * @internal
 */
class SubtitlesSettingComponent {
    constructor(layoutService) {
        this.layoutService = layoutService;
        this.languagesAvailable = [];
        this.langSelected = 'English';
    }
    ngOnInit() {
        this.subscribeToSubtitles();
    }
    ngOnDestroy() {
        if (this.subtitlesSubs)
            this.subtitlesSubs.unsubscribe();
    }
    onLangSelected(lang) {
        this.langSelected = lang;
    }
    toggleSubtitles() {
        this.layoutService.toggleSubtitles();
    }
    subscribeToSubtitles() {
        this.subtitlesSubs = this.layoutService.subtitlesTogglingObs.subscribe((value) => {
            this.subtitlesEnabled = value;
            // this.cd.markForCheck();
        });
    }
}
SubtitlesSettingComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: SubtitlesSettingComponent, deps: [{ token: LayoutService }], target: i0.ɵɵFactoryTarget.Component });
SubtitlesSettingComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: SubtitlesSettingComponent, selector: "ov-subtitles-settings", ngImport: i0, template: "<mat-list>\n\t<mat-list-item>\n\t\t<div mat-line>{{ 'PANEL.SETTINGS.SUBTITLE' | translate }}</div>\n\t\t<mat-slide-toggle (change)=\"toggleSubtitles()\" [checked]=\"subtitlesEnabled\" [disableRipple]=\"true\"></mat-slide-toggle>\n\t</mat-list-item>\n\t<mat-list-item>\n\t\t<div mat-line>{{ 'PANEL.SETTINGS.LANGUAGE' | translate }}:</div>\n\t\t<button mat-flat-button [matMenuTriggerFor]=\"menu\" class=\"lang-button\"  [disabled]=\"true\">\n\t\t\t<span>{{langSelected}}</span>\n\t\t\t<mat-icon>expand_more</mat-icon>\n\t\t</button>\n\t\t<mat-menu #menu=\"matMenu\">\n\t\t\t<button mat-menu-item *ngFor=\"let lang of languagesAvailable\" (click)=\"onLangSelected(lang)\">\n\t\t\t\t<span>{{lang}}</span>\n\t\t\t</button>\n\t\t</mat-menu>\n\t</mat-list-item>\n</mat-list>\n\n\n\n", styles: ["::ng-deep .mat-slide-toggle.mat-checked .mat-slide-toggle-bar{background-color:var(--ov-tertiary-color)}::ng-deep .mat-slide-toggle.mat-checked .mat-slide-toggle-thumb{background-color:var(--ov-light-color)}\n"], components: [{ type: i5$1.MatList, selector: "mat-list, mat-action-list", inputs: ["disableRipple", "disabled"], exportAs: ["matList"] }, { type: i5$1.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["disableRipple", "disabled"], exportAs: ["matListItem"] }, { type: i3$1.MatSlideToggle, selector: "mat-slide-toggle", inputs: ["disabled", "disableRipple", "color", "tabIndex", "name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "checked"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i18.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { type: i18.MatMenuItem, selector: "[mat-menu-item]", inputs: ["disabled", "disableRipple", "role"], exportAs: ["matMenuItem"] }], directives: [{ type: i6$1.MatLine, selector: "[mat-line], [matLine]" }, { type: i18.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: SubtitlesSettingComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-subtitles-settings', template: "<mat-list>\n\t<mat-list-item>\n\t\t<div mat-line>{{ 'PANEL.SETTINGS.SUBTITLE' | translate }}</div>\n\t\t<mat-slide-toggle (change)=\"toggleSubtitles()\" [checked]=\"subtitlesEnabled\" [disableRipple]=\"true\"></mat-slide-toggle>\n\t</mat-list-item>\n\t<mat-list-item>\n\t\t<div mat-line>{{ 'PANEL.SETTINGS.LANGUAGE' | translate }}:</div>\n\t\t<button mat-flat-button [matMenuTriggerFor]=\"menu\" class=\"lang-button\"  [disabled]=\"true\">\n\t\t\t<span>{{langSelected}}</span>\n\t\t\t<mat-icon>expand_more</mat-icon>\n\t\t</button>\n\t\t<mat-menu #menu=\"matMenu\">\n\t\t\t<button mat-menu-item *ngFor=\"let lang of languagesAvailable\" (click)=\"onLangSelected(lang)\">\n\t\t\t\t<span>{{lang}}</span>\n\t\t\t</button>\n\t\t</mat-menu>\n\t</mat-list-item>\n</mat-list>\n\n\n\n", styles: ["::ng-deep .mat-slide-toggle.mat-checked .mat-slide-toggle-bar{background-color:var(--ov-tertiary-color)}::ng-deep .mat-slide-toggle.mat-checked .mat-slide-toggle-thumb{background-color:var(--ov-light-color)}\n"] }]
        }], ctorParameters: function () { return [{ type: LayoutService }]; } });

/**
 * @internal
 */
class SettingsPanelComponent {
    constructor(panelService, libService) {
        this.panelService = panelService;
        this.libService = libService;
        this.settingsOptions = PanelSettingsOptions;
        this.selectedOption = PanelSettingsOptions.GENERAL;
        this.showSubtitles = true;
    }
    ngOnInit() {
        this.subscribeToPanelToggling();
        this.subscribeToDirectives();
    }
    ngOnDestroy() {
        if (this.subtitlesSubs)
            this.subtitlesSubs.unsubscribe();
    }
    close() {
        this.panelService.togglePanel(PanelType.SETTINGS);
    }
    onSelectionChanged(e) {
        this.selectedOption = e.option.value;
    }
    subscribeToDirectives() {
        this.subtitlesSubs = this.libService.subtitlesButtonObs.subscribe((value) => {
            this.showSubtitles = value;
        });
    }
    subscribeToPanelToggling() {
        this.panelSubscription = this.panelService.panelOpenedObs.subscribe((ev) => {
            if (ev.type === PanelType.SETTINGS && !!ev.expand) {
                this.selectedOption = ev.expand;
            }
        });
    }
}
SettingsPanelComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: SettingsPanelComponent, deps: [{ token: PanelService }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Component });
SettingsPanelComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: SettingsPanelComponent, selector: "ov-settings-panel", ngImport: i0, template: "<div class=\"panel-container\" id=\"settings-container\" fxLayout=\"column\" fxLayoutAlign=\"space-evenly none\">\n\t<div class=\"panel-header-container\" fxFlex=\"55px\" fxLayoutAlign=\"start center\">\n\t\t<h3 class=\"panel-title\">{{ 'PANEL.SETTINGS.TITLE' | translate }}</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"settings-container\" fxFlex=\"100%\" fxLayoutAlign=\"space-evenly none\">\n\t\t<div class=\"item-menu\">\n\t\t\t<mat-selection-list (selectionChange)=\"onSelectionChanged($event)\" [multiple]=\"false\">\n\t\t\t\t<mat-list-option class=\"option\" id=\"general-opt\" [selected]=\"selectedOption === settingsOptions.GENERAL\" [value]=\"settingsOptions.GENERAL\">\n\t\t\t\t\t<mat-icon mat-list-icon>manage_accounts</mat-icon>\n\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.GENERAL' | translate }}</div>\n\t\t\t\t</mat-list-option>\n\t\t\t\t<mat-list-option class=\"option\" id=\"video-opt\" [selected]=\"selectedOption === settingsOptions.VIDEO\" [value]=\"settingsOptions.VIDEO\">\n\t\t\t\t\t<mat-icon mat-list-icon>videocam</mat-icon>\n\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.VIDEO' | translate }}</div>\n\t\t\t\t</mat-list-option>\n\t\t\t\t<mat-list-option class=\"option\" id=\"audio-opt\" [selected]=\"selectedOption === settingsOptions.AUDIO\" [value]=\"settingsOptions.AUDIO\">\n\t\t\t\t\t<mat-icon mat-list-icon>mic</mat-icon>\n\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.AUDIO' | translate }}</div>\n\t\t\t\t</mat-list-option>\n\t\t\t\t<mat-list-option\n\t\t\t\t\t*ngIf=\"showSubtitles\"\n\t\t\t\t\tclass=\"option\"\n\t\t\t\t\t[selected]=\"selectedOption === settingsOptions.SUBTITLES\"\n\t\t\t\t\t[value]=\"settingsOptions.SUBTITLES\"\n\t\t\t\t\tid=\"subtitles-opt\"\n\t\t\t\t>\n\t\t\t\t\t<mat-icon mat-list-icon>closed_caption</mat-icon>\n\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.SUBTITLE' | translate }}</div>\n\t\t\t\t</mat-list-option>\n\t\t\t</mat-selection-list>\n\t\t</div>\n\n\t\t<div class=\"item-content\">\n\t\t\t<div *ngIf=\"selectedOption === settingsOptions.GENERAL\">\n\t\t\t\t<ov-nickname-input></ov-nickname-input>\n\t\t\t\t<mat-list>\n\t\t\t\t\t<mat-list-item>\n\t\t\t\t\t\t<mat-icon mat-list-icon>language</mat-icon>\n\t\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.LANGUAGE' | translate }}:</div>\n\t\t\t\t\t\t<ov-lang-selector></ov-lang-selector>\n\t\t\t\t\t</mat-list-item>\n\t\t\t\t</mat-list>\n\t\t\t</div>\n\t\t\t<ov-video-devices-select *ngIf=\"selectedOption === settingsOptions.VIDEO\"></ov-video-devices-select>\n\t\t\t<ov-audio-devices-select *ngIf=\"selectedOption === settingsOptions.AUDIO\"></ov-audio-devices-select>\n\t\t\t<ov-subtitles-settings *ngIf=\"selectedOption === settingsOptions.SUBTITLES && showSubtitles\"></ov-subtitles-settings>\n\t\t</div>\n\t</div>\n</div>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".settings-container{display:flex;padding:10px}.item-menu{padding-right:5px;border-right:1px solid var(--ov-secondary-color);width:200px}.item-content{padding:16px;flex-grow:1}.option{border-radius:var(--ov-panel-radius)}.lang-container button{width:100%}mat-list-option[aria-selected=true]{background:var(--ov-light-color)}::ng-deep .mat-list-item-content{padding:5px!important}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i5$1.MatSelectionList, selector: "mat-selection-list", inputs: ["disableRipple", "tabIndex", "color", "compareWith", "disabled", "multiple"], outputs: ["selectionChange"], exportAs: ["matSelectionList"] }, { type: i5$1.MatListOption, selector: "mat-list-option", inputs: ["disableRipple", "checkboxPosition", "color", "value", "disabled", "selected"], outputs: ["selectedChange"], exportAs: ["matListOption"] }, { type: NicknameInputComponent, selector: "ov-nickname-input" }, { type: i5$1.MatList, selector: "mat-list, mat-action-list", inputs: ["disableRipple", "disabled"], exportAs: ["matList"] }, { type: i5$1.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["disableRipple", "disabled"], exportAs: ["matListItem"] }, { type: LangSelectorComponent, selector: "ov-lang-selector", outputs: ["onLangSelectorClicked"] }, { type: VideoDevicesComponent, selector: "ov-video-devices-select", outputs: ["onDeviceSelectorClicked"] }, { type: AudioDevicesComponent, selector: "ov-audio-devices-select", outputs: ["onDeviceSelectorClicked"] }, { type: SubtitlesSettingComponent, selector: "ov-subtitles-settings" }], directives: [{ type: i5.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { type: i5.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }, { type: i5.DefaultFlexDirective, selector: "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", inputs: ["fxFlex", "fxFlex.xs", "fxFlex.sm", "fxFlex.md", "fxFlex.lg", "fxFlex.xl", "fxFlex.lt-sm", "fxFlex.lt-md", "fxFlex.lt-lg", "fxFlex.lt-xl", "fxFlex.gt-xs", "fxFlex.gt-sm", "fxFlex.gt-md", "fxFlex.gt-lg"] }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: i5$1.MatListIconCssMatStyler, selector: "[mat-list-icon], [matListIcon]" }, { type: i6$1.MatLine, selector: "[mat-line], [matLine]" }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: SettingsPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-settings-panel', template: "<div class=\"panel-container\" id=\"settings-container\" fxLayout=\"column\" fxLayoutAlign=\"space-evenly none\">\n\t<div class=\"panel-header-container\" fxFlex=\"55px\" fxLayoutAlign=\"start center\">\n\t\t<h3 class=\"panel-title\">{{ 'PANEL.SETTINGS.TITLE' | translate }}</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"settings-container\" fxFlex=\"100%\" fxLayoutAlign=\"space-evenly none\">\n\t\t<div class=\"item-menu\">\n\t\t\t<mat-selection-list (selectionChange)=\"onSelectionChanged($event)\" [multiple]=\"false\">\n\t\t\t\t<mat-list-option class=\"option\" id=\"general-opt\" [selected]=\"selectedOption === settingsOptions.GENERAL\" [value]=\"settingsOptions.GENERAL\">\n\t\t\t\t\t<mat-icon mat-list-icon>manage_accounts</mat-icon>\n\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.GENERAL' | translate }}</div>\n\t\t\t\t</mat-list-option>\n\t\t\t\t<mat-list-option class=\"option\" id=\"video-opt\" [selected]=\"selectedOption === settingsOptions.VIDEO\" [value]=\"settingsOptions.VIDEO\">\n\t\t\t\t\t<mat-icon mat-list-icon>videocam</mat-icon>\n\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.VIDEO' | translate }}</div>\n\t\t\t\t</mat-list-option>\n\t\t\t\t<mat-list-option class=\"option\" id=\"audio-opt\" [selected]=\"selectedOption === settingsOptions.AUDIO\" [value]=\"settingsOptions.AUDIO\">\n\t\t\t\t\t<mat-icon mat-list-icon>mic</mat-icon>\n\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.AUDIO' | translate }}</div>\n\t\t\t\t</mat-list-option>\n\t\t\t\t<mat-list-option\n\t\t\t\t\t*ngIf=\"showSubtitles\"\n\t\t\t\t\tclass=\"option\"\n\t\t\t\t\t[selected]=\"selectedOption === settingsOptions.SUBTITLES\"\n\t\t\t\t\t[value]=\"settingsOptions.SUBTITLES\"\n\t\t\t\t\tid=\"subtitles-opt\"\n\t\t\t\t>\n\t\t\t\t\t<mat-icon mat-list-icon>closed_caption</mat-icon>\n\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.SUBTITLE' | translate }}</div>\n\t\t\t\t</mat-list-option>\n\t\t\t</mat-selection-list>\n\t\t</div>\n\n\t\t<div class=\"item-content\">\n\t\t\t<div *ngIf=\"selectedOption === settingsOptions.GENERAL\">\n\t\t\t\t<ov-nickname-input></ov-nickname-input>\n\t\t\t\t<mat-list>\n\t\t\t\t\t<mat-list-item>\n\t\t\t\t\t\t<mat-icon mat-list-icon>language</mat-icon>\n\t\t\t\t\t\t<div mat-line>{{ 'PANEL.SETTINGS.LANGUAGE' | translate }}:</div>\n\t\t\t\t\t\t<ov-lang-selector></ov-lang-selector>\n\t\t\t\t\t</mat-list-item>\n\t\t\t\t</mat-list>\n\t\t\t</div>\n\t\t\t<ov-video-devices-select *ngIf=\"selectedOption === settingsOptions.VIDEO\"></ov-video-devices-select>\n\t\t\t<ov-audio-devices-select *ngIf=\"selectedOption === settingsOptions.AUDIO\"></ov-audio-devices-select>\n\t\t\t<ov-subtitles-settings *ngIf=\"selectedOption === settingsOptions.SUBTITLES && showSubtitles\"></ov-subtitles-settings>\n\t\t</div>\n\t</div>\n</div>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".settings-container{display:flex;padding:10px}.item-menu{padding-right:5px;border-right:1px solid var(--ov-secondary-color);width:200px}.item-content{padding:16px;flex-grow:1}.option{border-radius:var(--ov-panel-radius)}.lang-container button{width:100%}mat-list-option[aria-selected=true]{background:var(--ov-light-color)}::ng-deep .mat-list-item-content{padding:5px!important}\n"] }]
        }], ctorParameters: function () { return [{ type: PanelService }, { type: OpenViduAngularConfigService }]; } });

/**
 * @internal
 */
class RecordingActivityComponent {
    /**
     * @internal
     */
    constructor(recordingService, participantService, libService, actionService, cd) {
        this.recordingService = recordingService;
        this.participantService = participantService;
        this.libService = libService;
        this.actionService = actionService;
        this.cd = cd;
        /**
         * Provides event notifications that fire when start recording button has been clicked.
         * The recording should be stopped using the REST API.
         */
        this.onStartRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when stop recording button has been clicked.
         * The recording should be stopped using the REST API.
         */
        this.onStopRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when delete recording button has been clicked.
         * The recording should be deleted using the REST API.
         */
        this.onDeleteRecordingClicked = new EventEmitter();
        /**
         * @internal
         */
        this.recordingStatus = RecordingStatus.STOPPED;
        /**
         * @internal
         */
        this.opened = false;
        /**
         * @internal
         */
        this.recStatusEnum = RecordingStatus;
        /**
         * @internal
         */
        this.isSessionCreator = false;
        /**
         * @internal
         */
        this.recordingAlive = false;
        /**
         * @internal
         */
        this.recordingsList = [];
    }
    /**
     * @internal
     */
    ngOnInit() {
        this.subscribeToRecordingStatus();
        this.subscribeToRecordingActivityDirective();
        this.isSessionCreator = this.participantService.getMyRole() === OpenViduRole.MODERATOR;
    }
    /**
     * @internal
     */
    ngOnDestroy() {
        if (this.recordingStatusSubscription)
            this.recordingStatusSubscription.unsubscribe();
        if (this.recordingListSubscription)
            this.recordingListSubscription.unsubscribe();
        if (this.recordingErrorSub)
            this.recordingErrorSub.unsubscribe();
    }
    /**
     * @internal
     */
    panelOpened() {
        this.opened = true;
    }
    /**
     * @internal
     */
    panelClosed() {
        this.opened = false;
    }
    /**
     * @internal
     */
    resetStatus() {
        let status = this.oldRecordingStatus;
        if (this.oldRecordingStatus === RecordingStatus.STARTING) {
            status = RecordingStatus.STOPPED;
        }
        else if (this.oldRecordingStatus === RecordingStatus.STOPPING) {
            status = RecordingStatus.STARTED;
        }
        this.recordingService.updateStatus(status);
    }
    /**
     * @internal
     */
    startRecording() {
        this.onStartRecordingClicked.emit();
        this.recordingService.updateStatus(RecordingStatus.STARTING);
    }
    /**
     * @internal
     */
    stopRecording() {
        this.onStopRecordingClicked.emit();
        this.recordingService.updateStatus(RecordingStatus.STOPPING);
    }
    /**
     * @internal
     */
    deleteRecording(id) {
        const succsessCallback = () => {
            this.onDeleteRecordingClicked.emit(id);
        };
        this.actionService.openDeleteRecordingDialog(succsessCallback);
    }
    /**
     * @internal
     */
    download(recording) {
        this.recordingService.downloadRecording(recording);
    }
    /**
     * @internal
     */
    play(recording) {
        this.recordingService.playRecording(recording);
    }
    subscribeToRecordingStatus() {
        this.recordingStatusSubscription = this.recordingService.recordingStatusObs.subscribe((ev) => {
            if (ev === null || ev === void 0 ? void 0 : ev.info) {
                if (this.recordingStatus !== RecordingStatus.FAILED) {
                    this.oldRecordingStatus = this.recordingStatus;
                }
                this.recordingStatus = ev.info.status;
                this.recordingAlive = ev.info.status === RecordingStatus.STARTED;
            }
            this.cd.markForCheck();
        });
    }
    subscribeToRecordingActivityDirective() {
        this.recordingListSubscription = this.libService.recordingsListObs.subscribe((recordingList) => {
            this.recordingsList = recordingList;
            this.cd.markForCheck();
        });
        this.recordingErrorSub = this.libService.recordingErrorObs.subscribe((error) => {
            var _a;
            if (error) {
                this.recordingService.updateStatus(RecordingStatus.FAILED);
                this.recordingError = ((_a = error.error) === null || _a === void 0 ? void 0 : _a.message) || error.message || error;
            }
        });
    }
}
RecordingActivityComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingActivityComponent, deps: [{ token: RecordingService }, { token: ParticipantService }, { token: OpenViduAngularConfigService }, { token: ActionService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
RecordingActivityComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: RecordingActivityComponent, selector: "ov-recording-activity", inputs: { expanded: "expanded" }, outputs: { onStartRecordingClicked: "onStartRecordingClicked", onStopRecordingClicked: "onStopRecordingClicked", onDeleteRecordingClicked: "onDeleteRecordingClicked" }, ngImport: i0, template: "<mat-expansion-panel (opened)=\"panelOpened()\" (closed)=\"panelClosed()\" [expanded]=\"expanded\">\n\t<mat-expansion-panel-header>\n\t\t<mat-list>\n\t\t\t<mat-list-item>\n\t\t\t\t<div\n\t\t\t\t\tmatListAvatar\n\t\t\t\t\tclass=\"activity-icon\"\n\t\t\t\t\t[ngClass]=\"{\n\t\t\t\t\t\tstarted: recordingStatus === recStatusEnum.STARTED,\n\t\t\t\t\t\tstopped: recordingStatus === recStatusEnum.STOPPED,\n\t\t\t\t\t\tfailed: recordingStatus === recStatusEnum.FAILED,\n\t\t\t\t\t\tpending: recordingStatus === recStatusEnum.STARTING || recordingStatus === recStatusEnum.STOPPING\n\t\t\t\t\t}\"\n\t\t\t\t>\n\t\t\t\t\t<mat-icon *ngIf=\"recordingStatus !== recStatusEnum.FAILED && recordingStatus !== recStatusEnum.STARTED\">\n\t\t\t\t\t\tvideo_camera_front\n\t\t\t\t\t</mat-icon>\n\t\t\t\t\t<mat-icon *ngIf=\"recordingStatus === recStatusEnum.FAILED\">error</mat-icon>\n\t\t\t\t\t<mat-icon class=\"blink\" *ngIf=\"recordingStatus === recStatusEnum.STARTED\">radio_button_checked</mat-icon>\n\t\t\t\t</div>\n\t\t\t\t<h3 matLine class=\"activity-title\">{{ 'PANEL.RECORDING.TITLE' | translate }}</h3>\n\t\t\t\t<p matLine class=\"activity-subtitle\">{{ 'PANEL.RECORDING.SUBTITLE' | translate }}</p>\n\t\t\t\t<div class=\"activity-action-buttons\">\n\t\t\t\t\t<div\n\t\t\t\t\t\tid=\"recording-status\"\n\t\t\t\t\t\t[ngClass]=\"{\n\t\t\t\t\t\t\tstarted: recordingStatus === recStatusEnum.STARTED,\n\t\t\t\t\t\t\tstopped: recordingStatus === recStatusEnum.STOPPED,\n\t\t\t\t\t\t\tfailed: recordingStatus === recStatusEnum.FAILED,\n\t\t\t\t\t\t\tpending: recordingStatus === recStatusEnum.STARTING || recordingStatus === recStatusEnum.STOPPING\n\t\t\t\t\t\t}\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<span>{{ recordingStatus | uppercase }}</span>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</mat-list-item>\n\t\t</mat-list>\n\t</mat-expansion-panel-header>\n\t<div *ngIf=\"opened\" class=\"panel-body-container\">\n\t\t<div class=\"content\">\n\t\t\t<!-- Recording image -->\n\t\t\t<div *ngIf=\"recordingsList.length === 0\">\n\t\t\t\t<img\n\t\t\t\t\tsrc=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAACyCAMAAABcOSIOAAAC+lBMVEUAAAAXf/wpbeLk19IWf/zq2Mnf19vc3OYWf/ze3ujc3OcVf/0Wf/wXffvY2OQWf/3d3efd3OYWf/3d3efe3ujd3egVf/3d3ecVfv3d3efb2+bc3Ofc3Ofd3ejc3ejd3ugVf/3/zJcXf/zc3Obd3ugVf/0Wf/zPz93c3OdZW9QVf/3d3efZ2eQVf/0Vf/zb2+j7voHe3ugVf/39zJgLDxbX2OUYgPv/zJcXfvz/zJfd3eja2uZTVHd6e6Lc3Of/zJd4ead7fKOevuxXXNX+zJj+yZP/zJd2d55an/T/zJelpsZfd9b/ypRXXNXkhiOiqc0BBw9ZW9T/zZYAAAD1ljH8y5lxc9jyjiXwkCr+/f3/zZfsjCYAAACbq9EBCBDzlzjtiyVtbpYAAQLjw6b4okg9j/PjyLX3sWlrbJNCZ+JTVHegyv0SaM1clt6WmMlIXI8Vf/3/zJf////V1eT/lSalpsbe3unY2OVZW9RTVHflhiLnuIgAAADU1OT9/P5RUnYTf/+qq8lWWNT+liimp8bp6fFyc9BhlODu7vT8lCZ6fKTKyt22t88qhfW8vdD+y5bc3OgggvhYWXzFxtpcX9SUw/2am+WPkMqio8dT2WpiY4Q/aeSTos0ld/NUXtf3kin+nTfqiiXx8fYyiO/39/rk5O44gd5HZd+Ojqf6yZbxjST/tGaGiKHyyJ3+xId8ftntvoz+qVBIjuV3eJ5eX4D/vXiGs/A9i+j2xZIhf/GKi9uEos7ywpDgwqf/yJDslDjZtJC1s7fMsJcZd+hrmdWlq7dydJlxqPG4rKO3yepTkuB3m8pQhceaq8PGubBTYHZTXXZTrG7vq2Tlw6JTcXS4km0MLFXik0A7kPhek9Q1abhoh7TOvK1uZntUVnhT0WuZoLTnu5JsbYxKW4wLQoRUU3VTwWzJkVgWa9KqkYfbrX7yoUs0Kh8OV66WiYdpVUGGnr54iaP1s293YEjMpH6qjnW3iV2ZelpLOyzd0MtdX7WHiMxkgKclYKhp7MdAAAAAcHRSTlMA/gcE5w4JFvPvtSTcEPg9lHLQNPg8GqAuKuuI29K/qk7ycVZ9i18fyb2wRE3FfyMd37k8/eem15jmZmGV1FwuGm/87MeGnE3+roJpYz313q6ZUsi/uuXWl4pxbVs3kWBGNibl3NPFpH3w6efczLu2U2kwRQAAFbNJREFUeNrs2T+L02AcwPHnic8QeJ4QyFAyaQgkQ6EZOpQOFhSHG8TB0fE2/ww+PRCa5eJB9aAnelSP6tXecuILsIODJ4g9dJK7wk0HVUQUXHwDLvaBmIfmkvTZmofmO2XI8uF5fvDwPKCoqKioqKioqKioqGgmDWOsKWDZUrBbNxBCRtVx8TLxS24ZQRoGUdktgeUIewakM0HimECg1ZuXLwF5K3mEJoTq5nx4o9NpSItXXIOmhLzsbb9y2+/ufpIWj2uQplexQEYXfd8PpMXrBs1MdbRMurx4i9B5Vc0surR4C9H5GXoGXVa8SahIxEqnS4pXylQsZKXSJcW7kApG9DS6nHilOk8MB/1+f8C+DJxClxNvornwvVartdcfQEprWjJdTrwFBeAshoe2GJ3jV0B+c6EQ/NnDv73e4T7BAnSOH3YaqyC3WVAI3nvenvbybT2dfhwV4Xc7nRwvOyZi8Hus9jtiptGPxr/Cxkd+WHeYZzqoC8NZb+w0+vH4Rdi3E0noJhGCbzze2nrUbm+WlWQ6W3bZ6MBSBeBPH6yvrb3a3tisaPGJuetHdtnowFWF4KztON10yOlPbpeNDlwkAmetf57Z8HodUcro3B6nXwX5Tq/ATDhvxwNRJoOHdG6P0V87GOQ6za6oGXDeHTOacQdRFhz98GfWPUanhpXz+3zNvpUO512IfifRkIxOGZ7bY3Sq1vN8nX/u2vUrGXDeDcBSLDYhvCk+4PYYfVpFBzlNDM7pZk2lsUbDiR+E9pOvcTpFbh42vVLSXdtzHM92dawIwzm95CF6pv33339HeD8IOJ3f6S42xbTLRIXhkKqk6lhCcE5Pfqu4f/ik2fyPD7qTSTdGp7C20IFXrBo6c3ITgfPOlyFN6kuTxfD+5M+Hg4OPE04Pq2KwsPSa6JE1vR2aGPxHvJnFuhCFcXyq2lJUq6ra20W0KC1CXJFKPNSLRCTEKx48e+iozHmo1lgaFblpG9uLhFSLxi5xqX0N1/ZA7EsIYt9iT0icMzPt12lnalp6/Sy36t6H33zf9z8L9xRNC/IvH9OEl0tAXWDAYOr/0A9GtBHxXDaRSOb+pJ65Sos59A7Uwf3/BH2fUaomxLN5FInEIgi/X1/9fqX3rtMvHzyEhhff6fbo7qzvP6CZiudRLMKTUF71+5f2F8kmh1cvCjlIfrKqBfNmzp49c858qvvo37eJGc+msbgAyimZdcL1/SxZ54n8syf3tvK9Vnz79ObTM29vTljMMXsO1WrAXLk4mOOSAwlQl014wtWLsMN78kIYshc3ibDgzb3sLvfBAxoQB/NIBbF8XfWDx0pjTmouUCyWngIxFzO7e3q+3/hGxMFcuXqm3O+npJb9p4trmUd1B8MUiwNxJtaA+qWCYF5YyYZrOAOdDkzojrIP6aVYHMhHxMTqzfrB6+VJz0hscl+AegXdMO2DBjQsDu0OJEFdvt3pS2EpdfDt3o4fplwcyAvtrmhxO1ugBY5tCUsgXfWZLd/a9O+pWBzIoep+Z+KgLp3uhCvSi/5NKfXZrVbvMVG5OJCI1fa7nLrqXIour2zS+b/9zf+oev9eDYpDvIuLLqfO3jlKlzgFISe+xvj8XUKdajGTGheHfgeysie3jgvloqfOstL7nV303m/fa9RbfG0zvYGLCCBbbZ6XP7ReOkRLhxywfxf+y1ck6yZ8e19WfzuUaiUzpjYhDurQ7rLqB0+mZEIOuEjUU9+w7if6cyntJ7zo2dLT+yzeXCzeqHosnZO9pVE9gqLvuhiWrTpx/7T4/VH6xmKBm6rw+Ba2fI+RvHkD4jDrYJ6VvaBiLz6Got+HkKuZdcL7xTdo+lOp6HfZsApavkXqazesUCwOCQ/dnpO/m8tcgHinj1QrQ8LTmL1vJrzCvwnmP7s68KVN6y4q+0zliw7iCkmWxSN5MK9VPxst0PKLOjygG1Eat/qbvTjsePO351EIN8mw5ry0I6g/MXwbpw7iSoknIjHsHYswWfjCWvUtF/am6DonFziuf4++erP4e6Fw6D0352/D0xDqzIR7NndHa/N5qD8wkVdfCgmtmGw+nWbyIC6pfimqpN9Zclx/gzv9/aGj9NFvnz79OsMSdRS63WTZLQN7m7RVjWARvTGoL6+eXtgM8Th4S6tvOV2/30GdY8KNvQUuDjvwm+cRpmtac9PuH8gMNGqoSkyOseKDOlFfdhimtXniEseXD1FF/c6+5dXfR49Ce3QiQuz8UJ26KXWGcesoYHLvgRaqgjEqTn3934snmTSTyFWpHzxd2e8bJbXham7C03t7U+U9nyqEePeQa2wTDd+bwegh7IL4jSmi/+j+j9Tj+UgM/0hneXUoerRyP8PWccc30S/wsR5u7zJdSKDd1rj6iHGMyN1DHoVJNOqg/pfmHDGU5NSh6NFUnf07y7KqTLFYVJFX5NeR8nb39u1MCAnYm1BX67Eq9LxtHAPqWv68Cup/b05AWaIORd9LE6CWld7Fy/feffn6/PnzG18+Xi5i8477NMc5rN7VWVY3BEWLtMZj0nF25oBG3j3I8Fg15FOtTFld49WTLx8eBvW/NIdzzDqId+j36qWNzVx+9/zE8kUlNj3feXnrORojBPx5BLTrdeBk1iPkIR+tdojsWkY4BXevWph8ftY1Rmagn1zKgfpfmgPJdbCmRyuWttRKtlL8xglBGuyv0RX31ZlOVEGw3MiT2xFR17Xhj8Z60R9M8+q9AxTVxhCIstZIHgFJuT+ox3PZZDKbizdgHmPWlW8ocL+nJFf1rV82LaplByyDHWHsHgF1vVbYpBkNZPjNNj0ZBD+lMfstOml1jZ7h8em0LoYwDjeJiSx6+EH2G1BXPZ5kEDe/sGeTIBERgzpL11JR0ahfL6UcW/x4C3yB5Qfgk6+oOs6fD4G7YwRfcgf/IMw+7s2AyWU3GJywbRNhK7W8SedgCPj5WezCzPfpWU89y0RiQiXxspXIyW3lZdQz57D6Ubom4NmtN1YtkmLzbvjkwpHbXSgG6nYzkTEZ+NjzuviPdsRjlI47CzYmOM1OIeXUbv4FCfg66kkUEzUygtLLm4M6u/8kVj9UW/WLr8BWrH6cBnYdmdaFAIOFGmG2OYTU86EqrDZpd6HuJq738eOz2RnCZPKdHaBea17thA9pyXidOQd1YWWDlIN/a8sc2bV7s7T6vhRdQeHKtBCqrLqx3WpAcjiMgRFqiZ53DySqRhO3xKupKXzc4eAbGgZ1eXOg3PcwErLqHaejXMoBVw+GVftPpejUPhl1WsTuz/c6V1fMuhW1ozoYHO6geOa1Go1aO4UU3kqq3dtfSvreeHrGyKpnUUQGlE/mhPTPo4icOgk5IeWAY+dOcfdQB2A5Fwc8cPzAvs2LTnxeU+5oNTUZuQx13X0Qd1qbx2t1+Xwu4xSL18EYyYwb1aUt3jicmZPk1HPpiCw4fJhEIpkg6S+vrnoUhZSrAjpeJuB379jMP53XxxAmsjo0l6I8BquhjrjeU866EUG9Pc0IOLz+oImazJDtj46ffRd+RBPxhnEtqFddvNWx5+9n6qmTnRyknJjUvnoBD+LkzSjW7brda7A6YHW3tfNj7UQ1uKZAyOtcjAjn5IDfbMfRVko5I7ejyYT2LAN1CK/mYZKdfL9DytUgrX68JC7qhWs/8JG9Y3qbCYd4wEHy3T+izY7b28DFn8vR3u50T9FRgDbo603SDfC524xkGMz8fjbIfZvueSShnvwb8Th/fHnUiDoE/HGR+HLMIuyOutb4TIGA16gnvs6xlN+JjCbSA4YpurFja64yNGaPqc3tGsdlmsvttnrbvNryIb63BauPvh1L16rn0F+Ik/M6v4mFgFekvmofCcB9y8FbQBh4ZCDaXKnbyK2j3cL1AF6xZFCrPaT2A91+Nf6Dx6srVd2BX/Ub3cmAumjQmxXHxIn6wZMQ8IrUScCnSMnBHAb+MQKwvB67jHWb8BnOQKJfFttvWu4ltIkgjAP4yJpdsqBsSMKSbJIiu9BCAjGIiBYUREVBFMQXelDwdRXERCPxgc/YGFP1JEJTX2grRcX6topY3ydFVIQivQgKooKC4sGZnazfms3ETTb7P4ivy8/vm/lmpo20v71yEP+lhBRCQoTOd0xfl6tB3+sMfiB9lXwD+DbY4C0ZosJ8FX2IlBzk5sY32dskUdWbWiBvrAkBsePpSNN4pSRCcdmPZOPWPm5hGujQ7s7gdIf/AnTGcMv39VTRoRdAbtT95XjjPBMWVQ7ZjC9tJDLNg4Jt8aCXHmjwmAM67O45J3Ay9R/hqY6XOnutD+4m8l6oOmhryUl/fFqvQctLgg121ZgriUEUFFUJ39/ohmelH3AIx3lEdzn2Dt+PnyV6sxY6Q06zWDWdZxRkM/TKRhOexvlFLRZQaT9Y6KdLjuAkR/fTAw3zSHP4Ur4vm832WXhWOpQ9vwHoHdORbXsM7AEN/1KR9ZaRrfQzTuG5o7v20w2e2fEDZSyvT6914vkJTzYeZDuClgJ7J0pENYTDxyz0kxmHcP1D3PSuztzoBnuzJD02ig7J57+RyU7jQw0k6RMjXm84IkqSFA/K0STd+4EOI90RfNfmzQad0fKHr7/INkCHlO9IsvFCG0SNhBNC/pDAkZ+0t0syX4u+1zkc6LXt529vo/TevD06ZO1E5e9w5xuye0LxuB/b6a6vIcRX00+XHMMJna51sB82lxz/BtAby+7ZSjNfihISEr7OBLxReXqSvlolENdWRT+TcwYHOn6igVw8/xd+kfz6o07vY9NZf7LWN94Y7Qm7vR5UooG/sz0lkS+xd0b9SAN6I3tciQUH+phhYgT89fP4uyVuEzjJXSz/8SPPlLP+VfKrYkbZO22w4TEe4hUTHFI6ksEA0G3vccVzw9sZcKDvfLatTj4t+PH7xldm0fuYa2Gxz3iLtTfZ4WESEpBDfJtI3ujhvr7XHvz4joenGXCgk8XOzP1z5GuLF1jynmyWRd+9Rpkmjqdv03bDqzHvv/iI2t4h4zPNTONt7nTGHnzHjocnWXCgj3nPcN97/ODUGPwqzaTne+vMvRdhP0++6NYhNLK/x/X1DvH64pFo+skbSodrS304zpX3JQYc6OQ7p2q6n13rxm4cJr2v3sgvr08ipIbhEG97l5cjJn1A0gKZucaL7F678AtF7AY4g45bfriKfX8Yu+FrrV9ZRa97xl1OIMr4OGo47aochc6PpSaPrdBPZmzDM0w40Em63w7fv1dRP37/7Kne50B/l2es9Lozf9lEUkM52Qjao0nKND+PkBCc7lMUSRY7IqmUt1L1myXHcMhlQzfm1OW3OE8vn+oes5O6gf68dlf/73y/UsdwjdB5UX+d9CVRJZxHaE/KTw5Reuvge251m4A4gLZBz2N33Y5f7EENx08vbynJz5l+M/wI6E7gkFunLMya9LN3GZtc/Y7vWY0aj6+UhgdKI9KTY0BvAfzE/kMbndLrd/zyhtBwprPgQ5PxkQbo7sOB/pqxv0PHsza6Zlue4tsSPNKjAN19OJsO+zt0PL2/lstl/RILB3nURDrNU12k+ORSS8Pnil2uwtn0PKFDx+8uXxocGBgaGBjsv1SmfPx7G7gm6JyG7YBv89NPQVTRc+eOFzKuwoFuXepQ9t3l/gG46BM+Tv/g0JSJqCn7Pyf5sCYYdKh4rmt05L2LcKCzpjpNuX/I+par/7AINWVXo2lzYn6DDhXvGt1xxF04u+FN9Lsgr8oc1FyS0j+FT3X+Q9crjv+DJHfhMNysuxzkG4sOHd9guLhoxoeXmnb4jF5xLHcXDqc561K3UfYJk1Cz4YNaWzQVDodTkZiimqte1Cu+deSge3C4vjB2ORtln40chPO0h0KhpMDDNkfHGan4kZGCa3Cgf2YsdRtlX8KjFsSgZ3Q4lo9cKIyO7Mq4BIfc+MCa6pAXDPrUGc1ZBVVRpgUFjlaf5yndmONHjhRyo8eLGdfgsNRZRYe8nmBlOxhv8Y4AOchGRUnTFFmMiUu34PyqzPFdoyOFTbuKbsEh3d+Z+ztk+ZxWLnY1nIYE8FsFfowm9Moc7yIVz2xyDQ6bnI2iL5s4aULrFns8ZT7IxtuFUCetemWc5dytOLT7a6u8r0q+YBXi5rVssvMiVZdKAW9sOg+fZN53rkDHmasVh+PMB7Yc2p1DaH7LJjsX9Cmar1NV1YTfg5CJXtzk+jgD+Y1XNuT6vXzG1Nr2+chpgL6n2JVzFw7p/sxe59Du+kOUZwpjn2shHX98vVBwFQ752mPZ263ylagefR7XQjrELThc2djNDnJqY23xszwu0F2CQ268si3nJs1iXt5coLsGh4nOaHbIYrzOPRMnrZgHNa/KVBfo7sDph3Xh7M4uee+f9u6etW0gDOD4SZHLgXQIbhAaZYEUIiohZJDlyR1kgxOXUtMsgUylY4uzdSy00DEYOnQIlOCpFHcIlA4mKQZnSXGGeM0naLasXXoXhyqt6/pFl8Ry9IPgBLz8L7asF6xnd/fbk2q1VAkLpHukbJF5Ovtw8g3N5lH3e7vd7h41G9GlttcXPtBU6uzs7OTk5PycnobMbm+Nk80xTmcfzjW7h6f91qCl1T/u7fz4NPBl4DNxcHCw/WftrafHD9/r9UkTa+xf8OyPztp95s3RETsDj6N0NuEcFCRse5b3vLV1XfIumzuPDac/mjGcE7DlmLKqIJ5wS2GeKFzDCoT3mN1vjqZH4aubujBDtmeYKgJXZajl++vM08uAjYcrL9+9fxOFLwMAZIubKts2tGgUO88jpCiKSJFHtBkyLt+uAUbQ2srPq+EUMvGE3RAHpspfJCuqZuqGb3k2liRJoMgjxs929plu6cMMYObB2oso/JKiY25stuTrMqLVoub4tiTAEU9sdnud4+PDzuBDPqZsDbDEb66uRuHRgP3/ZVuOrPD0eZphC2OWidw1r9EgP829t+1e53S/9XHm8kIVXLNoEMpwtWAHOs2mZAPD+hRe0VVofj3qtg87T/OF7LTh5Ry4Ibyo6YGHJeGChD3fMWURgUtiINRnQg9nGoK/lqttlMqVkKzB+H33bL6yUVwCN4pHiqgSooL4ofkRsUBP4+mFMNct5mpVsgrlynpIdgYKhexv5I98uF4uVXPuEpgXCq7HBi0ZROgVoUzGJStRLOYGyG+um5mf6GiCa3yCPg+DraYkwzoLMIHtyKozAU2QOCpm047neYjfCDKjdh0kj+pxLNJ9kEB0OmV8VvI2dJSo2zBuugESCsnRAcxMhLmd1zkBpGqOhYXZ/v2cAxKOR6JsOr4nTbkCnJHMd/owerZGNywMucnKobMo5dECmMEk2z+sgUWEZGdMvWAkcEduQkjz4ejwQAWLjJetf8ZDW5/zwetM4gMJ/n3FwpERuBOUwdnqwfm9QNfEBduqj4EUkVDQ3apOpVKpVCqVSk3sF8syBtQPXiTJAAAAAElFTkSuQmCC\"\n\t\t\t\t/>\n\t\t\t</div>\n\n\t\t\t<h2 *ngIf=\"recordingsList.length === 0\">{{ 'PANEL.RECORDING.CONTENT_TITLE' | translate }}</h2>\n\t\t\t<span *ngIf=\"recordingsList.length === 0\">{{ 'PANEL.RECORDING.CONTENT_SUBTITLE' | translate }}</span>\n\n\t\t\t<!-- Recording button -->\n\t\t\t<div *ngIf=\"isSessionCreator\" class=\"item recording-action-buttons\">\n\t\t\t\t<button *ngIf=\"recordingAlive\" mat-flat-button id=\"stop-recording-btn\" (click)=\"stopRecording()\">\n\t\t\t\t\t<span>{{ 'TOOLBAR.STOP_RECORDING' | translate }}</span>\n\t\t\t\t</button>\n\n\t\t\t\t<button\n\t\t\t\t\t*ngIf=\"recordingStatus === recStatusEnum.STOPPED\"\n\t\t\t\t\tmat-flat-button\n\t\t\t\t\tid=\"start-recording-btn\"\n\t\t\t\t\t(click)=\"startRecording()\"\n\t\t\t\t>\n\t\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.STOPPED\">{{ 'TOOLBAR.START_RECORDING' | translate }}</span>\n\t\t\t\t</button>\n\n\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.STARTING\">{{ 'PANEL.RECORDING.STARTING' | translate }} </span>\n\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.STOPPING\">{{ 'PANEL.RECORDING.STOPPING' | translate }} </span>\n\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.FAILED\">Message: </span>\n\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.FAILED\" class=\"recording-error\">{{ recordingError | json }} </span>\n\t\t\t\t<div>\n\t\t\t\t\t<button\n\t\t\t\t\t\t*ngIf=\"recordingStatus === recStatusEnum.FAILED\"\n\t\t\t\t\t\tmat-flat-button\n\t\t\t\t\t\tid=\"reset-recording-status-btn\"\n\t\t\t\t\t\t(click)=\"resetStatus()\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<span>{{ 'PANEL.RECORDING.RESTORE' | translate }}</span>\n\t\t\t\t\t</button>\n\t\t\t\t</div>\n\t\t\t</div>\n\n\t\t\t<!-- Message for no Moderators-->\n\t\t\t<p *ngIf=\"!isSessionCreator\" class=\"not-allowed-message\">{{ 'PANEL.RECORDING.NO_MODERATOR' | translate }}</p>\n\t\t</div>\n\t\t<mat-divider *ngIf=\"recordingsList.length > 0\"></mat-divider>\n\n\t\t<!-- Recording list -->\n\t\t<div *ngIf=\"recordingsList.length > 0\" class=\"item\">\n\t\t\t<mat-list>\n\t\t\t\t<div mat-subheader>{{ 'PANEL.RECORDING.RECORDINGS' | translate }}</div>\n\t\t\t\t<mat-list-item *ngFor=\"let recording of recordingsList\">\n\t\t\t\t\t<mat-icon class=\"recording-icon\" mat-list-icon>video_file</mat-icon>\n\t\t\t\t\t<div mat-line>\n\t\t\t\t\t\t<span class=\"recording-name\">{{ recording.id }}</span>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div mat-line class=\"time-container\">\n\t\t\t\t\t\t<span class=\"recording-duration\"> {{ recording.duration | duration }} </span>\n\t\t\t\t\t\t<span class=\"recording-size\"> | {{ recording.size / 1024 / 1024 | number: '1.1-2' }} MBs</span>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div mat-line class=\"recording-date\">{{ recording.createdAt | date: 'HH:mm - dd/MM/yyyy' }}</div>\n\n\t\t\t\t\t<button\n\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t(click)=\"play(recording)\"\n\t\t\t\t\t\tid=\"play-recording-btn\"\n\t\t\t\t\t\tmatTooltip=\"{{ 'PANEL.RECORDING.PLAY' | translate }}\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<mat-icon>play_arrow</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t\t<button\n\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t(click)=\"download(recording)\"\n\t\t\t\t\t\tid=\"download-recording-btn\"\n\t\t\t\t\t\tmatTooltip=\"{{ 'PANEL.RECORDING.DOWNLOAD' | translate }}\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<mat-icon>download</mat-icon>\n\t\t\t\t\t</button>\n\n\t\t\t\t\t<button\n\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\tclass=\"delete-recording-btn\"\n\t\t\t\t\t\tid=\"delete-recording-btn\"\n\t\t\t\t\t\t(click)=\"deleteRecording(recording.id)\"\n\t\t\t\t\t\tmatTooltip=\"{{ 'PANEL.RECORDING.DELETE' | translate }}\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<mat-icon>delete</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t</mat-list-item>\n\t\t\t</mat-list>\n\t\t</div>\n\t</div>\n</mat-expansion-panel>\n", styles: ["#recording-status{color:var(--ov-text-color);display:inline;padding:5px;font-size:12px;border-radius:var(--ov-panel-radius)}.time-container{padding:2px}.recording-icon{font-size:32px!important;height:32px!important;width:32px!important}.recording-duration{background-color:var(--ov-light-color);padding:4px 8px;border-radius:var(--ov-panel-radius);font-weight:500}.recording-duration mat-icon{font-size:18px;width:18px;height:18px}.started{background-color:#3b7430!important;color:var(--ov-text-color)}.activity-icon.started,.failed{background-color:var(--ov-warn-color)!important;color:var(--ov-text-color)}.stopped{background-color:var(--ov-light-color);color:var(--ov-panel-text-color)!important}.pending{background-color:#ffd79b!important;color:var(--ov-panel-text-color)!important}.panel-body-container{padding:10px}.panel-body-container>.content{align-items:stretch;justify-content:center;display:flex;flex-direction:column;box-flex:1;flex-grow:1;text-align:center}.recording-error{color:var(--ov-warn-color);font-weight:600}.recording-name{font-size:16px;font-weight:700}.recording-date{font-size:12px!important;font-style:italic}.not-allowed-message{margin-top:10px;font-weight:700}.recording-action-buttons{margin-top:20px;margin-bottom:20px}#start-recording-btn{width:100%;background-color:var(--ov-tertiary-color);color:var(--ov-text-color)}#stop-recording-btn{width:100%;background-color:var(--ov-warn-color);color:var(--ov-text-color)}.delete-recording-btn{color:var(--ov-warn-color)}#reset-recording-status-btn{width:100%;background-color:var(--ov-light-color)}mat-expansion-panel{margin:0 0 15px}.blink{animation:blinker 1.5s linear infinite!important}@keyframes blinker{50%{opacity:.4}}\n", ".activities-body-container{display:block!important;overflow-y:auto;overflow-x:hidden;padding:10px}.activity-icon{display:inherit;background-color:var(--ov-light-color);border-radius:var(--ov-panel-radius)}.activity-icon mat-icon{margin:auto}.activity-subtitle{font-style:italic;font-size:11px!important}.activity-title{font-weight:700!important}.activity-action-buttons{align-self:flex-start;margin-top:15px;font-weight:600}::ng-deep .mat-list-text{padding-left:10px!important}::ng-deep .mat-expansion-panel-header{padding:0 10px!important;height:65px!important}::ng-deep .mat-list-base .mat-list-item .mat-list-item-content,.mat-list-base .mat-list-option .mat-list-item-content{padding:0!important}::ng-deep mat-expansion-panel .mat-expansion-panel-body{padding:0!important;min-height:400px}::ng-deep .mat-expansion-panel-header-description{flex-grow:0!important}::ng-deep .mat-expansion-panel{box-shadow:none!important}\n"], components: [{ type: i5$2.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["disabled", "expanded", "hideToggle", "togglePosition"], outputs: ["opened", "closed", "expandedChange", "afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { type: i5$2.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["tabIndex", "expandedHeight", "collapsedHeight"] }, { type: i5$1.MatList, selector: "mat-list, mat-action-list", inputs: ["disableRipple", "disabled"], exportAs: ["matList"] }, { type: i5$1.MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["disableRipple", "disabled"], exportAs: ["matListItem"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i19.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }], directives: [{ type: i5$1.MatListAvatarCssMatStyler, selector: "[mat-list-avatar], [matListAvatar]" }, { type: i10.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i2$1.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i6$1.MatLine, selector: "[mat-line], [matLine]" }, { type: i5$1.MatListSubheaderCssMatStyler, selector: "[mat-subheader], [matSubheader]" }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i5$1.MatListIconCssMatStyler, selector: "[mat-list-icon], [matListIcon]" }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }], pipes: { "translate": TranslatePipe, "uppercase": i10.UpperCasePipe, "json": i10.JsonPipe, "duration": DurationFromSecondsPipe, "number": i10.DecimalPipe, "date": i10.DatePipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingActivityComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-recording-activity', changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-expansion-panel (opened)=\"panelOpened()\" (closed)=\"panelClosed()\" [expanded]=\"expanded\">\n\t<mat-expansion-panel-header>\n\t\t<mat-list>\n\t\t\t<mat-list-item>\n\t\t\t\t<div\n\t\t\t\t\tmatListAvatar\n\t\t\t\t\tclass=\"activity-icon\"\n\t\t\t\t\t[ngClass]=\"{\n\t\t\t\t\t\tstarted: recordingStatus === recStatusEnum.STARTED,\n\t\t\t\t\t\tstopped: recordingStatus === recStatusEnum.STOPPED,\n\t\t\t\t\t\tfailed: recordingStatus === recStatusEnum.FAILED,\n\t\t\t\t\t\tpending: recordingStatus === recStatusEnum.STARTING || recordingStatus === recStatusEnum.STOPPING\n\t\t\t\t\t}\"\n\t\t\t\t>\n\t\t\t\t\t<mat-icon *ngIf=\"recordingStatus !== recStatusEnum.FAILED && recordingStatus !== recStatusEnum.STARTED\">\n\t\t\t\t\t\tvideo_camera_front\n\t\t\t\t\t</mat-icon>\n\t\t\t\t\t<mat-icon *ngIf=\"recordingStatus === recStatusEnum.FAILED\">error</mat-icon>\n\t\t\t\t\t<mat-icon class=\"blink\" *ngIf=\"recordingStatus === recStatusEnum.STARTED\">radio_button_checked</mat-icon>\n\t\t\t\t</div>\n\t\t\t\t<h3 matLine class=\"activity-title\">{{ 'PANEL.RECORDING.TITLE' | translate }}</h3>\n\t\t\t\t<p matLine class=\"activity-subtitle\">{{ 'PANEL.RECORDING.SUBTITLE' | translate }}</p>\n\t\t\t\t<div class=\"activity-action-buttons\">\n\t\t\t\t\t<div\n\t\t\t\t\t\tid=\"recording-status\"\n\t\t\t\t\t\t[ngClass]=\"{\n\t\t\t\t\t\t\tstarted: recordingStatus === recStatusEnum.STARTED,\n\t\t\t\t\t\t\tstopped: recordingStatus === recStatusEnum.STOPPED,\n\t\t\t\t\t\t\tfailed: recordingStatus === recStatusEnum.FAILED,\n\t\t\t\t\t\t\tpending: recordingStatus === recStatusEnum.STARTING || recordingStatus === recStatusEnum.STOPPING\n\t\t\t\t\t\t}\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<span>{{ recordingStatus | uppercase }}</span>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</mat-list-item>\n\t\t</mat-list>\n\t</mat-expansion-panel-header>\n\t<div *ngIf=\"opened\" class=\"panel-body-container\">\n\t\t<div class=\"content\">\n\t\t\t<!-- Recording image -->\n\t\t\t<div *ngIf=\"recordingsList.length === 0\">\n\t\t\t\t<img\n\t\t\t\t\tsrc=\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPoAAACyCAMAAABcOSIOAAAC+lBMVEUAAAAXf/wpbeLk19IWf/zq2Mnf19vc3OYWf/ze3ujc3OcVf/0Wf/wXffvY2OQWf/3d3efd3OYWf/3d3efe3ujd3egVf/3d3ecVfv3d3efb2+bc3Ofc3Ofd3ejc3ejd3ugVf/3/zJcXf/zc3Obd3ugVf/0Wf/zPz93c3OdZW9QVf/3d3efZ2eQVf/0Vf/zb2+j7voHe3ugVf/39zJgLDxbX2OUYgPv/zJcXfvz/zJfd3eja2uZTVHd6e6Lc3Of/zJd4ead7fKOevuxXXNX+zJj+yZP/zJd2d55an/T/zJelpsZfd9b/ypRXXNXkhiOiqc0BBw9ZW9T/zZYAAAD1ljH8y5lxc9jyjiXwkCr+/f3/zZfsjCYAAACbq9EBCBDzlzjtiyVtbpYAAQLjw6b4okg9j/PjyLX3sWlrbJNCZ+JTVHegyv0SaM1clt6WmMlIXI8Vf/3/zJf////V1eT/lSalpsbe3unY2OVZW9RTVHflhiLnuIgAAADU1OT9/P5RUnYTf/+qq8lWWNT+liimp8bp6fFyc9BhlODu7vT8lCZ6fKTKyt22t88qhfW8vdD+y5bc3OgggvhYWXzFxtpcX9SUw/2am+WPkMqio8dT2WpiY4Q/aeSTos0ld/NUXtf3kin+nTfqiiXx8fYyiO/39/rk5O44gd5HZd+Ojqf6yZbxjST/tGaGiKHyyJ3+xId8ftntvoz+qVBIjuV3eJ5eX4D/vXiGs/A9i+j2xZIhf/GKi9uEos7ywpDgwqf/yJDslDjZtJC1s7fMsJcZd+hrmdWlq7dydJlxqPG4rKO3yepTkuB3m8pQhceaq8PGubBTYHZTXXZTrG7vq2Tlw6JTcXS4km0MLFXik0A7kPhek9Q1abhoh7TOvK1uZntUVnhT0WuZoLTnu5JsbYxKW4wLQoRUU3VTwWzJkVgWa9KqkYfbrX7yoUs0Kh8OV66WiYdpVUGGnr54iaP1s293YEjMpH6qjnW3iV2ZelpLOyzd0MtdX7WHiMxkgKclYKhp7MdAAAAAcHRSTlMA/gcE5w4JFvPvtSTcEPg9lHLQNPg8GqAuKuuI29K/qk7ycVZ9i18fyb2wRE3FfyMd37k8/eem15jmZmGV1FwuGm/87MeGnE3+roJpYz313q6ZUsi/uuXWl4pxbVs3kWBGNibl3NPFpH3w6efczLu2U2kwRQAAFbNJREFUeNrs2T+L02AcwPHnic8QeJ4QyFAyaQgkQ6EZOpQOFhSHG8TB0fE2/ww+PRCa5eJB9aAnelSP6tXecuILsIODJ4g9dJK7wk0HVUQUXHwDLvaBmIfmkvTZmofmO2XI8uF5fvDwPKCoqKioqKioqKioqGgmDWOsKWDZUrBbNxBCRtVx8TLxS24ZQRoGUdktgeUIewakM0HimECg1ZuXLwF5K3mEJoTq5nx4o9NpSItXXIOmhLzsbb9y2+/ufpIWj2uQplexQEYXfd8PpMXrBs1MdbRMurx4i9B5Vc0surR4C9H5GXoGXVa8SahIxEqnS4pXylQsZKXSJcW7kApG9DS6nHilOk8MB/1+f8C+DJxClxNvornwvVartdcfQEprWjJdTrwFBeAshoe2GJ3jV0B+c6EQ/NnDv73e4T7BAnSOH3YaqyC3WVAI3nvenvbybT2dfhwV4Xc7nRwvOyZi8Hus9jtiptGPxr/Cxkd+WHeYZzqoC8NZb+w0+vH4Rdi3E0noJhGCbzze2nrUbm+WlWQ6W3bZ6MBSBeBPH6yvrb3a3tisaPGJuetHdtnowFWF4KztON10yOlPbpeNDlwkAmetf57Z8HodUcro3B6nXwX5Tq/ATDhvxwNRJoOHdG6P0V87GOQ6za6oGXDeHTOacQdRFhz98GfWPUanhpXz+3zNvpUO512IfifRkIxOGZ7bY3Sq1vN8nX/u2vUrGXDeDcBSLDYhvCk+4PYYfVpFBzlNDM7pZk2lsUbDiR+E9pOvcTpFbh42vVLSXdtzHM92dawIwzm95CF6pv33339HeD8IOJ3f6S42xbTLRIXhkKqk6lhCcE5Pfqu4f/ik2fyPD7qTSTdGp7C20IFXrBo6c3ITgfPOlyFN6kuTxfD+5M+Hg4OPE04Pq2KwsPSa6JE1vR2aGPxHvJnFuhCFcXyq2lJUq6ra20W0KC1CXJFKPNSLRCTEKx48e+iozHmo1lgaFblpG9uLhFSLxi5xqX0N1/ZA7EsIYt9iT0icMzPt12lnalp6/Sy36t6H33zf9z8L9xRNC/IvH9OEl0tAXWDAYOr/0A9GtBHxXDaRSOb+pJ65Sos59A7Uwf3/BH2fUaomxLN5FInEIgi/X1/9fqX3rtMvHzyEhhff6fbo7qzvP6CZiudRLMKTUF71+5f2F8kmh1cvCjlIfrKqBfNmzp49c858qvvo37eJGc+msbgAyimZdcL1/SxZ54n8syf3tvK9Vnz79ObTM29vTljMMXsO1WrAXLk4mOOSAwlQl014wtWLsMN78kIYshc3ibDgzb3sLvfBAxoQB/NIBbF8XfWDx0pjTmouUCyWngIxFzO7e3q+3/hGxMFcuXqm3O+npJb9p4trmUd1B8MUiwNxJtaA+qWCYF5YyYZrOAOdDkzojrIP6aVYHMhHxMTqzfrB6+VJz0hscl+AegXdMO2DBjQsDu0OJEFdvt3pS2EpdfDt3o4fplwcyAvtrmhxO1ugBY5tCUsgXfWZLd/a9O+pWBzIoep+Z+KgLp3uhCvSi/5NKfXZrVbvMVG5OJCI1fa7nLrqXIour2zS+b/9zf+oev9eDYpDvIuLLqfO3jlKlzgFISe+xvj8XUKdajGTGheHfgeysie3jgvloqfOstL7nV303m/fa9RbfG0zvYGLCCBbbZ6XP7ReOkRLhxywfxf+y1ck6yZ8e19WfzuUaiUzpjYhDurQ7rLqB0+mZEIOuEjUU9+w7if6cyntJ7zo2dLT+yzeXCzeqHosnZO9pVE9gqLvuhiWrTpx/7T4/VH6xmKBm6rw+Ba2fI+RvHkD4jDrYJ6VvaBiLz6Got+HkKuZdcL7xTdo+lOp6HfZsApavkXqazesUCwOCQ/dnpO/m8tcgHinj1QrQ8LTmL1vJrzCvwnmP7s68KVN6y4q+0zliw7iCkmWxSN5MK9VPxst0PKLOjygG1Eat/qbvTjsePO351EIN8mw5ry0I6g/MXwbpw7iSoknIjHsHYswWfjCWvUtF/am6DonFziuf4++erP4e6Fw6D0352/D0xDqzIR7NndHa/N5qD8wkVdfCgmtmGw+nWbyIC6pfimqpN9Zclx/gzv9/aGj9NFvnz79OsMSdRS63WTZLQN7m7RVjWARvTGoL6+eXtgM8Th4S6tvOV2/30GdY8KNvQUuDjvwm+cRpmtac9PuH8gMNGqoSkyOseKDOlFfdhimtXniEseXD1FF/c6+5dXfR49Ce3QiQuz8UJ26KXWGcesoYHLvgRaqgjEqTn3934snmTSTyFWpHzxd2e8bJbXham7C03t7U+U9nyqEePeQa2wTDd+bwegh7IL4jSmi/+j+j9Tj+UgM/0hneXUoerRyP8PWccc30S/wsR5u7zJdSKDd1rj6iHGMyN1DHoVJNOqg/pfmHDGU5NSh6NFUnf07y7KqTLFYVJFX5NeR8nb39u1MCAnYm1BX67Eq9LxtHAPqWv68Cup/b05AWaIORd9LE6CWld7Fy/feffn6/PnzG18+Xi5i8477NMc5rN7VWVY3BEWLtMZj0nF25oBG3j3I8Fg15FOtTFld49WTLx8eBvW/NIdzzDqId+j36qWNzVx+9/zE8kUlNj3feXnrORojBPx5BLTrdeBk1iPkIR+tdojsWkY4BXevWph8ftY1Rmagn1zKgfpfmgPJdbCmRyuWttRKtlL8xglBGuyv0RX31ZlOVEGw3MiT2xFR17Xhj8Z60R9M8+q9AxTVxhCIstZIHgFJuT+ox3PZZDKbizdgHmPWlW8ocL+nJFf1rV82LaplByyDHWHsHgF1vVbYpBkNZPjNNj0ZBD+lMfstOml1jZ7h8em0LoYwDjeJiSx6+EH2G1BXPZ5kEDe/sGeTIBERgzpL11JR0ahfL6UcW/x4C3yB5Qfgk6+oOs6fD4G7YwRfcgf/IMw+7s2AyWU3GJywbRNhK7W8SedgCPj5WezCzPfpWU89y0RiQiXxspXIyW3lZdQz57D6Ubom4NmtN1YtkmLzbvjkwpHbXSgG6nYzkTEZ+NjzuviPdsRjlI47CzYmOM1OIeXUbv4FCfg66kkUEzUygtLLm4M6u/8kVj9UW/WLr8BWrH6cBnYdmdaFAIOFGmG2OYTU86EqrDZpd6HuJq738eOz2RnCZPKdHaBea17thA9pyXidOQd1YWWDlIN/a8sc2bV7s7T6vhRdQeHKtBCqrLqx3WpAcjiMgRFqiZ53DySqRhO3xKupKXzc4eAbGgZ1eXOg3PcwErLqHaejXMoBVw+GVftPpejUPhl1WsTuz/c6V1fMuhW1ozoYHO6geOa1Go1aO4UU3kqq3dtfSvreeHrGyKpnUUQGlE/mhPTPo4icOgk5IeWAY+dOcfdQB2A5Fwc8cPzAvs2LTnxeU+5oNTUZuQx13X0Qd1qbx2t1+Xwu4xSL18EYyYwb1aUt3jicmZPk1HPpiCw4fJhEIpkg6S+vrnoUhZSrAjpeJuB379jMP53XxxAmsjo0l6I8BquhjrjeU866EUG9Pc0IOLz+oImazJDtj46ffRd+RBPxhnEtqFddvNWx5+9n6qmTnRyknJjUvnoBD+LkzSjW7brda7A6YHW3tfNj7UQ1uKZAyOtcjAjn5IDfbMfRVko5I7ejyYT2LAN1CK/mYZKdfL9DytUgrX68JC7qhWs/8JG9Y3qbCYd4wEHy3T+izY7b28DFn8vR3u50T9FRgDbo603SDfC524xkGMz8fjbIfZvueSShnvwb8Th/fHnUiDoE/HGR+HLMIuyOutb4TIGA16gnvs6xlN+JjCbSA4YpurFja64yNGaPqc3tGsdlmsvttnrbvNryIb63BauPvh1L16rn0F+Ik/M6v4mFgFekvmofCcB9y8FbQBh4ZCDaXKnbyK2j3cL1AF6xZFCrPaT2A91+Nf6Dx6srVd2BX/Ub3cmAumjQmxXHxIn6wZMQ8IrUScCnSMnBHAb+MQKwvB67jHWb8BnOQKJfFttvWu4ltIkgjAP4yJpdsqBsSMKSbJIiu9BCAjGIiBYUREVBFMQXelDwdRXERCPxgc/YGFP1JEJTX2grRcX6topY3ydFVIQivQgKooKC4sGZnazfms3ETTb7P4ivy8/vm/lmpo20v71yEP+lhBRCQoTOd0xfl6tB3+sMfiB9lXwD+DbY4C0ZosJ8FX2IlBzk5sY32dskUdWbWiBvrAkBsePpSNN4pSRCcdmPZOPWPm5hGujQ7s7gdIf/AnTGcMv39VTRoRdAbtT95XjjPBMWVQ7ZjC9tJDLNg4Jt8aCXHmjwmAM67O45J3Ay9R/hqY6XOnutD+4m8l6oOmhryUl/fFqvQctLgg121ZgriUEUFFUJ39/ohmelH3AIx3lEdzn2Dt+PnyV6sxY6Q06zWDWdZxRkM/TKRhOexvlFLRZQaT9Y6KdLjuAkR/fTAw3zSHP4Ur4vm832WXhWOpQ9vwHoHdORbXsM7AEN/1KR9ZaRrfQzTuG5o7v20w2e2fEDZSyvT6914vkJTzYeZDuClgJ7J0pENYTDxyz0kxmHcP1D3PSuztzoBnuzJD02ig7J57+RyU7jQw0k6RMjXm84IkqSFA/K0STd+4EOI90RfNfmzQad0fKHr7/INkCHlO9IsvFCG0SNhBNC/pDAkZ+0t0syX4u+1zkc6LXt529vo/TevD06ZO1E5e9w5xuye0LxuB/b6a6vIcRX00+XHMMJna51sB82lxz/BtAby+7ZSjNfihISEr7OBLxReXqSvlolENdWRT+TcwYHOn6igVw8/xd+kfz6o07vY9NZf7LWN94Y7Qm7vR5UooG/sz0lkS+xd0b9SAN6I3tciQUH+phhYgT89fP4uyVuEzjJXSz/8SPPlLP+VfKrYkbZO22w4TEe4hUTHFI6ksEA0G3vccVzw9sZcKDvfLatTj4t+PH7xldm0fuYa2Gxz3iLtTfZ4WESEpBDfJtI3ujhvr7XHvz4joenGXCgk8XOzP1z5GuLF1jynmyWRd+9Rpkmjqdv03bDqzHvv/iI2t4h4zPNTONt7nTGHnzHjocnWXCgj3nPcN97/ODUGPwqzaTne+vMvRdhP0++6NYhNLK/x/X1DvH64pFo+skbSodrS304zpX3JQYc6OQ7p2q6n13rxm4cJr2v3sgvr08ipIbhEG97l5cjJn1A0gKZucaL7F678AtF7AY4g45bfriKfX8Yu+FrrV9ZRa97xl1OIMr4OGo47aochc6PpSaPrdBPZmzDM0w40Em63w7fv1dRP37/7Kne50B/l2es9Lozf9lEUkM52Qjao0nKND+PkBCc7lMUSRY7IqmUt1L1myXHcMhlQzfm1OW3OE8vn+oes5O6gf68dlf/73y/UsdwjdB5UX+d9CVRJZxHaE/KTw5Reuvge251m4A4gLZBz2N33Y5f7EENx08vbynJz5l+M/wI6E7gkFunLMya9LN3GZtc/Y7vWY0aj6+UhgdKI9KTY0BvAfzE/kMbndLrd/zyhtBwprPgQ5PxkQbo7sOB/pqxv0PHsza6Zlue4tsSPNKjAN19OJsO+zt0PL2/lstl/RILB3nURDrNU12k+ORSS8Pnil2uwtn0PKFDx+8uXxocGBgaGBjsv1SmfPx7G7gm6JyG7YBv89NPQVTRc+eOFzKuwoFuXepQ9t3l/gG46BM+Tv/g0JSJqCn7Pyf5sCYYdKh4rmt05L2LcKCzpjpNuX/I+par/7AINWVXo2lzYn6DDhXvGt1xxF04u+FN9Lsgr8oc1FyS0j+FT3X+Q9crjv+DJHfhMNysuxzkG4sOHd9guLhoxoeXmnb4jF5xLHcXDqc561K3UfYJk1Cz4YNaWzQVDodTkZiimqte1Cu+deSge3C4vjB2ORtln40chPO0h0KhpMDDNkfHGan4kZGCa3Cgf2YsdRtlX8KjFsSgZ3Q4lo9cKIyO7Mq4BIfc+MCa6pAXDPrUGc1ZBVVRpgUFjlaf5yndmONHjhRyo8eLGdfgsNRZRYe8nmBlOxhv8Y4AOchGRUnTFFmMiUu34PyqzPFdoyOFTbuKbsEh3d+Z+ztk+ZxWLnY1nIYE8FsFfowm9Moc7yIVz2xyDQ6bnI2iL5s4aULrFns8ZT7IxtuFUCetemWc5dytOLT7a6u8r0q+YBXi5rVssvMiVZdKAW9sOg+fZN53rkDHmasVh+PMB7Yc2p1DaH7LJjsX9Cmar1NV1YTfg5CJXtzk+jgD+Y1XNuT6vXzG1Nr2+chpgL6n2JVzFw7p/sxe59Du+kOUZwpjn2shHX98vVBwFQ752mPZ263ylagefR7XQjrELThc2djNDnJqY23xszwu0F2CQ268si3nJs1iXt5coLsGh4nOaHbIYrzOPRMnrZgHNa/KVBfo7sDph3Xh7M4uee+f9u6etW0gDOD4SZHLgXQIbhAaZYEUIiohZJDlyR1kgxOXUtMsgUylY4uzdSy00DEYOnQIlOCpFHcIlA4mKQZnSXGGeM0naLasXXoXhyqt6/pFl8Ry9IPgBLz8L7asF6xnd/fbk2q1VAkLpHukbJF5Ovtw8g3N5lH3e7vd7h41G9GlttcXPtBU6uzs7OTk5PycnobMbm+Nk80xTmcfzjW7h6f91qCl1T/u7fz4NPBl4DNxcHCw/WftrafHD9/r9UkTa+xf8OyPztp95s3RETsDj6N0NuEcFCRse5b3vLV1XfIumzuPDac/mjGcE7DlmLKqIJ5wS2GeKFzDCoT3mN1vjqZH4aubujBDtmeYKgJXZajl++vM08uAjYcrL9+9fxOFLwMAZIubKts2tGgUO88jpCiKSJFHtBkyLt+uAUbQ2srPq+EUMvGE3RAHpspfJCuqZuqGb3k2liRJoMgjxs929plu6cMMYObB2oso/JKiY25stuTrMqLVoub4tiTAEU9sdnud4+PDzuBDPqZsDbDEb66uRuHRgP3/ZVuOrPD0eZphC2OWidw1r9EgP829t+1e53S/9XHm8kIVXLNoEMpwtWAHOs2mZAPD+hRe0VVofj3qtg87T/OF7LTh5Ry4Ibyo6YGHJeGChD3fMWURgUtiINRnQg9nGoK/lqttlMqVkKzB+H33bL6yUVwCN4pHiqgSooL4ofkRsUBP4+mFMNct5mpVsgrlynpIdgYKhexv5I98uF4uVXPuEpgXCq7HBi0ZROgVoUzGJStRLOYGyG+um5mf6GiCa3yCPg+DraYkwzoLMIHtyKozAU2QOCpm047neYjfCDKjdh0kj+pxLNJ9kEB0OmV8VvI2dJSo2zBuugESCsnRAcxMhLmd1zkBpGqOhYXZ/v2cAxKOR6JsOr4nTbkCnJHMd/owerZGNywMucnKobMo5dECmMEk2z+sgUWEZGdMvWAkcEduQkjz4ejwQAWLjJetf8ZDW5/zwetM4gMJ/n3FwpERuBOUwdnqwfm9QNfEBduqj4EUkVDQ3apOpVKpVCqVSk3sF8syBtQPXiTJAAAAAElFTkSuQmCC\"\n\t\t\t\t/>\n\t\t\t</div>\n\n\t\t\t<h2 *ngIf=\"recordingsList.length === 0\">{{ 'PANEL.RECORDING.CONTENT_TITLE' | translate }}</h2>\n\t\t\t<span *ngIf=\"recordingsList.length === 0\">{{ 'PANEL.RECORDING.CONTENT_SUBTITLE' | translate }}</span>\n\n\t\t\t<!-- Recording button -->\n\t\t\t<div *ngIf=\"isSessionCreator\" class=\"item recording-action-buttons\">\n\t\t\t\t<button *ngIf=\"recordingAlive\" mat-flat-button id=\"stop-recording-btn\" (click)=\"stopRecording()\">\n\t\t\t\t\t<span>{{ 'TOOLBAR.STOP_RECORDING' | translate }}</span>\n\t\t\t\t</button>\n\n\t\t\t\t<button\n\t\t\t\t\t*ngIf=\"recordingStatus === recStatusEnum.STOPPED\"\n\t\t\t\t\tmat-flat-button\n\t\t\t\t\tid=\"start-recording-btn\"\n\t\t\t\t\t(click)=\"startRecording()\"\n\t\t\t\t>\n\t\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.STOPPED\">{{ 'TOOLBAR.START_RECORDING' | translate }}</span>\n\t\t\t\t</button>\n\n\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.STARTING\">{{ 'PANEL.RECORDING.STARTING' | translate }} </span>\n\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.STOPPING\">{{ 'PANEL.RECORDING.STOPPING' | translate }} </span>\n\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.FAILED\">Message: </span>\n\t\t\t\t<span *ngIf=\"recordingStatus === recStatusEnum.FAILED\" class=\"recording-error\">{{ recordingError | json }} </span>\n\t\t\t\t<div>\n\t\t\t\t\t<button\n\t\t\t\t\t\t*ngIf=\"recordingStatus === recStatusEnum.FAILED\"\n\t\t\t\t\t\tmat-flat-button\n\t\t\t\t\t\tid=\"reset-recording-status-btn\"\n\t\t\t\t\t\t(click)=\"resetStatus()\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<span>{{ 'PANEL.RECORDING.RESTORE' | translate }}</span>\n\t\t\t\t\t</button>\n\t\t\t\t</div>\n\t\t\t</div>\n\n\t\t\t<!-- Message for no Moderators-->\n\t\t\t<p *ngIf=\"!isSessionCreator\" class=\"not-allowed-message\">{{ 'PANEL.RECORDING.NO_MODERATOR' | translate }}</p>\n\t\t</div>\n\t\t<mat-divider *ngIf=\"recordingsList.length > 0\"></mat-divider>\n\n\t\t<!-- Recording list -->\n\t\t<div *ngIf=\"recordingsList.length > 0\" class=\"item\">\n\t\t\t<mat-list>\n\t\t\t\t<div mat-subheader>{{ 'PANEL.RECORDING.RECORDINGS' | translate }}</div>\n\t\t\t\t<mat-list-item *ngFor=\"let recording of recordingsList\">\n\t\t\t\t\t<mat-icon class=\"recording-icon\" mat-list-icon>video_file</mat-icon>\n\t\t\t\t\t<div mat-line>\n\t\t\t\t\t\t<span class=\"recording-name\">{{ recording.id }}</span>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div mat-line class=\"time-container\">\n\t\t\t\t\t\t<span class=\"recording-duration\"> {{ recording.duration | duration }} </span>\n\t\t\t\t\t\t<span class=\"recording-size\"> | {{ recording.size / 1024 / 1024 | number: '1.1-2' }} MBs</span>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div mat-line class=\"recording-date\">{{ recording.createdAt | date: 'HH:mm - dd/MM/yyyy' }}</div>\n\n\t\t\t\t\t<button\n\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t(click)=\"play(recording)\"\n\t\t\t\t\t\tid=\"play-recording-btn\"\n\t\t\t\t\t\tmatTooltip=\"{{ 'PANEL.RECORDING.PLAY' | translate }}\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<mat-icon>play_arrow</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t\t<button\n\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t(click)=\"download(recording)\"\n\t\t\t\t\t\tid=\"download-recording-btn\"\n\t\t\t\t\t\tmatTooltip=\"{{ 'PANEL.RECORDING.DOWNLOAD' | translate }}\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<mat-icon>download</mat-icon>\n\t\t\t\t\t</button>\n\n\t\t\t\t\t<button\n\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\tclass=\"delete-recording-btn\"\n\t\t\t\t\t\tid=\"delete-recording-btn\"\n\t\t\t\t\t\t(click)=\"deleteRecording(recording.id)\"\n\t\t\t\t\t\tmatTooltip=\"{{ 'PANEL.RECORDING.DELETE' | translate }}\"\n\t\t\t\t\t>\n\t\t\t\t\t\t<mat-icon>delete</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t</mat-list-item>\n\t\t\t</mat-list>\n\t\t</div>\n\t</div>\n</mat-expansion-panel>\n", styles: ["#recording-status{color:var(--ov-text-color);display:inline;padding:5px;font-size:12px;border-radius:var(--ov-panel-radius)}.time-container{padding:2px}.recording-icon{font-size:32px!important;height:32px!important;width:32px!important}.recording-duration{background-color:var(--ov-light-color);padding:4px 8px;border-radius:var(--ov-panel-radius);font-weight:500}.recording-duration mat-icon{font-size:18px;width:18px;height:18px}.started{background-color:#3b7430!important;color:var(--ov-text-color)}.activity-icon.started,.failed{background-color:var(--ov-warn-color)!important;color:var(--ov-text-color)}.stopped{background-color:var(--ov-light-color);color:var(--ov-panel-text-color)!important}.pending{background-color:#ffd79b!important;color:var(--ov-panel-text-color)!important}.panel-body-container{padding:10px}.panel-body-container>.content{align-items:stretch;justify-content:center;display:flex;flex-direction:column;box-flex:1;flex-grow:1;text-align:center}.recording-error{color:var(--ov-warn-color);font-weight:600}.recording-name{font-size:16px;font-weight:700}.recording-date{font-size:12px!important;font-style:italic}.not-allowed-message{margin-top:10px;font-weight:700}.recording-action-buttons{margin-top:20px;margin-bottom:20px}#start-recording-btn{width:100%;background-color:var(--ov-tertiary-color);color:var(--ov-text-color)}#stop-recording-btn{width:100%;background-color:var(--ov-warn-color);color:var(--ov-text-color)}.delete-recording-btn{color:var(--ov-warn-color)}#reset-recording-status-btn{width:100%;background-color:var(--ov-light-color)}mat-expansion-panel{margin:0 0 15px}.blink{animation:blinker 1.5s linear infinite!important}@keyframes blinker{50%{opacity:.4}}\n", ".activities-body-container{display:block!important;overflow-y:auto;overflow-x:hidden;padding:10px}.activity-icon{display:inherit;background-color:var(--ov-light-color);border-radius:var(--ov-panel-radius)}.activity-icon mat-icon{margin:auto}.activity-subtitle{font-style:italic;font-size:11px!important}.activity-title{font-weight:700!important}.activity-action-buttons{align-self:flex-start;margin-top:15px;font-weight:600}::ng-deep .mat-list-text{padding-left:10px!important}::ng-deep .mat-expansion-panel-header{padding:0 10px!important;height:65px!important}::ng-deep .mat-list-base .mat-list-item .mat-list-item-content,.mat-list-base .mat-list-option .mat-list-item-content{padding:0!important}::ng-deep mat-expansion-panel .mat-expansion-panel-body{padding:0!important;min-height:400px}::ng-deep .mat-expansion-panel-header-description{flex-grow:0!important}::ng-deep .mat-expansion-panel{box-shadow:none!important}\n"] }]
        }], ctorParameters: function () { return [{ type: RecordingService }, { type: ParticipantService }, { type: OpenViduAngularConfigService }, { type: ActionService }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { expanded: [{
                type: Input
            }], onStartRecordingClicked: [{
                type: Output
            }], onStopRecordingClicked: [{
                type: Output
            }], onDeleteRecordingClicked: [{
                type: Output
            }] } });

class ActivitiesPanelComponent {
    /**
     * @internal
     */
    constructor(panelService, libService, cd) {
        this.panelService = panelService;
        this.libService = libService;
        this.cd = cd;
        /**
         * Provides event notifications that fire when start recording button has been clicked.
         * The recording should be stated using the OpenVidu REST API.
         */
        this.onStartRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when stop recording button has been clicked.
         * The recording should be stopped using the OpenVidu REST API.
         */
        this.onStopRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when delete recording button has been clicked.
         * The recording should be deleted using the OpenVidu REST API.
         */
        this.onDeleteRecordingClicked = new EventEmitter();
        /**
         * @internal
         */
        this.expandedPanel = '';
        /**
         * @internal
         */
        this.showRecordingActivity = true;
    }
    /**
     * @internal
     */
    ngOnInit() {
        this.subscribeToPanelToggling();
        this.subscribeToActivitiesPanelDirective();
    }
    /**
     * @internal
     */
    ngOnDestroy() {
        if (this.panelSubscription)
            this.panelSubscription.unsubscribe();
        if (this.recordingActivitySub)
            this.recordingActivitySub.unsubscribe();
    }
    /**
     * @internal
     */
    close() {
        this.panelService.togglePanel(PanelType.ACTIVITIES);
    }
    /**
     * @internal
     */
    _onStartRecordingClicked() {
        this.onStartRecordingClicked.emit();
    }
    /**
     * @internal
     */
    _onStopRecordingClicked() {
        this.onStopRecordingClicked.emit();
    }
    /**
     * @internal
     */
    _onDeleteRecordingClicked(recordingId) {
        this.onDeleteRecordingClicked.emit(recordingId);
    }
    subscribeToPanelToggling() {
        this.panelSubscription = this.panelService.panelOpenedObs.subscribe((ev) => {
            if (ev.type === PanelType.ACTIVITIES && !!ev.expand) {
                this.expandedPanel = ev.expand;
            }
        });
    }
    subscribeToActivitiesPanelDirective() {
        this.recordingActivitySub = this.libService.recordingActivity.subscribe((value) => {
            this.showRecordingActivity = value;
            this.cd.markForCheck();
        });
    }
}
ActivitiesPanelComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ActivitiesPanelComponent, deps: [{ token: PanelService }, { token: OpenViduAngularConfigService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
ActivitiesPanelComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: ActivitiesPanelComponent, selector: "ov-activities-panel", outputs: { onStartRecordingClicked: "onStartRecordingClicked", onStopRecordingClicked: "onStopRecordingClicked", onDeleteRecordingClicked: "onDeleteRecordingClicked" }, ngImport: i0, template: "<div class=\"panel-container\" id=\"activities-container\" fxLayout=\"column\" fxLayoutAlign=\"space-evenly none\">\n\t<div class=\"panel-header-container\" fxFlex=\"55px\" fxLayoutAlign=\"start center\">\n\t\t<h3 class=\"panel-title\">Activities</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"activities-body-container\" fxFlex=\"75%\" fxLayoutAlign=\"space-evenly none\">\n\t\t<mat-accordion>\n\t\t\t<ov-recording-activity\n\t\t\t\t*ngIf=\"showRecordingActivity\"\n\t\t\t\tid=\"recording-activity\"\n\t\t\t\t[expanded]=\"expandedPanel === 'recording'\"\n\t\t\t\t(onStartRecordingClicked)=\"_onStartRecordingClicked()\"\n\t\t\t\t(onStopRecordingClicked)=\"_onStopRecordingClicked()\"\n\t\t\t\t(onDeleteRecordingClicked)=\"_onDeleteRecordingClicked($event)\"\n\t\t\t></ov-recording-activity>\n\t\t</mat-accordion>\n\t</div>\n</div>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".activities-body-container{display:block!important;overflow-y:auto;overflow-x:hidden;padding:10px}.activity-icon{display:inherit;background-color:var(--ov-light-color);border-radius:var(--ov-panel-radius)}.activity-icon mat-icon{margin:auto}.activity-subtitle{font-style:italic;font-size:11px!important}.activity-title{font-weight:700!important}.activity-action-buttons{align-self:flex-start;margin-top:15px;font-weight:600}::ng-deep .mat-list-text{padding-left:10px!important}::ng-deep .mat-expansion-panel-header{padding:0 10px!important;height:65px!important}::ng-deep .mat-list-base .mat-list-item .mat-list-item-content,.mat-list-base .mat-list-option .mat-list-item-content{padding:0!important}::ng-deep mat-expansion-panel .mat-expansion-panel-body{padding:0!important;min-height:400px}::ng-deep .mat-expansion-panel-header-description{flex-grow:0!important}::ng-deep .mat-expansion-panel{box-shadow:none!important}\n"], components: [{ type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: RecordingActivityComponent, selector: "ov-recording-activity", inputs: ["expanded"], outputs: ["onStartRecordingClicked", "onStopRecordingClicked", "onDeleteRecordingClicked"] }], directives: [{ type: i5.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { type: i5.DefaultLayoutAlignDirective, selector: "  [fxLayoutAlign], [fxLayoutAlign.xs], [fxLayoutAlign.sm], [fxLayoutAlign.md],  [fxLayoutAlign.lg], [fxLayoutAlign.xl], [fxLayoutAlign.lt-sm], [fxLayoutAlign.lt-md],  [fxLayoutAlign.lt-lg], [fxLayoutAlign.lt-xl], [fxLayoutAlign.gt-xs], [fxLayoutAlign.gt-sm],  [fxLayoutAlign.gt-md], [fxLayoutAlign.gt-lg]", inputs: ["fxLayoutAlign", "fxLayoutAlign.xs", "fxLayoutAlign.sm", "fxLayoutAlign.md", "fxLayoutAlign.lg", "fxLayoutAlign.xl", "fxLayoutAlign.lt-sm", "fxLayoutAlign.lt-md", "fxLayoutAlign.lt-lg", "fxLayoutAlign.lt-xl", "fxLayoutAlign.gt-xs", "fxLayoutAlign.gt-sm", "fxLayoutAlign.gt-md", "fxLayoutAlign.gt-lg"] }, { type: i5.DefaultFlexDirective, selector: "  [fxFlex], [fxFlex.xs], [fxFlex.sm], [fxFlex.md],  [fxFlex.lg], [fxFlex.xl], [fxFlex.lt-sm], [fxFlex.lt-md],  [fxFlex.lt-lg], [fxFlex.lt-xl], [fxFlex.gt-xs], [fxFlex.gt-sm],  [fxFlex.gt-md], [fxFlex.gt-lg]", inputs: ["fxFlex", "fxFlex.xs", "fxFlex.sm", "fxFlex.md", "fxFlex.lg", "fxFlex.xl", "fxFlex.lt-sm", "fxFlex.lt-md", "fxFlex.lt-lg", "fxFlex.lt-xl", "fxFlex.gt-xs", "fxFlex.gt-sm", "fxFlex.gt-md", "fxFlex.gt-lg"] }, { type: i6.MatTooltip, selector: "[matTooltip]", exportAs: ["matTooltip"] }, { type: i5$2.MatAccordion, selector: "mat-accordion", inputs: ["multi", "hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }], pipes: { "translate": TranslatePipe }, changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ActivitiesPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-activities-panel', changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"panel-container\" id=\"activities-container\" fxLayout=\"column\" fxLayoutAlign=\"space-evenly none\">\n\t<div class=\"panel-header-container\" fxFlex=\"55px\" fxLayoutAlign=\"start center\">\n\t\t<h3 class=\"panel-title\">Activities</h3>\n\t\t<button class=\"panel-close-button\" mat-icon-button matTooltip=\"{{ 'PANEL.CLOSE' | translate }}\" (click)=\"close()\">\n\t\t\t<mat-icon>close</mat-icon>\n\t\t</button>\n\t</div>\n\n\t<div class=\"activities-body-container\" fxFlex=\"75%\" fxLayoutAlign=\"space-evenly none\">\n\t\t<mat-accordion>\n\t\t\t<ov-recording-activity\n\t\t\t\t*ngIf=\"showRecordingActivity\"\n\t\t\t\tid=\"recording-activity\"\n\t\t\t\t[expanded]=\"expandedPanel === 'recording'\"\n\t\t\t\t(onStartRecordingClicked)=\"_onStartRecordingClicked()\"\n\t\t\t\t(onStopRecordingClicked)=\"_onStopRecordingClicked()\"\n\t\t\t\t(onDeleteRecordingClicked)=\"_onDeleteRecordingClicked($event)\"\n\t\t\t></ov-recording-activity>\n\t\t</mat-accordion>\n\t</div>\n</div>\n", styles: [".panel-container{margin:20px;background-color:var(--ov-panel-background);border-radius:var(--ov-panel-radius);max-height:calc(100% - 40px);min-height:calc(100% - 40px)}.panel-header-container{padding:10px;display:flex}.panel-title{margin-left:5px;margin-top:auto;margin-bottom:auto}.panel-close-button{margin-left:auto;border-radius:var(--ov-buttons-radius)}::-webkit-scrollbar{width:8px}::-webkit-scrollbar-thumb{background:#a7a7a7;border-radius:4px}::-webkit-scrollbar-thumb:hover{background:#7c7c7c}::-webkit-scrollbar-track{background:var(--ov-light-color);border-radius:4px}\n", ".activities-body-container{display:block!important;overflow-y:auto;overflow-x:hidden;padding:10px}.activity-icon{display:inherit;background-color:var(--ov-light-color);border-radius:var(--ov-panel-radius)}.activity-icon mat-icon{margin:auto}.activity-subtitle{font-style:italic;font-size:11px!important}.activity-title{font-weight:700!important}.activity-action-buttons{align-self:flex-start;margin-top:15px;font-weight:600}::ng-deep .mat-list-text{padding-left:10px!important}::ng-deep .mat-expansion-panel-header{padding:0 10px!important;height:65px!important}::ng-deep .mat-list-base .mat-list-item .mat-list-item-content,.mat-list-base .mat-list-option .mat-list-item-content{padding:0!important}::ng-deep mat-expansion-panel .mat-expansion-panel-body{padding:0!important;min-height:400px}::ng-deep .mat-expansion-panel-header-description{flex-grow:0!important}::ng-deep .mat-expansion-panel{box-shadow:none!important}\n"] }]
        }], ctorParameters: function () { return [{ type: PanelService }, { type: OpenViduAngularConfigService }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { onStartRecordingClicked: [{
                type: Output
            }], onStopRecordingClicked: [{
                type: Output
            }], onDeleteRecordingClicked: [{
                type: Output
            }] } });

/**
 * The **VideoconferenceComponent** is the parent of all OpenVidu components.
 * It allow us to create a modern, useful and powerful videoconference apps with ease.
 *
 * <div class="custom-table-container">
 * <div>
 *  <h3>API Directives</h3>
 *
 * This component allows us to show or hide certain HTML elements with the following {@link https://angular.io/guide/attribute-directives Angular attribute directives}
 * with the aim of fully customizing the videoconference application.
 *
 * | **Parameter**                  | **Type**  | **Reference**                                   |
 * | :----------------------------: | :-------: | :---------------------------------------------: |
 * | **minimal**                        | `boolean` | {@link MinimalDirective}                        |
 * | **lang**                           | `string`  | {@link LangDirective}                           |
 * | **prejoin**                        | `boolean` | {@link PrejoinDirective}                        |
 * | **participantName**                | `string`  | {@link ParticipantNameDirective}                |
 * | **videoMuted**                     | `boolean` | {@link VideoMutedDirective}                     |
 * | **audioMuted**                     | `boolean` | {@link AudioMutedDirective}                     |
 * | **toolbarScreenshareButton**       | `boolean` | {@link ToolbarScreenshareButtonDirective}       |
 * | **toolbarFullscreenButton**        | `boolean` | {@link ToolbarFullscreenButtonDirective}        |
 * | **toolbarBackgroundEffectsButton** | `boolean` | {@link ToolbarBackgroundEffectsButtonDirective} |
 * | **toolbarLeaveButton**             | `boolean` | {@link ToolbarLeaveButtonDirective}             |
 * | **toolbarChatPanelButton**         | `boolean` | {@link ToolbarChatPanelButtonDirective}         |
 * | **toolbarParticipantsPanelButton** | `boolean` | {@link ToolbarParticipantsPanelButtonDirective} |
 * | **toolbarDisplayLogo**             | `boolean` | {@link ToolbarDisplayLogoDirective}             |
 * | **toolbarDisplaySessionName**      | `boolean` | {@link ToolbarDisplaySessionNameDirective}      |
 * | **streamDisplayParticipantName**   | `boolean` | {@link StreamDisplayParticipantNameDirective}   |
 * | **streamDisplayAudioDetection**    | `boolean` | {@link StreamDisplayAudioDetectionDirective}    |
 * | **streamSettingsButton**           | `boolean` | {@link StreamSettingsButtonDirective}           |
 * | **participantPanelItemMuteButton** | `boolean` | {@link ParticipantPanelItemMuteButtonDirective} |
 * | **recordingActivityRecordingList** | `{@link RecordingInfo}[]` | {@link RecordingActivityRecordingListDirective} |
 *
 * <p class="component-link-text">
 * <span class="italic">See all {@link ApiDirectiveModule API Directives}</span>
 * </p>
 * </div>
 *
 * <div>
 *
 * <h3>OpenVidu Angular Directives</h3>
 *
 *
 * The VideoconferenceComponent is also providing us a way to **replace the default templates** with a custom one.
 * It will recognise the following {@link https://angular.io/guide/structural-directives Angular structural directives}
 * in the elements added as children.
 *
 * |             **Directive**           |                 **Reference**                 |
 * |:-----------------------------------:|:---------------------------------------------:|
 * |            ***ovToolbar**           |            {@link ToolbarDirective}           |
 * |   ***ovToolbarAdditionalButtons**   |   {@link ToolbarAdditionalButtonsDirective}   |
 * |***ovToolbarAdditionalPanelButtons**   |   {@link ToolbarAdditionalPanelButtonsDirective}   |
 * |             ***ovPanel**            |             {@link PanelDirective}            |
 * |        ***ovAdditionalPanels**      |       {@link AdditionalPanelsDirective}       |
 * |           ***ovChatPanel**          |           {@link ChatPanelDirective}          |
 * |       ***ovParticipantsPanel**      |       {@link ParticipantsPanelDirective}      |
 * |     ***ovParticipantPanelItem**     |     {@link ParticipantPanelItemDirective}     |
 * | ***ovParticipantPanelItemElements** | {@link ParticipantPanelItemElementsDirective} |
 * |            ***ovLayout**            |            {@link LayoutDirective}            |
 * |            ***ovStream**            |            {@link StreamDirective}            |
 *
 * <p class="component-link-text">
 * 	<span class="italic">See all {@link OpenViduAngularDirectiveModule OpenVidu Angular Directives}</span>
 * </p>
 * </div>
 * </div>
 */
class VideoconferenceComponent {
    /**
     * @internal
     */
    constructor(loggerSrv, storageSrv, participantService, deviceSrv, openviduService, actionService, libService, tokenService, translateService) {
        this.loggerSrv = loggerSrv;
        this.storageSrv = storageSrv;
        this.participantService = participantService;
        this.deviceSrv = deviceSrv;
        this.openviduService = openviduService;
        this.actionService = actionService;
        this.libService = libService;
        this.tokenService = tokenService;
        this.translateService = translateService;
        /**
         * Provides event notifications that fire when join button (in prejoin page) has been clicked.
         */
        this.onJoinButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when leave button has been clicked.
         */
        this.onToolbarLeaveButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when camera toolbar button has been clicked.
         */
        this.onToolbarCameraButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when microphone toolbar button has been clicked.
         */
        this.onToolbarMicrophoneButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when screenshare toolbar button has been clicked.
         */
        this.onToolbarScreenshareButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when fullscreen toolbar button has been clicked.
         */
        this.onToolbarFullscreenButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when participants panel button has been clicked.
         */
        this.onToolbarParticipantsPanelButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when chat panel button has been clicked.
         */
        this.onToolbarChatPanelButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when activities panel button has been clicked.
         */
        this.onToolbarActivitiesPanelButtonClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when start recording button is clicked {@link ToolbarComponent}.
         *  The recording should be stopped using the REST API.
         */
        this.onToolbarStartRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when stop recording button is clicked from {@link ToolbarComponent}.
         *  The recording should be stopped using the REST API.
         */
        this.onToolbarStopRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when start recording button is clicked {@link ActivitiesPanelComponent}.
         *  The recording should be stopped using the REST API.
         */
        this.onActivitiesPanelStartRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when stop recording button is clicked from {@link ActivitiesPanelComponent}.
         *  The recording should be stopped using the REST API.
         */
        this.onActivitiesPanelStopRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when delete recording button is clicked from {@link ActivitiesPanelComponent}.
         *  The recording should be deleted using the REST API.
         */
        this.onActivitiesPanelDeleteRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when play recording button is clicked from {@link ActivitiesPanelComponent}.
         */
        this.onActivitiesPanelPlayRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when OpenVidu Session is created.
         * See {@link https://docs.openvidu.io/en/stable/api/openvidu-browser/classes/Session.html openvidu-browser Session}.
         */
        this.onSessionCreated = new EventEmitter();
        /**
         * Provides event notifications that fire when local participant is created.
         */
        this.onParticipantCreated = new EventEmitter();
        /**
         * @internal
         */
        this.showVideoconference = false;
        /**
         * @internal
         */
        this.participantReady = false;
        /**
         * @internal
         */
        this.error = false;
        /**
         * @internal
         */
        this.errorMessage = '';
        /**
         * @internal
         */
        this.showPrejoin = true;
        /**
         * @internal
         */
        this.isSessionInitialized = false;
        /**
         * @internal
         */
        this.loading = true;
        this.log = this.loggerSrv.get('VideoconferenceComponent');
    }
    /**
     * @param {TokenModel} tokens  The tokens parameter must be an object with `webcam` and `screen` fields.
     *  Both of them are `string` type. See {@link TokenModel}
     */
    set tokens(tokens) {
        if (!tokens || !tokens.webcam) {
            this.log.w('No tokens received');
        }
        else {
            this.log.w('Tokens received');
            this.tokenService.setWebcamToken(tokens.webcam);
            const openviduEdition = new URL(tokens.webcam).searchParams.get('edition');
            if (!!openviduEdition) {
                this.openviduService.setOpenViduEdition(OpenViduEdition.PRO);
            }
            else {
                this.openviduService.setOpenViduEdition(OpenViduEdition.CE);
                this.libService.backgroundEffectsButton.next(false);
            }
            if (tokens.screen) {
                this.tokenService.setScreenToken(tokens.screen);
            }
            else {
                this.log.w('No screen token found. Screenshare feature will be disabled');
            }
            this.start();
        }
    }
    ngOnInit() {
        return __awaiter(this, void 0, void 0, function* () {
            this.subscribeToVideconferenceDirectives();
        });
    }
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.deviceSrv.forceInitDevices();
            const nickname = this.externalParticipantName || this.storageSrv.getNickname() || `OpenVidu_User${Math.floor(Math.random() * 100)}`;
            this.participantService.initLocalParticipant({ local: true, nickname });
            this.openviduService.initialize();
            if (this.deviceSrv.hasVideoDeviceAvailable() || this.deviceSrv.hasAudioDeviceAvailable()) {
                yield this.initwebcamPublisher();
            }
            this.isSessionInitialized = true;
            this.onParticipantCreated.emit(this.participantService.getLocalParticipant());
            this.loading = false;
        });
    }
    initwebcamPublisher() {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                try {
                    const publisher = yield this.openviduService.initDefaultPublisher();
                    if (publisher) {
                        publisher.once('accessDenied', (e) => {
                            this.handlePublisherError(e);
                            resolve();
                        });
                        publisher.once('accessAllowed', () => __awaiter(this, void 0, void 0, function* () {
                            yield this.handlePublisherSuccess();
                            this.participantReady = true;
                            resolve();
                        }));
                    }
                }
                catch (error) {
                    this.actionService.openDialog(error.name.replace(/_/g, ' '), error.message, true);
                    this.log.e(error);
                    reject();
                }
            }));
        });
    }
    ngOnDestroy() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.prejoinSub)
                this.prejoinSub.unsubscribe();
            if (this.participantNameSub)
                this.participantNameSub.unsubscribe();
            this.deviceSrv.clear();
            yield this.openviduService.clear();
        });
    }
    /**
     * @internal
     */
    ngAfterViewInit() {
        if (this.externalToolbar) {
            this.log.d('Setting EXTERNAL TOOLBAR');
            this.openviduAngularToolbarTemplate = this.externalToolbar.template;
        }
        else {
            this.log.d('Setting  DEFAULT TOOLBAR');
            if (this.externalToolbarAdditionalButtons) {
                this.log.d('Setting EXTERNAL TOOLBAR ADDITIONAL BUTTONS');
                this.openviduAngularToolbarAdditionalButtonsTemplate = this.externalToolbarAdditionalButtons.template;
            }
            if (this.externalToolbarAdditionalPanelButtons) {
                this.log.d('Setting EXTERNAL TOOLBAR ADDITIONAL PANEL BUTTONS');
                this.openviduAngularToolbarAdditionalPanelButtonsTemplate = this.externalToolbarAdditionalPanelButtons.template;
            }
            this.openviduAngularToolbarTemplate = this.defaultToolbarTemplate;
        }
        if (this.externalPanel) {
            this.log.d('Setting EXTERNAL PANEL');
            this.openviduAngularPanelTemplate = this.externalPanel.template;
        }
        else {
            this.log.d('Setting DEFAULT PANEL');
            if (this.externalParticipantsPanel) {
                this.openviduAngularParticipantsPanelTemplate = this.externalParticipantsPanel.template;
                this.log.d('Setting EXTERNAL PARTICIPANTS PANEL');
            }
            else {
                this.log.d('Setting DEFAULT PARTICIPANTS PANEL');
                if (this.externalParticipantPanelItem) {
                    this.log.d('Setting EXTERNAL P ITEM');
                    this.openviduAngularParticipantPanelItemTemplate = this.externalParticipantPanelItem.template;
                }
                else {
                    if (this.externalParticipantPanelItemElements) {
                        this.log.d('Setting EXTERNAL PARTICIPANT PANEL ITEM ELEMENT');
                        this.openviduAngularParticipantPanelItemElementsTemplate = this.externalParticipantPanelItemElements.template;
                    }
                    this.openviduAngularParticipantPanelItemTemplate = this.defaultParticipantPanelItemTemplate;
                    this.log.d('Setting DEFAULT P ITEM');
                }
                this.openviduAngularParticipantsPanelTemplate = this.defaultParticipantsPanelTemplate;
            }
            if (this.externalChatPanel) {
                this.log.d('Setting EXTERNAL CHAT PANEL');
                this.openviduAngularChatPanelTemplate = this.externalChatPanel.template;
            }
            else {
                this.log.d('Setting DEFAULT CHAT PANEL');
                this.openviduAngularChatPanelTemplate = this.defaultChatPanelTemplate;
            }
            if (this.externalActivitiesPanel) {
                this.log.d('Setting EXTERNAL ACTIVITIES PANEL');
                this.openviduAngularActivitiesPanelTemplate = this.externalActivitiesPanel.template;
            }
            else {
                this.log.d('Setting DEFAULT ACTIVITIES PANEL');
                this.openviduAngularActivitiesPanelTemplate = this.defaultActivitiesPanelTemplate;
            }
            if (this.externalAdditionalPanels) {
                this.log.d('Setting EXTERNAL ADDITIONAL PANELS');
                this.openviduAngularAdditionalPanelsTemplate = this.externalAdditionalPanels.template;
            }
            this.openviduAngularPanelTemplate = this.defaultPanelTemplate;
        }
        if (this.externalLayout) {
            this.log.d('Setting EXTERNAL LAYOUT');
            this.openviduAngularLayoutTemplate = this.externalLayout.template;
        }
        else {
            this.log.d('Setting DEAFULT LAYOUT');
            if (this.externalStream) {
                this.log.d('Setting EXTERNAL STREAM');
                this.openviduAngularStreamTemplate = this.externalStream.template;
            }
            else {
                this.log.d('Setting DEFAULT STREAM');
                this.openviduAngularStreamTemplate = this.defaultStreamTemplate;
            }
            this.openviduAngularLayoutTemplate = this.defaultLayoutTemplate;
        }
    }
    /**
     * @internal
     */
    _onJoinButtonClicked() {
        this.showVideoconference = true;
        this.showPrejoin = false;
        this.onJoinButtonClicked.emit();
    }
    /**
     * @internal
     */
    onLeaveButtonClicked() {
        this.showVideoconference = false;
        this.participantReady = false;
        this.onToolbarLeaveButtonClicked.emit();
    }
    /**
     * @internal
     */
    onCameraButtonClicked() {
        this.onToolbarCameraButtonClicked.emit();
    }
    /**
     * @internal
     */
    onMicrophoneButtonClicked() {
        this.onToolbarMicrophoneButtonClicked.emit();
    }
    /**
     * @internal
     */
    onScreenshareButtonClicked() {
        this.onToolbarScreenshareButtonClicked.emit();
    }
    /**
     * @internal
     */
    onFullscreenButtonClicked() {
        this.onToolbarFullscreenButtonClicked.emit();
    }
    /**
     * @internal
     */
    onParticipantsPanelButtonClicked() {
        this.onToolbarParticipantsPanelButtonClicked.emit();
    }
    /**
     * @internal
     */
    onChatPanelButtonClicked() {
        this.onToolbarChatPanelButtonClicked.emit();
    }
    /**
     * @internal
     */
    onActivitiesPanelButtonClicked() {
        this.onToolbarActivitiesPanelButtonClicked.emit();
    }
    /**
     * @internal
     */
    onStartRecordingClicked(from) {
        if (from === 'toolbar') {
            this.onToolbarStartRecordingClicked.emit();
        }
        else if (from === 'panel') {
            this.onActivitiesPanelStartRecordingClicked.emit();
        }
    }
    /**
     * @internal
     */
    onStopRecordingClicked(from) {
        if (from === 'toolbar') {
            this.onToolbarStopRecordingClicked.emit();
        }
        else if (from === 'panel') {
            this.onActivitiesPanelStopRecordingClicked.emit();
        }
    }
    /**
     * @internal
     */
    onDeleteRecordingClicked(recordingId) {
        this.onActivitiesPanelDeleteRecordingClicked.emit(recordingId);
    }
    /**
     * @internal
     */
    _onSessionCreated(session) {
        this.onSessionCreated.emit(session);
    }
    handlePublisherError(e) {
        let message = '';
        console.log('ERROR!', e);
        if (e.name === OpenViduErrorName.DEVICE_ALREADY_IN_USE) {
            this.log.w('Video device already in use. Disabling video device...');
            // Allow access to the room with only mic if camera device is already in use
            this.deviceSrv.disableVideoDevices();
            return this.initwebcamPublisher();
        }
        if (e.name === OpenViduErrorName.DEVICE_ACCESS_DENIED) {
            message = this.translateService.translate('ERRORS.MEDIA_ACCESS');
            this.deviceSrv.disableVideoDevices();
            this.deviceSrv.disableAudioDevices();
            return this.initwebcamPublisher();
        }
        else if (e.name === OpenViduErrorName.NO_INPUT_SOURCE_SET) {
            message = this.translateService.translate('ERRORS.DEVICE_NOT_FOUND');
        }
        this.actionService.openDialog(e.name.replace(/_/g, ' '), message, true);
        this.log.e(e.message);
    }
    handlePublisherSuccess() {
        var _a, _b, _c, _d, _e, _f, _g, _h;
        return __awaiter(this, void 0, void 0, function* () {
            // The devices are initialized without labels in Firefox.
            // We need to force an update after publisher is allowed.
            if (this.deviceSrv.areEmptyLabels()) {
                yield this.deviceSrv.forceInitDevices();
                if (this.deviceSrv.hasAudioDeviceAvailable()) {
                    const audioLabel = (_d = (_c = (_b = (_a = this.participantService.getMyCameraPublisher()) === null || _a === void 0 ? void 0 : _a.stream) === null || _b === void 0 ? void 0 : _b.getMediaStream()) === null || _c === void 0 ? void 0 : _c.getAudioTracks()[0]) === null || _d === void 0 ? void 0 : _d.label;
                    this.deviceSrv.setMicSelected(audioLabel);
                }
                if (this.deviceSrv.hasVideoDeviceAvailable()) {
                    const videoLabel = (_h = (_g = (_f = (_e = this.participantService.getMyCameraPublisher()) === null || _e === void 0 ? void 0 : _e.stream) === null || _f === void 0 ? void 0 : _f.getMediaStream()) === null || _g === void 0 ? void 0 : _g.getVideoTracks()[0]) === null || _h === void 0 ? void 0 : _h.label;
                    this.deviceSrv.setCameraSelected(videoLabel);
                }
            }
        });
    }
    subscribeToVideconferenceDirectives() {
        this.prejoinSub = this.libService.prejoin.subscribe((value) => {
            this.showPrejoin = value;
            // this.cd.markForCheck();
        });
        this.participantNameSub = this.libService.participantName.subscribe((nickname) => {
            this.externalParticipantName = nickname;
        });
    }
}
VideoconferenceComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VideoconferenceComponent, deps: [{ token: LoggerService }, { token: StorageService }, { token: ParticipantService }, { token: DeviceService }, { token: OpenViduService }, { token: ActionService }, { token: OpenViduAngularConfigService }, { token: TokenService }, { token: TranslateService }], target: i0.ɵɵFactoryTarget.Component });
VideoconferenceComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: VideoconferenceComponent, selector: "ov-videoconference", inputs: { tokens: "tokens" }, outputs: { onJoinButtonClicked: "onJoinButtonClicked", onToolbarLeaveButtonClicked: "onToolbarLeaveButtonClicked", onToolbarCameraButtonClicked: "onToolbarCameraButtonClicked", onToolbarMicrophoneButtonClicked: "onToolbarMicrophoneButtonClicked", onToolbarScreenshareButtonClicked: "onToolbarScreenshareButtonClicked", onToolbarFullscreenButtonClicked: "onToolbarFullscreenButtonClicked", onToolbarParticipantsPanelButtonClicked: "onToolbarParticipantsPanelButtonClicked", onToolbarChatPanelButtonClicked: "onToolbarChatPanelButtonClicked", onToolbarActivitiesPanelButtonClicked: "onToolbarActivitiesPanelButtonClicked", onToolbarStartRecordingClicked: "onToolbarStartRecordingClicked", onToolbarStopRecordingClicked: "onToolbarStopRecordingClicked", onActivitiesPanelStartRecordingClicked: "onActivitiesPanelStartRecordingClicked", onActivitiesPanelStopRecordingClicked: "onActivitiesPanelStopRecordingClicked", onActivitiesPanelDeleteRecordingClicked: "onActivitiesPanelDeleteRecordingClicked", onActivitiesPanelPlayRecordingClicked: "onActivitiesPanelPlayRecordingClicked", onSessionCreated: "onSessionCreated", onParticipantCreated: "onParticipantCreated" }, queries: [{ propertyName: "externalToolbar", first: true, predicate: ToolbarDirective, descendants: true }, { propertyName: "externalToolbarAdditionalButtons", first: true, predicate: ToolbarAdditionalButtonsDirective, descendants: true }, { propertyName: "externalToolbarAdditionalPanelButtons", first: true, predicate: ToolbarAdditionalPanelButtonsDirective, descendants: true }, { propertyName: "externalAdditionalPanels", first: true, predicate: AdditionalPanelsDirective, descendants: true }, { propertyName: "externalPanel", first: true, predicate: PanelDirective, descendants: true }, { propertyName: "externalChatPanel", first: true, predicate: ChatPanelDirective, descendants: true }, { propertyName: "externalActivitiesPanel", first: true, predicate: ActivitiesPanelDirective, descendants: true }, { propertyName: "externalParticipantsPanel", first: true, predicate: ParticipantsPanelDirective, descendants: true }, { propertyName: "externalParticipantPanelItem", first: true, predicate: ParticipantPanelItemDirective, descendants: true }, { propertyName: "externalParticipantPanelItemElements", first: true, predicate: ParticipantPanelItemElementsDirective, descendants: true }, { propertyName: "externalLayout", first: true, predicate: LayoutDirective, descendants: true }, { propertyName: "externalStream", first: true, predicate: StreamDirective, descendants: true }], viewQueries: [{ propertyName: "defaultToolbarTemplate", first: true, predicate: ["defaultToolbar"], descendants: true, read: TemplateRef }, { propertyName: "defaultPanelTemplate", first: true, predicate: ["defaultPanel"], descendants: true, read: TemplateRef }, { propertyName: "defaultChatPanelTemplate", first: true, predicate: ["defaultChatPanel"], descendants: true, read: TemplateRef }, { propertyName: "defaultParticipantsPanelTemplate", first: true, predicate: ["defaultParticipantsPanel"], descendants: true, read: TemplateRef }, { propertyName: "defaultActivitiesPanelTemplate", first: true, predicate: ["defaultActivitiesPanel"], descendants: true, read: TemplateRef }, { propertyName: "defaultParticipantPanelItemTemplate", first: true, predicate: ["defaultParticipantPanelItem"], descendants: true, read: TemplateRef }, { propertyName: "defaultLayoutTemplate", first: true, predicate: ["defaultLayout"], descendants: true, read: TemplateRef }, { propertyName: "defaultStreamTemplate", first: true, predicate: ["defaultStream"], descendants: true, read: TemplateRef }], ngImport: i0, template: "<div id=\"call-container\">\n\n\t<div id=\"spinner\" *ngIf=\"loading\" >\n\t\t<mat-spinner [diameter]=\"50\"></mat-spinner>\n\t\t<span>{{ 'PREJOIN.PREPARING' | translate }}</span>\n\t</div>\n\n\t<div [@inOutAnimation] id=\"pre-join-container\" *ngIf=\"showPrejoin && participantReady && !loading\">\n\t\t<ov-pre-join (onJoinButtonClicked)=\"_onJoinButtonClicked()\"></ov-pre-join>\n\t</div>\n\n\t<div id=\"spinner\" *ngIf=\"!loading && error\">\n\t\t<mat-icon class=\"error-icon\">error</mat-icon>\n\t\t<span>{{ errorMessage }}</span>\n\t</div>\n\n\t<div [@inOutAnimation] id=\"vc-container\" *ngIf=\"showVideoconference || (!showPrejoin && !loading && !error)\">\n\t\t<ov-session (onSessionCreated)=\"_onSessionCreated($event)\" *ngIf=\"isSessionInitialized\">\n\t\t\t<ng-template #toolbar>\n\t\t\t\t<ng-container *ngIf=\"openviduAngularToolbarTemplate\">\n\t\t\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularToolbarTemplate\"></ng-container>\n\t\t\t\t</ng-container>\n\t\t\t</ng-template>\n\n\t\t\t<ng-template #panel>\n\t\t\t\t<ng-container *ngIf=\"openviduAngularPanelTemplate\">\n\t\t\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularPanelTemplate\"></ng-container>\n\t\t\t\t</ng-container>\n\t\t\t</ng-template>\n\n\t\t\t<ng-template #layout>\n\t\t\t\t<ng-container *ngIf=\"openviduAngularLayoutTemplate\">\n\t\t\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularLayoutTemplate\"></ng-container>\n\t\t\t\t</ng-container>\n\t\t\t</ng-template>\n\t\t</ov-session>\n\t</div>\n</div>\n\n<ng-template #defaultToolbar>\n\t<ov-toolbar\n\t\tid=\"default-toolbar\"\n\t\t(onLeaveButtonClicked)=\"onLeaveButtonClicked()\"\n\t\t(onCameraButtonClicked)=\"onCameraButtonClicked()\"\n\t\t(onMicrophoneButtonClicked)=\"onMicrophoneButtonClicked()\"\n\t\t(onScreenshareButtonClicked)=\"onScreenshareButtonClicked()\"\n\t\t(onFullscreenButtonClicked)=\"onFullscreenButtonClicked()\"\n\t\t(onParticipantsPanelButtonClicked)=\"onParticipantsPanelButtonClicked()\"\n\t\t(onChatPanelButtonClicked)=\"onChatPanelButtonClicked()\"\n\t\t(onActivitiesPanelButtonClicked)=\"onActivitiesPanelButtonClicked()\"\n\t\t(onStartRecordingClicked)=\"onStartRecordingClicked('toolbar')\"\n\t\t(onStopRecordingClicked)=\"onStopRecordingClicked('toolbar')\"\n\t>\n\t\t<ng-template #toolbarAdditionalButtons>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularToolbarAdditionalButtonsTemplate\"></ng-container>\n\t\t</ng-template>\n\n\t\t<ng-template #toolbarAdditionalPanelButtons>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularToolbarAdditionalPanelButtonsTemplate\"></ng-container>\n\t\t</ng-template>\n\t</ov-toolbar>\n</ng-template>\n\n<ng-template #defaultPanel>\n\t<ov-panel id=\"default-panel\">\n\t\t<ng-template #chatPanel>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularChatPanelTemplate\"></ng-container>\n\t\t</ng-template>\n\n\t\t<ng-template #participantsPanel>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularParticipantsPanelTemplate\"></ng-container>\n\t\t</ng-template>\n\n\t\t<ng-template #backgroundEffectsPanel>\n\t\t\t<ov-background-effects-panel id=\"default-background-effects-panel\"></ov-background-effects-panel>\n\t\t</ng-template>\n\n\t\t<ng-template #settingsPanel>\n\t\t\t<ov-settings-panel id=\"default-settings-panel\"></ov-settings-panel>\n\t\t</ng-template>\n\n\t\t<ng-template #activitiesPanel>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularActivitiesPanelTemplate\"></ng-container>\n\t\t</ng-template>\n\n\t\t<ng-template #additionalPanels>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularAdditionalPanelsTemplate\"></ng-container>\n\t\t</ng-template>\n\t</ov-panel>\n</ng-template>\n\n<ng-template #defaultChatPanel>\n\t<ov-chat-panel id=\"default-chat-panel\"></ov-chat-panel>\n</ng-template>\n\n<ng-template #defaultActivitiesPanel>\n\t<ov-activities-panel\n\t\tid=\"default-activities-panel\"\n\t\t(onStartRecordingClicked)=\"onStartRecordingClicked('panel')\"\n\t\t(onStopRecordingClicked)=\"onStopRecordingClicked('panel')\"\n\t\t(onDeleteRecordingClicked)=\"onDeleteRecordingClicked($event)\"\n\t></ov-activities-panel>\n</ng-template>\n\n<ng-template #defaultParticipantsPanel>\n\t<ov-participants-panel id=\"default-participants-panel\">\n\t\t<ng-template #participantPanelItem let-participant>\n\t\t\t<ng-container\n\t\t\t\t*ngTemplateOutlet=\"openviduAngularParticipantPanelItemTemplate; context: { $implicit: participant }\"\n\t\t\t></ng-container>\n\t\t</ng-template>\n\t</ov-participants-panel>\n</ng-template>\n\n<ng-template #defaultParticipantPanelItem let-participant>\n\t<ov-participant-panel-item [participant]=\"participant\" id=\"default-participant-panel-item\">\n\t\t<ng-template #participantPanelItemElements>\n\t\t\t<ng-container\n\t\t\t\t*ngTemplateOutlet=\"openviduAngularParticipantPanelItemElementsTemplate; context: { $implicit: participant }\"\n\t\t\t></ng-container>\n\t\t</ng-template>\n\t</ov-participant-panel-item>\n</ng-template>\n\n<ng-template #defaultLayout>\n\t<ov-layout id=\"default-layout\">\n\t\t<ng-template #stream let-stream>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularStreamTemplate; context: { $implicit: stream }\"> </ng-container>\n\t\t</ng-template>\n\t</ov-layout>\n</ng-template>\n\n<ng-template #defaultStream let-stream>\n\t<ov-stream [stream]=\"stream\" id=\"default-stream\"></ov-stream>\n</ng-template>\n", styles: ["#call-container,#vc-container{height:100%}#vc-container{background-color:var(--ov-primary-color)}#pre-join-container{height:inherit}.error-icon{color:var(--ov-warn-color)}#spinner{position:absolute;inset:40% 0 0;margin:auto;text-align:-webkit-center;text-align:-moz-center;color:var(--ov-panel-text-color)}#call-container{--ov-captions-height: 250px}\n"], components: [{ type: i10$2.MatSpinner, selector: "mat-spinner", inputs: ["color"] }, { type: PreJoinComponent, selector: "ov-pre-join", outputs: ["onJoinButtonClicked"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: SessionComponent, selector: "ov-session", inputs: ["usedInPrejoinPage"], outputs: ["onSessionCreated"] }, { type: ToolbarComponent, selector: "ov-toolbar", outputs: ["onLeaveButtonClicked", "onCameraButtonClicked", "onMicrophoneButtonClicked", "onFullscreenButtonClicked", "onScreenshareButtonClicked", "onParticipantsPanelButtonClicked", "onChatPanelButtonClicked", "onActivitiesPanelButtonClicked", "onStartRecordingClicked", "onStopRecordingClicked"] }, { type: PanelComponent, selector: "ov-panel" }, { type: BackgroundEffectsPanelComponent, selector: "ov-background-effects-panel" }, { type: SettingsPanelComponent, selector: "ov-settings-panel" }, { type: ChatPanelComponent, selector: "ov-chat-panel" }, { type: ActivitiesPanelComponent, selector: "ov-activities-panel", outputs: ["onStartRecordingClicked", "onStopRecordingClicked", "onDeleteRecordingClicked"] }, { type: ParticipantsPanelComponent, selector: "ov-participants-panel" }, { type: ParticipantPanelItemComponent, selector: "ov-participant-panel-item", inputs: ["participant"] }, { type: LayoutComponent, selector: "ov-layout" }, { type: StreamComponent, selector: "ov-stream", inputs: ["stream"] }], directives: [{ type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i10.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet"] }], pipes: { "translate": TranslatePipe }, animations: [
        trigger('inOutAnimation', [
            transition(':enter', [style({ opacity: 0 }), animate('300ms ease-out', style({ opacity: 1 }))])
            // transition(':leave', [style({ opacity: 1 }), animate('50ms ease-in', style({ opacity: 0.9 }))])
        ])
    ] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VideoconferenceComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-videoconference', animations: [
                        trigger('inOutAnimation', [
                            transition(':enter', [style({ opacity: 0 }), animate('300ms ease-out', style({ opacity: 1 }))])
                            // transition(':leave', [style({ opacity: 1 }), animate('50ms ease-in', style({ opacity: 0.9 }))])
                        ])
                    ], template: "<div id=\"call-container\">\n\n\t<div id=\"spinner\" *ngIf=\"loading\" >\n\t\t<mat-spinner [diameter]=\"50\"></mat-spinner>\n\t\t<span>{{ 'PREJOIN.PREPARING' | translate }}</span>\n\t</div>\n\n\t<div [@inOutAnimation] id=\"pre-join-container\" *ngIf=\"showPrejoin && participantReady && !loading\">\n\t\t<ov-pre-join (onJoinButtonClicked)=\"_onJoinButtonClicked()\"></ov-pre-join>\n\t</div>\n\n\t<div id=\"spinner\" *ngIf=\"!loading && error\">\n\t\t<mat-icon class=\"error-icon\">error</mat-icon>\n\t\t<span>{{ errorMessage }}</span>\n\t</div>\n\n\t<div [@inOutAnimation] id=\"vc-container\" *ngIf=\"showVideoconference || (!showPrejoin && !loading && !error)\">\n\t\t<ov-session (onSessionCreated)=\"_onSessionCreated($event)\" *ngIf=\"isSessionInitialized\">\n\t\t\t<ng-template #toolbar>\n\t\t\t\t<ng-container *ngIf=\"openviduAngularToolbarTemplate\">\n\t\t\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularToolbarTemplate\"></ng-container>\n\t\t\t\t</ng-container>\n\t\t\t</ng-template>\n\n\t\t\t<ng-template #panel>\n\t\t\t\t<ng-container *ngIf=\"openviduAngularPanelTemplate\">\n\t\t\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularPanelTemplate\"></ng-container>\n\t\t\t\t</ng-container>\n\t\t\t</ng-template>\n\n\t\t\t<ng-template #layout>\n\t\t\t\t<ng-container *ngIf=\"openviduAngularLayoutTemplate\">\n\t\t\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularLayoutTemplate\"></ng-container>\n\t\t\t\t</ng-container>\n\t\t\t</ng-template>\n\t\t</ov-session>\n\t</div>\n</div>\n\n<ng-template #defaultToolbar>\n\t<ov-toolbar\n\t\tid=\"default-toolbar\"\n\t\t(onLeaveButtonClicked)=\"onLeaveButtonClicked()\"\n\t\t(onCameraButtonClicked)=\"onCameraButtonClicked()\"\n\t\t(onMicrophoneButtonClicked)=\"onMicrophoneButtonClicked()\"\n\t\t(onScreenshareButtonClicked)=\"onScreenshareButtonClicked()\"\n\t\t(onFullscreenButtonClicked)=\"onFullscreenButtonClicked()\"\n\t\t(onParticipantsPanelButtonClicked)=\"onParticipantsPanelButtonClicked()\"\n\t\t(onChatPanelButtonClicked)=\"onChatPanelButtonClicked()\"\n\t\t(onActivitiesPanelButtonClicked)=\"onActivitiesPanelButtonClicked()\"\n\t\t(onStartRecordingClicked)=\"onStartRecordingClicked('toolbar')\"\n\t\t(onStopRecordingClicked)=\"onStopRecordingClicked('toolbar')\"\n\t>\n\t\t<ng-template #toolbarAdditionalButtons>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularToolbarAdditionalButtonsTemplate\"></ng-container>\n\t\t</ng-template>\n\n\t\t<ng-template #toolbarAdditionalPanelButtons>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularToolbarAdditionalPanelButtonsTemplate\"></ng-container>\n\t\t</ng-template>\n\t</ov-toolbar>\n</ng-template>\n\n<ng-template #defaultPanel>\n\t<ov-panel id=\"default-panel\">\n\t\t<ng-template #chatPanel>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularChatPanelTemplate\"></ng-container>\n\t\t</ng-template>\n\n\t\t<ng-template #participantsPanel>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularParticipantsPanelTemplate\"></ng-container>\n\t\t</ng-template>\n\n\t\t<ng-template #backgroundEffectsPanel>\n\t\t\t<ov-background-effects-panel id=\"default-background-effects-panel\"></ov-background-effects-panel>\n\t\t</ng-template>\n\n\t\t<ng-template #settingsPanel>\n\t\t\t<ov-settings-panel id=\"default-settings-panel\"></ov-settings-panel>\n\t\t</ng-template>\n\n\t\t<ng-template #activitiesPanel>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularActivitiesPanelTemplate\"></ng-container>\n\t\t</ng-template>\n\n\t\t<ng-template #additionalPanels>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularAdditionalPanelsTemplate\"></ng-container>\n\t\t</ng-template>\n\t</ov-panel>\n</ng-template>\n\n<ng-template #defaultChatPanel>\n\t<ov-chat-panel id=\"default-chat-panel\"></ov-chat-panel>\n</ng-template>\n\n<ng-template #defaultActivitiesPanel>\n\t<ov-activities-panel\n\t\tid=\"default-activities-panel\"\n\t\t(onStartRecordingClicked)=\"onStartRecordingClicked('panel')\"\n\t\t(onStopRecordingClicked)=\"onStopRecordingClicked('panel')\"\n\t\t(onDeleteRecordingClicked)=\"onDeleteRecordingClicked($event)\"\n\t></ov-activities-panel>\n</ng-template>\n\n<ng-template #defaultParticipantsPanel>\n\t<ov-participants-panel id=\"default-participants-panel\">\n\t\t<ng-template #participantPanelItem let-participant>\n\t\t\t<ng-container\n\t\t\t\t*ngTemplateOutlet=\"openviduAngularParticipantPanelItemTemplate; context: { $implicit: participant }\"\n\t\t\t></ng-container>\n\t\t</ng-template>\n\t</ov-participants-panel>\n</ng-template>\n\n<ng-template #defaultParticipantPanelItem let-participant>\n\t<ov-participant-panel-item [participant]=\"participant\" id=\"default-participant-panel-item\">\n\t\t<ng-template #participantPanelItemElements>\n\t\t\t<ng-container\n\t\t\t\t*ngTemplateOutlet=\"openviduAngularParticipantPanelItemElementsTemplate; context: { $implicit: participant }\"\n\t\t\t></ng-container>\n\t\t</ng-template>\n\t</ov-participant-panel-item>\n</ng-template>\n\n<ng-template #defaultLayout>\n\t<ov-layout id=\"default-layout\">\n\t\t<ng-template #stream let-stream>\n\t\t\t<ng-container *ngTemplateOutlet=\"openviduAngularStreamTemplate; context: { $implicit: stream }\"> </ng-container>\n\t\t</ng-template>\n\t</ov-layout>\n</ng-template>\n\n<ng-template #defaultStream let-stream>\n\t<ov-stream [stream]=\"stream\" id=\"default-stream\"></ov-stream>\n</ng-template>\n", styles: ["#call-container,#vc-container{height:100%}#vc-container{background-color:var(--ov-primary-color)}#pre-join-container{height:inherit}.error-icon{color:var(--ov-warn-color)}#spinner{position:absolute;inset:40% 0 0;margin:auto;text-align:-webkit-center;text-align:-moz-center;color:var(--ov-panel-text-color)}#call-container{--ov-captions-height: 250px}\n"] }]
        }], ctorParameters: function () { return [{ type: LoggerService }, { type: StorageService }, { type: ParticipantService }, { type: DeviceService }, { type: OpenViduService }, { type: ActionService }, { type: OpenViduAngularConfigService }, { type: TokenService }, { type: TranslateService }]; }, propDecorators: { externalToolbar: [{
                type: ContentChild,
                args: [ToolbarDirective]
            }], externalToolbarAdditionalButtons: [{
                type: ContentChild,
                args: [ToolbarAdditionalButtonsDirective]
            }], externalToolbarAdditionalPanelButtons: [{
                type: ContentChild,
                args: [ToolbarAdditionalPanelButtonsDirective]
            }], externalAdditionalPanels: [{
                type: ContentChild,
                args: [AdditionalPanelsDirective]
            }], externalPanel: [{
                type: ContentChild,
                args: [PanelDirective]
            }], externalChatPanel: [{
                type: ContentChild,
                args: [ChatPanelDirective]
            }], externalActivitiesPanel: [{
                type: ContentChild,
                args: [ActivitiesPanelDirective]
            }], externalParticipantsPanel: [{
                type: ContentChild,
                args: [ParticipantsPanelDirective]
            }], externalParticipantPanelItem: [{
                type: ContentChild,
                args: [ParticipantPanelItemDirective]
            }], externalParticipantPanelItemElements: [{
                type: ContentChild,
                args: [ParticipantPanelItemElementsDirective]
            }], externalLayout: [{
                type: ContentChild,
                args: [LayoutDirective]
            }], externalStream: [{
                type: ContentChild,
                args: [StreamDirective]
            }], defaultToolbarTemplate: [{
                type: ViewChild,
                args: ['defaultToolbar', { static: false, read: TemplateRef }]
            }], defaultPanelTemplate: [{
                type: ViewChild,
                args: ['defaultPanel', { static: false, read: TemplateRef }]
            }], defaultChatPanelTemplate: [{
                type: ViewChild,
                args: ['defaultChatPanel', { static: false, read: TemplateRef }]
            }], defaultParticipantsPanelTemplate: [{
                type: ViewChild,
                args: ['defaultParticipantsPanel', { static: false, read: TemplateRef }]
            }], defaultActivitiesPanelTemplate: [{
                type: ViewChild,
                args: ['defaultActivitiesPanel', { static: false, read: TemplateRef }]
            }], defaultParticipantPanelItemTemplate: [{
                type: ViewChild,
                args: ['defaultParticipantPanelItem', { static: false, read: TemplateRef }]
            }], defaultLayoutTemplate: [{
                type: ViewChild,
                args: ['defaultLayout', { static: false, read: TemplateRef }]
            }], defaultStreamTemplate: [{
                type: ViewChild,
                args: ['defaultStream', { static: false, read: TemplateRef }]
            }], tokens: [{
                type: Input
            }], onJoinButtonClicked: [{
                type: Output
            }], onToolbarLeaveButtonClicked: [{
                type: Output
            }], onToolbarCameraButtonClicked: [{
                type: Output
            }], onToolbarMicrophoneButtonClicked: [{
                type: Output
            }], onToolbarScreenshareButtonClicked: [{
                type: Output
            }], onToolbarFullscreenButtonClicked: [{
                type: Output
            }], onToolbarParticipantsPanelButtonClicked: [{
                type: Output
            }], onToolbarChatPanelButtonClicked: [{
                type: Output
            }], onToolbarActivitiesPanelButtonClicked: [{
                type: Output
            }], onToolbarStartRecordingClicked: [{
                type: Output
            }], onToolbarStopRecordingClicked: [{
                type: Output
            }], onActivitiesPanelStartRecordingClicked: [{
                type: Output
            }], onActivitiesPanelStopRecordingClicked: [{
                type: Output
            }], onActivitiesPanelDeleteRecordingClicked: [{
                type: Output
            }], onActivitiesPanelPlayRecordingClicked: [{
                type: Output
            }], onSessionCreated: [{
                type: Output
            }], onParticipantCreated: [{
                type: Output
            }] } });

class OpenViduAngularDirectiveModule {
}
OpenViduAngularDirectiveModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularDirectiveModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
OpenViduAngularDirectiveModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularDirectiveModule, declarations: [ChatPanelDirective,
        LayoutDirective,
        PanelDirective,
        AdditionalPanelsDirective,
        ParticipantPanelItemDirective,
        ParticipantsPanelDirective,
        StreamDirective,
        ToolbarDirective,
        ToolbarAdditionalButtonsDirective,
        ToolbarAdditionalPanelButtonsDirective,
        ParticipantPanelItemElementsDirective,
        ActivitiesPanelDirective,
        BackgroundEffectsPanelDirective], exports: [ChatPanelDirective,
        LayoutDirective,
        PanelDirective,
        AdditionalPanelsDirective,
        ParticipantPanelItemDirective,
        ParticipantsPanelDirective,
        StreamDirective,
        ToolbarDirective,
        ToolbarAdditionalButtonsDirective,
        ToolbarAdditionalPanelButtonsDirective,
        ParticipantPanelItemElementsDirective,
        ActivitiesPanelDirective,
        BackgroundEffectsPanelDirective] });
OpenViduAngularDirectiveModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularDirectiveModule });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularDirectiveModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        ChatPanelDirective,
                        LayoutDirective,
                        PanelDirective,
                        AdditionalPanelsDirective,
                        ParticipantPanelItemDirective,
                        ParticipantsPanelDirective,
                        StreamDirective,
                        ToolbarDirective,
                        ToolbarAdditionalButtonsDirective,
                        ToolbarAdditionalPanelButtonsDirective,
                        ParticipantPanelItemElementsDirective,
                        ActivitiesPanelDirective,
                        BackgroundEffectsPanelDirective
                    ],
                    exports: [
                        ChatPanelDirective,
                        LayoutDirective,
                        PanelDirective,
                        AdditionalPanelsDirective,
                        ParticipantPanelItemDirective,
                        ParticipantsPanelDirective,
                        StreamDirective,
                        ToolbarDirective,
                        ToolbarAdditionalButtonsDirective,
                        ToolbarAdditionalPanelButtonsDirective,
                        ParticipantPanelItemElementsDirective,
                        ActivitiesPanelDirective,
                        BackgroundEffectsPanelDirective
                    ]
                }]
        }] });

/**
 * The **recordingActivity** directive allows show/hide the recording activity in {@link ActivitiesPanelComponent} activity panel component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `activitiesPanel` component:
 *
 * @example
 * <ov-videoconference [activitiesPanelRecordingActivity]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ActivitiesPanelComponent}.
 * @example
 * <ov-activities-panel [recordingActivity]="false"></ov-activities-panel>
 */
class ActivitiesPanelRecordingActivityDirective {
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.recordingActivityValue = true;
    }
    set activitiesPanelRecordingActivity(value) {
        this.recordingActivityValue = value;
        this.update(this.recordingActivityValue);
    }
    set recordingList(value) {
        this.recordingActivityValue = value;
        this.update(this.recordingActivityValue);
    }
    ngAfterViewInit() {
        this.update(this.recordingActivityValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.recordingActivityValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.recordingActivity.getValue() !== value) {
            this.libService.recordingActivity.next(value);
        }
    }
}
ActivitiesPanelRecordingActivityDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ActivitiesPanelRecordingActivityDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ActivitiesPanelRecordingActivityDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ActivitiesPanelRecordingActivityDirective, selector: "ov-videoconference[activitiesPanelRecordingActivity], ov-activities-panel[recordingActivity]", inputs: { activitiesPanelRecordingActivity: "activitiesPanelRecordingActivity", recordingList: "recordingList" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ActivitiesPanelRecordingActivityDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[activitiesPanelRecordingActivity], ov-activities-panel[recordingActivity]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { activitiesPanelRecordingActivity: [{
                type: Input
            }], recordingList: [{
                type: Input
            }] } });

/**
 * The **recordingsList** directive allows show all recordings saved in your OpenVidu deployment in {@link AdminDashboardComponent}.
 *
 * Default: `[]`
 *
 * @example
 * <ov-admin-dashboard [recordingsList]="recordings"></ov-admin-dashboard>
 *
 */
class AdminRecordingsListDirective {
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.recordingsValue = [];
    }
    set recordingsList(value) {
        this.recordingsValue = value;
        this.update(this.recordingsValue);
    }
    ngAfterViewInit() {
        this.update(this.recordingsValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.recordingsValue = null;
        this.update(null);
    }
    update(value) {
        if (this.libService.adminRecordingsList.getValue() !== value) {
            this.libService.adminRecordingsList.next(value);
        }
    }
}
AdminRecordingsListDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdminRecordingsListDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
AdminRecordingsListDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: AdminRecordingsListDirective, selector: "ov-admin-dashboard[recordingsList]", inputs: { recordingsList: "recordingsList" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdminRecordingsListDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-admin-dashboard[recordingsList]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { recordingsList: [{
                type: Input
            }] } });
/**
 * The **error** directive allows show the authentication error in {@link AdminLoginComponent}.
 *
 * Default: `null`
 *
 * @example
 * <ov-admin-login [error]="error"></ov-admin-login>
 *
 */
class AdminLoginDirective {
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.errorValue = null;
    }
    set error(value) {
        this.errorValue = value;
        this.update(this.errorValue);
    }
    ngAfterViewInit() {
        this.update(this.errorValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.errorValue = null;
        this.update(null);
    }
    update(value) {
        if (this.libService.adminLoginError.getValue() !== value) {
            this.libService.adminLoginError.next(value);
        }
    }
}
AdminLoginDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdminLoginDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
AdminLoginDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: AdminLoginDirective, selector: "ov-admin-login[error]", inputs: { error: "error" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdminLoginDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-admin-login[error]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { error: [{
                type: Input
            }] } });

/**
 * The **muteButton** directive allows show/hide the muted button in participant panel item component.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `participantPanelItem` component:
 *
 * @example
 * <ov-videoconference [participantPanelItemMuteButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ParticipantPanelItemComponent}.
 * @example
 * <ov-participant-panel-item [muteButton]="false"></ov-participant-panel-item>
 */
class ParticipantPanelItemMuteButtonDirective {
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.muteValue = true;
    }
    set participantPanelItemMuteButton(value) {
        this.muteValue = value;
        this.update(this.muteValue);
    }
    set muteButton(value) {
        this.muteValue = value;
        this.update(this.muteValue);
    }
    ngAfterViewInit() {
        this.update(this.muteValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.muteValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.participantItemMuteButton.getValue() !== value) {
            this.libService.participantItemMuteButton.next(value);
        }
    }
}
ParticipantPanelItemMuteButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantPanelItemMuteButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ParticipantPanelItemMuteButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ParticipantPanelItemMuteButtonDirective, selector: "ov-videoconference[participantPanelItemMuteButton], ov-participant-panel-item[muteButton]", inputs: { participantPanelItemMuteButton: "participantPanelItemMuteButton", muteButton: "muteButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantPanelItemMuteButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[participantPanelItemMuteButton], ov-participant-panel-item[muteButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { participantPanelItemMuteButton: [{
                type: Input
            }], muteButton: [{
                type: Input
            }] } });

/**
 * The **recordingsList** directive allows show the recordings available for the session in {@link RecordingActivityComponent}.
 *
 * Default: `[]`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `recordingActivity` component:
 *
 * @example
 * <ov-videoconference [recordingActivityRecordingsList]="list"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link RecordingActivityComponent}.
 * @example
 * <ov-recording-activity [recordingsList]="list"></ov-recording-activity>
 */
class RecordingActivityRecordingsListDirective {
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.recordingsValue = [];
    }
    set recordingActivityRecordingsList(value) {
        this.recordingsValue = value;
        this.update(this.recordingsValue);
    }
    set recordingsList(value) {
        this.recordingsValue = value;
        this.update(this.recordingsValue);
    }
    ngAfterViewInit() {
        this.update(this.recordingsValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.recordingsValue = null;
        this.update(null);
    }
    update(value) {
        if (this.libService.recordingsList.getValue() !== value) {
            this.libService.recordingsList.next(value);
        }
    }
}
RecordingActivityRecordingsListDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingActivityRecordingsListDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
RecordingActivityRecordingsListDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: RecordingActivityRecordingsListDirective, selector: "ov-videoconference[recordingActivityRecordingsList], ov-recording-activity[recordingsList]", inputs: { recordingActivityRecordingsList: "recordingActivityRecordingsList", recordingsList: "recordingsList" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingActivityRecordingsListDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[recordingActivityRecordingsList], ov-recording-activity[recordingsList]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { recordingActivityRecordingsList: [{
                type: Input
            }], recordingsList: [{
                type: Input
            }] } });
/**
 * The **recordingError** directive allows to show any possible error with the recording in the {@link RecordingActivityComponent}.
 *
 * Default: `[]`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `recordingActivity` component:
 *
 * @example
 * <ov-videoconference [recordingActivityRecordingError]="error"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link RecordingActivityComponent}.
 * @example
 * <ov-recording-activity [recordingError]="error"></ov-recording-activity>
 */
class RecordingActivityRecordingErrorDirective {
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.recordingErrorValue = [];
    }
    set recordingActivityRecordingError(value) {
        this.recordingErrorValue = value;
        this.update(this.recordingErrorValue);
    }
    set recordingError(value) {
        this.recordingErrorValue = value;
        this.update(this.recordingErrorValue);
    }
    ngAfterViewInit() {
        this.update(this.recordingErrorValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.recordingErrorValue = null;
        this.update(null);
    }
    update(value) {
        if (this.libService.recordingError.getValue() !== value) {
            this.libService.recordingError.next(value);
        }
    }
}
RecordingActivityRecordingErrorDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingActivityRecordingErrorDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
RecordingActivityRecordingErrorDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: RecordingActivityRecordingErrorDirective, selector: "ov-videoconference[recordingActivityRecordingError], ov-recording-activity[recordingError]", inputs: { recordingActivityRecordingError: "recordingActivityRecordingError", recordingError: "recordingError" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: RecordingActivityRecordingErrorDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[recordingActivityRecordingError], ov-recording-activity[recordingError]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { recordingActivityRecordingError: [{
                type: Input
            }], recordingError: [{
                type: Input
            }] } });

/**
 * The **screenshareButton** directive allows show/hide the screenshare toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarScreenshareButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [screenshareButton]="false"></ov-toolbar>
 */
class ToolbarScreenshareButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.screenshareValue = true;
    }
    /**
     * @ignore
     */
    set toolbarScreenshareButton(value) {
        this.screenshareValue = value;
        this.update(this.screenshareValue);
    }
    /**
     * @ignore
     */
    set screenshareButton(value) {
        this.screenshareValue = value;
        this.update(this.screenshareValue);
    }
    ngAfterViewInit() {
        this.update(this.screenshareValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.screenshareValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.screenshareButton.getValue() !== value) {
            this.libService.screenshareButton.next(value);
        }
    }
}
ToolbarScreenshareButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarScreenshareButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarScreenshareButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarScreenshareButtonDirective, selector: "ov-videoconference[toolbarScreenshareButton], ov-toolbar[screenshareButton]", inputs: { toolbarScreenshareButton: "toolbarScreenshareButton", screenshareButton: "screenshareButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarScreenshareButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarScreenshareButton], ov-toolbar[screenshareButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarScreenshareButton: [{
                type: Input
            }], screenshareButton: [{
                type: Input
            }] } });
/**
 * The **recordingButton** directive allows show/hide the start/stop recording toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarRecordingButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [recordingButton]="false"></ov-toolbar>
 *
 * @internal
 */
class ToolbarRecordingButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.recordingValue = true;
    }
    /**
     * @ignore
     */
    set toolbarRecordingButton(value) {
        this.recordingValue = value;
        this.update(this.recordingValue);
    }
    /**
     * @ignore
     */
    set recordingButton(value) {
        this.recordingValue = value;
        this.update(this.recordingValue);
    }
    ngAfterViewInit() {
        this.update(this.recordingValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.recordingValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.recordingButton.getValue() !== value) {
            this.libService.recordingButton.next(value);
        }
    }
}
ToolbarRecordingButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarRecordingButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarRecordingButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarRecordingButtonDirective, selector: "ov-videoconference[toolbarRecordingButton], ov-toolbar[recordingButton]", inputs: { toolbarRecordingButton: "toolbarRecordingButton", recordingButton: "recordingButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarRecordingButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarRecordingButton], ov-toolbar[recordingButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarRecordingButton: [{
                type: Input
            }], recordingButton: [{
                type: Input
            }] } });
/**
 * The **fullscreenButton** directive allows show/hide the fullscreen toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarFullscreenButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [fullscreenButton]="false"></ov-toolbar>
 */
class ToolbarFullscreenButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.fullscreenValue = true;
    }
    /**
     * @ignore
     */
    set toolbarFullscreenButton(value) {
        this.fullscreenValue = value;
        this.update(this.fullscreenValue);
    }
    /**
     * @ignore
     */
    set fullscreenButton(value) {
        this.fullscreenValue = value;
        this.update(this.fullscreenValue);
    }
    ngAfterViewInit() {
        this.update(this.fullscreenValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.fullscreenValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.fullscreenButton.getValue() !== value) {
            this.libService.fullscreenButton.next(value);
        }
    }
}
ToolbarFullscreenButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarFullscreenButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarFullscreenButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarFullscreenButtonDirective, selector: "ov-videoconference[toolbarFullscreenButton], ov-toolbar[fullscreenButton]", inputs: { toolbarFullscreenButton: "toolbarFullscreenButton", fullscreenButton: "fullscreenButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarFullscreenButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarFullscreenButton], ov-toolbar[fullscreenButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarFullscreenButton: [{
                type: Input
            }], fullscreenButton: [{
                type: Input
            }] } });
/**
 * The **backgroundEffectsButton** directive allows show/hide the background effects toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarBackgroundEffectsButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [backgroundEffectsButton]="false"></ov-toolbar>
 */
class ToolbarBackgroundEffectsButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.backgroundEffectsValue = true;
    }
    /**
     * @ignore
     */
    set toolbarBackgroundEffectsButton(value) {
        this.backgroundEffectsValue = value;
        this.update(this.backgroundEffectsValue);
    }
    /**
     * @ignore
     */
    set backgroundEffectsButton(value) {
        this.backgroundEffectsValue = value;
        this.update(this.backgroundEffectsValue);
    }
    ngAfterViewInit() {
        this.update(this.backgroundEffectsValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.backgroundEffectsValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.backgroundEffectsButton.getValue() !== value) {
            this.libService.backgroundEffectsButton.next(value);
        }
    }
}
ToolbarBackgroundEffectsButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarBackgroundEffectsButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarBackgroundEffectsButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarBackgroundEffectsButtonDirective, selector: "ov-videoconference[toolbarBackgroundEffectsButton], ov-toolbar[backgroundEffectsButton]", inputs: { toolbarBackgroundEffectsButton: "toolbarBackgroundEffectsButton", backgroundEffectsButton: "backgroundEffectsButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarBackgroundEffectsButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarBackgroundEffectsButton], ov-toolbar[backgroundEffectsButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarBackgroundEffectsButton: [{
                type: Input
            }], backgroundEffectsButton: [{
                type: Input
            }] } });
/**
 * The **captionsButton** directive allows show/hide the captions toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarCaptionsButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [captionsButton]="false"></ov-toolbar>
 */
class ToolbarCaptionsButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.captionsButtonValue = true;
    }
    /**
     * @ignore
     */
    set toolbarCaptionsButton(value) {
        this.captionsButtonValue = value;
        this.update(this.captionsButtonValue);
    }
    /**
     * @ignore
     */
    set captionsButton(value) {
        this.captionsButtonValue = value;
        this.update(this.captionsButtonValue);
    }
    ngAfterViewInit() {
        this.update(this.captionsButtonValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.captionsButtonValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.subtitlesButton.getValue() !== value) {
            this.libService.subtitlesButton.next(value);
        }
    }
}
ToolbarCaptionsButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarCaptionsButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarCaptionsButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarCaptionsButtonDirective, selector: "ov-videoconference[toolbarCaptionsButton], ov-toolbar[captionsButton]", inputs: { toolbarCaptionsButton: "toolbarCaptionsButton", captionsButton: "captionsButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarCaptionsButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarCaptionsButton], ov-toolbar[captionsButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarCaptionsButton: [{
                type: Input
            }], captionsButton: [{
                type: Input
            }] } });
/**
 * The **settingsButton** directive allows show/hide the settings toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarSettingsButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [settingsButton]="false"></ov-toolbar>
 */
class ToolbarSettingsButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.settingsValue = true;
    }
    /**
     * @ignore
     */
    set toolbarSettingsButton(value) {
        this.settingsValue = value;
        this.update(this.settingsValue);
    }
    /**
     * @ignore
     */
    set settingsButton(value) {
        this.settingsValue = value;
        this.update(this.settingsValue);
    }
    ngAfterViewInit() {
        this.update(this.settingsValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.settingsValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.toolbarSettingsButton.getValue() !== value) {
            this.libService.toolbarSettingsButton.next(value);
        }
    }
}
ToolbarSettingsButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarSettingsButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarSettingsButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarSettingsButtonDirective, selector: "ov-videoconference[toolbarSettingsButton], ov-toolbar[settingsButton]", inputs: { toolbarSettingsButton: "toolbarSettingsButton", settingsButton: "settingsButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarSettingsButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarSettingsButton], ov-toolbar[settingsButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarSettingsButton: [{
                type: Input
            }], settingsButton: [{
                type: Input
            }] } });
/**
 * The **leaveButton** directive allows show/hide the leave toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarLeaveButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [leaveButton]="false"></ov-toolbar>
 */
class ToolbarLeaveButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.leaveValue = true;
    }
    /**
     * @ignore
     */
    set toolbarLeaveButton(value) {
        this.leaveValue = value;
        this.update(this.leaveValue);
    }
    /**
     * @ignore
     */
    set leaveButton(value) {
        this.leaveValue = value;
        this.update(this.leaveValue);
    }
    ngAfterViewInit() {
        this.update(this.leaveValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.leaveValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.leaveButton.getValue() !== value) {
            this.libService.leaveButton.next(value);
        }
    }
}
ToolbarLeaveButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarLeaveButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarLeaveButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarLeaveButtonDirective, selector: "ov-videoconference[toolbarLeaveButton], ov-toolbar[leaveButton]", inputs: { toolbarLeaveButton: "toolbarLeaveButton", leaveButton: "leaveButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarLeaveButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarLeaveButton], ov-toolbar[leaveButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarLeaveButton: [{
                type: Input
            }], leaveButton: [{
                type: Input
            }] } });
/**
 * The **participantsPanelButton** directive allows show/hide the participants panel toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarParticipantsPanelButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [participantsPanelButton]="false"></ov-toolbar>
 */
class ToolbarParticipantsPanelButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.participantsPanelValue = true;
    }
    /**
     * @ignore
     */
    set toolbarParticipantsPanelButton(value) {
        this.participantsPanelValue = value;
        this.update(this.participantsPanelValue);
    }
    /**
     * @ignore
     */
    set participantsPanelButton(value) {
        this.participantsPanelValue = value;
        this.update(this.participantsPanelValue);
    }
    ngAfterViewInit() {
        this.update(this.participantsPanelValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.participantsPanelValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.participantsPanelButton.getValue() !== value) {
            this.libService.participantsPanelButton.next(value);
        }
    }
}
ToolbarParticipantsPanelButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarParticipantsPanelButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarParticipantsPanelButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarParticipantsPanelButtonDirective, selector: "ov-videoconference[toolbarParticipantsPanelButton], ov-toolbar[participantsPanelButton]", inputs: { toolbarParticipantsPanelButton: "toolbarParticipantsPanelButton", participantsPanelButton: "participantsPanelButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarParticipantsPanelButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarParticipantsPanelButton], ov-toolbar[participantsPanelButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarParticipantsPanelButton: [{
                type: Input
            }], participantsPanelButton: [{
                type: Input
            }] } });
/**
 * The **chatPanelButton** directive allows show/hide the chat panel toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarChatPanelButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [chatPanelButton]="false"></ov-toolbar>
 */
class ToolbarChatPanelButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.toolbarChatPanelValue = true;
    }
    /**
     * @ignore
     */
    set toolbarChatPanelButton(value) {
        this.toolbarChatPanelValue = value;
        this.update(this.toolbarChatPanelValue);
    }
    /**
     * @ignore
     */
    set chatPanelButton(value) {
        this.toolbarChatPanelValue = value;
        this.update(this.toolbarChatPanelValue);
    }
    ngAfterViewInit() {
        this.update(this.toolbarChatPanelValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.toolbarChatPanelValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.chatPanelButton.getValue() !== value) {
            this.libService.chatPanelButton.next(value);
        }
    }
}
ToolbarChatPanelButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarChatPanelButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarChatPanelButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarChatPanelButtonDirective, selector: "ov-videoconference[toolbarChatPanelButton], ov-toolbar[chatPanelButton]", inputs: { toolbarChatPanelButton: "toolbarChatPanelButton", chatPanelButton: "chatPanelButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarChatPanelButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarChatPanelButton], ov-toolbar[chatPanelButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarChatPanelButton: [{
                type: Input
            }], chatPanelButton: [{
                type: Input
            }] } });
/**
 * The **activitiesPanelButton** directive allows show/hide the activities panel toolbar button.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarActivitiesPanelButton]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [activitiesPanelButton]="false"></ov-toolbar>
 *
 * @internal
 */
class ToolbarActivitiesPanelButtonDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.toolbarActivitiesPanelValue = true;
    }
    /**
     * @ignore
     */
    set toolbarActivitiesPanelButton(value) {
        this.toolbarActivitiesPanelValue = value;
        this.update(this.toolbarActivitiesPanelValue);
    }
    /**
     * @ignore
     */
    set activitiesPanelButton(value) {
        this.toolbarActivitiesPanelValue = value;
        this.update(this.toolbarActivitiesPanelValue);
    }
    ngAfterViewInit() {
        this.update(this.toolbarActivitiesPanelValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.toolbarActivitiesPanelValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.activitiesPanelButton.getValue() !== value) {
            this.libService.activitiesPanelButton.next(value);
        }
    }
}
ToolbarActivitiesPanelButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarActivitiesPanelButtonDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarActivitiesPanelButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarActivitiesPanelButtonDirective, selector: "ov-videoconference[toolbarActivitiesPanelButton], ov-toolbar[activitiesPanelButton]", inputs: { toolbarActivitiesPanelButton: "toolbarActivitiesPanelButton", activitiesPanelButton: "activitiesPanelButton" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarActivitiesPanelButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarActivitiesPanelButton], ov-toolbar[activitiesPanelButton]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarActivitiesPanelButton: [{
                type: Input
            }], activitiesPanelButton: [{
                type: Input
            }] } });
/**
 * The **displaySessionName** directive allows show/hide the session name.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarDisplaySessionName]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [displaySessionName]="false"></ov-toolbar>
 */
class ToolbarDisplaySessionNameDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.displaySessionValue = true;
    }
    /**
     * @ignore
     */
    set toolbarDisplaySessionName(value) {
        this.displaySessionValue = value;
        this.update(this.displaySessionValue);
    }
    /**
     * @ignore
     */
    set displaySessionName(value) {
        this.displaySessionValue = value;
        this.update(this.displaySessionValue);
    }
    ngAfterViewInit() {
        this.update(this.displaySessionValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.displaySessionValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.displaySessionName.getValue() !== value) {
            this.libService.displaySessionName.next(value);
        }
    }
}
ToolbarDisplaySessionNameDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarDisplaySessionNameDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarDisplaySessionNameDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarDisplaySessionNameDirective, selector: "ov-videoconference[toolbarDisplaySessionName], ov-toolbar[displaySessionName]", inputs: { toolbarDisplaySessionName: "toolbarDisplaySessionName", displaySessionName: "displaySessionName" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarDisplaySessionNameDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarDisplaySessionName], ov-toolbar[displaySessionName]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarDisplaySessionName: [{
                type: Input
            }], displaySessionName: [{
                type: Input
            }] } });
/**
 * The **displayLogo** directive allows show/hide the branding logo.
 *
 * Default: `true`
 *
 * It can be used in the parent element {@link VideoconferenceComponent} specifying the name of the `toolbar` component:
 *
 * @example
 * <ov-videoconference [toolbarDisplayLogo]="false"></ov-videoconference>
 *
 * \
 * And it also can be used in the {@link ToolbarComponent}.
 * @example
 * <ov-toolbar [displayLogo]="false"></ov-toolbar>
 */
class ToolbarDisplayLogoDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
        this.displayLogoValue = true;
    }
    /**
     * @ignore
     */
    set toolbarDisplayLogo(value) {
        this.displayLogoValue = value;
        this.update(this.displayLogoValue);
    }
    /**
     * @ignore
     */
    set displayLogo(value) {
        this.displayLogoValue = value;
        this.update(this.displayLogoValue);
    }
    ngAfterViewInit() {
        this.update(this.displayLogoValue);
    }
    ngOnDestroy() {
        this.clear();
    }
    clear() {
        this.displayLogoValue = true;
        this.update(true);
    }
    update(value) {
        if (this.libService.displayLogo.getValue() !== value) {
            this.libService.displayLogo.next(value);
        }
    }
}
ToolbarDisplayLogoDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarDisplayLogoDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ToolbarDisplayLogoDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ToolbarDisplayLogoDirective, selector: "ov-videoconference[toolbarDisplayLogo], ov-toolbar[displayLogo]", inputs: { toolbarDisplayLogo: "toolbarDisplayLogo", displayLogo: "displayLogo" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ToolbarDisplayLogoDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[toolbarDisplayLogo], ov-toolbar[displayLogo]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { toolbarDisplayLogo: [{
                type: Input
            }], displayLogo: [{
                type: Input
            }] } });

/**
 * The **minimal** directive applies a minimal UI hiding all controls except for cam and mic.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 *  Default: `false`
 *
 * @example
 * <ov-videoconference [minimal]="true"></ov-videoconference>
 */
class MinimalDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
    }
    /**
     * @ignore
     */
    set minimal(value) {
        this.update(value);
    }
    /**
     * @ignore
     */
    ngOnDestroy() {
        this.clear();
    }
    /**
     * @ignore
     */
    clear() {
        this.update(false);
    }
    /**
     * @ignore
     */
    update(value) {
        if (this.libService.minimal.getValue() !== value) {
            this.libService.minimal.next(value);
        }
    }
}
MinimalDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: MinimalDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
MinimalDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: MinimalDirective, selector: "ov-videoconference[minimal]", inputs: { minimal: "minimal" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: MinimalDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[minimal]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { minimal: [{
                type: Input
            }] } });
/**
 * The **lang** directive allows et the UI language to a default language.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * **Default:** English `en`
 *
 * **Available:**
 *
 * * English: `en`
 * * Spanish: `es`
 * * German: `de`
 * * French: `fr`
 * * Chinese: `cn`
 * * Hindi: `hi`
 * * Italian: `it`
 * * Japanese: `ja`
 * * Netherlands: `nl`
 * * Portuguese: `pt`
 *
 * @example
 * <ov-videoconference [lang]="es"></ov-videoconference>
 */
class LangDirective {
    /**
     * @ignore
     */
    constructor(elementRef, translateService) {
        this.elementRef = elementRef;
        this.translateService = translateService;
    }
    /**
     * @ignore
     */
    set lang(value) {
        this.update(value);
    }
    /**
     * @ignore
     */
    ngOnDestroy() {
        this.clear();
    }
    /**
     * @ignore
     */
    clear() {
        this.update('en');
    }
    /**
     * @ignore
     */
    update(value) {
        this.translateService.setLanguage(value);
    }
}
LangDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LangDirective, deps: [{ token: i0.ElementRef }, { token: TranslateService }], target: i0.ɵɵFactoryTarget.Directive });
LangDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: LangDirective, selector: "ov-videoconference[lang]", inputs: { lang: "lang" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: LangDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[lang]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: TranslateService }]; }, propDecorators: { lang: [{
                type: Input
            }] } });
/**
 * The **participantName** directive sets the participant name. It can be useful for aplications which doesn't need the prejoin page.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * @example
 * <ov-videoconference [participantName]="'OpenVidu'"></ov-videoconference>
 */
class ParticipantNameDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
    }
    /**
     * @ignore
     */
    ngOnInit() {
        this.update(this.participantName);
    }
    /**
     * @ignore
     */
    ngOnDestroy() {
        this.clear();
    }
    /**
     * @ignore
     */
    clear() {
        this.update('');
    }
    /**
     * @ignore
     */
    update(value) {
        this.libService.participantName.next(value);
    }
}
ParticipantNameDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantNameDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
ParticipantNameDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: ParticipantNameDirective, selector: "ov-videoconference[participantName]", inputs: { participantName: "participantName" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ParticipantNameDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[participantName]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { participantName: [{
                type: Input
            }] } });
/**
 * The **prejoin** directive allows show/hide the prejoin page for selecting media devices.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * Default: `true`
 *
 * @example
 * <ov-videoconference [prejoin]="false"></ov-videoconference>
 */
class PrejoinDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
    }
    /**
     * @ignore
     */
    set prejoin(value) {
        this.update(value);
    }
    /**
     * @ignore
     */
    ngOnDestroy() {
        this.clear();
    }
    /**
     * @ignore
     */
    clear() {
        this.update(true);
    }
    /**
     * @ignore
     */
    update(value) {
        if (this.libService.prejoin.getValue() !== value) {
            this.libService.prejoin.next(value);
        }
    }
}
PrejoinDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PrejoinDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
PrejoinDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: PrejoinDirective, selector: "ov-videoconference[prejoin]", inputs: { prejoin: "prejoin" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: PrejoinDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[prejoin]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { prejoin: [{
                type: Input
            }] } });
/**
 * The **videoMuted** directive allows to join the session with camera muted/unmuted.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * Default: `false`
 *
 *
 * @example
 * <ov-videoconference [videoMuted]="true"></ov-videoconference>
 */
class VideoMutedDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
    }
    /**
     * @ignore
     */
    set videoMuted(value) {
        this.update(value);
    }
    /**
     * @ignore
     */
    ngOnDestroy() {
        this.clear();
    }
    /**
     * @ignore
     */
    clear() {
        this.update(false);
    }
    /**
     * @ignore
     */
    update(value) {
        if (this.libService.videoMuted.getValue() !== value) {
            this.libService.videoMuted.next(value);
        }
    }
}
VideoMutedDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VideoMutedDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
VideoMutedDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: VideoMutedDirective, selector: "ov-videoconference[videoMuted]", inputs: { videoMuted: "videoMuted" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: VideoMutedDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[videoMuted]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { videoMuted: [{
                type: Input
            }] } });
/**
 * The **audioMuted** directive allows to join the session with microphone muted/unmuted.
 *
 * It is only available for {@link VideoconferenceComponent}.
 *
 * Default: `false`
 *
 * @example
 * <ov-videoconference [audioMuted]="true"></ov-videoconference>
 */
class AudioMutedDirective {
    /**
     * @ignore
     */
    constructor(elementRef, libService) {
        this.elementRef = elementRef;
        this.libService = libService;
    }
    /**
     * @ignore
     */
    set audioMuted(value) {
        this.update(value);
    }
    ngOnDestroy() {
        this.clear();
    }
    /**
     * @ignore
     */
    clear() {
        this.update(false);
    }
    /**
     * @ignore
     */
    update(value) {
        if (this.libService.audioMuted.getValue() !== value) {
            this.libService.audioMuted.next(value);
        }
    }
}
AudioMutedDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AudioMutedDirective, deps: [{ token: i0.ElementRef }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Directive });
AudioMutedDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "12.0.0", version: "13.0.0", type: AudioMutedDirective, selector: "ov-videoconference[audioMuted]", inputs: { audioMuted: "audioMuted" }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AudioMutedDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ov-videoconference[audioMuted]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }, { type: OpenViduAngularConfigService }]; }, propDecorators: { audioMuted: [{
                type: Input
            }] } });

class ApiDirectiveModule {
}
ApiDirectiveModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ApiDirectiveModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
ApiDirectiveModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ApiDirectiveModule, declarations: [MinimalDirective,
        LangDirective,
        PrejoinDirective,
        VideoMutedDirective,
        AudioMutedDirective,
        ToolbarScreenshareButtonDirective,
        ToolbarFullscreenButtonDirective,
        ToolbarBackgroundEffectsButtonDirective,
        ToolbarCaptionsButtonDirective,
        ToolbarLeaveButtonDirective,
        ToolbarRecordingButtonDirective,
        ToolbarParticipantsPanelButtonDirective,
        ToolbarChatPanelButtonDirective,
        ToolbarActivitiesPanelButtonDirective,
        ToolbarDisplaySessionNameDirective,
        ToolbarDisplayLogoDirective,
        ToolbarSettingsButtonDirective,
        StreamDisplayParticipantNameDirective,
        StreamDisplayAudioDetectionDirective,
        StreamSettingsButtonDirective,
        LogoDirective,
        ParticipantPanelItemMuteButtonDirective,
        ParticipantNameDirective,
        ActivitiesPanelRecordingActivityDirective,
        RecordingActivityRecordingsListDirective,
        RecordingActivityRecordingErrorDirective,
        AdminRecordingsListDirective,
        AdminLoginDirective], exports: [MinimalDirective,
        LangDirective,
        PrejoinDirective,
        VideoMutedDirective,
        AudioMutedDirective,
        ToolbarScreenshareButtonDirective,
        ToolbarFullscreenButtonDirective,
        ToolbarBackgroundEffectsButtonDirective,
        ToolbarCaptionsButtonDirective,
        ToolbarLeaveButtonDirective,
        ToolbarRecordingButtonDirective,
        ToolbarParticipantsPanelButtonDirective,
        ToolbarChatPanelButtonDirective,
        ToolbarActivitiesPanelButtonDirective,
        ToolbarDisplaySessionNameDirective,
        ToolbarDisplayLogoDirective,
        ToolbarSettingsButtonDirective,
        StreamDisplayParticipantNameDirective,
        StreamDisplayAudioDetectionDirective,
        StreamSettingsButtonDirective,
        LogoDirective,
        ParticipantPanelItemMuteButtonDirective,
        ParticipantNameDirective,
        ActivitiesPanelRecordingActivityDirective,
        RecordingActivityRecordingsListDirective,
        RecordingActivityRecordingErrorDirective,
        AdminRecordingsListDirective,
        AdminLoginDirective] });
ApiDirectiveModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ApiDirectiveModule });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: ApiDirectiveModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        MinimalDirective,
                        LangDirective,
                        PrejoinDirective,
                        VideoMutedDirective,
                        AudioMutedDirective,
                        ToolbarScreenshareButtonDirective,
                        ToolbarFullscreenButtonDirective,
                        ToolbarBackgroundEffectsButtonDirective,
                        ToolbarCaptionsButtonDirective,
                        ToolbarLeaveButtonDirective,
                        ToolbarRecordingButtonDirective,
                        ToolbarParticipantsPanelButtonDirective,
                        ToolbarChatPanelButtonDirective,
                        ToolbarActivitiesPanelButtonDirective,
                        ToolbarDisplaySessionNameDirective,
                        ToolbarDisplayLogoDirective,
                        ToolbarSettingsButtonDirective,
                        StreamDisplayParticipantNameDirective,
                        StreamDisplayAudioDetectionDirective,
                        StreamSettingsButtonDirective,
                        LogoDirective,
                        ParticipantPanelItemMuteButtonDirective,
                        ParticipantNameDirective,
                        ActivitiesPanelRecordingActivityDirective,
                        RecordingActivityRecordingsListDirective,
                        RecordingActivityRecordingErrorDirective,
                        AdminRecordingsListDirective,
                        AdminLoginDirective
                    ],
                    exports: [
                        MinimalDirective,
                        LangDirective,
                        PrejoinDirective,
                        VideoMutedDirective,
                        AudioMutedDirective,
                        ToolbarScreenshareButtonDirective,
                        ToolbarFullscreenButtonDirective,
                        ToolbarBackgroundEffectsButtonDirective,
                        ToolbarCaptionsButtonDirective,
                        ToolbarLeaveButtonDirective,
                        ToolbarRecordingButtonDirective,
                        ToolbarParticipantsPanelButtonDirective,
                        ToolbarChatPanelButtonDirective,
                        ToolbarActivitiesPanelButtonDirective,
                        ToolbarDisplaySessionNameDirective,
                        ToolbarDisplayLogoDirective,
                        ToolbarSettingsButtonDirective,
                        StreamDisplayParticipantNameDirective,
                        StreamDisplayAudioDetectionDirective,
                        StreamSettingsButtonDirective,
                        LogoDirective,
                        ParticipantPanelItemMuteButtonDirective,
                        ParticipantNameDirective,
                        ActivitiesPanelRecordingActivityDirective,
                        RecordingActivityRecordingsListDirective,
                        RecordingActivityRecordingErrorDirective,
                        AdminRecordingsListDirective,
                        AdminLoginDirective
                    ]
                }]
        }] });

class AdminDashboardComponent {
    /**
     * @internal
     */
    constructor(actionService, recordingService, libService) {
        this.actionService = actionService;
        this.recordingService = recordingService;
        this.libService = libService;
        /**
         * Provides event notifications that fire when delete recording button has been clicked.
         * The recording should be deleted using the REST API.
         * @param recordingId
         */
        this.onDeleteRecordingClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when refresh recordings button has been clicked.
         */
        this.onRefreshRecordingsClicked = new EventEmitter();
        /**
         * Provides event notifications that fire when logout button has been clicked.
         */
        this.onLogoutClicked = new EventEmitter();
        /**
         * @internal
         */
        this.recordings = [];
        /**
         * @internal
         */
        this.sortDescendent = true;
        /**
         * @internal
         */
        this.sortByLegend = 'Sort by';
        /**
         * @internal
         */
        this.searchValue = '';
    }
    /**
     * @internal
     */
    ngOnInit() {
        this.subscribeToAdminDirectives();
    }
    /**
     * @internal
     */
    ngOnDestroy() {
        if (this.adminSubscription)
            this.adminSubscription.unsubscribe();
    }
    /**
     * @internal
     */
    logout() {
        this.onLogoutClicked.emit();
    }
    /**
     * @internal
     */
    sortRecordingsByDate() {
        this.recordings.sort((a, b) => {
            if (a.createdAt > b.createdAt) {
                return this.sortDescendent ? -1 : 1;
            }
            else if (a.createdAt < b.createdAt) {
                return this.sortDescendent ? 1 : -1;
            }
            else {
                return 0;
            }
        });
        this.sortByLegend = 'Date';
    }
    /**
     * @internal
     */
    sortRecordingsByDuration() {
        this.recordings.sort((a, b) => {
            if (a.duration > b.duration) {
                return this.sortDescendent ? -1 : 1;
            }
            else if (a.duration < b.duration) {
                return this.sortDescendent ? 1 : -1;
            }
            else {
                return 0;
            }
        });
        this.sortByLegend = 'Duration';
    }
    /**
     * @internal
     */
    sortRecordingsBySize() {
        this.recordings.sort((a, b) => {
            if (a.size > b.size) {
                return this.sortDescendent ? -1 : 1;
            }
            else if (a.size < b.size) {
                return this.sortDescendent ? 1 : -1;
            }
            else {
                return 0;
            }
        });
        this.sortByLegend = 'Size';
    }
    /**
     * @internal
     */
    deleteRecording(recordingId) {
        const succsessCallback = () => {
            this.onDeleteRecordingClicked.emit(recordingId);
        };
        this.actionService.openDeleteRecordingDialog(succsessCallback);
    }
    /**
     * @internal
     */
    download(recording) {
        this.recordingService.downloadRecording(recording);
    }
    /**
     * @internal
     */
    refreshRecordings() {
        this.onRefreshRecordingsClicked.emit();
    }
    /**
     * @internal
     */
    play(recording) {
        return __awaiter(this, void 0, void 0, function* () {
            this.recordingService.playRecording(recording);
        });
    }
    subscribeToAdminDirectives() {
        this.adminSubscription = this.libService.adminRecordingsListObs.subscribe((recordings) => {
            this.recordings = recordings;
        });
    }
}
AdminDashboardComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdminDashboardComponent, deps: [{ token: ActionService }, { token: RecordingService }, { token: OpenViduAngularConfigService }], target: i0.ɵɵFactoryTarget.Component });
AdminDashboardComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: AdminDashboardComponent, selector: "ov-admin-dashboard", outputs: { onDeleteRecordingClicked: "onDeleteRecordingClicked", onRefreshRecordingsClicked: "onRefreshRecordingsClicked", onLogoutClicked: "onLogoutClicked" }, ngImport: i0, template: "<div class=\"dashboard-container\">\n\t<mat-toolbar class=\"header\">\n\t\t<span>{{ 'ADMIN.DASHBOARD' | translate }}</span>\n\t\t<div class=\"refresh-btn\">\n\t\t\t<button matSuffix mat-icon-button aria-label=\"Refresh\" (click)=\"logout()\">\n\t\t\t\t<mat-icon>logout</mat-icon>\n\t\t\t</button>\n\t\t</div>\n\t</mat-toolbar>\n\n\t<div class=\"dashboard-body\">\n\t\t<div id=\"toolbar-search\">\n\t\t\t<div class=\"search-bar\">\n\t\t\t\t<textarea\n\t\t\t\t\tid=\"search-input\"\n\t\t\t\t\tmaxlength=\"100\"\n\t\t\t\t\trows=\"4\"\n\t\t\t\t\tplaceholder=\"{{ 'ADMIN.SEARCH' | translate }}\"\n\t\t\t\t\tautocomplete=\"off\"\n\t\t\t\t\t[(ngModel)]=\"searchValue\"\n\t\t\t\t></textarea>\n\t\t\t\t<div>\n\t\t\t\t\t<button *ngIf=\"searchValue\" matSuffix mat-icon-button aria-label=\"Clear\" (click)=\"searchValue = ''\">\n\t\t\t\t\t\t<mat-icon>close</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t\t<button *ngIf=\"!searchValue\" matSuffix mat-icon-button aria-label=\"Search\">\n\t\t\t\t\t\t<mat-icon>search</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t<div>\n\t\t\t\t<button id=\"sort-menu-btn\" color=\"primary\" mat-flat-button [matMenuTriggerFor]=\"sortMenu\">\n\t\t\t\t\t{{ sortByLegend }}\n\t\t\t\t\t<mat-icon>arrow_drop_down</mat-icon>\n\t\t\t\t</button>\n\n\t\t\t\t<mat-menu #sortMenu=\"matMenu\">\n\t\t\t\t\t<button mat-menu-item class=\"order-select-btn\" (click)=\"sortRecordingsByDate()\">{{ 'ADMIN.DATE' | translate }}</button>\n\t\t\t\t\t<button mat-menu-item class=\"order-select-btn\" (click)=\"sortRecordingsByDuration()\">\n\t\t\t\t\t\t{{ 'ADMIN.DURATION' | translate }}\n\t\t\t\t\t</button>\n\t\t\t\t\t<button mat-menu-item class=\"order-select-btn\" (click)=\"sortRecordingsBySize()\">{{ 'ADMIN.SIZE' | translate }}</button>\n\t\t\t\t</mat-menu>\n\n\t\t\t\t<div class=\"refresh-btn\">\n\t\t\t\t\t<button matSuffix mat-icon-button aria-label=\"Refresh\" (click)=\"refreshRecordings()\">\n\t\t\t\t\t\t<mat-icon>refresh</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\n\t\t<div *ngIf=\"!recordings || recordings.length === 0\" class=\"no-recordings-warn\">\n\t\t\t<span>{{ 'ADMIN.NO_RECORDINGS' | translate }}</span>\n\t\t</div>\n\n\t\t<div class=\"recordings-container\">\n\t\t\t<div\n\t\t\t\t*ngFor=\"\n\t\t\t\t\tlet recording of recordings\n\t\t\t\t\t\t| searchByStringProperty: { properties: ['sessionId', 'properties?.name || name'], filter: searchValue }\n\t\t\t\t\"\n\t\t\t\tclass=\"item\"\n\t\t\t>\n\t\t\t\t<mat-card class=\"recording-card\">\n\t\t\t\t\t<mat-card-content>\n\t\t\t\t\t\t<div class=\"video-div-container\">\n\t\t\t\t\t\t\t<img *ngIf=\"!!recording.url\" [src]=\"recording.url | thumbnailUrl\" />\n\t\t\t\t\t\t\t<div class=\"video-btns\">\n\t\t\t\t\t\t\t\t<button\n\t\t\t\t\t\t\t\t\t*ngIf=\"recording.status !== 'failed' && recording.status !== 'stopped'\"\n\t\t\t\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t\t\t\t(click)=\"play(recording)\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<mat-icon id=\"play\" aria-label=\"Play\" title=\"{{ 'PANEL.RECORDING.PLAY' | translate }}\"\n\t\t\t\t\t\t\t\t\t\t>play_arrow</mat-icon\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t</button>\n\n\t\t\t\t\t\t\t\t<button\n\t\t\t\t\t\t\t\t\t(click)=\"download(recording)\"\n\t\t\t\t\t\t\t\t\t*ngIf=\"!!recording.url && recording.status !== 'failed' && recording.status !== 'stopped'\"\n\t\t\t\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t\t\t\taria-label=\"Download\"\n\t\t\t\t\t\t\t\t\ttitle=\"{{ 'PANEL.RECORDING.DOWNLOAD' | translate }}\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<mat-icon id=\"download\">download</mat-icon>\n\t\t\t\t\t\t\t\t</button>\n\t\t\t\t\t\t\t\t<button mat-icon-button class=\"delete-recording-btn\" (click)=\"deleteRecording(recording.id)\">\n\t\t\t\t\t\t\t\t\t<mat-icon id=\"delete\" aria-label=\"Delete\" title=\"{{ 'PANEL.RECORDING.DELETE' | translate }}\"\n\t\t\t\t\t\t\t\t\t\t>delete</mat-icon\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t</button>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"video-info-container\">\n\t\t\t\t\t\t\t<div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.NAME' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.properties?.name || recording.name }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.SESSION' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.sessionId }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.OUTPUT' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.properties?.outputMode || recording.outputMode }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.DATE' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.createdAt | date: 'M/d/yy, H:mm' }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.DURATION' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.duration | duration }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.SIZE' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.size / 1024 / 1024 | number: '1.1-2' }} MBs</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\" style=\"margin-top: 11px\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.STATUS' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value status-value\" [ngClass]=\"recording.status\">{{ recording.status }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</mat-card-content>\n\t\t\t\t</mat-card>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n\t<mat-toolbar class=\"footer\" fxLayout fxLayout.xs=\"row\" fxLayoutGap=\"2px\" id=\"footer\" role=\"heading\">\n\t\t<span>{{ 'ADMIN.POWERED_BY' | translate }}</span>\n\t\t<a href=\"https://openvidu.io/\">OpenVidu</a>\n\t</mat-toolbar>\n</div>\n", styles: [".dashboard-container{height:100%}.header{height:50px;background-color:var(--ov-secondary-color);color:var(--ov-text-color)}.dashboard-body{height:calc(100% - 75px)}#toolbar-search{width:100%;height:40px;background-color:var(--ov-light-color);padding:6px;display:flex;align-items:center}#toolbar-sort-div{display:flex;flex-direction:row;align-items:center}#sort-menu-btn{margin-left:5px;background-color:var(--ov-panel-background)}.search-bar{height:95%;width:30%;display:flex;background-color:var(--ov-panel-background);padding:0 10px;border-radius:var(--ov-panel-radius)}#search-input{width:100%;height:16px;margin:auto;background-color:transparent;display:block;border:none;padding:0;word-wrap:break-word;white-space:pre-wrap;resize:none;outline:none;box-shadow:none;font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif}#refresh-btn{float:right}#refresh-btn mat-icon{color:inherit}.refresh-btn{position:absolute;right:0;display:inline-flex}.recordings-container{height:calc(100% - 51px);display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));overflow-y:auto;overflow-x:hidden}.recording-card{background-color:var(--ov-panel-background)}.video-div-container{position:relative;text-align:center;width:100%;height:42%;overflow:hidden;background-color:var(--ov-light-color);display:flex;justify-content:center;align-items:center}.video-div-container img{border-radius:var(--ov-video-radius);display:inline;position:relative;max-width:100%;max-height:100%}.item{flex-grow:1;margin:10px}.item+.item{margin-left:2%}.video-btns{position:absolute;transform:translate(-50%,-50%);margin-right:-50%;top:50%;left:50%;background-color:var(--ov-logo-background-color);border-radius:var(--ov-panel-radius)}.video-btns button #play{color:var(--ov-text-color)}.video-btns button #download{color:var(--ov-tertiary-color)}.video-btns button #delete{color:var(--ov-warn-color)}.video-info-container>div{width:100%;height:100%;display:table;table-layout:fixed;box-sizing:border-box;margin-top:20px}.video-div-tag:first-child{margin-top:20px}.video-div-tag{display:table-row}.video-card-tag{font-size:13px;color:var(--ov-panel-text-color)}.video-card-value{float:right;font-size:13.5px}.footer{height:25px;background-color:var(--ov-secondary-color);color:var(--ov-text-color);position:absolute;bottom:0;left:0;font-size:12px}.footer a{color:var(--ov-tertiary-color)}.no-recordings-warn{height:calc(100% - 52px);width:100%;display:table;text-align:center}::ng-deep .mat-form-field-appearance-fill .mat-form-field-flex{padding:0!important;background-color:var(--ov-light-color)!important}::ng-deep .mat-form-field-wrapper{height:100%!important}\n"], components: [{ type: i15.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }, { type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { type: i18.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { type: i18.MatMenuItem, selector: "[mat-menu-item]", inputs: ["disabled", "disableRipple", "role"], exportAs: ["matMenuItem"] }, { type: i5$3.MatCard, selector: "mat-card", exportAs: ["matCard"] }], directives: [{ type: i9$1.MatSuffix, selector: "[matSuffix]" }, { type: i9.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { type: i9.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { type: i9.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i9.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i18.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { type: i10.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { type: i5$3.MatCardContent, selector: "mat-card-content, [mat-card-content], [matCardContent]" }, { type: i10.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { type: i2$1.DefaultClassDirective, selector: "  [ngClass], [ngClass.xs], [ngClass.sm], [ngClass.md], [ngClass.lg], [ngClass.xl],  [ngClass.lt-sm], [ngClass.lt-md], [ngClass.lt-lg], [ngClass.lt-xl],  [ngClass.gt-xs], [ngClass.gt-sm], [ngClass.gt-md], [ngClass.gt-lg]", inputs: ["ngClass", "ngClass.xs", "ngClass.sm", "ngClass.md", "ngClass.lg", "ngClass.xl", "ngClass.lt-sm", "ngClass.lt-md", "ngClass.lt-lg", "ngClass.lt-xl", "ngClass.gt-xs", "ngClass.gt-sm", "ngClass.gt-md", "ngClass.gt-lg"] }, { type: i5.DefaultLayoutDirective, selector: "  [fxLayout], [fxLayout.xs], [fxLayout.sm], [fxLayout.md],  [fxLayout.lg], [fxLayout.xl], [fxLayout.lt-sm], [fxLayout.lt-md],  [fxLayout.lt-lg], [fxLayout.lt-xl], [fxLayout.gt-xs], [fxLayout.gt-sm],  [fxLayout.gt-md], [fxLayout.gt-lg]", inputs: ["fxLayout", "fxLayout.xs", "fxLayout.sm", "fxLayout.md", "fxLayout.lg", "fxLayout.xl", "fxLayout.lt-sm", "fxLayout.lt-md", "fxLayout.lt-lg", "fxLayout.lt-xl", "fxLayout.gt-xs", "fxLayout.gt-sm", "fxLayout.gt-md", "fxLayout.gt-lg"] }, { type: i5.DefaultLayoutGapDirective, selector: "  [fxLayoutGap], [fxLayoutGap.xs], [fxLayoutGap.sm], [fxLayoutGap.md],  [fxLayoutGap.lg], [fxLayoutGap.xl], [fxLayoutGap.lt-sm], [fxLayoutGap.lt-md],  [fxLayoutGap.lt-lg], [fxLayoutGap.lt-xl], [fxLayoutGap.gt-xs], [fxLayoutGap.gt-sm],  [fxLayoutGap.gt-md], [fxLayoutGap.gt-lg]", inputs: ["fxLayoutGap", "fxLayoutGap.xs", "fxLayoutGap.sm", "fxLayoutGap.md", "fxLayoutGap.lg", "fxLayoutGap.xl", "fxLayoutGap.lt-sm", "fxLayoutGap.lt-md", "fxLayoutGap.lt-lg", "fxLayoutGap.lt-xl", "fxLayoutGap.gt-xs", "fxLayoutGap.gt-sm", "fxLayoutGap.gt-md", "fxLayoutGap.gt-lg"] }], pipes: { "translate": TranslatePipe, "searchByStringProperty": SearchByStringPropertyPipe, "thumbnailUrl": ThumbnailFromUrlPipe, "date": i10.DatePipe, "duration": DurationFromSecondsPipe, "number": i10.DecimalPipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdminDashboardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-admin-dashboard', template: "<div class=\"dashboard-container\">\n\t<mat-toolbar class=\"header\">\n\t\t<span>{{ 'ADMIN.DASHBOARD' | translate }}</span>\n\t\t<div class=\"refresh-btn\">\n\t\t\t<button matSuffix mat-icon-button aria-label=\"Refresh\" (click)=\"logout()\">\n\t\t\t\t<mat-icon>logout</mat-icon>\n\t\t\t</button>\n\t\t</div>\n\t</mat-toolbar>\n\n\t<div class=\"dashboard-body\">\n\t\t<div id=\"toolbar-search\">\n\t\t\t<div class=\"search-bar\">\n\t\t\t\t<textarea\n\t\t\t\t\tid=\"search-input\"\n\t\t\t\t\tmaxlength=\"100\"\n\t\t\t\t\trows=\"4\"\n\t\t\t\t\tplaceholder=\"{{ 'ADMIN.SEARCH' | translate }}\"\n\t\t\t\t\tautocomplete=\"off\"\n\t\t\t\t\t[(ngModel)]=\"searchValue\"\n\t\t\t\t></textarea>\n\t\t\t\t<div>\n\t\t\t\t\t<button *ngIf=\"searchValue\" matSuffix mat-icon-button aria-label=\"Clear\" (click)=\"searchValue = ''\">\n\t\t\t\t\t\t<mat-icon>close</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t\t<button *ngIf=\"!searchValue\" matSuffix mat-icon-button aria-label=\"Search\">\n\t\t\t\t\t\t<mat-icon>search</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t\t<div>\n\t\t\t\t<button id=\"sort-menu-btn\" color=\"primary\" mat-flat-button [matMenuTriggerFor]=\"sortMenu\">\n\t\t\t\t\t{{ sortByLegend }}\n\t\t\t\t\t<mat-icon>arrow_drop_down</mat-icon>\n\t\t\t\t</button>\n\n\t\t\t\t<mat-menu #sortMenu=\"matMenu\">\n\t\t\t\t\t<button mat-menu-item class=\"order-select-btn\" (click)=\"sortRecordingsByDate()\">{{ 'ADMIN.DATE' | translate }}</button>\n\t\t\t\t\t<button mat-menu-item class=\"order-select-btn\" (click)=\"sortRecordingsByDuration()\">\n\t\t\t\t\t\t{{ 'ADMIN.DURATION' | translate }}\n\t\t\t\t\t</button>\n\t\t\t\t\t<button mat-menu-item class=\"order-select-btn\" (click)=\"sortRecordingsBySize()\">{{ 'ADMIN.SIZE' | translate }}</button>\n\t\t\t\t</mat-menu>\n\n\t\t\t\t<div class=\"refresh-btn\">\n\t\t\t\t\t<button matSuffix mat-icon-button aria-label=\"Refresh\" (click)=\"refreshRecordings()\">\n\t\t\t\t\t\t<mat-icon>refresh</mat-icon>\n\t\t\t\t\t</button>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\n\t\t<div *ngIf=\"!recordings || recordings.length === 0\" class=\"no-recordings-warn\">\n\t\t\t<span>{{ 'ADMIN.NO_RECORDINGS' | translate }}</span>\n\t\t</div>\n\n\t\t<div class=\"recordings-container\">\n\t\t\t<div\n\t\t\t\t*ngFor=\"\n\t\t\t\t\tlet recording of recordings\n\t\t\t\t\t\t| searchByStringProperty: { properties: ['sessionId', 'properties?.name || name'], filter: searchValue }\n\t\t\t\t\"\n\t\t\t\tclass=\"item\"\n\t\t\t>\n\t\t\t\t<mat-card class=\"recording-card\">\n\t\t\t\t\t<mat-card-content>\n\t\t\t\t\t\t<div class=\"video-div-container\">\n\t\t\t\t\t\t\t<img *ngIf=\"!!recording.url\" [src]=\"recording.url | thumbnailUrl\" />\n\t\t\t\t\t\t\t<div class=\"video-btns\">\n\t\t\t\t\t\t\t\t<button\n\t\t\t\t\t\t\t\t\t*ngIf=\"recording.status !== 'failed' && recording.status !== 'stopped'\"\n\t\t\t\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t\t\t\t(click)=\"play(recording)\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<mat-icon id=\"play\" aria-label=\"Play\" title=\"{{ 'PANEL.RECORDING.PLAY' | translate }}\"\n\t\t\t\t\t\t\t\t\t\t>play_arrow</mat-icon\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t</button>\n\n\t\t\t\t\t\t\t\t<button\n\t\t\t\t\t\t\t\t\t(click)=\"download(recording)\"\n\t\t\t\t\t\t\t\t\t*ngIf=\"!!recording.url && recording.status !== 'failed' && recording.status !== 'stopped'\"\n\t\t\t\t\t\t\t\t\tmat-icon-button\n\t\t\t\t\t\t\t\t\taria-label=\"Download\"\n\t\t\t\t\t\t\t\t\ttitle=\"{{ 'PANEL.RECORDING.DOWNLOAD' | translate }}\"\n\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t\t<mat-icon id=\"download\">download</mat-icon>\n\t\t\t\t\t\t\t\t</button>\n\t\t\t\t\t\t\t\t<button mat-icon-button class=\"delete-recording-btn\" (click)=\"deleteRecording(recording.id)\">\n\t\t\t\t\t\t\t\t\t<mat-icon id=\"delete\" aria-label=\"Delete\" title=\"{{ 'PANEL.RECORDING.DELETE' | translate }}\"\n\t\t\t\t\t\t\t\t\t\t>delete</mat-icon\n\t\t\t\t\t\t\t\t\t>\n\t\t\t\t\t\t\t\t</button>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"video-info-container\">\n\t\t\t\t\t\t\t<div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.NAME' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.properties?.name || recording.name }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.SESSION' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.sessionId }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.OUTPUT' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.properties?.outputMode || recording.outputMode }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.DATE' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.createdAt | date: 'M/d/yy, H:mm' }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.DURATION' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.duration | duration }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.SIZE' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value\">{{ recording.size / 1024 / 1024 | number: '1.1-2' }} MBs</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t<div class=\"video-div-tag\" style=\"margin-top: 11px\">\n\t\t\t\t\t\t\t\t\t<span class=\"video-card-tag\">{{ 'ADMIN.STATUS' | translate }}</span\n\t\t\t\t\t\t\t\t\t><span class=\"video-card-value status-value\" [ngClass]=\"recording.status\">{{ recording.status }}</span>\n\t\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</mat-card-content>\n\t\t\t\t</mat-card>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n\t<mat-toolbar class=\"footer\" fxLayout fxLayout.xs=\"row\" fxLayoutGap=\"2px\" id=\"footer\" role=\"heading\">\n\t\t<span>{{ 'ADMIN.POWERED_BY' | translate }}</span>\n\t\t<a href=\"https://openvidu.io/\">OpenVidu</a>\n\t</mat-toolbar>\n</div>\n", styles: [".dashboard-container{height:100%}.header{height:50px;background-color:var(--ov-secondary-color);color:var(--ov-text-color)}.dashboard-body{height:calc(100% - 75px)}#toolbar-search{width:100%;height:40px;background-color:var(--ov-light-color);padding:6px;display:flex;align-items:center}#toolbar-sort-div{display:flex;flex-direction:row;align-items:center}#sort-menu-btn{margin-left:5px;background-color:var(--ov-panel-background)}.search-bar{height:95%;width:30%;display:flex;background-color:var(--ov-panel-background);padding:0 10px;border-radius:var(--ov-panel-radius)}#search-input{width:100%;height:16px;margin:auto;background-color:transparent;display:block;border:none;padding:0;word-wrap:break-word;white-space:pre-wrap;resize:none;outline:none;box-shadow:none;font-family:Roboto,RobotoDraft,Helvetica,Arial,sans-serif}#refresh-btn{float:right}#refresh-btn mat-icon{color:inherit}.refresh-btn{position:absolute;right:0;display:inline-flex}.recordings-container{height:calc(100% - 51px);display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));overflow-y:auto;overflow-x:hidden}.recording-card{background-color:var(--ov-panel-background)}.video-div-container{position:relative;text-align:center;width:100%;height:42%;overflow:hidden;background-color:var(--ov-light-color);display:flex;justify-content:center;align-items:center}.video-div-container img{border-radius:var(--ov-video-radius);display:inline;position:relative;max-width:100%;max-height:100%}.item{flex-grow:1;margin:10px}.item+.item{margin-left:2%}.video-btns{position:absolute;transform:translate(-50%,-50%);margin-right:-50%;top:50%;left:50%;background-color:var(--ov-logo-background-color);border-radius:var(--ov-panel-radius)}.video-btns button #play{color:var(--ov-text-color)}.video-btns button #download{color:var(--ov-tertiary-color)}.video-btns button #delete{color:var(--ov-warn-color)}.video-info-container>div{width:100%;height:100%;display:table;table-layout:fixed;box-sizing:border-box;margin-top:20px}.video-div-tag:first-child{margin-top:20px}.video-div-tag{display:table-row}.video-card-tag{font-size:13px;color:var(--ov-panel-text-color)}.video-card-value{float:right;font-size:13.5px}.footer{height:25px;background-color:var(--ov-secondary-color);color:var(--ov-text-color);position:absolute;bottom:0;left:0;font-size:12px}.footer a{color:var(--ov-tertiary-color)}.no-recordings-warn{height:calc(100% - 52px);width:100%;display:table;text-align:center}::ng-deep .mat-form-field-appearance-fill .mat-form-field-flex{padding:0!important;background-color:var(--ov-light-color)!important}::ng-deep .mat-form-field-wrapper{height:100%!important}\n"] }]
        }], ctorParameters: function () { return [{ type: ActionService }, { type: RecordingService }, { type: OpenViduAngularConfigService }]; }, propDecorators: { onDeleteRecordingClicked: [{
                type: Output
            }], onRefreshRecordingsClicked: [{
                type: Output
            }], onLogoutClicked: [{
                type: Output
            }] } });

class AdminLoginComponent {
    /**
     * @internal
     */
    constructor(libService, actionService) {
        this.libService = libService;
        this.actionService = actionService;
        /**
         * Provides event notifications that fire when login button has been clicked.
         * The event will contain the password value.
         */
        this.onLoginButtonClicked = new EventEmitter();
        /**
         * @internal
         */
        this.checkingLogged = false;
        /**
         * @internal
         */
        this.showSpinner = false;
        /**
         * @internal
         */
        this.loginFormControl = new FormControl('', [Validators.required]);
        /**
         * @internal
         */
        this.matcher = new FormErrorStateMatcher();
    }
    /**
     * @internal
     */
    ngOnInit() {
        this.subscribeToAdminLoginDirectives();
    }
    /**
     * @internal
     */
    ngOnDestroy() {
        this.showSpinner = false;
        if (this.errorSub)
            this.errorSub.unsubscribe();
    }
    /**
     * @internal
     */
    login() {
        this.showSpinner = true;
        this.onLoginButtonClicked.emit(this.secret);
    }
    /**
     * @internal
     */
    submitForm() {
        if (this.loginForm.nativeElement.checkValidity()) {
            this.login();
        }
        else {
            this.submitBtn.nativeElement.click();
        }
    }
    subscribeToAdminLoginDirectives() {
        this.errorSub = this.libService.adminLoginErrorObs.subscribe((value) => {
            const errorExists = !!value;
            if (errorExists) {
                this.showSpinner = false;
                this.actionService.openDialog(value.error, value.message, true);
            }
        });
    }
}
AdminLoginComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdminLoginComponent, deps: [{ token: OpenViduAngularConfigService }, { token: ActionService }], target: i0.ɵɵFactoryTarget.Component });
AdminLoginComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "12.0.0", version: "13.0.0", type: AdminLoginComponent, selector: "ov-admin-login", outputs: { onLoginButtonClicked: "onLoginButtonClicked" }, viewQueries: [{ propertyName: "submitBtn", first: true, predicate: ["submitBtn"], descendants: true }, { propertyName: "loginForm", first: true, predicate: ["loginForm"], descendants: true, read: ElementRef }], ngImport: i0, template: "<mat-toolbar class=\"header\">\n</mat-toolbar>\n\n<div *ngIf=\"checkingLogged\" class=\"outer\">\n\t<div class=\"middle\">\n\t\t<div class=\"inner\">\n\t\t\t<mat-spinner *ngIf=\"checkingLogged\"></mat-spinner>\n\t\t</div>\n\t</div>\n</div>\n\n<mat-card *ngIf=\"!checkingLogged\">\n\t<mat-card-content>\n\t\t<form ngNativeValidate #loginForm (ngSubmit)=\"login()\">\n\t\t\t<table class=\"full-width\" cellspacing=\"0\">\n\t\t\t\t<tr>\n\t\t\t\t\t<td>\n\t\t\t\t\t\t<mat-form-field id=\"secret-field\" class=\"full-width\" appearance=\"outline\">\n\t\t\t\t\t\t\t<mat-label>{{ 'ADMIN.SECRET' | translate }}</mat-label>\n\t\t\t\t\t\t\t<input\n\t\t\t\t\t\t\t\tid=\"secret-input\"\n\t\t\t\t\t\t\t\tmatInput\n\t\t\t\t\t\t\t\t[(ngModel)]=\"secret\"\n\t\t\t\t\t\t\t\t[disabled]=\"showSpinner\"\n\t\t\t\t\t\t\t\ttype=\"password\"\n\t\t\t\t\t\t\t\tname=\"secret\"\n\t\t\t\t\t\t\t\tautocomplete=\"current-password\"\n\t\t\t\t\t\t\t\trequired\n\t\t\t\t\t\t\t/>\n\t\t\t\t\t\t\t<mat-error *ngIf=\"loginFormControl.hasError('required')\"> {{ 'ADMIN.SECRET_REQURED' | translate }} </mat-error>\n\t\t\t\t\t\t</mat-form-field>\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t\t</table>\n\t\t\t<input #submitBtn type=\"submit\" [style.display]=\"'none'\" />\n\t\t</form>\n\t\t<mat-spinner [style.display]=\"showSpinner ? 'block' : 'none'\"></mat-spinner>\n\t</mat-card-content>\n\t<mat-card-actions>\n\t\t<button mat-flat-button id=\"login-btn\" type=\"submit\" (click)=\"submitForm()\" color=\"primary\" class=\"full-width\">\n\t\t\t{{ 'ADMIN.LOGIN' | translate }}\n\t\t</button>\n\t</mat-card-actions>\n</mat-card>\n", styles: ["mat-card{max-width:220px;margin:auto;margin-top:10vh}mat-card-content{margin-bottom:8px}mat-card-actions{padding-top:0}.header{height:50px;background-color:var(--ov-secondary-color);color:var(--ov-text-color)}mat-spinner{margin:auto}.mat-card-actions{margin:0}.full-width{width:100%}.outer{display:table;position:absolute;height:100%;width:100%}.middle{display:table-cell;vertical-align:middle}.inner{margin-left:auto;margin-right:auto}#login-btn{text-transform:none;font-size:17px;width:100%}::ng-deep .mat-input-element{caret-color:#000}::ng-deep .mat-primary .mat-option.mat-selected:not(.mat-option-disabled){color:#000}::ng-deep .mat-form-field-label{color:var(--ov-panel-text-color)!important}::ng-deep .mat-form-field.mat-focused .mat-form-field-ripple{background-color:var(--ov-panel-text-color)!important}\n"], components: [{ type: i15.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { type: i10$2.MatSpinner, selector: "mat-spinner", inputs: ["color"] }, { type: i5$3.MatCard, selector: "mat-card", exportAs: ["matCard"] }, { type: i9$1.MatFormField, selector: "mat-form-field", inputs: ["color", "appearance", "hideRequiredMarker", "hintLabel", "floatLabel"], exportAs: ["matFormField"] }, { type: i3.MatButton, selector: "button[mat-button], button[mat-raised-button], button[mat-icon-button],             button[mat-fab], button[mat-mini-fab], button[mat-stroked-button],             button[mat-flat-button]", inputs: ["disabled", "disableRipple", "color"], exportAs: ["matButton"] }], directives: [{ type: i10.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { type: i5$3.MatCardContent, selector: "mat-card-content, [mat-card-content], [matCardContent]" }, { type: i9.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { type: i9.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { type: i9$1.MatLabel, selector: "mat-label" }, { type: i15$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { type: i9.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { type: i9.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { type: i9.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { type: i9.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { type: i9$1.MatError, selector: "mat-error", inputs: ["id"] }, { type: i5$3.MatCardActions, selector: "mat-card-actions", inputs: ["align"], exportAs: ["matCardActions"] }], pipes: { "translate": TranslatePipe } });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AdminLoginComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ov-admin-login', template: "<mat-toolbar class=\"header\">\n</mat-toolbar>\n\n<div *ngIf=\"checkingLogged\" class=\"outer\">\n\t<div class=\"middle\">\n\t\t<div class=\"inner\">\n\t\t\t<mat-spinner *ngIf=\"checkingLogged\"></mat-spinner>\n\t\t</div>\n\t</div>\n</div>\n\n<mat-card *ngIf=\"!checkingLogged\">\n\t<mat-card-content>\n\t\t<form ngNativeValidate #loginForm (ngSubmit)=\"login()\">\n\t\t\t<table class=\"full-width\" cellspacing=\"0\">\n\t\t\t\t<tr>\n\t\t\t\t\t<td>\n\t\t\t\t\t\t<mat-form-field id=\"secret-field\" class=\"full-width\" appearance=\"outline\">\n\t\t\t\t\t\t\t<mat-label>{{ 'ADMIN.SECRET' | translate }}</mat-label>\n\t\t\t\t\t\t\t<input\n\t\t\t\t\t\t\t\tid=\"secret-input\"\n\t\t\t\t\t\t\t\tmatInput\n\t\t\t\t\t\t\t\t[(ngModel)]=\"secret\"\n\t\t\t\t\t\t\t\t[disabled]=\"showSpinner\"\n\t\t\t\t\t\t\t\ttype=\"password\"\n\t\t\t\t\t\t\t\tname=\"secret\"\n\t\t\t\t\t\t\t\tautocomplete=\"current-password\"\n\t\t\t\t\t\t\t\trequired\n\t\t\t\t\t\t\t/>\n\t\t\t\t\t\t\t<mat-error *ngIf=\"loginFormControl.hasError('required')\"> {{ 'ADMIN.SECRET_REQURED' | translate }} </mat-error>\n\t\t\t\t\t\t</mat-form-field>\n\t\t\t\t\t</td>\n\t\t\t\t</tr>\n\t\t\t</table>\n\t\t\t<input #submitBtn type=\"submit\" [style.display]=\"'none'\" />\n\t\t</form>\n\t\t<mat-spinner [style.display]=\"showSpinner ? 'block' : 'none'\"></mat-spinner>\n\t</mat-card-content>\n\t<mat-card-actions>\n\t\t<button mat-flat-button id=\"login-btn\" type=\"submit\" (click)=\"submitForm()\" color=\"primary\" class=\"full-width\">\n\t\t\t{{ 'ADMIN.LOGIN' | translate }}\n\t\t</button>\n\t</mat-card-actions>\n</mat-card>\n", styles: ["mat-card{max-width:220px;margin:auto;margin-top:10vh}mat-card-content{margin-bottom:8px}mat-card-actions{padding-top:0}.header{height:50px;background-color:var(--ov-secondary-color);color:var(--ov-text-color)}mat-spinner{margin:auto}.mat-card-actions{margin:0}.full-width{width:100%}.outer{display:table;position:absolute;height:100%;width:100%}.middle{display:table-cell;vertical-align:middle}.inner{margin-left:auto;margin-right:auto}#login-btn{text-transform:none;font-size:17px;width:100%}::ng-deep .mat-input-element{caret-color:#000}::ng-deep .mat-primary .mat-option.mat-selected:not(.mat-option-disabled){color:#000}::ng-deep .mat-form-field-label{color:var(--ov-panel-text-color)!important}::ng-deep .mat-form-field.mat-focused .mat-form-field-ripple{background-color:var(--ov-panel-text-color)!important}\n"] }]
        }], ctorParameters: function () { return [{ type: OpenViduAngularConfigService }, { type: ActionService }]; }, propDecorators: { onLoginButtonClicked: [{
                type: Output
            }], submitBtn: [{
                type: ViewChild,
                args: ['submitBtn']
            }], loginForm: [{
                type: ViewChild,
                args: ['loginForm', { read: ElementRef }]
            }] } });
/**
 * @internal
 */
class FormErrorStateMatcher {
    isErrorState(control, form) {
        const isSubmitted = form && form.submitted;
        return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
    }
}

class AppMaterialModule {
}
AppMaterialModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AppMaterialModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
AppMaterialModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AppMaterialModule, imports: [BrowserAnimationsModule], exports: [MatButtonModule,
        MatCardModule,
        MatToolbarModule,
        MatIconModule,
        MatInputModule,
        MatFormFieldModule,
        MatDialogModule,
        MatTooltipModule,
        MatBadgeModule,
        MatGridListModule,
        MatSelectModule,
        MatOptionModule,
        MatProgressSpinnerModule,
        MatSliderModule,
        MatSidenavModule,
        MatSnackBarModule,
        FlexLayoutModule,
        MatMenuModule,
        MatDividerModule,
        MatListModule,
        MatExpansionModule,
        MatSlideToggleModule] });
AppMaterialModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AppMaterialModule, imports: [[BrowserAnimationsModule], MatButtonModule,
        MatCardModule,
        MatToolbarModule,
        MatIconModule,
        MatInputModule,
        MatFormFieldModule,
        MatDialogModule,
        MatTooltipModule,
        MatBadgeModule,
        MatGridListModule,
        MatSelectModule,
        MatOptionModule,
        MatProgressSpinnerModule,
        MatSliderModule,
        MatSidenavModule,
        MatSnackBarModule,
        FlexLayoutModule,
        MatMenuModule,
        MatDividerModule,
        MatListModule,
        MatExpansionModule,
        MatSlideToggleModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: AppMaterialModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [BrowserAnimationsModule],
                    exports: [
                        MatButtonModule,
                        MatCardModule,
                        MatToolbarModule,
                        MatIconModule,
                        MatInputModule,
                        MatFormFieldModule,
                        MatDialogModule,
                        MatTooltipModule,
                        MatBadgeModule,
                        MatGridListModule,
                        MatSelectModule,
                        MatOptionModule,
                        MatProgressSpinnerModule,
                        MatSliderModule,
                        MatSidenavModule,
                        MatSnackBarModule,
                        FlexLayoutModule,
                        MatMenuModule,
                        MatDividerModule,
                        MatListModule,
                        MatExpansionModule,
                        MatSlideToggleModule
                    ]
                }]
        }] });

const publicComponents = [
    AdminDashboardComponent,
    AdminLoginComponent,
    VideoconferenceComponent,
    ToolbarComponent,
    PanelComponent,
    ActivitiesPanelComponent,
    ParticipantsPanelComponent,
    ParticipantPanelItemComponent,
    ChatPanelComponent,
    StreamComponent,
    LayoutComponent
];
const privateComponents = [
    PreJoinComponent,
    SessionComponent,
    BackgroundEffectsPanelComponent,
    SettingsPanelComponent,
    AudioWaveComponent,
    CaptionsComponent,
    DialogTemplateComponent,
    RecordingDialogComponent,
    DeleteDialogComponent,
    AvatarProfileComponent,
    VideoComponent,
    VideoDevicesComponent,
    AudioDevicesComponent,
    NicknameInputComponent,
    LangSelectorComponent,
    RecordingActivityComponent,
    SubtitlesSettingComponent
];
class OpenViduAngularModule {
    static forRoot(config) {
        // console.log(`${library.name} config: ${environment}`);
        const libConfig = config;
        return {
            ngModule: OpenViduAngularModule,
            providers: [OpenViduAngularConfigService, { provide: 'OPENVIDU_ANGULAR_CONFIG', useValue: libConfig }]
        };
    }
}
OpenViduAngularModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
OpenViduAngularModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularModule, declarations: [AdminDashboardComponent,
        AdminLoginComponent,
        VideoconferenceComponent,
        ToolbarComponent,
        PanelComponent,
        ActivitiesPanelComponent,
        ParticipantsPanelComponent,
        ParticipantPanelItemComponent,
        ChatPanelComponent,
        StreamComponent,
        LayoutComponent, PreJoinComponent,
        SessionComponent,
        BackgroundEffectsPanelComponent,
        SettingsPanelComponent,
        AudioWaveComponent,
        CaptionsComponent,
        DialogTemplateComponent,
        RecordingDialogComponent,
        DeleteDialogComponent,
        AvatarProfileComponent,
        VideoComponent,
        VideoDevicesComponent,
        AudioDevicesComponent,
        NicknameInputComponent,
        LangSelectorComponent,
        RecordingActivityComponent,
        SubtitlesSettingComponent, LinkifyPipe,
        ParticipantStreamsPipe,
        DurationFromSecondsPipe,
        SearchByStringPropertyPipe,
        ThumbnailFromUrlPipe,
        StreamTypesEnabledPipe,
        TranslatePipe,
        CustomLayoutExtensionDirective], imports: [CommonModule,
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule, i1$3.RouterModule, AppMaterialModule,
        OpenViduAngularDirectiveModule,
        ApiDirectiveModule], exports: [AdminDashboardComponent,
        AdminLoginComponent,
        VideoconferenceComponent,
        ToolbarComponent,
        PanelComponent,
        ActivitiesPanelComponent,
        ParticipantsPanelComponent,
        ParticipantPanelItemComponent,
        ChatPanelComponent,
        StreamComponent,
        LayoutComponent, ParticipantStreamsPipe,
        DurationFromSecondsPipe,
        StreamTypesEnabledPipe,
        CommonModule,
        OpenViduAngularDirectiveModule,
        ApiDirectiveModule] });
OpenViduAngularModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularModule, providers: [
        ActionService,
        CdkOverlayContainer,
        { provide: OverlayContainer, useClass: CdkOverlayContainer },
        CustomBreakPointsProvider,
        ChatService,
        PanelService,
        DeviceService,
        DocumentService,
        LayoutService,
        LoggerService,
        PlatformService,
        ParticipantService,
        StorageService,
        TokenService,
        OpenViduService,
        RecordingService
    ], imports: [[
            CommonModule,
            HttpClientModule,
            FormsModule,
            ReactiveFormsModule,
            RouterModule.forRoot([]),
            AppMaterialModule,
            OpenViduAngularDirectiveModule,
            ApiDirectiveModule
        ], CommonModule,
        OpenViduAngularDirectiveModule,
        ApiDirectiveModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.0.0", ngImport: i0, type: OpenViduAngularModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        publicComponents,
                        privateComponents,
                        LinkifyPipe,
                        ParticipantStreamsPipe,
                        DurationFromSecondsPipe,
                        SearchByStringPropertyPipe,
                        ThumbnailFromUrlPipe,
                        StreamTypesEnabledPipe,
                        TranslatePipe,
                        CustomLayoutExtensionDirective,
                    ],
                    imports: [
                        CommonModule,
                        HttpClientModule,
                        FormsModule,
                        ReactiveFormsModule,
                        RouterModule.forRoot([]),
                        AppMaterialModule,
                        OpenViduAngularDirectiveModule,
                        ApiDirectiveModule
                    ],
                    providers: [
                        ActionService,
                        CdkOverlayContainer,
                        { provide: OverlayContainer, useClass: CdkOverlayContainer },
                        CustomBreakPointsProvider,
                        ChatService,
                        PanelService,
                        DeviceService,
                        DocumentService,
                        LayoutService,
                        LoggerService,
                        PlatformService,
                        ParticipantService,
                        StorageService,
                        TokenService,
                        OpenViduService,
                        RecordingService
                    ],
                    exports: [
                        publicComponents,
                        ParticipantStreamsPipe,
                        DurationFromSecondsPipe,
                        StreamTypesEnabledPipe,
                        CommonModule,
                        OpenViduAngularDirectiveModule,
                        ApiDirectiveModule
                    ],
                    entryComponents: [DialogTemplateComponent, RecordingDialogComponent, DeleteDialogComponent]
                }]
        }] });

/*
 * Public API Surface of openvidu-components-angular
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ActionService, ActivitiesPanelComponent, ActivitiesPanelDirective, ActivitiesPanelRecordingActivityDirective, AdditionalPanelsDirective, AdminDashboardComponent, AdminLoginComponent, AdminLoginDirective, AdminRecordingsListDirective, ApiDirectiveModule, AudioMutedDirective, BackgroundEffectsPanelDirective, ChatPanelComponent, ChatPanelDirective, ChatService, DurationFromSecondsPipe, FormErrorStateMatcher, LangDirective, LayoutComponent, LayoutDirective, LayoutService, LogoDirective, MinimalDirective, OpenViduAngularDirectiveModule, OpenViduAngularModule, OpenViduRole, OpenViduService, PanelComponent, PanelDirective, PanelService, PanelSettingsOptions, PanelType, ParticipantAbstractModel, ParticipantModel, ParticipantNameDirective, ParticipantPanelItemComponent, ParticipantPanelItemDirective, ParticipantPanelItemElementsDirective, ParticipantPanelItemMuteButtonDirective, ParticipantService, ParticipantStreamsPipe, ParticipantsPanelComponent, ParticipantsPanelDirective, PrejoinDirective, RecordingActivityRecordingErrorDirective, RecordingActivityRecordingsListDirective, RecordingService, RecordingStatus, ScreenType, SearchByStringPropertyPipe, Signal, StreamComponent, StreamDirective, StreamDisplayAudioDetectionDirective, StreamDisplayParticipantNameDirective, StreamSettingsButtonDirective, StreamTypesEnabledPipe, ThumbnailFromUrlPipe, ToolbarActivitiesPanelButtonDirective, ToolbarAdditionalButtonsDirective, ToolbarAdditionalPanelButtonsDirective, ToolbarBackgroundEffectsButtonDirective, ToolbarCaptionsButtonDirective, ToolbarChatPanelButtonDirective, ToolbarComponent, ToolbarDirective, ToolbarDisplayLogoDirective, ToolbarDisplaySessionNameDirective, ToolbarFullscreenButtonDirective, ToolbarLeaveButtonDirective, ToolbarParticipantsPanelButtonDirective, ToolbarRecordingButtonDirective, ToolbarScreenshareButtonDirective, ToolbarSettingsButtonDirective, VideoMutedDirective, VideoType, VideoconferenceComponent };
